setwd("E:/Santander_CAR/Yao/MMA_Rebuild/Wealth Indicator Model")
.libPaths("E:/Santander_CAR/R/win-library/3.3")
.libPaths()
library(car)
library(glmnet)
library(Boruta)
library(MASS)
library(caret)
library(gbm)
library(energy)
library(nortest)
library(dplyr)
library(xgboost)
variable_type=c("character",rep("numeric",36))
train_data_sub=read.csv("train_data_new_deposits.csv",colClasses = variable_type, header=TRUE)
train_data_outlier<-train_data_sub[train_data_sub$deposits_1<quantile(train_data_sub$deposits_1,0.99),]
#box cox transformation
nn<-train_data_outlier$deposits_1+1
bc<-boxcox(nn~1,lambda=seq(-3,3,0.1))
cc<-data.frame(bc$x,bc$y)
cc2<-cc[with(cc,order(-bc$y)),]
lambda<-cc2[1,"bc.x"]
save(lambda,file="best box cox transform parameter.RData")
train_data_outlier$dep_trans<-(nn^lambda-1)/lambda
densityPlot(train_data_outlier$dep_trans)
qqnorm(dep_trans)
qqline(dep_trans)

#variable creation
train_data_outlier$per_hhinc200k<-train_data_outlier$HINC200_CY/train_data_outlier$TOTHH_CY
train_data_outlier$per_hhinc200k[is.na(train_data_outlier$per_hhinc200k)]<-0
train_data_outlier$per_homeval500k<-(train_data_outlier$VAL500K_CY+train_data_outlier$VAL750K_CY+train_data_outlier$VAL1M_CY)/train_data_outlier$TOTHH_CY
train_data_outlier$per_homeval500k[is.na(train_data_outlier$per_homeval500k)]<-0
train_data_outlier$per_nw500k<-train_data_outlier$NW500_CY/train_data_outlier$TOTHH_CY
train_data_outlier$per_nw500k[is.na(train_data_outlier$per_nw500k)]<-0
train_data_outlier$per_disp150k<-(train_data_outlier$DI150_CY+train_data_outlier$DI200_CY)/train_data_outlier$TOTHH_CY
train_data_outlier$per_disp150k[is.na(train_data_outlier$per_disp150k)]<-0


var_select1<-c("per_homeval500k","per_nw500k","per_hhinc200k","per_disp150k","X14060_I","X14064_I", "X14058_I", "AP001294_1",
               "nP005196", "N7606", "n8642","nflc1882",  "AP001294_5","MP10011a_I", "MP10086a_I","n8440", "n8621_6",
               "MP10101a_I", "n7650","nP004975", "nflcf998", "n8608","AVGHHSZ_CY",
               "MP10082a_I", "n7848","n9350")
var_select2<-c("per_homeval500k","per_nw500k","per_hhinc200k","per_disp150k","X14060_I","X14064_I", "X14058_I", 
               "nP005196", "n8642","nflc1882",  "AP001294_1","AP001294_5","MP10011a_I", "MP10086a_I","n8440", "n8621_6",
               "MP10101a_I", "nP004975", "n8608", "MP10082a_I","n9350")

plot_uni(train_data_outlier,"nP004975",10)
#try tunning parameter2
dtrain<-xgb.DMatrix(data = data.matrix(train_data_outlier[,var_select1]), label = train_data_outlier$dep_trans)
best_param = list()
best_seednumber = 1234
best_logloss = Inf
best_logloss_index = 0

for (iter in 1:10) {
  param <- list( booster = "gbtree",objective = "reg:linear",
                 max_depth = sample(4:7, 1),
                 eta = runif(1, .01, 0.3),
                 gamma = runif(1, 0.0, 0.2), 
                 subsample = runif(1, .6, .9),
                 colsample_bytree = runif(1, .5, .8), 
                 min_child_weight = sample(1:40, 1),
                 max_delta_step = sample(1:10, 1)
  )
  cv.nround = 200
  cv.nfold = 4
  seed.number = sample.int(10000, 1)[[1]]
  set.seed(seed.number)
  mdcv <- xgb.cv( data=dtrain,params = param, 
                  nfold=cv.nfold, nrounds=cv.nround,
                  verbose = T, early_stopping_rounds=8, maximize=FALSE,nthread=6)
  
  min_logloss = min(mdcv$evaluation_log[,test_error_mean])
  min_logloss_index = which.min(mdcv$evaluation_log[,test_error_mean])
  
  if (min_logloss < best_logloss) {
    best_logloss = min_logloss
    best_logloss_index = min_logloss_index
    best_seednumber = seed.number
    best_param = param
  }
}

nround = best_logloss_index
set.seed(best_seednumber)
md_newdep <- xgboost(data= dtrain,  params=best_param, nrounds=nround)
xgb.pred <- predict(md_newdep, data.matrix(train_data_outlier[,var_select1]))
save(md_newdep,file="best xgboost var2 with new deposits.RData")
postResample(xgb.pred, train_data_outlier$dep_trans)
pp<-((xgb.pred*lambda+1)^(1/lambda)-1)
Train_RSq <- (cor(pp, train_data_outlier$deposits_1))^2
Train_RSq
train_data_outlier$pred<-pp
train_data_outlier$pred_trans<-xgb.pred
mat <- xgb.importance (feature_names = colnames(train_data_outlier[,var_select1]),model = md_newdep)
xgb.plot.importance (importance_matrix = mat[1:20]) 


##test validation
variable_type=c("character",rep("numeric",36))
test_data=read.csv("test_data_new_deposits.csv",colClasses = variable_type, header=TRUE)
validation_data=read.csv("validation_data_new_deposits.csv",colClasses = variable_type, header=TRUE)
test_data$dep_trans<-((test_data$deposits_1+1)^lambda-1)/lambda
validation_data$dep_trans<-((validation_data$deposits_1+1)^lambda-1)/lambda

test_data$per_hhinc200k<-test_data$HINC200_CY/test_data$TOTHH_CY
test_data$per_hhinc200k[is.na(test_data$per_hhinc200k)]<-0
test_data$per_homeval500k<-(test_data$VAL500K_CY+test_data$VAL750K_CY+test_data$VAL1M_CY)/test_data$TOTHH_CY
test_data$per_homeval500k[is.na(test_data$per_homeval500k)]<-0
test_data$per_nw500k<-test_data$NW500_CY/test_data$TOTHH_CY
test_data$per_nw500k[is.na(test_data$per_nw500k)]<-0
test_data$per_disp150k<-(test_data$DI150_CY+test_data$DI200_CY)/test_data$TOTHH_CY
test_data$per_disp150k[is.na(test_data$per_disp150k)]<-0


validation_data$per_hhinc200k<-validation_data$HINC200_CY/validation_data$TOTHH_CY
validation_data$per_hhinc200k[is.na(validation_data$per_hhinc200k)]<-0
validation_data$per_homeval500k<-(validation_data$VAL500K_CY+validation_data$VAL750K_CY+validation_data$VAL1M_CY)/validation_data$TOTHH_CY
validation_data$per_homeval500k[is.na(validation_data$per_homeval500k)]<-0
validation_data$per_nw500k<-validation_data$NW500_CY/validation_data$TOTHH_CY
validation_data$per_nw500k[is.na(validation_data$per_nw500k)]<-0
validation_data$per_disp150k<-(validation_data$DI150_CY+validation_data$DI200_CY)/validation_data$TOTHH_CY
validation_data$per_disp150k[is.na(validation_data$per_disp150k)]<-0

test.pred <- predict(md_newdep, data.matrix(test_data[,var_select1]))
postResample(test.pred, test_data$dep_trans)
test.pp<-((test.pred*lambda+1)^(1/lambda)-1)
test_data$pred<-test.pp
test_data$pred_trans<-test.pred
Test_RSq <- (cor(test.pp, test_data$deposits_1))^2
Test_RSq


validation.pred <- predict(md_newdep, data.matrix(validation_data[,var_select1]))
valid.pp<-((validation.pred*lambda+1)^(1/lambda)-1)
validation_data$pred<-valid.pp
validation_data$pred_trans<-validation.pred
postResample(validation.pred, validation_data$dep_trans)
valid_RSq <- (cor(valid.pp, validation_data$deposits))^2
valid_RSq


## plot univariate analysis
plot_uni<-function(try_outlier_r3,a,d)
{
  uni_analysis<-try_outlier_r3[,c("deposits",a)]
  if(length(unique(train_data_outlier[,a]))==2){uni_analysis$decile<-uni_analysis[,a]}
  else { uni_analysis$decile<-ntile(uni_analysis[,a],d)}
  uni_analysis_d<-aggregate(uni_analysis$deposits, by=list(Category=uni_analysis$decile), FUN=mean)
  uni_analysis_x<-aggregate(uni_analysis[,a], by=list(Category=uni_analysis$decile), FUN=mean)
  plot(uni_analysis_x$x,uni_analysis_d$x)
  lines(uni_analysis_x$x,uni_analysis_d$x,col="red")
}
plot_uni(train_data_outlier,"AVGHHSZ_CY")

##MaY CD File validation
variable_type=c("character",rep("numeric",38))
maycd_data=read.csv("maycd_file_new_deposits.csv",colClasses = variable_type, header=TRUE)
maycd_data$dep_trans<-((maycd_data$deposits_1+1)^lambda-1)/lambda

maycd_data$per_hhinc200k<-maycd_data$HINC200_CY/maycd_data$TOTHH_CY
maycd_data$per_hhinc200k[is.na(maycd_data$per_hhinc200k)]<-0
maycd_data$per_homeval500k<-(maycd_data$VAL500K_CY+maycd_data$VAL750K_CY+maycd_data$VAL1M_CY)/maycd_data$TOTHH_CY
maycd_data$per_homeval500k[is.na(maycd_data$per_homeval500k)]<-0
maycd_data$per_nw500k<-maycd_data$NW500_CY/maycd_data$TOTHH_CY
maycd_data$per_nw500k[is.na(maycd_data$per_nw500k)]<-0
maycd_data$per_disp150k<-(maycd_data$DI150_CY+maycd_data$DI200_CY)/maycd_data$TOTHH_CY
maycd_data$per_disp150k[is.na(maycd_data$per_disp150k)]<-0


maycd.pred <- predict(md_newdep, data.matrix(maycd_data[,var_select1]))
postResample(maycd.pred, maycd_data$dep_trans)
maycd.pp<-((maycd.pred*lambda+1)^(1/lambda)-1)
Test_RSq <- (cor(maycd.pp, maycd_data$deposits_1))^2
Test_RSq
maycd_data$pred_trans<-maycd.pred
maycd_data$pred<-maycd.pp

###analysis

train_data_outlier$decile<-11-ntile(train_data_outlier[,"pred_trans"],10)
analysis_1<-aggregate(train_data_outlier$deposits_1, by=list(Category=train_data_outlier$decile), FUN=mean)
analysis_2<-aggregate(train_data_outlier$dep_trans, by=list(Category=train_data_outlier$decile), FUN=mean)
analysis_3<-aggregate(train_data_outlier$pred, by=list(Category=train_data_outlier$decile), FUN=mean)
analysis_4<-aggregate(train_data_outlier$pred_trans, by=list(Category=train_data_outlier$decile), FUN=mean)
train_data_outlier$ixi_filter[train_data_outlier$deposits_1>10000]<-1
train_data_outlier$ixi_filter[train_data_outlier$deposits_1<=10000]<-0
analysis_5<-aggregate(train_data_outlier$ixi_filter, by=list(Category=train_data_outlier$decile), FUN=mean)
max(train_data_outlier$pred[train_data_outlier$decile==10])
min(train_data_outlier$pred[train_data_outlier$decile==9])
train_data_outlier$pred_filter[train_data_outlier$pred>20000]<-1
train_data_outlier$pred_filter[train_data_outlier$pred<=20000]<-0
table(train_data_outlier$pred_filter,train_data_outlier$ixi_filter)


test_data$decile<-11-ntile(test_data[,"pred_trans"],10)
test_analysis_1<-aggregate(test_data$deposits_1, by=list(Category=test_data$decile), FUN=mean)
test_analysis_2<-aggregate(test_data$dep_trans, by=list(Category=test_data$decile), FUN=mean)
test_analysis_3<-aggregate(test_data$pred, by=list(Category=test_data$decile), FUN=mean)
test_analysis_4<-aggregate(test_data$pred_trans, by=list(Category=test_data$decile), FUN=mean)
test_data$ixi_filter[test_data$deposits_1>10000]<-1
test_data$ixi_filter[test_data$deposits_1<=10000]<-0
test_analysis_5<-aggregate(test_data$ixi_filter, by=list(Category=test_data$decile), FUN=mean)
max(test_data$pred[test_data$decile==10])
min(test_data$pred[test_data$decile==9])
test_data$pred_filter[test_data$pred>20000]<-1
test_data$pred_filter[test_data$pred<=20000]<-0
table(test_data$pred_filter,test_data$ixi_filter)

validation_data$decile<-11-ntile(validation_data[,"pred_trans"],10)
val_analysis_1<-aggregate(validation_data$deposits_1, by=list(Category=validation_data$decile), FUN=mean)
val_analysis_2<-aggregate(validation_data$dep_trans, by=list(Category=validation_data$decile), FUN=mean)
val_analysis_3<-aggregate(validation_data$pred, by=list(Category=validation_data$decile), FUN=mean)
val_analysis_4<-aggregate(validation_data$pred_trans, by=list(Category=validation_data$decile), FUN=mean)
validation_data$ixi_filter[validation_data$deposits_1>10000]<-1
validation_data$ixi_filter[validation_data$deposits_1<=10000]<-0
val_analysis_5<-aggregate(validation_data$ixi_filter, by=list(Category=validation_data$decile), FUN=mean)
max(validation_data$pred[validation_data$decile==10])
min(validation_data$pred[validation_data$decile==9])
validation_data$pred_filter[validation_data$pred>20000]<-1
validation_data$pred_filter[validation_data$pred<=20000]<-0
table(validation_data$pred_filter,validation_data$ixi_filter)

maycd_data$decile<-11-ntile(maycd_data[,"pred"],10)
table(maycd_data$decile)
maycd_analysis_1<-aggregate(maycd_data$deposits_1, by=list(Category=maycd_data$decile), FUN=mean)
maycd_analysis_2<-aggregate(maycd_data$dep_trans, by=list(Category=maycd_data$decile), FUN=mean)
maycd_analysis_3<-aggregate(maycd_data$pred, by=list(Category=maycd_data$decile), FUN=mean)
maycd_analysis_4<-aggregate(maycd_data$pred_trans, by=list(Category=maycd_data$decile), FUN=mean)
maycd_data$ixi_filter[maycd_data$deposits_1>10000]<-1
maycd_data$ixi_filter[maycd_data$deposits_1<=10000]<-0
maycd_analysis_5<-aggregate(maycd_data$ixi_filter, by=list(Category=maycd_data$decile), FUN=mean)
max(maycd_data$pred[maycd_data$decile==10])
min(maycd_data$pred[maycd_data$decile==9])
maycd_data$pred_filter[maycd_data$pred>20000]<-1
maycd_data$pred_filter[maycd_data$pred<=20000]<-0
table(maycd_data$pred_filter,maycd_data$ixi_filter)

maycd_analysis_6<-aggregate(maycd_data$filter, by=list(Category=maycd_data$decile), FUN=sum)
maycd_analysis_6
table(maycd_data$pred_filter,maycd_data$filter)
max(maycd_data$pred[maycd_data$decile==8])
maycd_data$pred_filter[maycd_data$pred>70000]<-1
maycd_data$pred_filter[maycd_data$pred<=70000]<-0
table(maycd_data$pred_filter,maycd_data$filter)

##fmcg vs ixi
maycd_data$ixi_decile<-11-ntile(maycd_data[,"deposits_1"],10)
ixi_analysis_1<-aggregate(maycd_data$filter, by=list(Category=maycd_data$ixi_decile), FUN=mean)
ixi_analysis_1
max(maycd_data$deposits_1[maycd_data$ixi_decile==8])
maycd_data$ff_filter[maycd_data$deposits_1>70000]<-1
maycd_data$ff_filter[maycd_data$deposits_1<=70000]<-0
table(maycd_data$ff_filter,maycd_data$filter)
##score prospect
variable_type=c("character",rep("numeric",11),"character",rep("numeric",64))
prosp_data=read.csv("CDMMA_PROSP_V2.csv",colClasses = variable_type, header=TRUE)
head(prosp_data)
load("best box cox transform parameter.RData")
prosp_data$per_hhinc200k<-prosp_data$HINC200_CY/prosp_data$TOTHH_CY
prosp_data$per_hhinc200k[is.na(prosp_data$per_hhinc200k)]<-0
prosp_data$per_homeval500k<-(prosp_data$VAL500K_CY+prosp_data$VAL750K_CY+prosp_data$VAL1M_CY)/prosp_data$TOTHH_CY
prosp_data$per_homeval500k[is.na(prosp_data$per_homeval500k)]<-0
prosp_data$per_nw500k<-prosp_data$NW500_CY/prosp_data$TOTHH_CY
prosp_data$per_nw500k[is.na(prosp_data$per_nw500k)]<-0
prosp_data$per_disp150k<-(prosp_data$DI150_CY+prosp_data$DI200_CY)/prosp_data$TOTHH_CY
prosp_data$per_disp150k[is.na(prosp_data$per_disp150k)]<-0
load("best xgboost var2 with new deposits.RData")
var_select1<-c("per_homeval500k","per_nw500k","per_hhinc200k","per_disp150k","X14060_I","X14064_I", "X14058_I", "AP001294_1",
               "nP005196", "N7606", "n8642","nflc1882",  "AP001294_5","MP10011a_I", "MP10086a_I","n8440", "n8621_6",
               "MP10101a_I", "n7650","nP004975", "nflcf998", "n8608","AVGHHSZ_CY",
               "MP10082a_I", "n7848","n9350")
prosp.pred <- predict(md_newdep, data.matrix(prosp_data[,var_select1]))
prosp.pp<-((prosp.pred*lambda+1)^(1/lambda)-1)
summary(prosp.pp)
prosp_data$pred<-prosp.pp
prosp_data$pred_trans<-prosp.pred

##output
write.csv(train_data_outlier[,c("ExperianCustomerID",var_select1,"deposits_1","deposits","dep_trans","pred","pred_trans","decile")],file="score_train_data_deposits.csv")
write.csv(test_data[,c("ExperianCustomerID",var_select1,"deposits_1","deposits","dep_trans","pred","pred_trans","decile")],file="score_test_data_deposits.csv")
write.csv(validation_data[,c("ExperianCustomerID",var_select1,"deposits_1","deposits","dep_trans","pred","pred_trans","decile")],file="score_validation_data_deposits.csv")
write.csv(maycd_data[,c("ExperianCustomerId",var_select1,"deposits_1","dep_trans","pred","pred_trans","decile","filter")],file="score_maycd_data_deposits.csv")
write.csv(prosp_data[,c("AbilitecConsumer_Link",var_select1,"pred","pred_trans")],file="score_prospect_data_deposits.csv")
## read in
variable_type=c("character","character",rep("numeric",32))
validation=read.csv("score_validation_data_deposits.csv",colClasses = variable_type, header=TRUE)
validation$f10k[validation$deposits_1<45000]<-0
validation$f10k[validation$deposits_1>=45000]<-1
aaa<-aggregate(validation$pred_trans, by=list(Category=validation$decile), FUN=mean)
bbb<-aggregate(validation$pred_trans, by=list(Category=validation$decile), FUN=sd)
ub<-aaa$x+2.8*bbb$x
lb<-aaa$x-2.8*bbb$x
aaa1<-((aaa*lambda+1)^(1/lambda)-1)
ub_1<-((ub*lambda+1)^(1/lambda)-1)
lb_1<-((lb*lambda+1)^(1/lambda)-1)

plot(density(p2$pred),xlim=range(c(0,600000)),col="red",lwd=2)
lines(density(p1$pred),col="grey",lwd=2)
lines(density(p3),lty=2,lwd=2)

for_bp<-validation
aaa<-aggregate(for_bp$dep_trans, by=list(Category=for_bp$decile), FUN=median)
aaa1<-((aaa*lambda+1)^(1/lambda)-1)
boxplot(pred_trans~decile,data=for_bp)
lines(aaa,col="red")

for_bp<-validation
aaa<-aggregate(for_bp$dep_trans, by=list(Category=for_bp$decile), FUN=median)
aaa1<-((aaa*lambda+1)^(1/lambda)-1)
boxplot(pred~decile,data=for_bp)
lines(aaa1,col="red")

