import pandas as pd
from pandasql import sqldf
#Read the first tab from excel
customer = pd.read_excel("/Interview Data APM L1-L4.xlsx",sheetname='Customer Overall Data',header=None)
new_header = customer.iloc[1402] #grab the last row for the header
customer = customer[:1402] #take the data less the header row
customer.columns = new_header  #update the header using last row
# standarize the column names: remove space and convert to lower case
customer.columns = customer.columns.str.strip().str.lower().str.replace(' ', '_')  

###################################################
############### Acquisition Analysis ##############
###################################################
#Read Cust funnel & spendthe from excel
funnel_spend = pd.read_excel("/Interview Data APM L1-L4.xlsx",sheetname='Cust funnel & spend by class')
# standarize the column names: remove space and convert to lower case
funnel_spend.columns = funnel_spend.columns.str.strip().str.lower().str.replace(' ', '_') 
#Calculate total revenue generated from each customer
customer_revenue = funnel_spend.groupby(['customer_id'])['revenue_generated'].sum()
customer_revenue = pd.DataFrame({'customer_id':customer_revenue.index, 'revenue_generated':customer_revenue.values})

#merge acquisition table with funnal data to get total revenue generated from each customer
customer_revenue_merge = customer.merge(customer_revenue, left_on='customer_id', right_on='customer_id')


###################################################
############### Time delay Analysis ###############
###################################################
#Calculate earlist skus view for each customer
customer_views_purchase = funnel_spend.groupby(['customer_id'])['revenue_generated'].sum()
customer_revenue = pd.DataFrame({'customer_id':customer_revenue.index, 'revenue_generated':customer_revenue.values})

###################################################################
############### Conversion funnel Analysis: customer level ########
###################################################################
customer_views_purchase = sqldf("""
                            select customer_id, sum(skus_viewed) as view, sum(skus_added_to_cart) as cart, sum(skus_purchased) as buy
                            from funnel_spend
                            group by customer_id;            
                            """)
customer_total_funnal = customer.merge(customer_views_purchase, left_on='customer_id', right_on='customer_id')
customer_total_funnal.astype(bool).sum(axis=0)
#customer_id            1402
#acquisition_date       1402
#acquisition_channel    1402
#acquisition_device     1402
#view                   1303
#cart                    569
#buy                     313
customer_total_funnal[customer_total_funnal['acquisition_device'] == 'Desktop'].astype(bool).sum(axis=0)
customer_total_funnal[customer_total_funnal['acquisition_device'] == 'Phone'].astype(bool).sum(axis=0)
customer_total_funnal[customer_total_funnal['acquisition_device'] == 'Tablet'].astype(bool).sum(axis=0)

customer_total_funnal[customer_total_funnal['acquisition_channel'] == 'Search - Paid'].astype(bool).sum(axis=0)
customer_total_funnal[customer_total_funnal['acquisition_channel'] == 'Search - Organic'].astype(bool).sum(axis=0)
customer_total_funnal[customer_total_funnal['acquisition_channel'] == 'Display - Acquisition'].astype(bool).sum(axis=0)
customer_total_funnal[customer_total_funnal['acquisition_channel'] == 'Social - Paid'].astype(bool).sum(axis=0)
customer_total_funnal[customer_total_funnal['acquisition_channel'] == 'Comparison Shopping'].astype(bool).sum(axis=0)

###################################################################
############### Conversion funnel Analysis: all view level ########
###################################################################
#merge  funnal table with acquisition data to get Acquisition info for each customer
funnel_spend_merge = funnel_spend.merge(customer, left_on='customer_id', right_on='customer_id')

# first look at overall situation from 2016 to 2018

#get funnel segment by product class
funnel_spend_class = funnel_spend_merge.groupby(['class_name'])[['skus_viewed','skus_added_to_cart','skus_purchased','revenue_generated']].sum()

#get funnel segment by acquisition_channel
funnel_spend_channel = funnel_spend_merge.groupby(['acquisition_channel'])[['skus_viewed','skus_added_to_cart','skus_purchased','revenue_generated']].sum()

#get funnel segment by product class
funnel_spend_device = funnel_spend_merge.groupby(['acquisition_device'])[['skus_viewed','skus_added_to_cart','skus_purchased','revenue_generated']].sum()

# Then look at the trend for tha past three years
funnel_spend_merge['Q'] = (funnel_spend_merge['month'] - 1) // 3 + 1
funnel_spend_merge['YYYYQQ'] = funnel_spend_merge['year'].map(str)  + 'Q' + funnel_spend_merge['Q'].map(str)

#get funnel segment by product class
funnel_spend_class_trend = funnel_spend_merge.groupby(['class_name','YYYYQQ'])[['skus_viewed','skus_added_to_cart','skus_purchased','revenue_generated']].sum()
funnel_spend_class_trend_new = funnel_spend_class_trend.reset_index()

#get funnel segment by channel 
funnel_spend_chennel_trend = funnel_spend_merge.groupby(['acquisition_channel','YYYYQQ'])[['skus_viewed','skus_added_to_cart','skus_purchased','revenue_generated']].sum()
funnel_spend_chennel_trend = funnel_spend_chennel_trend.reset_index()

#get funnel segment by device 
funnel_spend_device_trend = funnel_spend_merge.groupby(['acquisition_device','YYYYQQ'])[['skus_viewed','skus_added_to_cart','skus_purchased','revenue_generated']].sum()
funnel_spend_device_trend = funnel_spend_device_trend.reset_index()


# clean up the column name: from 2 layer to 1
#funnel_spend_class_trend.columns = ["_".join(x) for x in funnel_spend_class_trend.columns.ravel()]

