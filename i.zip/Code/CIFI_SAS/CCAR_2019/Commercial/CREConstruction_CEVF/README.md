CCAR IMPLEMENTATION FRAMEWORK

COMMERCIAL

    -CNI
    -CRE
    -CRE Construction_CEVF_EJM
    -GCB
    -Utilities

RETAIL

    -EJM
    -Residential
    -Streamlined
    -Utilities

LIST OF SAS PROGRAMS AND THEIR FUNCTIONALITY

The production code of all commercial EJMs and models are encapsulated in the COMMERCIAL folder, while the code for all Retail EJMs and models are encapsulated in the RETAIL folder. 

The structure of the code is as follows:

- "portfolio"_config.sas: this program contains the configuration and mapping functions specific to the model.
- "portfolio"_macro.sas: this program contains individual fucntions/macros which contain the main model-regressions, transition matrices, etc., which produce the final PD, LGD and EAD rates.
- "portfolio"_execute.sas: this program contains the main execution function which is set up to call upon the functions in portfolio_config and portfolio_macro which generate the final PD, LGD and EAD output.
- config.sas : this program is common to all commercial models, and contains SAS credentials used to access RFO in order to fetch data and macrovariables.
- masterdataset.sas: this program contains the fucntion used to fecth the snapshot data from RFO. The program also aggregates the utilization level data to facility level.
- macrovariable.sas: this program contains functions which apply transfromations such as change, growth, lag, log, etc., to the raw macro series from RFO. 
- contributorfile.sas: this program presents PD, LGD and EAD rates in a standard contributor file format which is passed on to the SAS forecasting engine for the CCAR balance walk.
- cf_checker.sas: this program runs checks on the contributor files in order to ensure that the ouput is error free. 
