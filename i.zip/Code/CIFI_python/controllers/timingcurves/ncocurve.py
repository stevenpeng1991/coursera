#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
SAMPLE USE

nco_tc_instance_ICP_Adverse = NCOTimingCurve(
    as_of_date=datetime.datetime(2016,6,30), 
    scenario='ICP_Adverse', 
    forecast_periods=42, 
    historical_nco_months=80,
    auto_gen = True
)
nco_tc_instance_ICP_Adverse.generateNCOTimingCurveCF()
nco_tc_instance_ICP_Adverse.exportCFData(output_file_path='I:/CRMPO/CCAR/3Q16/ICAAP/CONTRIBUTOR_FILES/Wholesale/NETCHARGEOFFCURVE_MC_Base_SB_COMM_LOSS.csv')

# ---------------------------------------------

nco_tc_instance_MC_Base = NCOTimingCurve(
    as_of_date=datetime.datetime(2016,6,30), 
    scenario='MC_Base', 
    forecast_periods=27, 
    historical_nco_months=80,
    auto_gen = True
)
nco_tc_instance_MC_Base.generateNCOTimingCurveCF()
nco_tc_instance_MC_Base.exportCFData(output_file_path='I:/CRMPO/CCAR/2Q16/Wholesale/MC_Base/NETCHARGEOFFCURVE_MC_Base_SB_COMM_LOSS.csv')

# ----------------------------------------------

nco_tc_instance_MC_Adverse = NCOTimingCurve(
    as_of_date=datetime.datetime(2016,6,30), 
    scenario='MC_Adverse', 
    forecast_periods=27, 
    historical_nco_months=80,
    auto_gen = True
)
nco_tc_instance_MC_Adverse.generateNCOTimingCurveCF()
nco_tc_instance_MC_Adverse.exportCFData(output_file_path='I:/CRMPO/CCAR/2Q16/Wholesale/MC_Adverse/NETCHARGEOFFCURVE_MC_Adverse_SB_COMM_LOSS.csv')

# ----------------------------------------------

nco_tc_instance_MC_SA = NCOTimingCurve(
    as_of_date=datetime.datetime(2016,6,30), 
    scenario='MC_SA', 
    forecast_periods=27, 
    historical_nco_months=80,
    auto_gen = True
)
nco_tc_instance_MC_SA.generateNCOTimingCurveCF()
nco_tc_instance_MC_SA.exportCFData(output_file_path='I:/CRMPO/CCAR/2Q16/Wholesale/MC_SA/NETCHARGEOFFCURVE_MC_SA_SB_COMM_LOSS.csv')



# ----------------------------------------------



nco_tc_instance_MC_SA = NCOTimingCurve(
    as_of_date=datetime.datetime(2016,6,30),
    scenario='MC_SA',
    forecast_periods=27,
    historical_nco_months=48,
    auto_gen = True
)


# ------------------------------------------------


nco_cf = nco_tc_instance.getNCOCF()
nco_cf.plotCFModelSegment({
    'MC_Base':{
        'NETCHARGEOFFCURVE_1':['None'], 
        'NETCHARGEOFFCURVE_3':['.'], 
        'NETCHARGEOFFCURVE_5':['.']    
    }
}, show_plot=True)

"""
import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import odbc
import pandas as pd
import numpy as np
import warnings
import datetime
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.contributorfile.contributorfile import ContributorFile


class NCOTimingCurve:
    """
    This class defines a contributor file generator for non-model approaches or 
    assumptions.
    ---------------------------------------------------------------------------
    """
    # Properties
    __as_of_date = None
    __scenario = None
    __forecast_periods = None
    __historical_nco_months = None
    __ODBC_source = None
    __rate_name = None
    __rate_type = None
    __transformation = None
    __period_lag = None
    __header_names = None
    __NCO_rates = None
    __NCO_contributor_file = None
    __segmentation_dictionary = None

    def __init__(
        self,
        as_of_date,
        scenario,
        auto_gen = True,
        forecast_periods = 27,
        historical_nco_months = 80, 
        ODBC_source = 'CCMIS Datamart',
        rate_name = 'NETCHARGEOFFCURVE',
        rate_type = '4',
        transformation = 'No Transformation',
        period_lag = '0',
        header_names=[
            'Scenario',
            'ModelSegment',
            'PeriodDate',
            'Vintage',
            'RateType',
            'FeesAndExpensesLineItem',
            'AssociatedG_L_Item',
            'Transformation',
            'PeriodLag',
            'RateName',
            'ModelOutputRate',
            'UncertaintyAdjustmentRate',
            'MgmtAdjustmentRate',
            'IdiosyncraticRate1',
            'IdiosyncraticRate2',
            'IdiosyncraticRate3',
            'IdiosyncraticRate4',
            'IdiosyncraticRate5',
            'Adjustment_Overlay_Justification'
        ]
    ):
        # Assign to class properties
        if isinstance(as_of_date, datetime.datetime):
            self.__as_of_date = as_of_date
        else:
            raise TypeError('Wrong input as_of_date type. Use datetime.datetime instance.')
        
        if isinstance(scenario, str):
            self.__scenario = scenario
        else:
            raise TypeError('Wrong input scenario type. Use str instance.')
            
        if isinstance(forecast_periods, (int, np.int, np.int0, np.int8, 
                                            np.int16, np.int32, np.int64)):
            self.__forecast_periods = forecast_periods
        else:
            raise TypeError('Wrong input forecast_periods type. Use int-like instance.')
            
        if isinstance(historical_nco_months, (int, np.int, np.int0, np.int8, 
                                            np.int16, np.int32, np.int64)):
            self.__historical_nco_months = historical_nco_months
        else:
            raise TypeError('Wrong input historical_nco_months type. Use int-like instance.')
        
        if isinstance(header_names, list):
            self.__header_names = header_names
        else:
            raise TypeError('Wrong input header_names type. Use list instance.')
            
        self.__ODBC_source = ODBC_source
        self.__rate_name = rate_name
        self.__rate_type = rate_type
        self.__transformation = transformation
        self.__period_lag = period_lag     
        self.generateSegmentationDictionary()
        if auto_gen:
            self.generateNCOTimingCurves()
        
    
    def getAsOfDate(self):
        return(self.__as_of_date)
    
    def getScenario(self):
        return(self.__scenario)
    
    def getForecastPeriods(self):
        return(self.__forecast_periods)
    
    def getHistoricalNCOMonths(self):
        return(self.__historical_nco_months)
        
    def getODBCSource(self):
        return(self.__ODBC_source)
        
    def getRateName(self):
        return(self.__rate_name)
        
    def getHeaderNames(self):
        return(self.__header_names)
        
    def getNCORates(self):
        return(self.__NCO_rates)
        
    def getNCOCF(self):
        return(self.__NCO_contributor_file)
        
    def getSegmentationDictionary(self):
        return(self.__segmentation_dictionary)
        
    
    def generateSegmentationDictionary(self):
        self.__segmentation_dictionary = pd.DataFrame.from_dict(dict(
            FAS114_STATUS=[val for sublist in 
                [[i]*5 for i in [
                    'A - NOT REQUIRED', 
                    'B - REQUIRED - NOT SUBMITTED', 
                    'C - REQUIRED - SUBMITTED']
                ] for val in sublist],
            ModelSegment=[self.__rate_name+'_'+str(i+1) for i in range(15)],
            SEGMENT=['C&I', 'CEVF', 'CRE', 'GBM', 'SBB']*3
        ))
        
        
    def generateNCOTimingCurves(self):
        # Verify input values
        if not isinstance(self.__as_of_date, datetime.datetime):
            raise TypeError('Input as_of_date is not a datetime.datetime/date instance.')    
        if self.__forecast_periods > self.__historical_nco_months:
            raise ValueError("Forecast periods cannot be larger than historical NCO months.")
            
        # Initialize ODBC connection variable
        try:
            db = odbc.odbc(self.__ODBC_source)
        except odbc.opError:
            try:
                db = odbc.odbc(self.__ODBC_source.replace(' ', ''))
            except odbc.opError:
                raise odbc.opError('ODBC source <' + self.__ODBC_source + '> NOT found. Check data sources.')
        
        # Create data source cursor object form connection object instance
        csr = db.cursor()
        
        # Process query with input parameters
        query = """
        SET NOCOUNT ON
        -- *****************************************
        -- DEFINE GLOBAL VARIABLES
        -- ***************************************** 
        DECLARE @as_of_date DATETIME = %s
        DECLARE @forecast_periods INT = %i
        """ % ("CAST('" + utilities.date2str(self.__as_of_date) + "' AS DATETIME)", self.__historical_nco_months)
        
        query += """
        -- *****************************************
        -- DROP EXISTING TEMP TABLES
        -- ***************************************** 
        IF OBJECT_ID('tempdb..#DEFAULTED_CUSTOMERS') IS NOT NULL
        DROP TABLE #DEFAULTED_CUSTOMERS 
        IF OBJECT_ID('tempdb..#CHARGE_OFF_TRANSACTIONS') IS NOT NULL
        DROP TABLE #CHARGE_OFF_TRANSACTIONS   
        IF OBJECT_ID('tempdb..#NCO') IS NOT NULL
        DROP TABLE #NCO 
        IF OBJECT_ID('tempdb..#BSH') IS NOT NULL
        DROP TABLE #BSH 
        IF OBJECT_ID('tempdb..#NCOSegment') IS NOT NULL
        DROP TABLE #NCOSegment   
        IF OBJECT_ID('tempdb..#PRE') IS NOT NULL
        DROP TABLE #PRE 
        IF OBJECT_ID('tempdb..#TOTALS') IS NOT NULL
        DROP TABLE #TOTALS 
        IF OBJECT_ID('tempdb..#RESULT') IS NOT NULL
        DROP TABLE #RESULT
        IF OBJECT_ID('tempdb..#FINAL') IS NOT NULL
        DROP TABLE #FINAL 
        IF OBJECT_ID('tempdb..#FINAL_2') IS NOT NULL
        DROP TABLE #FINAL_2
        
        
        --
        -- Get defaulted customer list
        --
        SELECT
        	cust.Default_Date,
        	cust.SourceId,
        	cust.OneObligorNumber,
        	cust.CustomerNumber,
        	cust.FacilityNumber,
        	cust.CustomerName,
        	cust.CostCenter,
        	cust.BookBalanceAmount_at_Default AS [BookBalanceAmount_at_Default],
        	cust.LCAmount_at_Default AS [LCAmount_at_Default],
        	v23.As_Of_Date_Segment_Name, 
        	CASE 
        		WHEN v23.PD_GROUP_CORE LIKE '%CRE%' AND v23.As_Of_Date_Segment_Name NOT LIKE '%Large Corporate%'
        			THEN 'CRE' 
        		--WHEN v23.PD_GROUP_CORE LIKE '%CEVF%' AND v23.As_Of_Date_Segment_Name NOT LIKE '%Large Corporate%'
        		--	THEN 'CEVF'
        		WHEN v23.PD_GROUP_CORE LIKE '%SBB%' AND v23.As_Of_Date_Segment_Name NOT LIKE '%Large Corporate%'
        			THEN 'SBB'
        		WHEN v23.PD_GROUP_CORE LIKE '%C_I%' AND v23.As_Of_Date_Segment_Name NOT LIKE '%Large Corporate%'
        			THEN 'C&I'
        		ELSE 'NOT FOUND'
        	END AS [SEGMENT]
        INTO 
        	#DEFAULTED_CUSTOMERS
        FROM 
        	CCMISDataMart.dbo.tbl_alll_facility_defaults AS cust 
        LEFT JOIN
        	dbo.tbl_commercial_model_v2_3 AS v23
        ON
        	cust.Default_Date = v23.AsOfDate
        	AND
        	cust.SourceId = v23.SourceId
        	AND
        	cust.OneObligorNumber = v23.OneObligorNumber
        	AND
        	cust.CustomerNumber = v23.CustomerNumber
        	AND
        	cust.FacilityNumber = v23.FacilityNumber
        WHERE
        	cust.Default_Date between '3/31/2007' and @as_of_date 
        	AND
        	BookBalanceAmount_at_Default > 0
        	
        
        --
        -- Get charge-off and recovery amounts per customer 
        --
        SELECT
        	charge.FacilityNumber,
        	charge.CustomerNumber,
        	charge.SourceId,
        	charge.TransactionPostingDate,
        	charge.ChargeOffAmount, 
        	charge.RecoveryAmount
        INTO 
        	#CHARGE_OFF_TRANSACTIONS
        FROM
        	CCMIS.dbo.ChargeOffTransactions AS charge 
        WHERE
        	charge.TransactionPostingDate between '3/31/2007' and @as_of_date 
        GROUP BY 
        	charge.FacilityNumber,
        	charge.ChargeOffAmount,
        	charge.RecoveryAmount,
        	charge.TransactionPostingDate,
        	charge.SourceId,
        	charge.CustomerNumber
        	
        	
        --
        -- Merge Customer table with charge-off transactions
        --
        SELECT
        	#DEFAULTED_CUSTOMERS.*, 
        	#CHARGE_OFF_TRANSACTIONS.TransactionPostingDate,
        	COALESCE(#CHARGE_OFF_TRANSACTIONS.ChargeOffAmount,'') as ChargeOffAmount,
        	COALESCE(#CHARGE_OFF_TRANSACTIONS.RecoveryAmount,'') as RecoveryAmount
        INTO 
        	#NCO
        FROM 
        	#DEFAULTED_CUSTOMERS
        LEFT JOIN
        	#CHARGE_OFF_TRANSACTIONS
        ON
        	#DEFAULTED_CUSTOMERS.FacilityNumber = #CHARGE_OFF_TRANSACTIONS.FacilityNumber
        	AND
        	#DEFAULTED_CUSTOMERS.CustomerNumber = #CHARGE_OFF_TRANSACTIONS.CustomerNumber
        	AND 
        	#DEFAULTED_CUSTOMERS.SourceId = #CHARGE_OFF_TRANSACTIONS.SourceId
        WHERE
        	#DEFAULTED_CUSTOMERS.SEGMENT <> 'NOT FOUND'
        
        
        --
        -- Get business segment hierarchy 
        --
        SELECT
        	bsh.AsOfDate,
        	bsh.SegmentRank,
        	bsh.SegmentName,
        	bsh.CostCenter,
        	bsh.PermanentSegmentID
        INTO
        	#BSH
        FROM
        	CCMISDataMart.dbo.tblBusinessSegmentHierarchy AS bsh 
        WHERE
        	bsh.AsOfDate = @as_of_date
        
        
        --
        -- Merge NCO (#NCO) table with hierarchy (#BSH)
        --
        SELECT
        	#NCO.*,
        	#BSH.SegmentName,
        	#BSH.PermanentSegmentID
        INTO
        	#NCOSegment   
        FROM
        	#NCO
        LEFT JOIN
        	#BSH 
        ON
        	#NCO.CostCenter = #BSH.CostCenter
        WHERE
        	--#BSH.PermanentSegmentID <> '16' 
        	--AND
        	#BSH.PermanentSegmentID <> '14'
        
        
        --
        -- Get list of CEVF customer to kick out
        --
        SELECT
        	n.*,
        	CEVFList.CustomColumn3
        INTO 
        	#PRE
        FROM 
        	#NCOSegment n
        LEFT JOIN (
        	SELECT
        		c.CustomerNumber,
        		COALESCE(MAX(c.CustomColumn3),'') AS [CustomColumn3]
        	FROM
        		CCMIS.dbo.Customer AS c 
        	WHERE
        		c.AsOfDate BETWEEN '6/30/2008' AND @as_of_date   
        	GROUP BY
        		c.CustomerNumber
        ) AS CEVFList
        ON 
        	n.CustomerNumber = CEVFList.CustomerNumber
        
        
        --
        -- Lessor Fix
        --
        DELETE FROM 
        	#PRE
        WHERE 
        	PermanentSegmentID = '24'
        	AND 
        	CustomColumn3 <> '001'
        	AND  
        	CustomColumn3 <> '008'
        	AND 
        	CustomColumn3 <> '009'
        	AND 
        	CustomColumn3 <> ''
        
        
        DELETE FROM 
        	#PRE
        WHERE 
        	PermanentSegmentID = '15'
        	AND 
        	CustomColumn3 <> '001'
        	AND  
        	CustomColumn3 <> '008'
        	AND 
        	CustomColumn3 <> '009'
        	AND 
        	CustomColumn3 <> ''
        
        --
        -- MAIN RESULT TABLE
        --
        SELECT
        	IDX.MonthsFromDefault AS [MonthsFromDefault],
        	COALESCE(tbl.ChargeOffAmount,0) AS [ChargeOffAmount],
        	COALESCE(tbl.RecoveryAmount,0) AS [RecoveryAmount],
        	--COALESCE(tbl.NetChargeOffAmount,0) AS [NetChargeOffAmount],
        	tbl.SEGMENT AS [SEGMENT]
        INTO 
        	#RESULT
        FROM 
        	(
        	SELECT DISTINCT MonthsFromDefault = number 
        	FROM master..[spt_values] 
        	WHERE number BETWEEN 0 AND @forecast_periods-1
        	) AS IDX
        LEFT JOIN (
        	SELECT
        		DATEDIFF(M, #PRE.Default_Date, #PRE.TransactionPostingDate) AS [MonthsFromDefault],
        		SUM(#PRE.ChargeOffAmount) AS [ChargeOffAmount], 
        		SUM(#PRE.RecoveryAmount) AS [RecoveryAmount],
        		--SUM(#PRE.ChargeOffAmount-#PRE.RecoveryAmount) AS [NetChargeOffAmount],
        		#PRE.SEGMENT
        
        	FROM 
        		#PRE
        	WHERE
        		(DATEDIFF(M, #PRE.Default_Date, #PRE.TransactionPostingDate) BETWEEN 0 AND @forecast_periods-1)
        	GROUP BY
        		DATEDIFF(M, #PRE.Default_Date, #PRE.TransactionPostingDate),
        		#PRE.SEGMENT
        	) AS tbl
        ON
        	IDX.MonthsFromDefault = tbl.MonthsFromDefault
        ORDER BY
        	IDX.MonthsFromDefault ASC
        
        
        
        --
        -- CREATE CUMULATIVE SUM COLUMNS
        --
        SELECT
        	T1.MonthsFromDefault AS [MonthsFromDefault],
        	(T1.ChargeOffAmount - T1.RecoveryAmount) AS [NCO],
        	SUM(T2.ChargeOffAmount - T2.RecoveryAmount) AS [CUMSUM_NCO],
        	T1.SEGMENT AS [SEGMENT]
        INTO
        	#FINAL
        FROM
        	#RESULT AS T1
        LEFT JOIN 
        	#RESULT AS T2
        ON 
        	T1.MonthsFromDefault >= T2.MonthsFromDefault
        	AND
        	T1.SEGMENT = T2.SEGMENT
        GROUP BY
        	T1.MonthsFromDefault,
        	(T1.ChargeOffAmount - T1.RecoveryAmount),
        	T1.SEGMENT
        
        
        --
        -- CREATE SUM TOTALS PER SEGMENT oF GCO AND REC
        --
        SELECT
        	SUM(#FINAL.NCO) AS [TOTAL_NCO],
        	#FINAL.SEGMENT AS [SEGMENT]	
        INTO
        	#TOTALS
        FROM
        	#FINAL
        WHERE 
        	#FINAL.NCO>=0
        GROUP BY
        	#FINAL.SEGMENT
        	
        --
        -- CREATES NON-PIVOTED (LONG FORMAT) NCO CURVES PER SEGMENT
        --
        SELECT
        	#FINAL.MonthsFromDefault, 
        	CASE
        		WHEN #FINAL.NCO < 0
        			THEN 0
        		ELSE ROUND((#FINAL.NCO/#TOTALS.TOTAL_NCO),6)
        	END AS [NCO_PERCENT], -- non-cumulative/point-in-time version, capped at 0
        	#FINAL.SEGMENT AS [SEGMENT]
        INTO
        	#FINAL_2
        FROM
        	#FINAL
        LEFT JOIN
        	#TOTALS
        ON
        	#FINAL.SEGMENT = #TOTALS.SEGMENT
        ORDER BY
        	#FINAL.MonthsFromDefault ASC
        
        -- COPY C&I AS GBM
        INSERT INTO #FINAL_2 ([MonthsFromDefault], [SEGMENT], [NCO_PERCENT])
        SELECT
        	#FINAL_2.MonthsFromDefault AS [MonthsFromDefault],
        	'GBM' AS [SEGMENT],
        	#FINAL_2.NCO_PERCENT AS [NCO_PERCENT]
        FROM
        	#FINAL_2
        WHERE
        	#FINAL_2.SEGMENT = 'C&I'
        
        -- COPY C&I AS CEVF
        INSERT INTO #FINAL_2 ([MonthsFromDefault], [SEGMENT], [NCO_PERCENT])
        SELECT
        	#FINAL_2.MonthsFromDefault AS [MonthsFromDefault],
        	'CEVF' AS [SEGMENT],
        	#FINAL_2.NCO_PERCENT AS [NCO_PERCENT]
        FROM
        	#FINAL_2
        WHERE
        	#FINAL_2.SEGMENT = 'C&I'
        
        
        --
        -- Return final results
        --
        SELECT 
        	#FINAL_2.* 
        FROM 
        	#FINAL_2 
        ORDER BY 
        	#FINAL_2.SEGMENT, #FINAL_2.MonthsFromDefault
        """
        
        # Execute and fetch query results 
        csr.execute(query)
        nco_data_raw = pd.DataFrame(csr.fetchall())
        nco_data_raw.columns = [column[0] for column in csr.description]
        
        # Check if sum of NCO rates is 1 for each segment
        check_completeness = []
        check_data = nco_data_raw.groupby('SEGMENT')['NCO_PERCENT'].sum()
        for idx in range(len(check_data)):
            if round(abs(check_data[idx]-1.0),4)>0.02: # threshold is 100% +- 2%
                check_completeness.append(check_data.index[idx])
        if len(check_completeness) > 0:
            warnings.warn('Sum of NCO rates is NOT 1 for the following segments ' + str(check_completeness))
            print(check_data)
        
        # Subset for up to forecast periods
        nco_rates = nco_data_raw[nco_data_raw['MonthsFromDefault']<self.__forecast_periods]
        
        # Merge with segmentation dictionary
        self.__NCO_rates = nco_rates.merge(self.__segmentation_dictionary,on='SEGMENT')


    def generateNCOTimingCurveCF(self):    
        # Create placeholder contributor file Dataframe
        placeholder = pd.DataFrame(columns=self.__header_names)
            
        # Get NCO timing curves from CCMIS
        if self.__NCO_rates is None:    
            self.generateNCOTimingCurves()
        
        # Create PeriodDate field
        self.__NCO_rates['PeriodDate'] = [utilities.date2str(utilities.generateDateSequence(
            as_of_date=self.__as_of_date,
            forecast_periods=idx+1
        )[-1]) for idx in self.__NCO_rates['MonthsFromDefault']]
        
        for model_segment in self.__segmentation_dictionary['ModelSegment'].unique():
            # Subset to get model segment data        
            model_segment_data = self.__NCO_rates[
                self.__NCO_rates['ModelSegment'] == model_segment
            ]
            
            # Append Data to Placeholder Dataframe
            placeholder = placeholder.append(pd.DataFrame.from_dict(dict(
                Scenario=self.__scenario,
                ModelSegment=model_segment,
                PeriodDate=model_segment_data['PeriodDate'],
                Vintage='.', 
                RateType=self.__rate_type,
                FeesAndExpensesLineItem='',
                AssociatedG_L_Item='',
                Transformation=self.__transformation,
                PeriodLag=self.__period_lag,
                RateName=self.__rate_name,
                ModelOutputRate=model_segment_data['NCO_PERCENT'],
                UncertaintyAdjustmentRate=int(0),
                MgmtAdjustmentRate=int(0),
                IdiosyncraticRate1=int(0),
                IdiosyncraticRate2=int(0),
                IdiosyncraticRate3=int(0),
                IdiosyncraticRate4=int(0),
                IdiosyncraticRate5=int(0),
                Adjustment_Overlay_Justification=''
            )))
            
        # Reorder columns
        placeholder = placeholder[self.__header_names]
        
        # Reset the index to match row numbers
        placeholder.reset_index(inplace=True, drop=True)
        
        # Initialize ContributorFile object instance from data
        CF_instance = ContributorFile(data=placeholder)
        
        # Check CF quality and return results
        CFIntegrityResponse = CF_instance.checkCFIntegrity()
        CFHeaderCompletenessResponse = CF_instance.checkCFHeadersCompleteness()
        if(
            CFIntegrityResponse.getResponse() 
            and CFHeaderCompletenessResponse.getResponse()
        ):
            self.__NCO_contributor_file = CF_instance
        else:
            response_dictionary = []
            if(CFIntegrityResponse.getResponse() == False):
                response_dictionary.append(CFIntegrityResponse.getDict())
            if(CFHeaderCompletenessResponse.getResponse() == False):
                response_dictionary.append(CFHeaderCompletenessResponse.getDict())
            raise Exception('CF quality check failed : ' + str(response_dictionary))
            
    def exportCFData(self, output_file_path):
        if self.__NCO_contributor_file is None:
            self.generateNCOTimingCurveCF()
        self.__NCO_contributor_file.toCSV(output_file_path)
        








