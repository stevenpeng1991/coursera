#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 04 10:43:53 2016

@author: n813863

SAMPLE USE

sbna_mc16_comm_loss_checker = CFChecker(
    group='SB_COMM_LOSS',
    cf_type='PRE_BW',
    run_name='MC16',
    as_of_date=datetime.datetime(2016,6,30),
    working_directory='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_Base',
    scenario='MC_Base',
    requirements_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/CF_REQUIREMENTS.xlsm',
    requirements_file_sheetname='CF_REQUIREMENTS',
    forecast_periods=27
)
sbna_mc16_comm_loss_checker.checkCFDirectory(debug=True)

log_data = sbna_mc16_comm_loss_checker.getLogData()

sbna_mc16_comm_loss_checker.toCSV(
    output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_Base/SB_COMM_LOSS_MC_Base_checker_log.csv'
)

#-------------------------------------------------------------------------------

sbna_mc16_comm_loss_checker = CFChecker(
    group='SB_COMM_LOSS',
    cf_type='PRE_BW',
    run_name='MC16',
    as_of_date=datetime.datetime(2016,6,30),
    working_directory='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_Adverse',
    scenario='MC_Adverse',
    requirements_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/CF_REQUIREMENTS.xlsm',
    requirements_file_sheetname='CF_REQUIREMENTS',
    forecast_periods=27
)
sbna_mc16_comm_loss_checker.checkCFDirectory(debug=True)

log_data = sbna_mc16_comm_loss_checker.getLogData()

sbna_mc16_comm_loss_checker.toCSV(
    output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_Adverse/SB_COMM_LOSS_MC_Adverse_checker_log.csv'
)

#----------------------------------------------------------------------
sbna_mc16_comm_loss_checker = CFChecker(
    group='SB_COMM_LOSS',
    cf_type='PRE_BW',
    run_name='MC16',
    as_of_date=datetime.datetime(2016,6,30),
    working_directory='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_SA',
    scenario='MC_SA',
    requirements_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/CF_REQUIREMENTS.xlsm',
    requirements_file_sheetname='CF_REQUIREMENTS',
    forecast_periods=27
)
sbna_mc16_comm_loss_checker.checkCFDirectory(debug=True)

log_data = sbna_mc16_comm_loss_checker.getLogData()

sbna_mc16_comm_loss_checker.toCSV(
    output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_SA/SB_COMM_LOSS_MC_SA_checker_log.csv'
)

#----------------------------------------------------------------------
sbna_mc16_comm_loss_checker = CFChecker(
    group='SB_RETAIL_LOSS',
    cf_type='PRE_BW',
    run_name='MC16',
    as_of_date=datetime.datetime(2016,6,30),
    working_directory='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Retail/PreBW - Run3',
    scenario='MC_SA',
    requirements_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/CF_REQUIREMENTS.xlsm',
    requirements_file_sheetname='CF_REQUIREMENTS',
    forecast_periods=27
)
sbna_mc16_comm_loss_checker.checkCFDirectory(debug=True)

log_data = sbna_mc16_comm_loss_checker.getLogData()

sbna_mc16_comm_loss_checker.toCSV(
    output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files//Retail/PreBW - Run3/SB_RETAIL_LOSS_checker_log.csv'
)

##
## ContributorFileGenerator
##

cfg = ContributorFileGenerator(
    run_id='Test Run',
    verbose=True
)
def add(n):
    cfg = ContributorFileGenerator(
        run_id='Test Run',
        verbose=False
    )

    for i in range(n):
        cfg.addCFChunk(
            as_of_date=datetime.datetime(2016,3,31),
            forecast_periods=27,
            forecast_periods_frequency='monthly',
            model_segment='PD_23',
            scenario='Base',
            rate_name='PD',
            rate_type='4',
            vintage_differentiation=False,
            model_output_rate=[0.0019373875,
                 0.0019373875,
                 0.0019373875,
                 0.0017652653999999999,
                 0.0017652653999999999,
                 0.0017652653999999999,
                 0.0022947745,
                 0.0022947745,
                 0.0022947745,
                 0.0024575810999999999,
                 0.0024575810999999999,
                 0.0024575810999999999,
                 0.0027941677,
                 0.0027941677,
                 0.0027941677,
                 0.0026856248,
                 0.0026856248,
                 0.0026856248,
                 0.0026618956999999999,
                 0.0026618956999999999,
                 0.0026618956999999999,
                 0.0024223742999999998,
                 0.0024223742999999998,
                 0.0024223742999999998,
                 0.0022803726999999999,
                 0.0022803726999999999,
                 0.0022803726999999999,
                 0.0021855277999999999,
                 0.0021855277999999999,
                 0.0021855277999999999,
                 0.0022918292000000001,
                 0.0022918292000000001,
                 0.0022918292000000001,
                 0.0021146886999999998,
                 0.0021146886999999998,
                 0.0021146886999999998,
                 0.0023054579000000002,
                 0.0023054579000000002,
                 0.0023054579000000002,
                 0.0025231063999999999,
                 0.0025231063999999999,
                 0.0025231063999999999,
                 0.0024936442999999998,
                 0.0024936442999999998,
                 0.0024936442999999998],
            uncertainty_adjustment_rate=0.0,
            mgmt_adjustment_rate=0.0
        )
    # print(len(cfg.contributor_file.getCFData()))
%timeit add(100)

cfg = ContributorFileGenerator(
    run_id='Test Run',
    verbose=True
)
cfg.addCFChunk(
    as_of_date=datetime.datetime(2016,3,31),
    forecast_periods=27,
    forecast_periods_frequency='monthly',
    model_segment='EAD_33',
    scenario='Base',
    rate_name='EAD',
    rate_type='4',
    vintage_differentiation=False,
    model_output_rate=[0.0019373875,
         0.0019373875,
         0.0019373875,
         0.0017652653999999999,
         0.0017652653999999999,
         0.0017652653999999999,
         0.0022947745,
         0.0022947745,
         0.0022947745,
         0.0024575810999999999,
         0.0024575810999999999,
         0.0024575810999999999,
         0.0027941677,
         0.0027941677,
         0.0027941677,
         0.0026856248,
         0.0026856248,
         0.0026856248,
         0.0026618956999999999,
         0.0026618956999999999,
         0.0026618956999999999,
         0.0024223742999999998,
         0.0024223742999999998,
         0.0024223742999999998,
         0.0022803726999999999,
         0.0022803726999999999,
         0.0022803726999999999,
         0.0021855277999999999,
         0.0021855277999999999,
         0.0021855277999999999,
         0.0022918292000000001,
         0.0022918292000000001,
         0.0022918292000000001,
         0.0021146886999999998,
         0.0021146886999999998,
         0.0021146886999999998,
         0.0023054579000000002,
         0.0023054579000000002,
         0.0023054579000000002,
         0.0025231063999999999,
         0.0025231063999999999,
         0.0025231063999999999,
         0.0024936442999999998,
         0.0024936442999999998,
         0.0024936442999999998],
    uncertainty_adjustment_rate=0.0,
    mgmt_adjustment_rate=0.0,
    EAD_available_line=0.75,
    EAD_total_line=None
)


##
## TEST APPENDCF
##
cfg = ContributorFileGenerator(
    run_id='Test Run',
    verbose=True
)
cfg.appendCF(
    scenario="MC_Base",
    model_segment=["EAD_12", "EAD_12", "PD_123"],
    period_date=datetime.datetime(2016,6,30),
    vintage=datetime.datetime(2016,6,30),
    rate_type=4,
    rate_name="EAD",
    model_output_rate=[1,1,1,1,1,1,1,1,1],
    uncertainty_adjustment_rate=0.,
    mgmt_adjustment_rate=0.,
    EAD_available_line=0.75,
    EAD_total_line=None
)
cfg.dataConcat()
cfg.dataConcat().to_clipboard(index=False)









import re
def subsetContributorData(cf_data,scenario, modelsegment, vintage):
    if vintage in ['null', 'NULL', 'None', None, '.', 'NaN', 'NaT']:
        return (
            cf_data[
                pd.isnull(cf_data['Vintage']) &
                (cf_data['ModelSegment'] == modelsegment) &
                (cf_data['Scenario'] == scenario)
            ]
        )
    elif isinstance(vintage, datetime.datetime):
        return (
            cf_data[
                (cf_data['Vintage'] == vintage) &
                (cf_data['ModelSegment'] == modelsegment) &
                (cf_data['Scenario'] == scenario)
            ]
        )
    elif isinstance(vintage, str):
        if bool(
            re.search(
                pattern='^[0-9]{1,2}[/]{1}[0-9]{1,2}[/]{1}[0-9]{4}$',
                string=vintage,
                flags=re.IGNORECASE
            )
        ):
            return (
                cf_data[
                    (cf_data['Vintage'] == utilities.str2date(vintage)) &
                    (cf_data['ModelSegment'] == modelsegment) &
                    (cf_data['Scenario'] == scenario)
                ]
            )
    else:
        return None


import pylab as plt
import re
import matplotlib
matplotlib.font_manager.FontProperties(size=10)
plt.ioff()
fig = plt.figure(figsize=(16, 9))
plt.clf()


msd = {
    'Base': {
        'PD_19':['None']
    },
    'FRB_SA': {
        'PD_19':[None,'12/31/2017']
    }
}

legend_tags = []
for scenario in msd.keys():
    for model_segment in msd[scenario].keys():
        for vintage in msd[scenario][model_segment]:
            print(scenario+model_segment+str(vintage))
            sub = subsetContributorData(cf_data,scenario, model_segment, vintage)
            if (sub is not None) & (not sub.empty):
                print('passed')
                legend_tags.append(scenario + '-' + model_segment + '-[' + str(vintage) + ']')
                plt.plot(
                    sub['PeriodDate'],
                    sub['ModelOutputRate']
                )
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.legend(legend_tags, loc='upper right', prop={'size':10})
manager = plt.get_current_fig_manager()
plt.grid(False)

#manager.window.showMaximized()
plt.show()


##
## TESTING EMPTY CONTRIBUTOR FILE INSTANCE
##
cf = ContributorFile(
    primary_key=CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS,
    date_fields=CONTRIBUTOR_DATA_DATE_FIELDS,
    header_list=CONTRIBUTOR_DATA_HEADER_NAMES,
    data=pd.DataFrame(columns=CONTRIBUTOR_DATA_HEADER_NAMES)
)


"""
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import numpy as np
import pandas as pd
import os
import io
import getpass
import re
import copy
import json
import cx_Oracle
import time
from CIFI.config import CONFIG
import datetime
import itertools
import matplotlib
import pylab as plt
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset

# ================ #
# GLOBAL VARIABLES #
# ================ #
# Define data type mapping from Python native types to Pandas dtypes
global PYTHON_NATIVE_TO_DTYPE
PYTHON_NATIVE_TO_DTYPE = {
    "character": ["object"],
    "categorical": ["object"],
    "object": ["object"],
    "factor": ["object"],
    "string": ["object"],
    "str": ["object"],
    "integer": ['int', 'int16', 'int32', 'int64'],
    "int": ['int', 'int16', 'int32', 'int64'],
    "float": ['float', 'float16', 'float32', 'float64'],
    "numerical": ['int', 'int16', 'int32', 'int64', 'float', 'float16',
                  'float32', 'float64'],
    "numeric": ['int', 'int16', 'int32', 'int64', 'float', 'float16',
                'float32', 'float64'],
    "numeric+datetime": ['int', 'int16', 'int32', 'int64', 'float', 'float16',
                'float32', 'float64', 'datetime.datetime', 'np.datetime64', 'datetime64[ns]'],
    "datetime":['datetime.datetime', 'np.datetime64', 'datetime64[ns]']
}

global NEUTRAL_SUBSETS
NEUTRAL_SUBSETS = ['ALL', 'TRUE', 'NEUTRAL', 'all', 'true', 'True', 'Neutral']

global ALLOWED_DISTRIBUTION_CHECK_NAMES
ALLOWED_DISTRIBUTION_CHECK_NAMES = [
    'class',
    'mean',
    'stdev',
    'norm_mean',
    'distinct_count',
    'mean_distinct_count',
    'stdev_distinct_count',
    'norm_mean_distinct_count'
]

global ALLOWED_INDIVIDUAL_CHECK_NAMES
ALLOWED_INDIVIDUAL_CHECK_NAMES = [
    'regex_pattern',
    'value_length',
    'upper_bound',
    'lower_bound',
    'check_na',
    'value'
]

global CONTRIBUTOR_DATA_HEADER_NAMES
CONTRIBUTOR_DATA_HEADER_NAMES = [
    "SCENARIO",
    "MODELSEGMENT",
    "PERIODDATE",
    "VINTAGE",
    "RATETYPE",
    "FEESANDEXPENSESLINEITEM",
    "ASSOCIATEDG_L_ITEM",
    "TRANSFORMATION",
    "PERIODLAG",
    "RATENAME",
    "MODELOUTPUTRATE",
    "UNCERTAINTYADJUSTMENTRATE",
    "MGMTADJUSTMENTRATE",
    "IDIOSYNCRATICRATE1",
    "IDIOSYNCRATICRATE2",
    "IDIOSYNCRATICRATE3",
    "IDIOSYNCRATICRATE4",
    "IDIOSYNCRATICRATE5",
    "ADJUSTMENT_OVERLAY_JUST"
]

global CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS
CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS = [
    "SCENARIO",
    "PERIODDATE",
    "VINTAGE",
    "MODELSEGMENT",
    "RATENAME"
]

global CONTRIBUTOR_DATA_DATE_FIELDS
CONTRIBUTOR_DATA_DATE_FIELDS = [
    'PERIODDATE',
    'VINTAGE'
]

global EAD_LEQ_SEGMENT_KEYS
EAD_LEQ_SEGMENT_KEYS = {
    'EADAVAILABLELINE':0.0,
    'EADBALANCE':1.0,
    'EADLETTEROFCREDIT':1.0,
    'EADTOTALLINE':0.0
}



class ContributorFileGenerator:
    """
    """
    # Properties
    # __as_of_date = None
    # __forecast_periods = None
    # __forecast_period_frequency = None
    __header_names = None
    __verbose = None
    __data = None
    __period_freq_map = None
    __allow_meta_content = None
    __run_id = None
    __run_datetime = None
    __session = None
    __makeList = None
    __processVector = None
    __expectedCFLength = None
    __LEQ_approach_switch = None
    logger = None



    # Methods
    def __init__(
        self,
        run_id,
        run_datetime=None,
        allow_meta_content=True,
        verbose=False,
        LEQ_approach_switch=False,
        logger=None
    ):
        # Process logger instance
        if logger is not None:
            if isinstance(logger, Logger):
                self.logger = logger
            else:
                raise TypeError("Input `logger` is not an instance of Logger().")

        # Init verbose bool
        if isinstance(verbose, bool):
            self.__verbose = verbose
        else:
            raise TypeError("Input verbose should be of type bool.")

        # LEQ Approach switch init
        utilities.checkDataType(LEQ_approach_switch, bool)
        self.__LEQ_approach_switch = LEQ_approach_switch

        # Meta content
        if isinstance(allow_meta_content, bool):
            self.__allow_meta_content = allow_meta_content
        else:
            raise TypeError("Input `allow_meta_content` is not of bool type.")

        # Initialize data container with header names
        self.__header_names = CONTRIBUTOR_DATA_HEADER_NAMES
        # if self.__allow_meta_content:
            # self.__header_names.append('meta_origin')
            # self.__header_names.append('meta_content')
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Initializing empty data container...',
                context='Contributor File Generator'
            )
        self.__data = list() # pd.DataFrame(columns=self.__header_names)

        # Validating run_id and run_datetime
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Validating run_id and run_datetime...',
                context='Contributor File Generator'
            )
        if isinstance(run_id,str):
            self.__run_id = run_id
        else:
            raise TypeError("Invalid data type for `run_id`.")

        if isinstance(run_datetime,datetime.datetime):
            self.__run_id = run_id
        elif run_datetime is None:
            self.__run_datetime = datetime.datetime.now()
        else:
            raise TypeError("Invalid data type for `run_datetime`.")

        # Creating period-frequency map
        self.__period_freq_map = {
            'monthly': 1,
            'quarterly': 3,
            'yearly': 12
        }

        # Creating lambda helpers
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Initializing lambda helper functions.',
                context='Contributor File Generator'
            )
        self.__makeList = lambda item: item if isinstance(item, list) else [item]
        self.__processVector = lambda l, fp: (
            self.__makeList(l) * fp
            if len(self.__makeList(l)) == 1
            else (self.__makeList(l)[0:fp] if len(self.__makeList(l)) >= fp else np.nan)
        )
        self.__expectedCFLength = lambda fp, v_diff: int(fp * (fp + 1) / 2 + fp) if v_diff else int(fp)

        # Finalize
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Meta content allowed.',
                context='Contributor File Generator'
            )

        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='ContributorFileGenerator instance created successfully.',
                context='Contributor File Generator'
            )

    def __isValidAsOfDate(self, some_as_of_date):
        """
        This function validates correct data type and range for as_of_date.
        Date ranges have been defined within a 1 year range from "now" or runtime.
        """
        if isinstance(some_as_of_date, datetime.datetime):
            if (
                        (some_as_of_date >= utilities.addMonths2date(datetime.datetime.now(), -12)) &
                        (some_as_of_date <= utilities.addMonths2date(datetime.datetime.now(), 12))
            ):
                return (True)
            else:
                raise ValueError('Input date is out of range. Date ranges are defined within a year from `now`.')
        else:
            raise TypeError('Invalid input date type. Use datetime.datetime instance.')

    def __isValidForecastPeriods(self, some_forecast_periods, some_forecast_periods_frequency):
        if isinstance(some_forecast_periods, int):
            if some_forecast_periods_frequency == 'monthly':
                if (some_forecast_periods > 0) & (some_forecast_periods <= 132):
                    return (True)
                else:
                    raise ValueError('Input forecast periods is out of range. Range is 1 to 132, inclusive.')
            elif some_forecast_periods_frequency == 'quarterly':
                if (some_forecast_periods > 1) & (some_forecast_periods <= 44):
                    return (True)
                else:
                    raise ValueError('Input forecast periods is out of range. Range is 1 to 44, inclusive.')
            elif some_forecast_periods_frequency == 'annually':
                if (some_forecast_periods > 1) & (some_forecast_periods <= 11):
                    return (True)
                else:
                    raise ValueError('Input forecast periods is out of range. Range is 1 to 11, inclusive.')
            else:
                raise ValueError('Input forecast periods frequency is invalid. Expects monthly, quarterly or annually.')
        else:
            raise TypeError('Input forecast periods is of the wrong data type. Expects type <int>.')

    def __isValidVintage(self, vintage):
        if pd.isnull(vintage):
            return(True)
        elif(isinstance(vintage,datetime.datetime)):
            if vintage in utilities.generateDateSequence(
                as_of_date=self.__as_of_date,
                forecast_periods=self.__forecast_periods,
                m_interval=self.__period_freq_map[self.__forecast_periods_frequency]
            ):
                return(True)
            else:
                raise ValueError("Input vintage " + str(vintage) + "out of range.")
        else:
            raise TypeError("Input vintage is not a np.nan or datetime.datetime instance.")

    @property
    def header_names(self):
        return self.__header_names

    @property
    def verbose(self):
        return self.__verbose

    @property
    def period_freq_map(self):
        return self.__period_freq_map

    @property
    def run_id(self):
        return self.__run_id

    @property
    def run_datetime(self):
        return self.__run_datetime

    @property
    def makeList(self):
        return self.__makeList

    @property
    def processVector(self):
        return self.__processVector

    @property
    def expectedCFLength(self):
        return self.__expectedCFLength

    @property
    def LEQ_approach_switch(self):
        return self.__LEQ_approach_switch

    @property
    def data(self):
        return(self.__data)


    def retailmanagementAdjustment(self,adjustment_dictionary,dataset_query_date,model):
        '''
        adjustment_dictionary={'PD_GROUP':['CRE_MULTIFAMILY','CRE_OTHER'], 'RATENAME':['PD','PD'], 'MGMTADJUSTMENT':[-0.008202,-0.007040]}
        '''
        data = self.dataConcat()
        # only need one adjustment toward the entire pd_group
        if model == 'EJM':
            data.ix[data['MODELSEGMENT']==adjustment_dictionary['MODELSEGMENT'],'MGMTADJUSTMENTRATE']=adjustment_dictionary['MGMTADJUSTMENT']*data['MODELOUTPUTRATE']
            self.__data=data.to_dict(orient='records')
        elif model == 'SBB':
            data.ix[data['RATENAME']==adjustment_dictionary['RATENAME'],'MGMTADJUSTMENTRATE']=adjustment_dictionary['MGMTADJUSTMENT']*data['MODELOUTPUTRATE']
            self.__data=data.to_dict(orient='records')            
        return(True)


    def managementAdjustment(self,adjustment_dictionary,dataset_query_date,pd_group_switch=False):
        '''
        adjustment_dictionary={'PD_GROUP':['CRE_MULTIFAMILY','CRE_OTHER'], 'RATENAME':['PD','PD'], 'MGMTADJUSTMENT':[-0.008202,-0.007040]}
        '''
        data = self.dataConcat()
        if pd_group_switch == False:
            # only need one adjustment toward the entire pd_group
            data.ix[data['RATENAME']==adjustment_dictionary['RATENAME'],'MGMTADJUSTMENTRATE']=adjustment_dictionary['MGMTADJUSTMENT']*data['MODELOUTPUTRATE']
        else:   
            # need multiple adjustments toward different pd_groups
            adjustment_df = pd.DataFrame(adjustment_dictionary,columns=['PD_GROUP', 'RATENAME', 'MGMTADJUSTMENT'])
            # Query CCMIS to get PD_GROUP
            dataset= CCMISMasterDataset(
                                asofdate=dataset_query_date,
                                pd_groups=adjustment_df['PD_GROUP'].unique().tolist(),
                                debug=False
                      ).data[['UNIQUE_FACILITY_ID','PD_GROUP']]
            # plus SB to match modelsegment
            dataset['MODELSEGMENT']='SB'+dataset['UNIQUE_FACILITY_ID']
            dataset.drop('UNIQUE_FACILITY_ID',axis=1,inplace=True)
            # get all unique_facility_id adjstment per PD_GROUP
            facility_adjustment=pd.merge(dataset,adjustment_df,how='left',on=['PD_GROUP'])
            # drop PD_GROUP Column
            facility_adjustment.drop('PD_GROUP',axis=1,inplace=True)
            # merge with result
            data_adjustment=pd.merge(data,facility_adjustment,how='left',on=['MODELSEGMENT','RATENAME'])
            # multiple MGMTADJUSTMENT with MODELOUTPUTRATE
            data_adjustment['MGMTADJUSTMENTRATE']=data_adjustment['MGMTADJUSTMENT']*data_adjustment['MODELOUTPUTRATE']
            # fill na for no adjustment
            data_adjustment['MGMTADJUSTMENTRATE'].fillna(0,inplace=True)
            # drop MGMTADJUSTMENT
            data_adjustment.drop('MGMTADJUSTMENT',axis=1,inplace=True)
            
            if data_adjustment.shape!=data.shape:
                raise ValueError('MGMTADJUSTMENT changes data result shape.')
            else:
                self.__data=data_adjustment.to_dict(orient='records')
        return(True)

        
    def generateContributorFileInstance(self):
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Generating Contributor File instance...',
                context='Contributor File Generator'
            )
        data = self.dataConcat()
        if data is not None:
            return(
                ContributorFile(
                    primary_key=CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS,
                    date_fields=CONTRIBUTOR_DATA_DATE_FIELDS,
                    header_list=CONTRIBUTOR_DATA_HEADER_NAMES,
                    data=data
                )
            )

    def dataConcat(self):
        # return(pd.concat(self.__data).reset_index(drop=True))
        if len(self.__data)>0:
            return(pd.DataFrame.from_dict(self.__data))
        else:
            return(pd.DataFrame(columns=CONTRIBUTOR_DATA_HEADER_NAMES))

    def resetGenerator(self):
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Resetting generator data container...',
                context='Contributor File Generator'
            )
        self.__data.clear()

    def appendCF(
        self,
        scenario,
        model_segment,
        period_date,
        vintage,
        rate_type,
        rate_name,
        model_output_rate,
        uncertainty_adjustment_rate,
        mgmt_adjustment_rate,
        fees_and_expenses_line_item='',
        associated_GL_item='',
        transformation='No Transformation',
        period_lag=0,
        idiosyncratic_rate_1=0,
        idiosyncratic_rate_2=0,
        idiosyncratic_rate_3=0,
        idiosyncratic_rate_4=0,
        idiosyncratic_rate_5=0,
        adjustment_overlay_justification="",
        EAD_available_line=None,
        EAD_total_line=None
    ) -> bool:
        if self.verbose: print('=> Appending new contributor file...')

        # Validating data types
        if self.verbose: print("=> Validating input data types...")
        utilities.checkDataType(model_segment, (list, str))
        utilities.checkDataType(scenario, (list, str))
        utilities.checkDataType(rate_name, (list, str))
        utilities.checkDataType(period_date, (list, datetime.datetime))
        utilities.checkDataType(vintage, (list, datetime.datetime))
        utilities.checkDataType(rate_type, (list, int))
        utilities.checkDataType(model_output_rate, (list, float, int))
        utilities.checkDataType(uncertainty_adjustment_rate, (list, int, float))
        utilities.checkDataType(mgmt_adjustment_rate, (list, float, int))
        utilities.checkDataType(transformation, (list, str))
        utilities.checkDataType(fees_and_expenses_line_item, (list, str))
        utilities.checkDataType(associated_GL_item, (list, str))
        utilities.checkDataType(period_lag, (list, int))
        utilities.checkDataType(idiosyncratic_rate_1, (list, float, int))
        utilities.checkDataType(idiosyncratic_rate_2, (list, float, int))
        utilities.checkDataType(idiosyncratic_rate_3, (list, float, int))
        utilities.checkDataType(idiosyncratic_rate_4, (list, float, int))
        utilities.checkDataType(idiosyncratic_rate_5, (list, float, int))
        utilities.checkDataType(adjustment_overlay_justification, (list, str))

        # Calculate and verify forecast periods
        max_arg_len = 0
        for arg, value in locals().items():
            if self.verbose:
                print("List : "+str(self.makeList(value)) + " | Length : " + str(len(self.makeList(value))) + " | max_arg_len : " + str(max_arg_len))
            max_arg_len = max(len(self.makeList(value)), max_arg_len)
        if max_arg_len == 0:
            raise ValueError("`max_arg_len` cannot be 0.")

        # Create initial placeholder data for contributor file (no vintage differentiation)
        if self.verbose: print("=> Creating chunk placeholder container...")

        data_dict = {
            'SCENARIO': self.processVector(scenario, max_arg_len),
            'MODELSEGMENT': self.processVector(model_segment, max_arg_len),
            'PERIODDATE': self.processVector(period_date, max_arg_len),
            'VINTAGE': pd.to_datetime(self.processVector(vintage, max_arg_len)),
            'RATETYPE': self.processVector(rate_type, max_arg_len),
            'FEESANDEXPENSESLINEITEM': self.processVector(fees_and_expenses_line_item, max_arg_len),
            'ASSOCIATEDG_L_ITEM': self.processVector(associated_GL_item, max_arg_len),
            'TRANSFORMATION': self.processVector(transformation, max_arg_len),
            'PERIODLAG': self.processVector(period_lag, max_arg_len),
            'RATENAME': self.processVector(rate_name, max_arg_len),
            'MODELOUTPUTRATE': self.processVector(model_output_rate, max_arg_len),
            'UNCERTAINTYADJUSTMENTRATE': self.processVector(uncertainty_adjustment_rate, max_arg_len),
            'MGMTADJUSTMENTRATE': self.processVector(mgmt_adjustment_rate, max_arg_len),
            'IDIOSYNCRATICRATE1': self.processVector(idiosyncratic_rate_1, max_arg_len),
            'IDIOSYNCRATICRATE2': self.processVector(idiosyncratic_rate_2, max_arg_len),
            'IDIOSYNCRATICRATE3': self.processVector(idiosyncratic_rate_3, max_arg_len),
            'IDIOSYNCRATICRATE4': self.processVector(idiosyncratic_rate_4, max_arg_len),
            'IDIOSYNCRATICRATE5': self.processVector(idiosyncratic_rate_5, max_arg_len),
            'ADJUSTMENT_OVERLAY_JUST': self.processVector(adjustment_overlay_justification, max_arg_len)
        }
        if self.verbose: print(data_dict)
        # df_to_append = pd.DataFrame(
        #     data_dict
        # )

        # Append data
        for record in pd.DataFrame(data_dict).to_dict(orient='records'):
            self.__data.append(
                record
            )
        # self.__data = list(itertools.chain(self.__data, df_to_append.to_dict(orient='records')))
        # self.__data = list(
        #     itertools.chain(
        #         self.__data,
        #         pd.DataFrame(data_dict).to_dict(
        #             orient='records'
        #         )
        #     )
        # )

        # Return data
        return(True)

    def addCFChunk(
        self,
        as_of_date,

        forecast_periods,
        forecast_periods_frequency,
        vintage_differentiation,

        model_segment,
        scenario,
        rate_name,
        rate_type,
        model_output_rate,
        uncertainty_adjustment_rate,
        mgmt_adjustment_rate,
        vintage_differentiation_shift: bool = False,
        transformation='No Transformation',
        fees_and_expenses_line_item='',
        associated_GL_item='',
        period_lag=0,
        idiosyncratic_rate_1=0,
        idiosyncratic_rate_2=0,
        idiosyncratic_rate_3=0,
        idiosyncratic_rate_4=0,
        idiosyncratic_rate_5=0,
        adjustment_overlay_justification='',
        EAD_available_line=None,
        EAD_total_line=None,
        process_additional_ead: bool= True,
        meta_origin=None,
        meta_content=None
    ):
        if self.__verbose: print('=> Creating new contributor file chunk...')



        # Validate chunk inputs
        if self.__verbose: print("=> Validating chunk inputs...")

        # Validating input as_of_date
        self.__isValidAsOfDate(as_of_date)

        # Validating input forecast_periods
        self.__isValidForecastPeriods(
            some_forecast_periods=forecast_periods,
            some_forecast_periods_frequency=forecast_periods_frequency
        )

        # Validating input vintage
        # self.__isValidVintage(vintage=vintage)

        # Validating data types
        utilities.checkDataType(model_segment,(list,str))
        utilities.checkDataType(scenario, (list,str))
        utilities.checkDataType(rate_name, (list,str))
        utilities.checkDataType(rate_type, (list,int))
        utilities.checkDataType(vintage_differentiation, bool)
        utilities.checkDataType(vintage_differentiation_shift, bool)
        utilities.checkDataType(model_output_rate, (list,float,int))
        utilities.checkDataType(uncertainty_adjustment_rate, (list,int,float))
        utilities.checkDataType(mgmt_adjustment_rate, (list,float,int))
        utilities.checkDataType(transformation, (list,str))
        utilities.checkDataType(fees_and_expenses_line_item,(list,str))
        utilities.checkDataType(associated_GL_item, (list,str))
        utilities.checkDataType(period_lag, (list,int))
        utilities.checkDataType(idiosyncratic_rate_1, (list,float,int))
        utilities.checkDataType(idiosyncratic_rate_2, (list,float,int))
        utilities.checkDataType(idiosyncratic_rate_3, (list,float,int))
        utilities.checkDataType(idiosyncratic_rate_4, (list,float,int))
        utilities.checkDataType(idiosyncratic_rate_5, (list,float,int))
        utilities.checkDataType(adjustment_overlay_justification, (list,str))
        utilities.checkDataType(process_additional_ead, bool)
        if meta_origin is not None:
            utilities.checkDataType(meta_origin, (str))
        if meta_content is not None:
            utilities.checkDataType(meta_content, (str))
        if self.__verbose: print("=> Chunk inputs validated.")

        # Create initial placeholder data for contributor file (no vintage differentiation)
        if self.__verbose: print("=> Creating chunk placeholder container...")

        data_dict = {
            'SCENARIO': self.processVector(scenario, forecast_periods),
            'MODELSEGMENT': self.processVector(model_segment, forecast_periods),
            'PERIODDATE': utilities.generateDateSequence(
                as_of_date=as_of_date,
                forecast_periods=forecast_periods,
                m_interval=self.__period_freq_map[forecast_periods_frequency]
            ),
            'VINTAGE': pd.to_datetime(self.processVector(as_of_date, forecast_periods)),
            'RATETYPE': self.processVector(rate_type, forecast_periods),
            'FEESANDEXPENSESLINEITEM': self.processVector(fees_and_expenses_line_item, forecast_periods),
            'ASSOCIATEDG_L_ITEM': self.processVector(associated_GL_item, forecast_periods),
            'TRANSFORMATION': self.processVector(transformation, forecast_periods),
            'PERIODLAG': self.processVector(period_lag, forecast_periods),
            'RATENAME': self.processVector(rate_name, forecast_periods),
            'MODELOUTPUTRATE': self.processVector(model_output_rate, forecast_periods),
            'UNCERTAINTYADJUSTMENTRATE': self.processVector(uncertainty_adjustment_rate, forecast_periods),
            'MGMTADJUSTMENTRATE': self.processVector(mgmt_adjustment_rate, forecast_periods),
            'IDIOSYNCRATICRATE1': self.processVector(idiosyncratic_rate_1, forecast_periods),
            'IDIOSYNCRATICRATE2': self.processVector(idiosyncratic_rate_2, forecast_periods),
            'IDIOSYNCRATICRATE3': self.processVector(idiosyncratic_rate_3, forecast_periods),
            'IDIOSYNCRATICRATE4': self.processVector(idiosyncratic_rate_4, forecast_periods),
            'IDIOSYNCRATICRATE5': self.processVector(idiosyncratic_rate_5, forecast_periods),
            'ADJUSTMENT_OVERLAY_JUST': self.processVector(adjustment_overlay_justification, forecast_periods)
        }

        placeholder = pd.DataFrame(
            data=data_dict
        )

        if (rate_name == 'EAD') and process_additional_ead:
            if self.verbose: print("=> Creating additional EAD chunks...")
            # Create dict of EAD vectors
            temp_dict = EAD_LEQ_SEGMENT_KEYS.copy()

            # Check valid additional EAD/LEQ inputs
            if (EAD_available_line is not None) & (EAD_total_line is not None):
                raise ValueError("`EAD_available_line` and `EAD_total_line` cannot both have a not None value.")
            elif (EAD_available_line is not None) & (EAD_total_line is None):
                # Check data types
                utilities.checkDataType(EAD_available_line, (list, float, int))

                # Override EADAVAILABLELINE values in dict of EAD vectors
                temp_dict["EADAVAILABLELINE"] = EAD_available_line
            elif (EAD_available_line is None) & (EAD_total_line is not None):
                # Check data types
                utilities.checkDataType(EAD_total_line, (list, float, int))

                # Override EADAVAILABLELINE values in dict of EAD vectors
                temp_dict["EADTOTALLINE"] = EAD_total_line
            else:
                pass

            for key in temp_dict.keys():
                data_dict_temp = data_dict.copy()
                data_dict_temp["RATENAME"] = key
                data_dict_temp["MODELOUTPUTRATE"] = self.processVector(temp_dict[key], forecast_periods)
                data_dict_temp["MODELSEGMENT"] = self.processVector(
                    model_segment.replace("EAD", key) if "EAD" in model_segment else model_segment,
                    forecast_periods
                )
                if self.verbose: print(data_dict_temp)
                self.__data = list(
                    itertools.chain(
                        self.__data,
                        pd.DataFrame(data_dict_temp).to_dict(
                            orient='records'
                        )
                    )
                )

        # Process vintage differentiation only when starting vintage is NA
        if (vintage_differentiation and (not vintage_differentiation_shift)):
            if self.__verbose: print("=> Processing vintage differentiation...")

            placeholder_v_diff = copy.deepcopy(placeholder)
            for idx in range(forecast_periods):
                new_vintage = placeholder[
                    placeholder['PERIODDATE'] >= utilities.addMonths2date(
                        min(placeholder['PERIODDATE']),
                        idx * self.__period_freq_map[forecast_periods_frequency]
                    )
                ].drop('VINTAGE', axis=1)
                new_vintage['VINTAGE'] = min(new_vintage['PERIODDATE'])
                new_vintage.reset_index(drop=True, inplace=True)
                placeholder_v_diff = placeholder_v_diff.append(new_vintage)

            # Check chunk length
            if self.__verbose: print("=> Checking final CF chunk length...")

            if len(placeholder_v_diff) == self.expectedCFLength(forecast_periods,True):
                # self.__data = list(
                #     itertools.chain(self.__data, placeholder_v_diff.to_dict(orient='records'))
                # )
                for record in placeholder_v_diff.to_dict(orient='records'):
                    self.__data.append(
                        record
                    )
            else:
                raise Exception(
                    "Invalid length of contributor file chunk [{}]. Expected [{}].".format(
                        str(len(placeholder_v_diff)),
                        str(self.expectedCFLength(forecast_periods,True))
                    )
                )
        elif vintage_differentiation and vintage_differentiation_shift:
            if self.__verbose: print("=> Processing vintage differentiation with shift...")
            # function to add one month to datetime
            shift1Month = lambda d: utilities.addMonths2date(d, 1)
            
            # placeholder for data with vintage differentiation
            placeholder_v_diff = copy.deepcopy(placeholder)
            for idx in range(forecast_periods):
                if idx == 0:
                    new_vintage = copy.deepcopy(placeholder)
                    vintage_date = utilities.addMonths2date(as_of_date, 1)
                else:
                    vintage_date = utilities.addMonths2date(vintage_date, 1)
                    new_vintage = new_vintage.iloc[:-1].drop('VINTAGE', axis=1)
                    new_vintage['PERIODDATE'] = new_vintage['PERIODDATE'].apply(shift1Month)
                new_vintage['VINTAGE'] = vintage_date
                new_vintage.reset_index(drop=True, inplace=True)
                placeholder_v_diff = placeholder_v_diff.append(new_vintage)

            # Check chunk length
            if self.__verbose: print("=> Checking final CF chunk length...")

            if len(placeholder_v_diff) == self.expectedCFLength(forecast_periods,True):
                # self.__data = list(
                #     itertools.chain(self.__data, placeholder_v_diff.to_dict(orient='records'))
                # )
                for record in placeholder_v_diff.to_dict(orient='records'):
                    self.__data.append(
                        record
                    )
            else:
                raise Exception(
                    "Invalid length of contributor file chunk [{}]. Expected [{}].".format(
                        str(len(placeholder_v_diff)),
                        str(self.expectedCFLength(forecast_periods,True))
                    )
                )
        else:
            # Check chunk length
            if self.__verbose: print("=> Checking final CF chunk length...")

            if len(placeholder) == self.expectedCFLength(forecast_periods, False):
                # self.__data = list(
                #     itertools.chain(self.__data, placeholder.to_dict(orient='records'))
                # )
                for record in placeholder.to_dict(orient='records'):
                    self.__data.append(
                        record
                    )
            else:
                raise Exception(
                    "Invalid length of contributor file chunk [{}]. Expected [{}].".format(
                        str(len(placeholder)),
                        str(self.expectedCFLength(forecast_periods, False))
                    )
                )

        if self.__verbose: print("=> Contributor file chunk generation completed.")

        return(True)


class CFCheckerResponse:
    """
    This class provides an abstraction of the response information that a CF
    checker function performs.
    ---------------------------------------------------------------------------
    """
    # Properties
    __check_type = None  # distribution or individual
    __check_name = None  # check title
    __subset = None      # 'ALL' or some subset
    __field_name = None
    __source_filename = None
    __check = None
    __response = True  # default is True for the checker response
    __message = None

    def __init__(
        self,
        check_type=None,
        check_name=None,
        subset=None,
        field_name=None,
        source_filename=None,
        check=None
    ):
        self.__check_type = check_type
        self.__check_name = check_name
        self.__subset = subset
        self.__field_name = field_name
        self.__source_filename = source_filename
        self.__check = check
        self.__location = [np.nan]

    def __str__(self):
        return str(self.getDict())

    def getDict(self):
        return {
            "check_type": self.__check_type,
            "check_name": self.__check_name,
            "subset": self.__subset,
            "field_name": self.__field_name,
            "source_filename": self.__source_filename,
            "check": self.__check,
            "location": self.__location,
            "response": self.__response,
            "message": self.__message
        }

    def setResponse(self, response):
        if isinstance(response, bool):
            self.__response = response
        else:
            raise TypeError('Input value is not an instance of type bool')

    def getResponse(self):
        return(self.__response)

    def setMessage(self, message):
        if isinstance(message, str):
            self.__message = message
        else:
            raise TypeError('Input value is not an instance of type str')

    def addLocation(self, location):
        if isinstance(location, int):
            if location not in self.__location:
                self.__location.append(location)
            
            # Remove Numpy nan's from location array
            if np.nan in self.__location: 
                self.__location = [i for i in self.__location if not pd.isnull(i)]
        else:
            raise TypeError('Input value ' + str(type(location)) + ' is not an instance of int')


class CFChecker:
    """
    This class defines a log object where all messages from the checker will be
    stored.
    ---------------------------------------------------------------------------
    """
    # Properties
    __log_data = None
    __run_id = None
    __run_datetime = None
    __user = None
    __cf_type = None
    __run_name = None
    __as_of_date = None
    __working_directory = None
    __scenario = None
    __requirements_file_path = None
    __requirements_file_sheetname = None
    __forecast_periods = None
    __primary_key = None
    __header_list = None
    __requirements = None

    def __init__(
        self, 
        group,
        cf_type,
        run_name,
        as_of_date,
        forecast_periods,
        working_directory=None,
        scenario=None,
        requirements_file_path=CONFIG['CONTRIBUTOR_FILE']['CHECKER_REQUIREMENTS_FILE_PATH'],
        requirements_file_sheetname=CONFIG['CONTRIBUTOR_FILE']['CHECKER_REQUIREMENTS_FILE_SHEETNAME'],
        primary_key=CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS,
        header_list=CONTRIBUTOR_DATA_DATE_FIELDS,
        auto_check=False
    ):
        self.__run_datetime = datetime.datetime.now()
        self.__user = getpass.getuser()
        self.__scenario = scenario
        self.__group = group
        self.__cf_type = cf_type
        self.__run_name = run_name
        self.__run_id = self.__group+'-'+self.__cf_type+'-'+self.__run_name+'-'+self.__scenario
        
        if isinstance(as_of_date, datetime.datetime):
            self.__as_of_date = as_of_date
        else:
            raise TypeError('Wrong input as_of_date type. Use datetime.datetime instance.')
            
        if os.path.exists(working_directory):
            self.__working_directory = working_directory
        else:
            raise OSError('Invalid input <working_directory>. Path does NOT exist or is not reachable')
        
        if os.path.exists(working_directory):
            self.__requirements_file_path = requirements_file_path
        else:
            raise OSError('Invalid input <requirements_file_path>. Path does NOT exist or is not reachable')

        self.__requirements_file_sheetname = requirements_file_sheetname
        
        if isinstance(primary_key, list):
            self.__primary_key = primary_key
        else:
            raise TypeError('Wrong input <primary_key> type. Expects a list instance.')
            
        if forecast_periods in [27,36,45]:
            self.__forecast_periods = forecast_periods
        else:
            raise ValueError('Invalid input <forecast_periods>. Expects 27, 36 or 45.')
            
        if isinstance(header_list, list):
            self.__header_list = header_list
        else:
            raise TypeError('Wrong input <header_list> type. Expects a list instance.')
            
        # Load requirements
        self.loadCFRequirements()
        
        # Automatic check
        if auto_check:
            self.checkCFDirectory()

    def __del__(self):
        class_name = self.__class__.__name__
        print(class_name+"destroyed")

    def __repr__(self):
        return '<%s.%s object at %s>' % (
            self.__class__.__module__,
            self.__class__.__name__,
            hex(id(self))
        )

    def __str__(self):
        return 'CFCheckerLog (User : %s, Run_ID : %s, Time : %s)' % (
            self.__user,
            self.__run_id,
            self.__run_datetime.strftime("%Y-%m-%d %H:%M"))

    def getLogData(self):
        if self.__log_data is None:
            raise Exception('Please run the checker. <log_data> is null.')
        elif self.__log_data.empty:
            raise Exception('<log_data> is empty. Check input values and requirements.')
        else:
            return(self.__log_data)

    def addRecord(self, cf_response_instance):
        response_record = cf_response_instance.getDict()
        response_record['GROUP'] = self.__group
        response_record['CF_TYPE'] = self.__cf_type
        response_record['RUN_NAME'] = self.__run_name
        response_record['SCENARIO'] = self.__scenario
        response_record['RUN_DATETIME'] = self.__run_datetime
        response_record['USER'] = self.__user

        # Initialize log
        if self.__log_data is None:
            self.__log_data = pd.DataFrame(columns=response_record.keys())
        
        # Log record
        self.__log_data = self.__log_data.append(
            pd.DataFrame.from_dict(response_record)   
        )

        # Check if valid
        return True
    
    def loadCFRequirements(self):
        # Loading Requirements
        requirements_temp = pd.read_excel(
            io=self.__requirements_file_path,
            sheetname=self.__requirements_file_sheetname
        )
        requirements = requirements_temp[
            (requirements_temp['group']==self.__group) & 
            (requirements_temp['cf_type']==self.__cf_type) &
            (requirements_temp['run_name']==self.__run_name)
        ]
        
        if requirements.empty:
            raise ValueError('Requirements subset is empty. Review input group, cf_type and run_name.')
        else:
            self.__requirements = requirements
            return(True)

    # def checkCF(
    #     self,
    #     cf: ContributorFile,
    #     debug: bool = False
    # ):
    #     # Initialize ContributorFile instance
    #     if debug:
    #         print("Checking file contributor data...")
    #
    #     ## ------------ ##
    #     ## CHECKS START ##
    #     ## ------------ ##
    #
    #     # Check header completeness
    #     header_completeness_response = cf.checkCFHeadersCompleteness()
    #     self.addRecord(cf_response_instance=header_completeness_response)
    #     if not header_completeness_response.getResponse():
    #         raise ValueError('Header Completeness check for contributor data failed.')
    #
    #     # Check header order
    #     self.addRecord(cf_response_instance=cf.checkCFHeadersOrder())
    #
    #     # Check CF integrity (duplicates)
    #     self.addRecord(cf_response_instance=cf.checkCFIntegrity())
    #
    #     # Custom checks
    #     for index, row in self.__requirements.iterrows():
    #         if debug:
    #             print(
    #                 '>>> Checking [' +
    #                 row['field_name'] +
    #                 '] for ' +
    #                 row['check_name'] +
    #                 ':' +
    #                 str(row['check']) +
    #                 ' @ ' +
    #                 row['subset'] +
    #                 ' ...'
    #             )
    #         if row['check_name'] in ALLOWED_DISTRIBUTION_CHECK_NAMES:
    #             self.addRecord(
    #                 cf_response_instance=cf.checkCFFieldDistribution(
    #                     field_name=row['field_name'],
    #                     subset=row['subset'],
    #                     check=row['check'],
    #                     error_message=row['error_message'],
    #                     check_name=row['check_name']
    #                 )
    #             )
    #
    #         elif row['check_name'] in ALLOWED_INDIVIDUAL_CHECK_NAMES:
    #             if row['check_name'] in ['value']:
    #                 check = str(row['check']).split(',')
    #             else:
    #                 check = row['check']
    #             self.addRecord(
    #                 cf_response_instance=cf.checkCFFieldItem(
    #                     field_name=row['field_name'],
    #                     subset=row['subset'],
    #                     check=check,
    #                     error_message=row['error_message'],
    #                     check_name=row['check_name']
    #                 )
    #             )
    #
    #         else:
    #             raise ValueError('Invalid input <check_name>.')
        
    def checkCFDirectory(self, debug=False):        
        # Search check files
        file_regex=re.compile('(' + self.__group + '.csv)$', re.IGNORECASE)
        if debug:        
            print("File REGEX: "+str(file_regex))
        dir_ls = os.listdir(self.__working_directory)
        files_to_check = [x for x in dir_ls if file_regex.search(x)]
        if debug:        
            print("Files to check: "+str(files_to_check))
        
        for file in files_to_check:
            # Initialize ContributorFile instance
            if debug:        
                print("Checking file: "+str(file))
            
            cf = ContributorFile(
                dir_path=self.__working_directory,
                filename=file
            )
            
            ## ------------ ##
            ## CHECKS START ##
            ## ------------ ##
            if debug:
                main_message = 'Checking file ['+file+']'
                print('='*len(main_message))
                print(main_message)
                print('='*len(main_message))
            
            # Check header completeness
            header_completeness_response = cf.checkCFHeadersCompleteness()
            self.addRecord(cf_response_instance=header_completeness_response)
            if not header_completeness_response.getResponse():
                print('Header Completeness check for file ' + file + ' failed.')
                break
            
            # Check header order
            self.addRecord(cf_response_instance=cf.checkCFHeadersOrder())
            
            # Check CF integrity (duplicates)
            self.addRecord(cf_response_instance=cf.checkCFIntegrity())
            
            # Custom checks
            for index,row in self.__requirements.iterrows():
                if debug:
                    print(
                        '>>> Checking [' + 
                        row['field_name'] + 
                        '] for ' + 
                        row['check_name'] + 
                        ':' +
                        str(row['check']) +
                        ' @ ' + 
                        row['subset'] + 
                        ' ...'
                    )
                if row['check_name'] in ALLOWED_DISTRIBUTION_CHECK_NAMES:
                    self.addRecord(
                        cf_response_instance = cf.checkCFFieldDistribution(
                            field_name=row['field_name'],
                            subset=row['subset'],
                            check=row['check'],
                            error_message=row['error_message'],
                            check_name=row['check_name']
                        )
                    ) 
                    
                elif row['check_name'] in ALLOWED_INDIVIDUAL_CHECK_NAMES:
                    if row['check_name'] in ['value']:
                        check = str(row['check']).split(',')
                    else:
                        check = row['check']
                    self.addRecord(
                        cf_response_instance = cf.checkCFFieldItem(
                            field_name=row['field_name'],
                            subset=row['subset'],
                            check=check,
                            error_message=row['error_message'],
                            check_name=row['check_name']
                        )
                    )         

                else:
                    raise ValueError('Invalid input <check_name>.')
        
    def toCSV(self, output_file_path):
        if '.csv' not in output_file_path:
            raise ValueError('output_file_path requires a specified csv full file path.')
        self.__log_data.to_csv(output_file_path, index=False)

    def toExcel(self, output_file_path):
        self.__log_data.to_excel(
            output_file_path,
            sheet_name=self.__run_id + " CHECKER LOG"
        )
        return True
        

class ContributorFile:
    """
    This class defines a contributor file object used as input for the
    SAS Engine that aggregates the CCAR exercise results.
    ---------------------------------------------------------------------------
    """
    # Properties
    __dir_path = None
    __filename = None
    __primary_key = None
    __date_fields = None
    __header_list = None
    __data = None
    __sep_char = None

    def __init__(
        self,
        primary_key=CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS,
        date_fields=CONTRIBUTOR_DATA_DATE_FIELDS,
        header_list=CONTRIBUTOR_DATA_HEADER_NAMES,
        data=None,
        dir_path=None,
        filename=None,
        sep_char=','
    ):
            # Assign to class properties
            self.__primary_key = primary_key
            self.__date_fields = date_fields
            self.__header_list = header_list
            self.sep_char = sep_char

            # Read contributor file from input path
            if (dir_path==None) or (filename==None):
                if data is not None:
                    self.__data = data
                else:
                    raise ValueError("No CF data was provided.")
#                if not isinstance(data, pd.DataFrame):
#                    raise Exception("`data` argument was NOT provided.")
#                else:
#                    self.__data = data
            else:
                if dir_path[-1]=='/':
                    self.__dir_path = dir_path.strip()
                else:
                    self.__dir_path = dir_path.strip()+'/'
                self.__filename = filename.strip()
                self.__data = self.readCSV(
                    path_to_cf=self.__dir_path + self.__filename,
                    sep_char=self.sep_char
                )

    # Getters
    def getCFData(self):
        return(self.__data)

    def getDirPath(self):
        return(self.__dir_path)

    def getFileName(self):
        return(self.__filename)

    def getPrimaryKey(self):
        return(self.__primary_key)

    def getHeaderList(self):
        return(self.__header_list)

    def getUniqueModelSegments(self,filter=True):
        if filter:
            return(
                [ms for ms in list(self.__data['MODELSEGMENT'].unique()) if bool(re.search(pattern='^[A-Z]+(_)[0-9]+$', string=ms, flags=re.IGNORECASE))]
            )
        else:
            return(list(self.__data['MODELSEGMENT'].unique()))

    def getUniqueVintageDates(self, stringify=True):
        if stringify:
            return(
                [utilities.date2str(i) if not pd.isnull(i) else "AS_OF_DATE" for i in
                 list(pd.to_datetime(list(self.__data['VINTAGE'].unique())))]
            )
        else:
            return(
                list(pd.to_datetime(list(self.__data['VINTAGE'].unique())))
            )

    def getUniqueScenarios(self):
        return(
            list(self.__data['SCENARIO'].unique())
        )
        
    def readCSV(self, path_to_cf, sep_char=','):
        """
        This function returns a pandas DataFrame object from a csv file.
        ---------------------------------------------------------------------------
     
        Parameters
        ----------
            path_to_cf (str) : address of the contributor file
            sep_char (str) : optional text file separation character
        Returns
        -------
            (DataFrame) : a Pandas Dataframe instance
        """
        try:
            data = pd.read_csv(
                filepath_or_buffer=path_to_cf,
                sep=sep_char,
                keep_default_na = False,
                na_values = ['nan', 'NaN', 'NULL', 'null', 'NA', 'N\A', '#N\A', 'None', 'none',''],
                encoding='utf-8'    ,
                date_parser=utilities.str2date,
                parse_dates=self.__date_fields
            )
        except IOError:
            raise Exception("File '" + path_to_cf + "' does not exist")
        
        # Clean BOM characters
        data.columns = [s.replace('\ufeff','').upper() for s in data.columns]
        data.replace('.', np.nan, inplace=True)
        
        # Return results
        return data
        
    def toCSV(self, output_file_path, replace_nan_by_dot=False):
        if '.csv' not in output_file_path:
            raise ValueError('output_file_path requires a specified csv full file path.')
        output_data = self.__data.copy(deep=True)
        if replace_nan_by_dot:
            output_data.replace(np.nan, '.')
        output_data.to_csv(output_file_path, index=False)

    def subsetContributorData(self,scenario, modelsegment, vintage):
        if vintage in ['null', 'NULL', 'None', None, '.', 'NaN', 'NaT','AS_OF_DATE']:
            return (
                self.__data[
                    pd.isnull(self.__data['VINTAGE']) &
                    (self.__data['MODELSEGMENT'] == modelsegment) &
                    (self.__data['SCENARIO'] == scenario)
                ]
            )
        elif isinstance(vintage, datetime.datetime):
            return (
                self.__data[
                    (self.__data['VINTAGE'] == vintage) &
                    (self.__data['MODELSEGMENT'] == modelsegment) &
                    (self.__data['SCENARIO'] == scenario)
                ]
            )
        elif isinstance(vintage, str):
            if bool(
                re.search(
                    pattern='^[0-9]{1,2}[/]{1}[0-9]{1,2}[/]{1}[0-9]{4}$',
                    string=vintage,
                    flags=re.IGNORECASE
                )
            ):
                return (
                    self.__data[
                        (self.__data['VINTAGE'] == utilities.str2date(vintage)) &
                        (self.__data['MODELSEGMENT'] == modelsegment) &
                        (self.__data['SCENARIO'] == scenario)
                    ]
                )
        else:
            return None


    def plotCFModelSegment(
        self,
        model_segment_dict,
        show_plot=False,
        output_file_path=None,
        bytes_buffer=None,
        debug=False
    ):
        # matplotlib.pyplot.clf()
        matplotlib.style.use('fivethirtyeight')
        plt.ioff()
        fig = plt.figure(figsize=(16, 9))
        plt.clf()
        
        def to_percent(y, position):
            # Ignore the passed in position. This has the effect of scaling the default
            # tick locations.
            s = str(100 * y)
        
            # The percent symbol needs escaping in latex
            if matplotlib.rcParams['text.usetex'] is True:
                return s + r'$\%$'
            else:
                return s + '%'
        
        legend_tags = []
        for scenario in model_segment_dict.keys():
            for model_segment in model_segment_dict[scenario].keys():
                for vintage in model_segment_dict[scenario][model_segment]:
                    if debug:
                        print(' - '.join([scenario, model_segment, str(vintage)]))
                    
                    subset = self.subsetContributorData(
                        scenario=scenario,
                        modelsegment=model_segment,
                        vintage=vintage
                    )
                    if (subset is not None) & (not subset.empty):
                        if debug:
                            print('Not None or empty.')
                        if isinstance(subset,pd.DataFrame):
                            if debug:
                                print('Is a Pandas DataFrame. Plotting...')

                            legend_tags.append(scenario + '-' + model_segment + '-[' + str(vintage) + ']')
                            plt.plot(
                                subset['PERIODDATE'],
                                subset['MODELOUTPUTRATE']
                            )
        if debug:
            print('Adding legend.')
        plt.xticks(fontsize=10)
        plt.yticks(fontsize=10)
        plt.legend(legend_tags, loc='upper right', prop={'size':10})
        plt.gca().yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(to_percent))
        manager = plt.get_current_fig_manager()
        plt.grid(False)

        if show_plot:
            manager.window.showMaximized()
            plt.show()
        if (bytes_buffer is not None) & isinstance(bytes_buffer, io.BytesIO):
            fig.savefig(bytes_buffer, format='png')
            # plt.close()
        if output_file_path is not None:
            fig.savefig(output_file_path, dpi=200, format='png')
            # plt.close()

    def enforceCFIntegrity(self):
        self.__data = self.__data.drop_duplicates(
            subset=self.__primary_key
        )
        return(True)

    def checkCFIntegrity(self, enforce=False):
        """
        This function checks a contributor file for duplicates given a primary
        key. IF `enforce` is set True, duplicates will be removed
        from the object instance data property.
        -----------------------------------------------------------------------

        Returns
        -------
            (CFCheckerResponse) : returns CF checker response object instance
        """
        # Initialize returned object
        response = CFCheckerResponse(
            check_type=None,
            check_name='duplicates',
            subset='ALL',
            field_name=None,
            source_filename=self.__filename,
            check='duplicates'
        )

        dups = self.__data.duplicated(subset=self.__primary_key, keep=False)
        dups_index = list(dups[dups==True].index)
        if len(dups_index)>0:
            response.setResponse(False)
            response.setMessage("Found "+str(len(dups_index))+" duplicates")
            for loc in dups_index:
                response.addLocation(int(loc))

        if enforce:
            self.enforceCFIntegrity()

        # Return results
        return(response)

    def enforceCFHeaderOrder(self):
        self.__data = self.__data[self.__header_list]
        return(True)

    def checkCFHeadersOrder(self, enforce=False):
        """
        This function checks the order of headers in a contributor file given
        some specifications.
        -----------------------------------------------------------------------

        Returns
        -------
            (CFCheckerResponse) : returns CF checker response object instance
        """

        # Initialize returned object
        response = CFCheckerResponse(
            check_type=None,
            check_name='headers order',
            subset='ALL',
            field_name=None,
            source_filename=self.__filename,
            check='headers'
        )

        # Check for order
        if(list(self.__data.columns) != list(self.__header_list)):
            response.setResponse(False)
            response.setMessage("Incorrect order of headers")

        if enforce:
            self.enforceCFHeaderOrder()

        # Return results
        return(response)

    def checkCFHeadersCompleteness(self):
        """
        This function checks the completeness of headers in a contributor file
        given some specifications.
        -----------------------------------------------------------------------

        Returns
        -------
            (CFCheckerResponse) : returns CF checker response object instance
        """

        # Initialize returned object
        response = CFCheckerResponse(
            check_type=None,
            check_name='headers completeness',
            subset='ALL',
            field_name=None,
            source_filename=self.__filename,
            check='headers'
        )

        # Get current CF header list and remove potential BOM character for first header name
        cf_h_set = set(self.__data.columns)

        # Check for completeness
        diff_set_union = list(
            set(cf_h_set)-set(self.__header_list)
            or
            set(self.__header_list)-set(cf_h_set)
        )

        if(len(diff_set_union) != 0):
            response.setResponse(False)
            response.setMessage("Incomplete set of headers with errors for " +
                str(diff_set_union))

        # Return results
        return(response)

    def checkCFFieldDistribution(
        self,
        field_name,
        subset,
        check,
        error_message,
        check_name,
        round_precision=4
    ):
        """
        This function checks the class of a pandas DataFrame vector.
        -----------------------------------------------------------------------

        Args
        ----
            field_name (str) : field in to check in contributor file
            subset (str) : a string to be evaluated to subset the CF data
            check (str) : string containing check logic
            error_message (str) : message to return in case check fails
            check_name (str) : the name of the check in the requirements.json
                                file, optional

        Returns
        -------
            (CFCheckerResponse) : returns CF checker response object instance
        """
        # Initialize returned object
        response = CFCheckerResponse(
            check_type='distribution',
            check_name=check_name,
            subset=subset,
            field_name=field_name,
            source_filename=self.__filename,
            check=check
        )

        # Check null values
        if check is None or error_message is None:
            return(response)

        # Subset contributor file
        data = copy.deepcopy(self.__data)
        if subset not in NEUTRAL_SUBSETS:
            data = data[eval(subset)]
        if data.empty:
            response.setMessage("Data has no records. Could be an empty subset.")
            return(response)

        if field_name in data.columns:
            field = data[field_name]
        else:
            raise KeyError("KeyError for key '"+field_name+"' in input cf.")

        if check_name == 'class':
            # #################################################################
            # Test CLASS
            try:
                mapped_types = PYTHON_NATIVE_TO_DTYPE[check]
                if str(field.dtype) not in mapped_types:
                    response.setResponse(False)
                    response.setMessage(error_message)
            except KeyError:
                response.setResponse(False)
                response.setMessage("KeyError for key '" +
                    check + "' in dtype_map.")
            # #################################################################

        elif check_name == 'mean':
            # #################################################################
            # Test MEAN
            if str(field.dtype) not in PYTHON_NATIVE_TO_DTYPE['numeric']:
                raise Exception("Input field is of non-numeric type " +
                    str(field.dtype))

            if not eval("round(field.mean(),"+str(int(round_precision))+")"+str(check)):
                response.setResponse(False)
                response.setMessage(error_message)
            # #################################################################
                
        elif check_name == 'norm_mean':
            # #################################################################
            # Test NORMALIZED MEAN (MEAN/STDEV)
            if str(field.dtype) not in PYTHON_NATIVE_TO_DTYPE['numeric']:
                raise Exception("Input field is of non-numeric type " +
                    str(field.dtype))

            if not eval("round(field.mean()/field.std(ddof=0),"+str(int(round_precision))+")"+str(check)):
                response.setResponse(False)
                response.setMessage(error_message)
            # #################################################################

        elif check_name == 'stdev':
            # #################################################################
            # Test STDEV
            if str(field.dtype) not in PYTHON_NATIVE_TO_DTYPE['numeric']:
                raise Exception("Input field is of non-numeric type " +
                    str(field.dtype))

            if not eval("round(field.std(ddof=0),"+str(int(round_precision))+")"+str(check)):
                response.setResponse(False)
                response.setMessage(error_message)
            # #################################################################

        elif check_name == 'distinct_count':
            # #################################################################
            # Test DISTINCT COUNT
            if str(field.dtype) in PYTHON_NATIVE_TO_DTYPE['numeric']:
                raise Exception("Input field is of non-categorical type " +
                    str(field.dtype))

            if not eval("len(field.unique())"+str(check)):
                response.setResponse(False)
                response.setMessage(error_message)
            # #################################################################

        elif check_name == 'mean_distinct_count':
            # #################################################################
            # Test MEAN DISTINCT COUNT
            if str(field.dtype) in PYTHON_NATIVE_TO_DTYPE['numeric']:
                raise Exception("Input field is of non-categorical type " +
                    str(field.dtype))

            if not eval("round(field.value_counts().mean(),"+str(int(round_precision))+")"+str(check)):
                response.setResponse(False)
                response.setMessage(error_message)
            # #################################################################

        elif check_name == 'stdev_distinct_count':
            # #################################################################
            # Test STDEV DISTINCT COUNT
            if str(field.dtype) in PYTHON_NATIVE_TO_DTYPE['numeric']:
                raise Exception("Input field is of non-categorical type " +
                    str(field.dtype))

            if not eval("round(field.value_counts().std(ddof=0),"+str(int(round_precision))+")"+str(check)):
                response.setResponse(False)
                response.setMessage(error_message)
            # #################################################################
                
        elif check_name == 'norm_mean_distinct_count':
            # #################################################################
            # Test MEAN/STDEV OF DISTINCT COUNT
            if str(field.dtype) in PYTHON_NATIVE_TO_DTYPE['numeric']:
                raise Exception("Input field is of non-categorical type " +
                    str(field.dtype))

            if not eval("round(field.value_counts().mean()/field.value_counts().std(ddof=0),"+str(int(round_precision))+")"+str(check)):
                response.setResponse(False)
                response.setMessage(error_message)
            # #################################################################
                
        else:
            raise Exception("Input check_name <" +
                check_name + "> is NOT valid.")
        # Return results
        del(data)
        return(response)

    def checkCFFieldItem(
        self,
        field_name,
        subset,
        check,
        error_message,
        check_name
    ):
        """
        This function checks individual values of a field provided some
        requirement (ex: regex, lower/upper bounds, ...).
        ---------------------------------------------------------------------------

        Args
        ----
            field_name (str) : field in to check in contributor file
            subset (str) : a string to be evaluated to subset the CF data
            check (str) : string containing check logic
            error_message (str) : message to return in case check fails
            check_name (str) : the name of the check in the requirements file, optional

        Returns
        -------
            (CFCheckerResponse) : returns CF checker response object instance
        """
        # Initialize returned object
        response = CFCheckerResponse(
            check_type='individual',
            check_name=check_name,
            subset=subset,
            field_name=field_name,
            source_filename=self.__filename,
            check=check
        )

        # Check null values
        if check is None or error_message is None:
            return(response)

        # Subset contributor file
        data = copy.deepcopy(self.__data)
        if subset not in NEUTRAL_SUBSETS:
            data = data[eval(subset)]
        if data.empty:
            response.setMessage("Data has no records. Could be an empty subset.")
            return(response)

        if field_name in data.columns:
            field = data[field_name]
            field_dtype = str(field.dtype)
        else:
            raise KeyError("KeyError for key '"+field_name+"' in input cf.")


        if check_name == 'regex_pattern':
            # #################################################################
            # Test REGEX PATTERN
            # Process NUMERIC types
            if str(data[field_name].dtype) in PYTHON_NATIVE_TO_DTYPE['numeric']:
                for index, row in data.iterrows():
                    if not bool(re.search(
                        pattern=str(check),
                        string=utilities.float2str(row[field_name]),
                        flags=re.IGNORECASE
                    )):
                        response.setResponse(False)
                        response.addLocation(int(index))
            
            elif str(data[field_name].dtype) in PYTHON_NATIVE_TO_DTYPE['datetime']:
                for index, row in data.iterrows():
                    if not bool(re.search(
                        pattern=str(check),
                        string=utilities.date2str(row[field_name]),
                        flags=re.IGNORECASE
                    )):
                        response.setResponse(False)
                        response.addLocation(int(index))
                        
            # Process CATEGORICAL types
            else:
                for index, row in data.iterrows():
                    if not bool(re.search(
                        pattern=str(check),
                        string=str(row[field_name]),
                        flags=re.IGNORECASE
                    )):
                        response.setResponse(False)
                        response.addLocation(int(index))
            # #################################################################

        elif check_name == 'value_length':
            # #################################################################
            # Test VALUE LENGTH
            # Check for correct numeric datatype
            if field_dtype in PYTHON_NATIVE_TO_DTYPE['numeric']:
                # raise Exception("Input field is of non-categorical type " + field_dtype)
                # Process NUMERIC types
                for index, row in data.iterrows():
                    if not eval("len(str(row[field_name]))"+str(check)):
                        response.setResponse(False)
                        response.addLocation(int(index))
            else:
                # Process CATEGORICAL types
                for index, row in data.iterrows():
                    if not eval("len(row[field_name])"+str(check)):
                        response.setResponse(False)
                        response.addLocation(int(index))
            # #################################################################

        elif check_name == 'upper_bound':
            # #################################################################
            # Test UPPER BOUND
            # Check for correct numeric datatype
            if str(field_dtype) not in PYTHON_NATIVE_TO_DTYPE['numeric+datetime']:
                raise Exception("Input field is of non-numeric or datetime type " +
                    str(field.dtype))
            if not isinstance(eval(str(check)), (int, float, datetime.datetime)):
                raise Exception("Input check is of non-numeric type " +
                    str(type(check)))

            # Process NUMERIC types
            for index, row in data.iterrows():
                if row[field_name] > eval(str(check)):
                    response.setResponse(False)
                    response.addLocation(int(index))
            # #################################################################

        elif check_name == 'lower_bound':
            # #################################################################
            # Test LOWER BOUND
            # Check for correct numeric datatype
            if str(field_dtype) not in PYTHON_NATIVE_TO_DTYPE['numeric+datetime']:
                raise Exception("Input field is of non-numeric or datetime type " +
                    str(field.dtype))
            if not isinstance(eval(str(check)), (int, float, datetime.datetime)):
                raise Exception("Input check is of non-numeric type " +
                    str(type(check)))

            # Process NUMERIC types
            for index, row in data.iterrows():
                if row[field_name] < eval(str(check)):
                    response.setResponse(False)
                    response.addLocation(int(index))
            # #################################################################

        elif check_name == 'check_na':
            # #################################################################
            # Test NA's
            na_list = list(pd.isnull(field)[pd.isnull(field)==True].index)
            if len(na_list) > 0:
                response.setResponse(False)
                for index in na_list:
                    response.addLocation(int(index))
            # #################################################################

        elif check_name == 'value':
            # #################################################################
            # Test VALUE
            # Check for correct numeric datatype
            if not isinstance(check, list):
                raise Exception("Input check is NOT a list instance")
                
            if field_dtype in PYTHON_NATIVE_TO_DTYPE['numeric']:
                # Process CATEGORICAL types
                for index, row in data.iterrows():
                    if row[field_name] not in [utilities.str2numeric(i) for i in check]:
                        response.setResponse(False)
                        response.addLocation(int(index))
            else:
                # Process CATEGORICAL types
                for index, row in data.iterrows():
                    if row[field_name] not in check:
                        response.setResponse(False)
                        response.addLocation(int(index))
            # #################################################################

        else:
            raise Exception("Input check_name <" +
                check_name + "> is NOT valid.")

        # Return results
        del(data)
        if not response.getResponse():
            response.setMessage(error_message)
        return(response)
    
    def testCurrentEnvGetRunSignature(
            self,
            p_reporting_date: datetime.datetime,
            p_run_id: int = 1          
        ):
            ''''
            Change from function above: 
            Use p_run_id instead of p_rerun, p_engine, p_cycle; Use UAT environment; SCHEMA_NAME add '_v2' ;
            '''
            connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][
                CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT']
            ]
            cx_Oracle_DSN = cx_Oracle.makedsn(
                host=connection_strings["HOST_IP"],
                port=connection_strings["ORACLE_PORT"],
                sid=connection_strings["SID"]
            )
            connection = cx_Oracle.connect(
                user=connection_strings["USER_NAME"],
                password=connection_strings["PASSWORD"],
                dsn=cx_Oracle_DSN
            )
            cursor = connection.cursor()
    
            v_run_sig = cursor.var(cx_Oracle.STRING)
            v_part_key = cursor.var(cx_Oracle.STRING)
            cursor.callproc(connection_strings["SCHEMA_NAME"] + "." + 'publish_run_signature', [
                p_reporting_date.strftime("%Y%m%d"),
                p_run_id,
                v_run_sig,
                v_part_key
            ])
    
            return(
                {
                    'partition_key':v_part_key.getvalue(),
                    'run_signature':v_run_sig.getvalue()
                }
            )

    def writeToMoodysRFO(
        self,
        p_reporting_date: datetime.datetime,
        as_of_date: datetime.datetime,
        p_run_id: str = 'N',
        debug: bool = True,
        moodys_rfo_env: str = "UAT_ENV",
        table_name: str =  CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
        contributor_file_id: int = 1,
        file_version: int = 1,
        overwrite_vintage_asofdate: datetime.datetime=None,
        run_signature: str = None,
        partition_key: str = None
    ) -> bool:
        """
        This function inserts contributor data into RFO.

        Parameters
        ----------
        as_of_date
        debug
        moodys_rfo_env
        table_name

        Returns
        -------
        (bool) whether or not the data was inserted correctly
        """

        # Check inputs
        if overwrite_vintage_asofdate is not None:
            utilities.checkDataType(overwrite_vintage_asofdate, datetime.datetime)


        # Connecting to database
        if debug:
            print("Connecting to database...")
        connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][moodys_rfo_env]
        cx_Oracle_DSN = cx_Oracle.makedsn(
            host=connection_strings["HOST_IP"],
            port=connection_strings["ORACLE_PORT"],
            sid=connection_strings["SID"]
        )
        connection = cx_Oracle.connect(
            user=connection_strings["USER_NAME"],
            password=connection_strings["PASSWORD"],
            dsn=cx_Oracle_DSN
        )
        cursor = connection.cursor()

        # Get run parameters
        if debug:
            print("Getting run parameters...")

        if (run_signature == None) and (partition_key == None):
            v_run_sig = cursor.var(cx_Oracle.STRING)
            v_part_key = cursor.var(cx_Oracle.STRING)
            cursor.callproc(connection_strings["SCHEMA_NAME"] + "." + 'publish_run_signature', [
                p_reporting_date.strftime("%Y%m%d"),
                p_run_id,
                v_run_sig,
                v_part_key
            ])
            run_sig  = v_run_sig.getvalue()
            part_key = v_part_key.getvalue()
            
        elif (run_signature != None) or (partition_key != None):
            run_sig = run_signature
            part_key = partition_key  
        else:
            raise ValueError('run_signature and partition_key should be both provided or neither provided')
                      
        # Get data and process additional fields
        self.__data["CONTRIBUTOR_FILE_ID"] = contributor_file_id
        self.__data["FILE_VERSION"] = file_version
        self.__data["RUN_SIGNATURE"] = run_sig
        self.__data["PARTITION_KEY"] = part_key

        # Overwrite vintage date
        if (overwrite_vintage_asofdate is not None) and (p_reporting_date is not None):
            self.__data["VINTAGE"].replace(
                to_replace=as_of_date,
                value=overwrite_vintage_asofdate,
                inplace=True
            )

        # Create SQL insert statement
        if debug:
            print("Creating INSERT statement...")

        def to_sql_array(A: list) -> str:
            """
            This function transforms an input array into a str representation
            of the corresponding SQL array

            Parameters
            ----------
            A: (list) some input array

            Returns
            -------
            (str) str containing the SQL array
            """
            s = '('
            for h in A:
                wrap_char = ""
                s += (wrap_char + str(h) + wrap_char + ',')
            s = s.strip(',')
            s += ')'
            return (s)
        statement = 'INSERT INTO ' + \
                    connection_strings["SCHEMA_NAME"] + "." + table_name + \
                    to_sql_array(self.__data.columns) + \
                    ' VALUES ' + \
                    to_sql_array([':' + str(i) for i in self.__data.columns])
        if debug:
            print("STATEMENT:\n" + statement)

        # Prepare data and replace NAs by None
        if debug:
            print("Transforming data to array of dicts...")
        records_to_insert = list(self.__data.to_dict(orient='records'))
        if len(records_to_insert) != len(self.__data):
            raise Exception("Not all records were converted to array of dictionaries.")

        # Define % counter
        items_to_process = len(records_to_insert)
        #report_breakpoints = list(np.array(list(range(1, 21))) * (items_to_process // 20))

        # Begin insert process
        if debug:
            print("Begin inserting {} records...".format(str(items_to_process)))

        # Begin write process
        t0 = time.time()

        # BEGIN STATEMENT EXECUTION
        try:
            cursor.executemany(statement, records_to_insert)
        except Exception as e:
            cursor.close()
            connection.close()
            raise e
        else:
            # Commit insert operation
            connection.commit()

        # Calculate runtime
        t1 = time.time()
        runtime = round((t1 - t0), 5)
        if debug:
            print("Insert completed!")
            print("Runtime : " + str(runtime) + "s.")

        # Revert vintage date
        if (overwrite_vintage_asofdate is not None) and (p_reporting_date is not None):
            self.__data["VINTAGE"].replace(
                to_replace=overwrite_vintage_asofdate,
                value=as_of_date,
                inplace=True
            )

        # Finalize
        cursor.close()
        connection.close()
        return True

    def checkCoverage(self):
        """
        SELECT
            MV.PD_GROUP_2017,
            MV.FAS114_STATUS,
            MV.UNIQUE_FACILITY_ID,
            MV.PD,
            UPPER(CF.MODELSEGMENT),
            CF.MODELSEGMENT
        FROM MV_LOSS_COMMERCIAL MV
        LEFT JOIN
            (SELECT DISTINCT MODELSEGMENT, RATENAME, MAX(FILE_VERSION)
            FROM STG_CONTRIBUTOR_DATA
            WHERE CONTRIBUTOR_FILE_ID = 1 AND SCENARIO='DR_BASE' AND RATENAME='PD'
            GROUP BY MODELSEGMENT, RATENAME
            ) CF
        ON
            UPPER(MV.PD) = UPPER(CF.MODELSEGMENT)
        WHERE
            CF.MODELSEGMENT IS NULL
            AND
            (
                (
                    MV.FAS114_STATUS = 'A - NOT REQUIRED'
                    AND
                    MV.LOCAL_NPL_FLAG = 'N'
                )
                OR
                MV.TDR = 'Y'
            )
            AND
            MV.ASOFDATE = '30-NOV-2016'
            AND
            UPPER(SOURCEID) NOT IN ('OFFLINE')
            AND
            PD_GROUP_2017 IN ('MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL')


        SELECT SOURCEID, COUNT(UNIQUE_FACILITY_ID) FROM MACCAR.MV_LOSS_COMMERCIAL GROUP BY SOURCEID;

        SELECT SOURCEID, UNIQUE_FACILITY_ID, PD FROM MACCAR.MV_LOSS_COMMERCIAL WHERE UNIQUE_FACILITY_ID = 'INFO LEASE4641946419007-8000000-002';


        SELECT
            SOURCEID,
            UNIQUE_FACILITY_ID,
            PD
        FROM MACCAR.MV_LOSS_COMMERCIAL
        WHERE
            'SB'||UNIQUE_FACILITY_ID <> PD
            AND
            PD NOT LIKE '%PD%'
            AND
            ROWNUM <= 5;

        SELECT DISTINCT
            SOURCEID,
            SUBSTR(UNIQUE_FACILITY_ID,1,LENGTH(SOURCEID)),
            SUBSTR(PD,3,LENGTH(SOURCEID))
        FROM MACCAR.MV_LOSS_COMMERCIAL
        WHERE
            PD NOT LIKE '%PD%';

        Returns
        -------

        """
        pass

def loadJSONRequirements(requirements_file_path, requirements_group):
    """
    This function loads the checker requirements from the json specs.
    It returns a list with of requirements for the specified requirement group.
    ---------------------------------------------------------------------------

    Args
    ----
        requirements_file_path (str) : path to json requirements file
        requirements_group (str) : name of group-defined requirements

    Returns
    -------
        (dict) : dict of `requirements_group` specific requirements.
    """
    with open(requirements_file_path, 'r') as data_file:
        requirements_dict = json.load(fp=data_file, encoding='utf-8',
                                      parse_float=True)
    return requirements_dict[requirements_group]

# End of contributorfile.py