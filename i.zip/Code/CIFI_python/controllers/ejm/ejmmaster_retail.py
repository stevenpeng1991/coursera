"""
SAMPLE USE
----------

#adjustment_dictionary={'MODELSEGMENT':'PD_CARDS', 'RATENAME':'PD', 'MGMTADJUSTMENT':0.7271}
#adjustment_dictionary1={'MODELSEGMENT':'GROSSCHARGEOFF_CARDS', 'RATENAME':'GROSSCHARGEOFF', 'MGMTADJUSTMENT':0.7271}



session = CCARSession(
    session_id='Commercial EJM Test',
    session_date=datetime.datetime(2017,12,31)
)
# create ejm generator instance
commercial_ejm_generator_st = EJMGenerator(
                as_of_date = datetime.datetime(2017,12,31),
                ejm_dictionary=ejmDictionaryGenerator(
                    asofdate = datetime.datetime(2017,12,31),
                    version_date = datetime.datetime(2017,12,31),
                    scenario_pairs = {
                        "STRESS":"FRB_SA",
                        "BASE":"FRB_BASE",
                        "ADVERSE":"FRB_ADVERSE",
                        "BHC_STRESS":"BHC_STRESS",
                        "BHC_ADVERSE":"GLOBAL_STRESS"
                    },
                    pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
                    rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
                    debug=True,
                    logger=session.logger
                ),
                forecast_periods=48,
                process_additional_ead=False,
                debug=True,
                logger=session.logger
            )

                
# ejm disctionary
ejm_dict = commercial_ejm_generator_st.ejm_dictionary

# execute ejm model and generate ejm contributor file
commercial_ejm_generator_st.execute(session=session)

# get contributor file instance check contributor file
#ADD Overlay
#session.contributor_file_generator.retailmanagementAdjustment(adjustment_dictionary=adjustment_dictionary,dataset_query_date=datetime.datetime(2017,6,30),model='EJM')
#session.contributor_file_generator.retailmanagementAdjustment(adjustment_dictionary=adjustment_dictionary1,dataset_query_date=datetime.datetime(2017,6,30),model='EJM')


cf_instance_st = session.contributor_file_generator.generateContributorFileInstance()
cf_instance_st.checkCFIntegrity().getResponse()
ejmcf_data_st = cf_instance_st.getCFData()




cf_instance = session.contributor_file_generator.generateContributorFileInstance()
cf_instance.checkCFIntegrity().getResponse()
ejmcf_data = cf_instance.getCFData()

ejmcf_data_st["PARTITION_KEY"] = 'S00000000419' 
ejmcf_data_st["RUN_SIGNATURE"] = '113017_122756' 
ejmcf_data_st["CONTRIBUTOR_FILE_ID"] = 2
ejmcf_data_st["FILE_VERSION"] = 1


cf_instance.writeToMoodysRFO(
     p_reporting_date= datetime.datetime(2017,12,31),
     moodys_rfo_env="PROD_ENV",
     table_name='STG_CONTRIBUTOR_DATA',
     contributor_file_id=2,
     file_version=1,
     as_of_date=datetime.datetime(2017,12,31),
     overwrite_vintage_asofdate=datetime.datetime(1900,1,31),
     run_signature='113017_122756',
     partition_key='S00000000419'
     )

ejmcf_data_st.to_csv("I:\\CRMPO\\CCAR\\4Q17\\3 - Contributor Files\\Retail\\DryRun2018\\EJM_BHC_STRESS_01252018.csv",date_format="%m/%d/%Y",index=False)










# test overlay
test_overlay = cf[cf['MODELSEGMENT'] == 'SBCHRYSLER6055460554-260554FLOORPLAN']
test_non_overlay = cf[cf['MODELSEGMENT'] == 'SBAFS0052398398005239839800523983980000000018']



"""

import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.session import CCARSession
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.config_retail import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO
import datetime
import pandas as pd
import numpy as np
import time
import copy
import os


def ejmDictionaryGenerator(
    asofdate: datetime.datetime,
    version_date: datetime.datetime,
    scenario_pairs: dict,
    pd_group_field: str,
    rfo_commercial_anchor_tb: str="MACCAR.MV_LOSS_COMMERCIAL",
    rfo_commercial_orig_tb: str="MACCAR.MV_LOSS_COMMERCIAL_ORIG",
    debug: bool=False,
    logger: Logger=None
) -> dict:
    """

    Parameters
    ----------
    asofdate
    scenario_pairs : List of scenario and severity levels : STRESS, ADVERSE, BASE
    pd_group_field
    rfo_commercial_anchor_tb
    rfo_commercial_orig_tb
    debug

    Returns
    -------

    """
                    
    # Validate inputs
    utilities.checkDataType(asofdate, datetime.datetime)
    utilities.checkDataType(version_date, datetime.datetime)

    # Fetch EJM_MASTER data
    if debug:
        print("Fetching EJM_MASTER data...")
    if logger is not None and isinstance(logger, Logger):
            logger.add(
                type='INFO',
                message='Initializing EJM Dictionary Generator...',
                context='EJM Dictionary Generator'
            )

    if logger is not None and isinstance(logger, Logger):
        logger.add(
            type='INFO',
            message='Fetching EJM_MASTER data...',
            context='EJM Dictionary Generator'
        )
    data = pd.read_excel(
        io=CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_PATH"],
        sheetname=CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_SHEETNAME"],
        na_values = [],    # read empty values as empty string instead of nan(missing) 
        keep_default_na = False,
        converters={'STRESS_JUSTIFICATION':str,'ADVERSE_JUSTIFICATION':str,'BASE_JUSTIFICATION':str,'BHC_STRESS_JUSTIFICATION':str,'BHC_ADVERSE_JUSTIFICATION':str,'BHC_BASE_JUSTIFICATION':str}
    )
    last_ob=data[data["FORECAST_PERIOD"]==45]
    for i in range(20):
        last_ob["FORECAST_PERIOD"]+=1
        data=data.append(last_ob)
    
    if len(
        data[data.duplicated(
            [
                "SEGMENTATION_VALUE",
                "RATE_NAME",
                "MODEL_SEGMENT",
                "FORECAST_PERIOD",
                "PRIORITY"
            ]
        )]
    ) != 0:
        raise Exception("EJM MASTER file contains duplicates.")

    # Fetch distinct loan level tags
    if debug:
        print("Fetching distinct loan level tags...")

    if logger is not None and isinstance(logger, Logger):
        logger.add(
            type='INFO',
            message='Fetching distinct loan level tags...',
            context='EJM Dictionary Generator'
        )

    # Helpers
    date2OracleSTR = lambda x: x.strftime("%d-%b-%y")

    # Fetch all loan level tags
    loan_level_tags = queryRFO(
        query = """
            (
            SELECT DISTINCT
                MAX({}) AS {},
                PD,
                LGD,
                EAD,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EADBALANCE,
                EADLETTEROFCREDIT,
                EADAVAILABLELINE,
                EADTOTALLINE
            FROM {}
            WHERE
                UPPER(SOURCEID) NOT IN ('OFFLINE')
                AND
                ASOFDATE = '{}'
            GROUP BY
                PD,
                LGD,
                EAD,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EADBALANCE,
                EADLETTEROFCREDIT,
                EADAVAILABLELINE,
                EADTOTALLINE
            )
            UNION ALL
            (
            SELECT DISTINCT
                MAX({}) AS {},
                PD,
                LGD,
                EAD,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EADBALANCE,
                EADLETTEROFCREDIT,
                EADAVAILABLELINE,
                EADTOTALLINE
            FROM {}
            WHERE
                UPPER(SOURCEID) NOT IN ('OFFLINE')
                AND
                ASOFDATE = '{}'
            GROUP BY
                PD,
                LGD,
                EAD,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EADBALANCE,
                EADLETTEROFCREDIT,
                EADAVAILABLELINE,
                EADTOTALLINE
            )
        """.format(
            pd_group_field,
            pd_group_field,
            rfo_commercial_anchor_tb,
            date2OracleSTR(asofdate),
            pd_group_field,
            pd_group_field,
            rfo_commercial_orig_tb,
            date2OracleSTR(asofdate)
        ),
        moodys_rfo_env = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT']
    )

    # Gather unique combinations
    if debug:
        print("Producing unique model segment combinations from EJM_MASTER...")
    if logger is not None and isinstance(logger, Logger):
        logger.add(
            type='INFO',
            message='Producing unique model segment combinations from EJM_MASTER...',
            context='EJM Dictionary Generator'
        )
    unique_combs = data.groupby(
        ["SEGMENTATION_VALUE", "RATE_NAME", "MODEL_SEGMENT", "PRIORITY"]
    ).size().reset_index().rename(columns={0:'count'})

    # Create empty results ejm_dictionary
    ejm_dictionary={}

    # Begin process
    for scenario_type in scenario_pairs:
        # Create empty region
        if debug:
            print("Processing scenario {}...".format(scenario_pairs[scenario_type]))
        if logger is not None and isinstance(logger, Logger):
            logger.add(
                type='INFO',
                message="Processing scenario {}...".format(scenario_pairs[scenario_type]),
                context='EJM Dictionary Generator'
            )
        ejm_dictionary[scenario_pairs[scenario_type]] = [] # empty placeholder for scenario

        # Process for each individual combination
        for index, row in unique_combs.iterrows():
            # Subset data
            subset = data[
                (data["SEGMENTATION_VALUE"] == row["SEGMENTATION_VALUE"])
                &
                (data["RATE_NAME"] == row["RATE_NAME"])
                &
                (data["MODEL_SEGMENT"] == row["MODEL_SEGMENT"])
                &
                (data["PRIORITY"] == row["PRIORITY"])
            ]

            # Pre-process values vector
            values_series = subset[[scenario_type, scenario_type + '_MGMT', scenario_type + '_UNCERTAINTY', scenario_type + '_JUSTIFICATION' ]]
            values_series = values_series.reset_index(drop=True)
            values_vector = pd.DataFrame(values_series, index=subset["FORECAST_PERIOD"] - 1)
            values_vector.columns = ["VALUES", "VALUES_MGMT", "VALUES_UNCERTAINTY", "VALUES_JUSTIFICATION"]
            values_vector.sort_index(ascending=True, inplace=True)

            # Case when model segment is not LOAN_LEVEL_TAGGING
            if row["MODEL_SEGMENT"] != "LOAN_LEVEL_TAGGING":
                model_segment_list = row["MODEL_SEGMENT"].split(",")
            else:
                model_segment_list = loan_level_tags[
                    loan_level_tags[pd_group_field] == row["SEGMENTATION_VALUE"]
                ][row["RATE_NAME"]].unique().tolist()

            for model_segment in model_segment_list:
                # Check if exists
                existing_item_with_same_props = [
                    idx for idx, item in enumerate(ejm_dictionary[scenario_pairs[scenario_type]])
                    if ((item['modelsegment'] == model_segment) and (item['ratename']==row["RATE_NAME"]))
                ]

                # If item already exists in container, check priority for overwrite
                if len(existing_item_with_same_props)>0:
                    for idx in existing_item_with_same_props:
                        if row["PRIORITY"]>ejm_dictionary[scenario_pairs[scenario_type]][idx]['priority']:
                            ejm_dictionary[
                                scenario_pairs[scenario_type]
                            ][idx]['values'] = {
                                utilities.date2str(version_date): values_vector["VALUES"].tolist()
                            }
                            ejm_dictionary[
                                scenario_pairs[scenario_type]
                            ][idx]['priority'] = row['PRIORITY']

                            # add adjustment rates for Overlay
                            ejm_dictionary[
                                scenario_pairs[scenario_type]
                            ][idx]['values_mgmt'] = {
                                utilities.date2str(version_date): values_vector["VALUES_MGMT"].tolist()
                            }
                            ejm_dictionary[
                                scenario_pairs[scenario_type]
                            ][idx]['values_uncertainty'] = {
                                utilities.date2str(version_date): values_vector["VALUES_UNCERTAINTY"].tolist()
                            }
                            ejm_dictionary[
                                scenario_pairs[scenario_type]
                            ][idx]['values_justification'] = {
                                utilities.date2str(version_date): values_vector["VALUES_JUSTIFICATION"].tolist()
                            }
                            

                # Add to ejm_dictionary if item is new
                else:
                    ejm_dictionary[scenario_pairs[scenario_type]].append({
                        "group": row["SEGMENTATION_VALUE"],
                        "ratename": row["RATE_NAME"],
                        "vintage_differentiation": False ,# True if row["RATE_NAME"] == "PD" else False,
                        "values": {
                            utilities.date2str(version_date): values_vector["VALUES"].tolist()
                        },
                        # add adjustment rates for Overlay
                        "values_mgmt": {
                            utilities.date2str(version_date): values_vector["VALUES_MGMT"].tolist()
                        },
                        "values_uncertainty": {
                            utilities.date2str(version_date): values_vector["VALUES_UNCERTAINTY"].tolist()
                        },
                        "values_justification": {
                            utilities.date2str(version_date): values_vector["VALUES_JUSTIFICATION"].tolist()
                        },
                        "modelsegment":model_segment,
                        "priority":row["PRIORITY"]
                    })

        if debug:
            print("Completed EJM dictionary generation.")
        if logger is not None and isinstance(logger, Logger):
            logger.add(
                type='INFO',
                message="Completed EJM dictionary generation.",
                context='EJM Dictionary Generator'
            )

    # Clean up and finalize
    return(ejm_dictionary)


class EJMGenerator:
    """
    This class defines a contributor file generator for non-model approaches or
    assumptions.
    ---------------------------------------------------------------------------
    """
    # Properties
    __as_of_date = None
    __ejm_dictionary = None
    __forecast_periods = None
    __scenario = None
    debug = None
    process_additional_ead = None
    __model_id = None
    logger = None

    def __init__(
        self,
        as_of_date: datetime.datetime,
        forecast_periods: int,
        ejm_dictionary: dict = None,
        path_to_json: str = None,
        scenarios: (str, list) = None,
        debug: bool= False,
        process_additional_ead: bool = True,
        logger: Logger=None
    ):
        # Process logger instance
        if logger is not None:
            if isinstance(logger, Logger):
                self.logger = logger
            else:
                raise TypeError("Input `logger` is not an instance of Logger().")

        # Validate data types
        if debug:
            print("Validating data types...")
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Validating data types...',
                context='EJM Generator'
            )
        utilities.checkDataType(as_of_date, datetime.datetime)
        if ejm_dictionary is not None:
            utilities.checkDataType(ejm_dictionary, dict)
        if path_to_json is not None:
            utilities.checkDataType(path_to_json, str)
        utilities.checkDataType(forecast_periods, int)
        if scenarios is not None:
            utilities.checkDataType(scenarios, (str, list))
        utilities.checkDataType(debug, bool)
        utilities.checkDataType(process_additional_ead, bool)

        # Assigning member properties
        if debug:
            print("Assigning member properties...")
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Assigning member properties...',
                context='EJM Generator'
            )
        self.__as_of_date = as_of_date
        self.__ejm_dictionary = ejm_dictionary if ejm_dictionary is not None else utilities.readJSON(path_to_json)
        self.__forecast_periods = forecast_periods
        self.__scenarios = scenarios
        self.debug = debug
        self.process_additional_ead = process_additional_ead
        self.__model_id = "EJM Generator"

        if debug:
            print("EJM Generator ready for use.")
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='EJM Generator initialized and ready for use.',
                context='EJM Generator'
            )
    # Getters
    @property
    def as_of_date(self):
        return (self.__as_of_date)

    @property
    def ejm_dictionary(self):
        return(self.__ejm_dictionary)

    @property
    def forecast_periods(self):
        return(self.__forecast_periods)

    @property
    def scenarios(self):
        return(self.__scenarios)

    @property
    def model_id(self):
        return(self.__model_id)

    def execute(self, session: CCARSession):
        """
        This function generates a contributor file.
        ---------------------------------------------------------------------------

        Args
        ----
            session (CCARSession) :

        """

        # Process and validate scenario
        if self.debug:
            print("Validating scenario list...")
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Process and validate scenario list...',
                context='EJM Generator'
            )
        available_scenarios = list(self.ejm_dictionary.keys())
        scenarios_to_run = []
        if self.scenarios is not None:
            if isinstance(self.scenarios, str):
                if self.scenarios not in available_scenarios:
                    raise Exception("Invalid scenario.")
                else:
                    scenarios_to_run.append(self.scenarios)
            else:
                if set(available_scenarios)<set(self.scenarios):
                    raise Exception("Not all scenarios are valid.")
                else:
                    scenarios_to_run = self.scenarios
        else:
            scenarios_to_run = available_scenarios

        # Loop through scenarios
        as_of_date_formatted = utilities.date2str(self.as_of_date)
        # Starting timer
        t0 = time.time()
        if self.debug:
            print("Beginning process...")
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Beginning process...',
                context='EJM Generator'
            )
        for scenario in scenarios_to_run:
            items_to_process = len(self.ejm_dictionary[scenario])
            report_breakpoints = list(np.array(list(range(1, 11))) * (items_to_process // 10))
            if self.debug:
                print("Processing scenario "+ scenario + \
                      " ({})".format(
                          str(items_to_process) + " items"
                      )
                )
            if self.logger is not None:
                self.logger.add(
                    type='INFO',
                    message="Processing scenario "+ scenario + \
                        " ({})".format(
                          str(items_to_process) + " items"
                        ),
                    context='EJM Generator'
                )
            for idx in range(items_to_process):
                if idx in report_breakpoints:
                    if self.debug:
                        print("\t\t" + str((report_breakpoints.index(idx) + 1) * 10) + "% complete...")
                    if self.logger is not None:
                        self.logger.add(
                            type='INFO',
                            message='Process '+str((report_breakpoints.index(idx)+1)*10)+"% complete...",
                            context='EJM Generator'
                        )
                if session is not None:
                    #True if self.ejm_dictionary[scenario][ejm_segment_key]['ratename'] == "PD" else False
                    session.contributor_file_generator.addCFChunk(
                        as_of_date=self.as_of_date,
                        forecast_periods=self.forecast_periods,
                        forecast_periods_frequency='monthly',
                        scenario=scenario,
                        model_segment=self.ejm_dictionary[scenario][idx]['modelsegment'],
                        rate_name=self.ejm_dictionary[scenario][idx]['ratename'],
                        rate_type=4,
                        vintage_differentiation=False,
                        model_output_rate=self.ejm_dictionary[scenario][idx]['values'][as_of_date_formatted],
                        # add adjustment rates for Overlay
                        uncertainty_adjustment_rate=self.ejm_dictionary[scenario][idx]['values_uncertainty'][as_of_date_formatted],
                        mgmt_adjustment_rate=self.ejm_dictionary[scenario][idx]['values_mgmt'][as_of_date_formatted],
                        adjustment_overlay_justification=self.ejm_dictionary[scenario][idx]['values_justification'][as_of_date_formatted],
                        process_additional_ead = self.process_additional_ead
                    )

        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        if self.debug:
            print('Execution completed in ' + str(runtime) + ' s.')
        if self.logger is not None:
            self.logger.add(
                type='INFO',
                message='Execution completed in ' + str(runtime) + ' s.',
                context='EJM Generator'
            )

















