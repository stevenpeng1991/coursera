#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
SAMPLE USE

ICAAP_2016_AD_EJM_Gen = EJMGenerator(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/',
    filename='nma_requirements_ICP_Adverse.json',
    as_of_date=datetime.datetime(2016, 6, 30),
    scenario='ICP_Adverse',
    forecast_periods=42,
    hold_constant_additional_periods=True
)
   
ICAAP_2016_AD_EJM_Gen.generateNMA()
ICAAP_2016_AD_EJM_Gen_CF = ICAAP_2016_AD_EJM_Gen.getEJMCF()

ICAAP_2016_AD_EJM_Gen_CF.toCSV(output_file_path='I:/CRMPO/CCAR/3Q16/ICAAP/CONTRIBUTOR_FILES/Wholesale/EJM_ICP_Adverse_SB_COMM_LOSS.csv')

# ------------------

NMA_Adverse = EJMGenerator(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/',
    filename='nma_requirements_MC_GCB_overlay.json',
    as_of_date=datetime.datetime(2016, 6, 30),
    scenario='MC_Adverse',
    forecast_periods=27
)
   
NMA_Adverse.generateNMA()
NMA_Adverse_CF = NMA_Adverse.getEJMCF()

NMA_Adverse_CF.toCSV(output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_Adverse/EJM_MC_Adverse_SB_COMM_LOSS.csv')

# ----------------------

NMA_SA = EJMGenerator(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/',
    filename='nma_requirements_MC_GCB_overlay.json',
    as_of_date=datetime.datetime(2016, 6, 30),
    scenario='MC_SA',
    forecast_periods=27
)
   
NMA_SA.generateNMA()
NMA_SA_CF = NMA_SA.getEJMCF()

NMA_SA_CF.toCSV(output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Wholesale/20160827/MC_SA/EJM_MC_SA_SB_COMM_LOSS.csv')

# ------------------------







NMA_Base_CF.plotCFModelSegment(model_segment_dict={
        "MC_Base":{
            'PD_44' : ['.'], 
            'PD_114' : ['.']        
        }
}, show_plot=True)

NMA_Base_CF.plotCFModelSegment(model_segment_dict={
        'ALLLCOVERAGE_33' : ['.'], 
        'ALLLCOVERAGE_51' : ['.']
})


#################
RETAIL

EJM_MC_Base_RETAIL_LOSS = EJMGenerator(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/',
    filename='Retail_Loss_EJMs.json',
    as_of_date=datetime.datetime(2016, 6, 30),
    scenario='MC_Base',
    forecast_periods=27
)

EJM_MC_Base_RETAIL_LOSS.generateNMA()
EJM_MC_Base_RETAIL_LOSS_CF = EJM_MC_Base_RETAIL_LOSS.getEJMCF()

#----------------------------------------------------------------
EJM_MC_Base_RETAIL_LOSS = EJMGenerator(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/',
    filename='Retail_Loss_EJMs.json',
    as_of_date=datetime.datetime(2016, 6, 30),
    scenario='MC_Base',
    forecast_periods=27
)

EJM_MC_Base_RETAIL_LOSS.generateNMA()
EJM_MC_Base_RETAIL_LOSS_CF = EJM_MC_Base_RETAIL_LOSS.getEJMCF()
EJM_MC_Base_RETAIL_LOSS_CF.toCSV(output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Retail/MC_Base/EJM_MC_Base_SB_RETAIL_LOSS.csv')
#----------------------------------------------------------------
EJM_MC_Adverse_RETAIL_LOSS = EJMGenerator(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/',
    filename='Retail_Loss_EJMs.json',
    as_of_date=datetime.datetime(2016, 6, 30),
    scenario='MC_Adverse',
    forecast_periods=27
)

EJM_MC_Adverse_RETAIL_LOSS.generateNMA()
EJM_MC_Adverse_RETAIL_LOSS_CF = EJM_MC_Adverse_RETAIL_LOSS.getEJMCF()
EJM_MC_Adverse_RETAIL_LOSS_CF.toCSV(output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Retail/MC_Adverse/EJM_MC_Adverse_SB_RETAIL_LOSS.csv')

#----------------------------------------------------------------
EJM_MC_SA_RETAIL_LOSS = EJMGenerator(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/',
    filename='Retail_Loss_EJMs.json',
    as_of_date=datetime.datetime(2016, 6, 30),
    scenario='MC_SA',
    forecast_periods=27
)

EJM_MC_SA_RETAIL_LOSS.generateNMA()
EJM_MC_SA_RETAIL_LOSS_CF = EJM_MC_SA_RETAIL_LOSS.getEJMCF()
EJM_MC_SA_RETAIL_LOSS_CF.toCSV(output_file_path='I:/CRMPO/CCAR/2Q16/3 - Contributor Files/Retail/MC_SA/EJM_MC_SA_SB_RETAIL_LOSS.csv')

"""
import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import pandas as pd
import copy
import datetime
import warnings
import json
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.contributorfile.contributorfile import ContributorFile

class EJMGenerator:
    """
    This class defines a contributor file generator for non-model approaches or 
    assumptions.
    ---------------------------------------------------------------------------
    """
    # Properties
    __as_of_date = None
    __forecast_periods = None
    __scenario = None
    __dir_path = None
    __filename = None
    __rate_type = None
    __transformation = None
    __period_lag = None
    __header_names = None
    __nma_requirements = None
    __EJM_CF = None
    __hold_constant_additional_periods = None

    def __init__(
        self,
        dir_path,
        as_of_date,
        scenario,
        hold_constant_additional_periods,
        forecast_periods = 27,
        filename = 'nma_requirements.json',
        rate_type = '4',
        transformation = 'No Transformation',
        period_lag = '0',
        header_names=(
            'Scenario',
            'ModelSegment',
            'PeriodDate',
            'Vintage',
            'RateType',
            'FeesAndExpensesLineItem',
            'AssociatedG_L_Item',
            'Transformation',
            'PeriodLag',
            'RateName',
            'ModelOutputRate',
            'UncertaintyAdjustmentRate',
            'MgmtAdjustmentRate',
            'IdiosyncraticRate1',
            'IdiosyncraticRate2',
            'IdiosyncraticRate3',
            'IdiosyncraticRate4',
            'IdiosyncraticRate5',
            'Adjustment_Overlay_Justification'
        )
    ):
            # Assign to class properties
            if dir_path[-1]=='/':
                self.__dir_path = dir_path.strip()
            else:
                self.__dir_path = dir_path.strip()+'/'
            self.__filename = filename.strip()
            if isinstance(as_of_date, datetime.datetime):
                self.__as_of_date = as_of_date
            else:
                raise TypeError('Wrong input as_of_date type. Use datetime.datetime instance.')
            self.__forecast_periods = forecast_periods
            self.__scenario = scenario
            self.__header_names = list(header_names)
            self.__rate_type = rate_type
            self.__transformation = transformation
            self.__period_lag = period_lag
            self.__hold_constant_additional_periods = hold_constant_additional_periods
            

            # Read contributor file from input path
            nma_requirements_file_path = self.__dir_path + self.__filename
            with open(nma_requirements_file_path, 'r') as data_file:
                    nma_requirements_dict = json.load(fp=data_file, encoding='utf-8')
            self.__nma_requirements = nma_requirements_dict

    # Getters
    def getNMARequirements(self):
        return(self.__nma_requirements)

    def getAsOfDate(self):
        return(self.__as_of_date)

    def getDirPath(self):
        return(self.__dir_path)

    def getFileName(self):
        return(self.__filename)

    def getForecastPeriods(self):
        return(self.__forecast_periods)

    def getScenario(self):
        return(self.__scenario)

    def getHeaderNames(self):
        return(self.__header_names)
        
    def getEJMData(self):
        return(self.__EJM_CF.getCFData())
        
    def getEJMCF(self):
        return(self.__EJM_CF)

    # Setters
    def setAsOfDate(self, input_as_of_date):
        if isinstance(input_as_of_date, datetime.datetime):
            self.__as_of_date = input_as_of_date
            if self.__EJM_CF is not None:
                self.generateNMA()
                warnings.warn(
                    'EJM data was re-generated given the new input as of date <' + 
                    utilities.date2str(self.__as_of_date) + 
                    '>.'
                )
        else:
            raise TypeError("Input parameter is NOT an instance of <datetime.datetime>")
            
        
    def generateNMA(self):
        """
        This function generates a contributor file.
        ---------------------------------------------------------------------------
    
        Args
        ----
            scenario (str) : the specific scenario to generate
            output_file (str) : path to save a csv version of the generated contributor 
                                file, argument is optional
    
        Returns
        -------
            (ContributorFile) : if `output_file` specified, a csv file will be saved, otherwise 
                                the method will return ContributorFile instance
        """        
        # Create placeholder contributor file Dataframe
        placeholder = pd.DataFrame(columns=self.__header_names)
        
        # Check if scenario exists
        if self.__scenario not in self.__nma_requirements:
            raise AttributeError('Scenario was not found in EJM data requirements.')
    
        # Loop through model segment keys in dictionary
        for key in self.__nma_requirements[self.__scenario].keys():
            # Get rate name
            if 'rate_name' in self.__nma_requirements[self.__scenario][key]:
                rate_name = self.__nma_requirements[self.__scenario][key]['ratetype'] 
                # PREVIOUSLY : key.strip().split("_")[0]
            else:
                rate_name = key.strip().split("_")[0]           
                # raise Exception('`ratetype` key NOT found for model segment <' + key + '>.')
            
            # Generate period date sequence
            period_date = [utilities.date2str(x) for x in utilities.generateDateSequence(
                as_of_date = self.__as_of_date, 
                forecast_periods = self.__forecast_periods)
            ]
            
            # Generate default vintage vector for non-vintage differentiated forecasts
            vintage = ['.']*self.__forecast_periods
            
            # Determine most recent NMA values (based on max date)
            max_date = utilities.date2str(max(
                [utilities.str2date(x) for x in self.__nma_requirements[self.__scenario][key]['values'].keys()]
            ))
            if len(self.__nma_requirements[self.__scenario][key]['values'][max_date]) == 1:
                model_output_rate = self.__nma_requirements[self.__scenario][key]['values'][
                    max_date
                ] * self.__forecast_periods
            elif len(self.__nma_requirements[self.__scenario][key]['values'][max_date]) >= self.__forecast_periods:
                model_output_rate = self.__nma_requirements[self.__scenario][key]['values'][max_date][
                    0:self.__forecast_periods
                ]
            else:
                if self.__hold_constant_additional_periods:
                    model_output_rate = self.__nma_requirements[self.__scenario][key]['values'][max_date]
                    model_output_rate = model_output_rate + [model_output_rate[-1]] * (
                        self.__forecast_periods - len(model_output_rate)
                    )
                else:
                    raise Exception('ModelOutputRate vector length is not valid for ' + str(key))
    
            # Process Vintage Differentiation
            if self.__nma_requirements[self.__scenario][key]['vintage_differentiation']: # rate_name == 'PD':
                # Vintage
                for idx in range(len(period_date)):
                    for rep in range(self.__forecast_periods-idx):
                        vintage.append(period_date[idx])
    
                # PeriodDate
                tmp_pdate = copy.deepcopy(period_date)
                for idx in range(len(tmp_pdate)):
                    for date in tmp_pdate[idx:self.__forecast_periods]:
                        period_date.append(date)
                    for rate in model_output_rate[idx:self.__forecast_periods]:
                        model_output_rate.append(rate)
    
            # Append Data to Placeholder Dataframe
            placeholder = placeholder.append(pd.DataFrame.from_dict(dict(
                Scenario=self.__scenario,
                ModelSegment=key.strip(),
                PeriodDate=period_date,
                Vintage=vintage, 
                RateType=self.__rate_type,
                FeesAndExpensesLineItem='',
                AssociatedG_L_Item='',
                Transformation=self.__transformation,
                PeriodLag=self.__period_lag,
                RateName=rate_name,
                ModelOutputRate=model_output_rate,
                UncertaintyAdjustmentRate='0',
                MgmtAdjustmentRate='0',
                IdiosyncraticRate1='0',
                IdiosyncraticRate2='0',
                IdiosyncraticRate3='0',
                IdiosyncraticRate4='0',
                IdiosyncraticRate5='0',
                Adjustment_Overlay_Justification=''
            )))
    
        # Reorder columns
        placeholder = placeholder[self.__header_names]
        
        # Reset the index to match row numbers
        placeholder.reset_index(inplace=True, drop=True)
        
        # Initialize ContributorFile object instance from data
        CF_instance = ContributorFile(data=placeholder)
        
        # Check CF quality and return results
        CFIntegrityResponse = CF_instance.checkCFIntegrity()
        CFHeaderCompletenessResponse = CF_instance.checkCFHeadersCompleteness()
        if(
            CFIntegrityResponse.getResponse() 
            and CFHeaderCompletenessResponse.getResponse()
        ):
            self.__EJM_CF = CF_instance
            return(True)
        else:
            response_dictionary = []
            if(CFIntegrityResponse.getResponse() == False):
                response_dictionary.append(CFIntegrityResponse.getDict())
            if(CFHeaderCompletenessResponse.getResponse() == False):
                response_dictionary.append(CFHeaderCompletenessResponse.getDict())
            raise Exception('CF quality check failed : ' + str(response_dictionary))
















