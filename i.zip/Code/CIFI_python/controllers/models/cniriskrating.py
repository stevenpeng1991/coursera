"""
SAMPLE USE
----------

# GETTING SAMPLE CONTRACT-LEVEL DATA 
## Getting contract-level data for the CNI Risk Rating model
sample_mds = CNIMasterDataset(
    asofdate=datetime.datetime(2017,6,30),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2017,6,30),
    financial_in_rfo = True
)

## Accessing the most complete version of the data within the CNIMasterDataset instance
df = sample_mds.mds_mra_additional_fields
df.to_clipboard(index=False) # in case you wish to copy it to an Excel spreadsheet


# KICKING-OFF A FULL RUN
############################# IFRS RUN config ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)     
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "BASE" # BASE/S1/S3
STRESS_TESTING_CYCLE = "IFRS9"  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 366      

# new switch added for IFRS #
PD_LAG1Q_SWITCH = True    # lag 1Q for macro for PD computation
PD_SPECIAL_SET1 = True    # If SRR in (1.0, 1.1, 1.2) or (SRR<1 and LOCAL_NPL_FLAG=”Y”) then PD=1 
USE_RFO_MACRO_SERIES = False   # Use macro in SQLite
NEW_LEQ_SWITCH = True    # Use new LEQ factors(44Q)
DISCOUNTING_LGD_SWITCH = True   # discounting LGD using interest rate and nco curve
ADD_UAT_COLUMNS = True    # add detailed columns for UAT
STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
#STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_dec16org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
MATURITY_SWITCH = True   # mature loans (check monthly)
MAXIMUM_MATURITY_DATE_IMPUTATION = True  # if maxMaturityDate missing, add 11 year from origination date
FORECAST_RESULT_FREQUENCY = 'quarterly'   # the output dataset is monthly(official run) or quarterly(uat purpose)
STAGE_DIFF_SWITCH = False  # forecast horizon different for stage 1 (4Q) and stage 2/3 (44Q)
PROVIDE_TEST_FACILITY = False  # provide specific facilities to test
MRS_SRR_SWITCH = True # convert SRR from 0.1 interval to 0.5 interval (downward)
FIX_FORECAST_PERIOD = True # fixed or dynamic decide forecast period for each facility  

## Create a session instance and a model shopping cart to run the CNIModel
ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 Mid Cycle',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

## Create CNIModel instance
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    PD_lag1Q_switch = PD_LAG1Q_SWITCH,
    PD_special_set1 = PD_SPECIAL_SET1,
    use_RFO_macro_series = USE_RFO_MACRO_SERIES,
    new_LEQ_switch = NEW_LEQ_SWITCH,
    discounting_LGD_switch = DISCOUNTING_LGD_SWITCH,
    add_uat_columns = ADD_UAT_COLUMNS,
    staging_dataset_input_path = STAGING_DATASET_INPUT_PATH,
    stage_diff_switch = STAGE_DIFF_SWITCH,
    fix_forecast_period = FIX_FORECAST_PERIOD,
    maturity_switch = MATURITY_SWITCH,
    maximum_maturity_date_imputation = MAXIMUM_MATURITY_DATE_IMPUTATION,
    mrs_srr_switch = MRS_SRR_SWITCH,
    forecast_result_frequency = FORECAST_RESULT_FREQUENCY,
    provide_test_facility = PROVIDE_TEST_FACILITY,
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True,
    show_result_plot = True
)

###############  Add model to the shopping cart and execute  ###########
cart.addModel(CI_ABL_risk_rating_model_instance)
cart.checkout()       # execute() is called here

## Check portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = CI_ABL_risk_rating_model_instance.portfolio_snapshot

## Check raw and transformed macro series
transformed_macro_series = CI_ABL_risk_rating_model_instance.transformed_macro_series

## Check raw and transformed macro series including t0
transformed_macro_series_include_t0 = CI_ABL_risk_rating_model_instance.transformed_macro_series_include_t0

## Check raw and transformed macro series including all
transformed_macro_series_include_all = CI_ABL_risk_rating_model_instance.transformed_macro_series_include_all

## Check change in sales, profit margin and pd mapping stress time series
macro_data = CI_ABL_risk_rating_model_instance.macro_data

## Check a list of all mapping objects as a dict
mapping_objects = CI_ABL_risk_rating_model_instance.mappings

## Get all rated contracts as a dict (quarterly forecast)
results_dictionary = CI_ABL_risk_rating_model_instance.results_set

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = CI_ABL_risk_rating_model_instance.results_df
results_df.to_clipboard(index=False) # in case you would like to copy to Excel

## Get LEQ factors
leq_df = CI_ABL_risk_rating_model_instance.LEQ_df

## Get C&I portfolio average interest rate
portfolio_average_interestrate = CI_ABL_risk_rating_model_instance.portfolio_average_interestrate

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()


#########  Create CNIModel instance for sensitivity  #########
# macro combination
macro_names = ['FLBR_US', 'FZ_US', 'FHOFHOPIQ_US', 'FGDPQ_US']
all_combos = combo_generator(macro_names,["FRB_BASE","FRB_SA"]) 
cni_model_instance = CNIModel(
    as_of_date=datetime.datetime(2016,12,31),                    # scenario as-of-date
    scenario=["FRB_BASE","FRB_SA"],                              # scenario name
    scenario_context="CCAR2017",                                 # stress testing cycle
    scenario_date=datetime.datetime(2016,12,31),                 # scenario as-of-date
    scenario_severity_level="STRESS",                            # scenario severity level
    forecast_periods=27,                                         # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes, number of random contracts to pick
    portfolio_snapshot_date=datetime.datetime(2016,12,31),       # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = datetime.datetime(2016,12,31),
    scenario_combinations = all_combos[4]
)

# INSERT MODEL PROPERTIES ITEM
from tinydb import TinyDB, Query

path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties)

property_to_insert = {
    
}
db.insert(property_to_insert)
db.close()


#################### Update ALLL/CONTINGENCY Covergae Rate ####################
path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties)

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'alll_coverage',
  'segment': 'all',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   1.0,
    1.5: 0.0800078746190864,
    2:   0.0421304017159306,
    2.5: 0.0421304017159306,
    3:   0.0421304017159306,
    3.5: 0.0224013294970956,
    4:   0.0224013294970956,
    4.5: 0.0106724532239101,
    5:   0.00632362559562368,
    5.5: 0.00539579582736586,
    6:   0.00374188691780179,
    6.5: 0.00296509442918514,
    7:   0.00296509442918514,
    7.5: 0.00296509442918514,
    8:   0.00296509442918514,
    8.5: 0.0
    }],
  'version_date': '03/31/2017'})

### test db search
alll = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & (Query().name == "alll_coverage")  
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2017, 3, 31))))
# get/remove record by Element IDs
db.get(eid = 314)
db.remove(eids = [313,314])

# close the connection
db.close()

alll = CI_instance_test._model_properties.getParameters(
                            type='property',
                            name='alll_coverage',
                            segemtn='all'
                        )[0]


############################# SP20 RUN Round 1 ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,2,28)
SCENARIO_DATE = datetime.datetime(2017,3,31)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2016,12,31)            # not in run.py
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "P20"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 45
STATEMENT_DAYS_THRESHOLD = 426           # not in run.py

############################# SP20 RUN Round 2 ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,3,31)
SCENARIO_DATE = datetime.datetime(2017,3,31)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2017,3,31)            # not in run.py
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "P20"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 45
STATEMENT_DAYS_THRESHOLD = 540           # not in run.py

ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 STRATPLAN',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

## Create CNIModel instance
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None
)

## Check portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = CI_ABL_risk_rating_model_instance.portfolio_snapshot

## Check raw and transformed macro series
transformed_macro_series = CI_ABL_risk_rating_model_instance.transformed_macro_series

## Check change in sales, profit margin and pd mapping stress time series
macro_data = CI_ABL_risk_rating_model_instance.macro_data

## Check a list of all mapping objects as a dict
mapping_objects = CI_ABL_risk_rating_model_instance.mappings

## Get all rated contracts as a dict (quarterly forecast)
results_dictionary = CI_ABL_risk_rating_model_instance.results_set

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = CI_ABL_risk_rating_model_instance.results_df

###############  Add model to the shopping cart and execute  ###########
cart.addModel(CI_ABL_risk_rating_model_instance)
cart.checkout()       # execute() is called here

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

## save contributor file to CSV file
cf_data.to_csv("I:/CRMPO/CCAR/1Q17/3 - Contributor Files/Wholesale/cf_files/archive/p20_feb_cni_CF_0517.csv", index = False)

## reset cf generator and shopping cart 
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()

### SP20 Run Balance Walk and sensitivity ####
# get portfolio snapshot
anchor_query, anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=["MIDDLE_MARKET", "BUSINESS_BANKING", "ABL"]
            )
## save anchor file to CSV file
anchor_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_feb/p20_feb_cni_anchor.csv")

# cf_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_CF.csv")
# anchor_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_anchor.csv")

# NOTE: need to update the switch and length of SEGFIELD2_TO_NCO_TIMING_CURVE in balancewalk.py
bw_output = balanceWalk(
    cf_data = cf_data,
    anchor_data = anchor_data,
    scenario_list = ['BASE'],
    process_ALLL_balances = False,
    debug = True
    )

bw_output.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_feb/p20_feb_cni_BW_Output_test.csv")


### Upload CF to RFO
FILE_VERSION = 1
#cf.writeToMoodysRFO(
#    p_reporting_date=PORTFOLIO_SNAPSHOT_DATE,
#    as_of_date=AS_OF_DATE,
#    p_rerun='N',
#    p_engine='ME_LOSS_ENGINE',
#    p_cycle='CCAR',
#    debug=True,
#    moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
#    table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
#    overwrite_vintage_asofdate=CONFIG['CONTRIBUTOR_FILE']["VINTAGE_ASOFDATE_VALUE"],
#    contributor_file_id=contributor_file_id,
#    file_version=FILE_VERSION
#)

"""
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
from CIFI.models.modelproperties.modelproperties import ModelProperties
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.models.riskratingmodel import Mapping
from CIFI.config import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.models.masterdataset.financialstatements import getRawMRA, getSourceSystemToMRAMap
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalk, balanceWalkMacroSensitivity, getNCOCurve, balanceWalkPivot
import datetime
import pandas as pd
from pandasql import sqldf
import numpy as np
import dateutil.relativedelta as relativedelta
import bisect
import math
import time
from tinydb import TinyDB, Query
import matplotlib.pyplot as plt
import copy


##
## GLOBAL VARIABLES
##
global MDS_SOURCEID
MDS_SOURCEID = 'SOURCEID'

global MIDDLE_MARKET_PD_GROUP
MIDDLE_MARKET_PD_GROUP = "MIDDLE_MARKET"

global BUSINESS_BANKING_PD_GROUP
BUSINESS_BANKING_PD_GROUP = "BUSINESS_BANKING"

global ABL_PD_GROUP
ABL_PD_GROUP = "ABL"

global CNI_PD_GROUP_LIST
CNI_PD_GROUP_LIST = [MIDDLE_MARKET_PD_GROUP, BUSINESS_BANKING_PD_GROUP, ABL_PD_GROUP]

global MRA_STATEMENT_MONTHS
MRA_STATEMENT_MONTHS = 12

global MRA_PRIMARY_KEY
MRA_PRIMARY_KEY = [
    'MasterCustomerID',
    'StatementDate',
    'AuditMethod'
]

global MRA_RAW_FIELDS
MRA_RAW_FIELDS = [
    'MasterCustomerID',
    'StatementID',
    'StatementDate',
    'StatementMonths',
    'AuditMethod',
    'DebtToTNW',
    'EBITDA',
    'InterestExpense',
    'CashAndEquivs',
    'NetTradeAcctsRec',
    'TotalCurLiabs',
    'ProfitBeforeTax',
    'NetSales'
]

global MRA_CLEAN_FIELDS
MRA_CLEAN_FIELDS = [
    'MasterCustomerID',
    'StatementID',
    'StatementDate',
    'StatementMonths',
    'AuditMethod',
    'DebtToTNW',
    'EBITDA',
    'InterestExpense',
    'CashAndEquivs',
    'NetTradeAcctsRec',
    'TotalCurLiabs',
    'ProfitBeforeTax',
    'NetSales'
]

global INVALID_AUDIT_METHODS
INVALID_AUDIT_METHODS = [
    'Projection',
    '',
    ' ',
    '  ',
    'Other',
    'other',
    'Interim',
    None
]
global AUDIT_METHOD_RANK_MAP
AUDIT_METHOD_RANK_MAP = {
    "Unqualif'd": 1,
    'Unqual': 2,
    'Unqual.': 3,
    'Qualified': 4,
    'Reviewed': 5,
    'Review': 6,
    'Compiled': 7,
    "Co.Prep'd": 8,
    'Co. Prep.': 9,
    'CO-PREP': 10,
    'Tax Return': 11,
    'Tax': 12
}

global PERIOD_FREQ_MAP
PERIOD_FREQ_MAP = {
    'monthly': 1,
    'quarterly': 3,
    'yearly': 12
}

# Helpers
date2OracleSTR = lambda x: x.strftime("%d-%b-%Y").upper()

##
## CONTRACT-LEVEL DATASET CLASS DEFINITION
##
class CNIMasterDataset(CCMISMasterDataset):
    """
    This class inherits from CCMISMasterDataset and provides an interface with CCMIS
    portfolio granular (contract-level) data adding financial statement fields from the 
    Moody's Risk Analyst monthly extract.


    Note:
        Properties created with the ``@property`` decorator should be documented in 
        the property's getter method.

    Attributes:
        __mds_mra (pandas.DataFrame) : Result of merge between master dataset and MRA fields.
        __mds_mra_financial_ratios (pandas.DataFrame) : Master dataset with calculated financial ratios.
        __mds_mra_additional_fields (pandas.DataFrame) : Master dataset with additional fields, ready for use.
        __processed_mra_data (pandas.DataFrame) : MRA data after cleaning process.
        __raw_mra_data (pandas.DataFrame) : MRA data unaltered from original source.
        __sourcesystem_to_mra (pandas.DataFrame) : mapping from CCMIS to CCLM id system.
        __pass_SRR (float) : inclusive upper bound SRR for non-pass ratings.
        __statement_days_threshold (int) : max age of a valid/current statement (in days).

    """
    # Member properties
    __mds_mra = None
    __mds_mra_financial_ratios = None
    __mds_mra_additional_fields = None
    __processed_mra_data = None
    __raw_mra_data = None
    __sourcesystem_to_mra = None
    __pass_SRR = None
    __statement_days_threshold = None
    __mra_asofdate = None
    __financial_in_rfo = None
    __new_financial_logic = None
    __maximum_maturity_date_imputation = None
    __mrs_srr_switch = None
    __risk_rating_dataset_input_path = None
    __risk_rating_dataset = None
    __line_term_type_input_path = None
    __line_term_type_dataset = None
    
    # Member methods
    def __init__(
        self,
        asofdate: datetime.datetime,
        pd_groups: list,
        pass_SRR: float = 4.,
        statement_days_threshold: int = 366,
        include_originations: bool = True,
        debug: bool = False,
        limit_contracts: int = None,
        mra_asofdate: datetime.datetime = None,
        financial_in_rfo: bool = False,
        new_financial_logic: bool = True,
        maximum_maturity_date_imputation: bool = False,
        mrs_srr_switch: bool = False,
        risk_rating_dataset_input_path: str = None, # path for risk rating data(finalrat_ind; financial ratios)
        line_term_type_input_path: str = None  # path for facility type data(LINE_TERM, SOURCEID, ONE_OBLIGOR_NUMBER, CUSTOMERNUMBER, FACILITYNUMBER)
    ):
        """
        Class constructor for the CNIMasterDataset class. 

        Note:
            As CNIMasterDataset inherits from CCMISMasterDataset, the latter's constructor will be called first. 

        Args:
            asofdate (datetime.datetime) : portfolio date (use only month ends).
            pd_groups () : list of PD_GROUPs to fetch from data source.
            pass_SRR (float) : inclusive upper bound SRR for non-pass ratings.
            statement_days_threshold (int) : max age of a valid/current statement (in days).
            include_originations (bool) : 
            debug (bool) :

        Raises:
            TypeError: If `pass_SRR` is not a float.
            TypeError: If `statement_days_threshold` is not an int.

        Examples:
            >>> sample_mds = CNIMasterDataset(
                    asofdate=datetime.datetime(2016,12,31),
                    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
                    pass_SRR=4.,
                    debug=True,
                    include_originations=True
                )

        """
        # Initialize parent class properties
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Initializing parent class..."
            )
        # If financial_in_rfo is true, call fetchCNIData() in masterdataset.py, otherwise call fetchData()
        CCMISMasterDataset.__init__(
            self,
            asofdate=asofdate,
            pd_groups=pd_groups,
            include_originations=include_originations,
            debug=debug,
            limit_contracts=limit_contracts,
            fetchCNI = financial_in_rfo,
            auto_fetch = True if risk_rating_dataset_input_path == None else False
        )

        # Validating data types for derived class inputs
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Validating data types for derived class inputs..."
            )
        utilities.checkDataType(pass_SRR,float)
        utilities.checkDataType(statement_days_threshold, int)

        if mra_asofdate is not None:
            utilities.checkDataType(mra_asofdate, datetime.datetime)
            self.__mra_asofdate = mra_asofdate
        else:
            self.__mra_asofdate = self.asofdate

        # Assigning member properties
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Assigning member properties..."
            )
        self.__statement_days_threshold = statement_days_threshold
        self.__pass_SRR = pass_SRR
        self.__financial_in_rfo = financial_in_rfo
        self.__new_financial_logic = new_financial_logic
        self.__maximum_maturity_date_imputation = maximum_maturity_date_imputation
        self.__mrs_srr_switch = mrs_srr_switch
        self.__risk_rating_dataset_input_path = risk_rating_dataset_input_path
        self.__line_term_type_input_path = line_term_type_input_path
        self.__include_originations = include_originations
        
        # Read risk rating dataset
        if self.__risk_rating_dataset_input_path != None:
            print(self.__class__.__name__ + " : " +
                "Reading risk rating dataset from {}...".format(self.__risk_rating_dataset_input_path))
#            risk_rating_dataset_input_path = "I:/CRMPO/CCAR/3Q17/4 - Models/Wholesale/Risk Rating/rfo_cni_sep2017_t_test.xlsx"
            self.__risk_rating_dataset = pd.read_excel(
                        io=self.__risk_rating_dataset_input_path,
                        converters={'MASTER_CUSTOMER_ID':str,'COSTCENTER':str})
#            self.__mds_mra_financial_ratios = self.__risk_rating_dataset.copy(deep=True)

        # Read facility type dataset
        if self.__line_term_type_input_path != None:
            print(self.__class__.__name__ + " : " +
                "Reading facility type(LINE_TERM) dataset from {}...".format(self.__line_term_type_input_path))   
            # line_term_type_input_path = "I:/CRMPO/CCAR/4Q17/4 - Models/Wholesale/C&I/MV_CCMIS_ALL_DATA_LINE_TERM_nov17.xlsx"
            self.__line_term_type_dataset = pd.read_excel(io=self.__line_term_type_input_path)

        # old method: fetch financials(raw MRA & mapping table) from source files
        if not self.financial_in_rfo:
            # Fetch and process/clean raw MRA data
            print(
                self.__class__.__name__ + " : " +
                "Fetching and processing raw MRA data {}...".format(str(self.mra_asofdate))
            )
            self.__processed_mra_data, self.__raw_mra_data = self.preProcessMRAData(
                mra_extract_asofdate=self.mra_asofdate,
                portfolio_asofdate=self.asofdate
            )
    
            # Fetch Source System to MRA Mapping table
            print(
                self.__class__.__name__ + " : " +
                "Fetching Source System to MRA Mapping table for {}...".format(str(self.mra_asofdate))
            )
            self.__sourcesystem_to_mra = getSourceSystemToMRAMap(as_of_date=self.mra_asofdate)
            
            # Merge Financails with master datasets, and calculate ratios
            print(
                self.__class__.__name__ + " : " +
                "Merging Master Data with processed MRA data using Mapping table..."
            )
            self.mergeMRA2MDS()
            
        # Process fanancial ratios
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Process financial ratios..."
            )
        
        # Calculate financial ratios if risk rating dataset is provided; otherwise use the ratios in dataset directly
        if self.__risk_rating_dataset_input_path == None:
            self.processFinancialRatios()   
        else:
            print('**********************************************************')
            print(self.__class__.__name__ + " : " +"Processing risk rating dataset: aggregating and checking...")
            self.processRiskRatingDataset()
        
        # Merge 
        if (self.line_term_type_input_path != None) and (self.line_term_type_dataset is None):
            raise Exception('`self.line_term_type_dataset` is None.')
            
        # Calculate additional fields
        self.processAdditionalFields()
        
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "C&I Dataset instance initialization completed ..."
            )

    @staticmethod
    def preProcessMRAData(mra_extract_asofdate: datetime.datetime, portfolio_asofdate: datetime.datetime):
        """
        This method .

        Args:
            asofdate (datetime.datetime) : portfolio date (use only month ends).

        Raises:
            TypeError: If `pass_SRR` is not a float.
            TypeError: If `statement_days_threshold` is not an int.

        Examples:
            >>> sample_mds = CNIMasterDataset(
                    asofdate=datetime.datetime(2016,12,31),
                    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
                    pass_SRR=4.,
                    debug=True,
                    include_originations=True
                )
        """
        all_audit_method_known_values = list(AUDIT_METHOD_RANK_MAP.keys())+INVALID_AUDIT_METHODS


        raw_mra = getRawMRA(source_data_set_date=mra_extract_asofdate)

        # Filter for invalid statements
        # Include Annual Statements only/Valid audit method/statement date prior to run date
        mra_1 = raw_mra[
            (raw_mra['StatementMonths'] == MRA_STATEMENT_MONTHS)
            &
            (~raw_mra['AuditMethod'].isin(INVALID_AUDIT_METHODS))
            &
            (~pd.isnull(raw_mra['AuditMethod']))
            &
            (raw_mra['StatementDate'] <= portfolio_asofdate)
        ]

        # Check for audit method values assumption
        set_of_input_audit_method_values = set(mra_1.AuditMethod.unique().tolist())
        set_audit_method_known_values = set(all_audit_method_known_values)
        if len(set_of_input_audit_method_values - set_audit_method_known_values) != 0:
            raise ValueError("AuditMethod values have changed and don't match current list: {}".format(
                list(set_of_input_audit_method_values - set_audit_method_known_values)
            ))

        # Get the MAX StatementDate for each obligor/customer
        mra_2 = mra_1.groupby(['MasterCustomerID']).apply(
            lambda df: df['StatementDate'].values[df['StatementDate'].values.argmax()]
        ).rename("MAX_StatementDate").reset_index()

        # Merge back to the main data frame with MAX_StatementDate
        mra_3 = mra_1.merge(
            mra_2,
            left_on='MasterCustomerID',
            right_on='MasterCustomerID',
            how='left'
        )

        # Filter for all statements per obligor/customer that are the most recent
        mra_4 = mra_3[mra_3['StatementDate'] == mra_3['MAX_StatementDate']]

        # Assign AuditMethodRank
        applyAuditMethodRank = lambda x: AUDIT_METHOD_RANK_MAP[x]
        pd.set_option('mode.chained_assignment', None)  # Temp removal of warnings
        mra_4.loc[:,'AuditMethodRank'] = np.vectorize(applyAuditMethodRank)(mra_4['AuditMethod'])
        pd.set_option('mode.chained_assignment', 'warn')  # Reestablish warning message

        # Get the MIN AuditMethodRank for each obligor/customer
        mra_5 = mra_4.groupby(['MasterCustomerID']).apply(
            lambda df: df['AuditMethodRank'].values[df['AuditMethodRank'].values.argmin()]
        ).rename("MIN_AuditMethodRank").reset_index()

        # Merge back to the main data frame with MIN_AuditMethodRank
        mra_6 = mra_4.merge(
            mra_5,
            left_on='MasterCustomerID',
            right_on='MasterCustomerID',
            how='left'
        )

        # Filter for all statements per obligor/customer have highest ranking audit method
        mra_7 = mra_6[mra_6['MIN_AuditMethodRank'] == mra_6['AuditMethodRank']]

        # Remove duplicates based on primary key:
        # ['MasterCustomerID', 'StatementDate', 'AuditMethod']
        # mra_dups = mra_7[mra_7.duplicated(MRA_PRIMARY_KEY)]
        mra_8 = mra_7[~mra_7.duplicated(MRA_PRIMARY_KEY)][MRA_CLEAN_FIELDS]

        # Finish process, return data
        return(mra_8, raw_mra[list(mra_8.columns)])

    def mergeMRA2MDS(self):
        """

        Returns
        -------

        """
        # Check source id equivalence
        if self.data is None:
            raise Exception('`self.data` is None.')
        if self.sourcesystem_to_mra is None:
            raise Exception('`self.sourcesystem_to_mra` is None.')
        if len(set(self.data[MDS_SOURCEID].unique()) - set(self.sourcesystem_to_mra['SourceId'].unique())) != 0:
            raise Exception("SourceID in mapping are not subset of source id in MDS.")

        # Create temporary dataframes
        mds_tmp = self.data
        mapping_df = self.sourcesystem_to_mra
        processed_mra_data = self.processed_mra_data

        # Merge
        if self.new_financial_logic:       
            mrg_1 = sqldf("""
                SELECT DISTINCT
                    master_dataset.*,
                    srcsysmap_1.MasterCustomerId,
                    srcsysmap_1.MasterOneObligorId
                FROM
                    mds_tmp AS master_dataset
                LEFT JOIN
                    mapping_df AS srcsysmap_1
                    ON
                    (master_dataset.SOURCEID = srcsysmap_1.SourceId)
                    AND
                    (master_dataset.CUSTOMERNUMBER = srcsysmap_1.CustomerNumber)
                ORDER BY
                    master_dataset.UNIQUE_FACILITY_ID;
            """)
        
        else:
            # old merge logic
            mrg_1 = sqldf("""
                SELECT DISTINCT
                    master_dataset.*,
                    COALESCE(srcsysmap_1.MasterCustomerId, srcsysmap_2.MasterCustomerId) AS MasterCustomerId,
                    COALESCE(srcsysmap_1.MasterOneObligorId, srcsysmap_2.MasterOneObligorId) AS MasterOneObligorId
                FROM
                    mds_tmp AS master_dataset
                LEFT JOIN
                    mapping_df AS srcsysmap_1
                    ON
                    (master_dataset.SOURCEID = srcsysmap_1.SourceId)
                    AND
                    (master_dataset.ONEOBLIGORNUMBER = srcsysmap_1.OneObligorNumber)
                LEFT JOIN
                    mapping_df AS srcsysmap_2
                    ON
                    (master_dataset.SOURCEID = srcsysmap_2.SourceId)
                    AND
                    (master_dataset.CUSTOMERNUMBER = srcsysmap_2.CustomerNumber)
                ORDER BY
                    master_dataset.UNIQUE_FACILITY_ID;
            """)
        
        mrg_dups_1 = mrg_1[mrg_1.duplicated(['ASOFDATE', 'UNIQUE_FACILITY_ID', 'IS_ORIG'], keep=False)]
        if mrg_dups_1.__len__() != 0:
            raise Exception("First step merger created duplicates.")
            
        if self.new_financial_logic:   
            mrg_2 = sqldf("""
            SELECT
                master_dataset.*,
                COALESCE(t1.MasterCustomerID, t2.MasterCustomerID) AS MC_MasterCustomer_ID,
                COALESCE(t1.StatementMonths, t2.StatementMonths) AS StatementMonths,
                COALESCE(t1.StatementID, t2.StatementID) AS StatementID,
                COALESCE(t1.AuditMethod, t2.AuditMethod) AS AuditMethod,
                COALESCE(t1.StatementDate, t2.StatementDate) AS StatementDate,
                COALESCE(t1.DebtToTNW, t2.DebtToTNW) AS DebtToTNW,
                COALESCE(t1.EBITDA, t2.EBITDA) AS EBITDA,
                COALESCE(t1.InterestExpense, t2.InterestExpense) AS InterestExpense,
                COALESCE(t1.CashAndEquivs, t2.CashAndEquivs) AS CashAndEquivs,
                COALESCE(t1.NetTradeAcctsRec, t2.NetTradeAcctsRec) AS NetTradeAcctsRec,
                COALESCE(t1.TotalCurLiabs, t2.TotalCurLiabs) AS TotalCurLiabs,
                COALESCE(t1.ProfitBeforeTax, t2.ProfitBeforeTax) AS ProfitBeforeTax,
                COALESCE(t1.NetSales, t2.NetSales) AS NetSales
            FROM
                mrg_1 AS master_dataset
            LEFT JOIN
                processed_mra_data AS t1
                ON
                (master_dataset.MasterCustomerId = t1.MasterCustomerID)
            LEFT JOIN
                processed_mra_data AS t2
                ON
                (master_dataset.MasterOneObligorId = t2.MasterCustomerID)
            ORDER BY
                master_dataset.FacilityNumber;
            """)
        else:
            # old merge logic
            mrg_2 = sqldf("""
            SELECT
                master_dataset.*,
                COALESCE(t1.StatementDate, t2.StatementDate) AS StatementDate,
                COALESCE(t1.DebtToTNW, t2.DebtToTNW) AS DebtToTNW,
                COALESCE(t1.EBITDA, t2.EBITDA) AS EBITDA,
                COALESCE(t1.InterestExpense, t2.InterestExpense) AS InterestExpense,
                COALESCE(t1.CashAndEquivs, t2.CashAndEquivs) AS CashAndEquivs,
                COALESCE(t1.NetTradeAcctsRec, t2.NetTradeAcctsRec) AS NetTradeAcctsRec,
                COALESCE(t1.TotalCurLiabs, t2.TotalCurLiabs) AS TotalCurLiabs,
                COALESCE(t1.ProfitBeforeTax, t2.ProfitBeforeTax) AS ProfitBeforeTax,
                COALESCE(t1.NetSales, t2.NetSales) AS NetSales
            FROM
                mrg_1 AS master_dataset
            LEFT JOIN
                processed_mra_data AS t1
                ON
                (master_dataset.MasterOneObligorId = t1.MasterCustomerID)
            LEFT JOIN
                processed_mra_data AS t2
                ON
                (master_dataset.MasterCustomerId = t2.MasterCustomerID)
            ORDER BY
                master_dataset.FacilityNumber;
            """)
        
        mrg_dups_2 = mrg_2[mrg_2.duplicated(['ASOFDATE', 'UNIQUE_FACILITY_ID', 'IS_ORIG'], keep=False)]
        if mrg_dups_2.__len__() != 0:
            raise Exception("Second step merger created duplicates.")

        if mds_tmp.__len__() != mrg_2.__len__():
            print("MDS : " + str(mds_tmp.__len__()))
            print("MERGE : " + str(mrg_2.__len__()))

        # Parse date fields
        parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S.%f')
        mrg_2["StatementDate"] = mrg_2["StatementDate"].apply(parse_date)
        mrg_2["ASOFDATE"] = mrg_2["ASOFDATE"].apply(parse_date)
        mrg_2["MAXIMUMMATURITYDATE"] = mrg_2["MAXIMUMMATURITYDATE"].apply(parse_date)

        self.__mds_mra = mrg_2

    def processFinancialRatios(self, new_ratio_approach: bool= True):
        """

        Returns
        -------

        """
        # Check for master data
        if self.data is None:
            raise Exception('`self.data` is None.')
            
        # If financials fetched from MV_LOSS_COMMERCIAL, parse date field and assign self.data to mds_mra_tmp 
        if self.financial_in_rfo:
            # Parse date fields
            parse_date = lambda x: pd.NaT if pd.isnull(x) else x
            self.data["StatementDate"] = self.data["StatementDate"].apply(parse_date)
#            self.data["ASOFDATE"] = self.data["ASOFDATE"].apply(parse_date)
#            self.data["MAXIMUMMATURITYDATE"] = self.data["MAXIMUMMATURITYDATE"].apply(parse_date)
            mds_mra_tmp = self.data.copy(deep=True)
        else:
            mds_mra_tmp = self.mds_mra.copy(deep=True)
            
        # Checks
        if mds_mra_tmp is None:
            raise Exception('`self.mds_mra or self.data` is None.')
        utilities.checkDataType(new_ratio_approach, bool)
        
        # Process ratios
        if new_ratio_approach:

            # DebtToTNW
            mds_mra_tmp['r_DebtToTNW1'] = round(
                mds_mra_tmp['DebtToTNW'],
                self.precision
            )

            # r_EBITDAoIntrst
            def r_EBITDAoIntrst(line):
                if pd.isnull(line['EBITDA']):
                    return (np.NaN)
                elif (pd.isnull(line['InterestExpense'])) or (line['InterestExpense'] < 0):
                    return (np.NaN)
                elif (line['InterestExpense'] == 0) and (pd.notnull(line['EBITDA'])):
                    return (line['EBITDA'])
                else:
                    return (line['EBITDA'] / line['InterestExpense'])
            mds_mra_tmp['r_EBITDAoIntrst'] = round(
                mds_mra_tmp.apply(
                    func=r_EBITDAoIntrst,
                    axis=1
                ),
                self.precision
            )

            # r_quickRatio
            def r_quickRatio(line):
                if pd.isnull(line['CashAndEquivs'] + line['NetTradeAcctsRec']):
                    return (np.NaN)
                elif (pd.isnull(line['TotalCurLiabs'])) or (line['TotalCurLiabs'] < 0):
                    return (np.NaN)
                elif (line['TotalCurLiabs'] == 0) and (pd.notnull(line['CashAndEquivs'] + line['NetTradeAcctsRec'])):
                    return (line['CashAndEquivs'] + line['NetTradeAcctsRec'])
                else:
                    return ((line['CashAndEquivs'] + line['NetTradeAcctsRec']) / line['TotalCurLiabs'])
            mds_mra_tmp['r_quickRatio'] = round(
                mds_mra_tmp.apply(
                    func=r_quickRatio,
                    axis=1
                ),
                self.precision
            )

            # r_proftmargin
            def r_proftmargin(line):
                if pd.isnull(line['ProfitBeforeTax']):
                    return (np.NaN)
                elif (pd.isnull(line['NetSales'])) or (line['NetSales'] < 0):
                    return (np.NaN)
                elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] >= 0):
                    return (np.NaN)
                elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] < 0):
                    return (line['ProfitBeforeTax'])
                else:
                    return (line['ProfitBeforeTax'] / line['NetSales'])
            mds_mra_tmp['r_proftmargin'] = round(
                mds_mra_tmp.apply(
                    func=r_proftmargin,
                    axis=1
                ),
                self.precision
            )

        else:
            # DebtToTNW
            mds_mra_tmp['r_DebtToTNW1'] = round(
                mds_mra_tmp['DebtToTNW'],
                self.precision
            )

            # r_EBITDAoIntrst
            def r_EBITDAoIntrst(line):
                if line['InterestExpense'] == 0:
                    return (np.NaN)
                else:
                    return (line['EBITDA'] / line['InterestExpense'])
            mds_mra_tmp['r_EBITDAoIntrst'] = round(
                mds_mra_tmp.apply(
                    func=r_EBITDAoIntrst,
                    axis=1
                ),
                self.precision
            )

            # r_quickRatio
            def r_quickRatio(line):
                if line['TotalCurLiabs'] == 0:
                    return (np.NaN)
                else:
                    return ((line['CashAndEquivs'] + line['NetTradeAcctsRec']) / line['TotalCurLiabs'])
            mds_mra_tmp['r_quickRatio'] = round(
                mds_mra_tmp.apply(
                    func=r_quickRatio,
                    axis=1
                ),
                self.precision
            )

            # r_proftmargin
            def r_proftmargin(line):
                if line['NetSales'] == 0:
                    return (np.NaN)
                else:
                    return (line['ProfitBeforeTax'] / line['NetSales'])
            mds_mra_tmp['r_proftmargin'] = round(
                mds_mra_tmp.apply(
                    func=r_proftmargin,
                    axis=1
                ),
                self.precision
            )

        # Finalize
        self.__mds_mra_financial_ratios = mds_mra_tmp

    def processRiskRatingDataset(self, use_pd_group_tool: bool= True):
        """

        Returns
        -------

        """
        # Check for risk_rating data and facility type data
        if self.risk_rating_dataset is None:
            raise Exception('`self.risk_rating_dataset` is None.')
        risk_rating_dataset_temp = self.risk_rating_dataset.copy(deep=True)
        
        if (self.line_term_type_input_path != None) and (self.line_term_type_dataset is None):
            raise Exception('`self.line_term_type_dataset` is None.')

        mds_mra_financial_ratios = sqldf("""
                        SELECT 
                            ASOFDATE,
                            ONEOBLIGORNUMBER,
                            CUSTOMERNUMBER,
                            FACILITYNUMBER,
                            MAX(MASTER_CUSTOMER_ID) AS MASTER_CUSTOMER_ID,
                            MAX(COSTCENTER) AS COSTCENTER,
                            SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                            LOCAL_NPL_FLAG,
                            MAX(PRI_COLLATVALUE) AS PRI_COLLATVALUE,
                            ROUND(MAX(SRR), 1) AS SRR,
                            UPPER(SOURCEID) AS SOURCEID,
                            FAS114_STATUS,
                            SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                            SUM(CALCULATED_LINE) AS EXPOSURE,
                            MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                            ALLLCOVERAGE,
                            CONTINGENTRESERVE,
                            EAD,
                            LGD,
                            PD,
                            MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                            MAX(CURRENTOCCUPANCY) AS CURRENTOCCUPANCY,
                            MAX(PRI_COLLATNOI) AS PRI_COLLATNOI,
                            UNIQUE_FACILITY_ID,
                            TDR,
                            PROPERTY_TYPE_MAP,
                            BINDINGINDICATOR,
                            MAX(PD_GROUP) AS PD_GROUP,
                            FACILITYTYPE,
                            SICCODE,
                            RETYPE,
                            COLLATERALCODE,
                            COLLATERAL_DESCRIPTION,
                            CONSOLIDATED_COLLATERAL_CODE,
                            PRI_COLLATSTATE,
                            UNSECURED_INDICATOR,
                            IS_ORIG,
                            StatementDate,
                            DAYSTOSTAT,
                            StatementMonths,
                            AuditMethod,
                            StatementID,
                            EBITDA,
                            InterestExpense,
                            CashAndEquivs,
                            NetTradeAcctsRec,
                            TotalCurLiabs,
                            ProfitBeforeTax,
                            NetSales,
                            DebtToTNW,
                            pd_group_tool AS PD_GROUP_TOOL,
                            finalrat_ind,
                            quantrat,
                            FINALRAT,
                            r_DebtToTNW1,
                            r_EBITDAoIntrst,
                            r_proftmargin,
                            r_quickRatio,
                            ChangeNetSal 
                        FROM (
                            SELECT 
                                ASOFDATE,
                                ONEOBLIGORNUMBER,
                                CUSTOMERNUMBER,
                                FACILITYNUMBER,
                                MASTER_CUSTOMER_ID,
                                COSTCENTER,
                                UTILIZATIONLCAMOUNT,
                                LOCAL_NPL_FLAG,
                                PRI_COLLATVALUE,
                                SRR,
                                SOURCEID,
                                FAS114_STATUS,
                                UTILIZATIONBOOKBALANCE,
                                CALCULATED_LINE,
                                UTILIZATIONOPENDATE,
                                ALLLCOVERAGE,
                                CONTINGENTRESERVE,
                                EAD,
                                LGD,
                                PD,
                                MAXIMUMMATURITYDATE,
                                CURRENTOCCUPANCY,
                                CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                                UNIQUE_FACILITY_ID,
                                TDR,
                                PROPERTY_TYPE_MAP,
                                BINDINGINDICATOR,
                                PD_GROUP_2017 AS PD_GROUP,
                                FACILITYTYPE,
                                SICCODE,
                                RETYPE,
                                COLLATERALCODE,
                                COLLATERAL_DESCRIPTION,
                                CONSOLIDATED_COLLATERAL_CODE,
                                PRI_COLLATSTATE,
                                UNSECURED_INDICATOR,
                                CASE WHEN SUBSTR(UNIQUE_FACILITY_ID, -2) = "_O" THEN 'Y' ELSE 'N' END AS IS_ORIG,
                                STATEMENTDATE AS StatementDate,
                                DAYSTOSTAT,
                                STATEMENTMONTHS AS StatementMonths,
                                AUDITMETHOD AS AuditMethod,
                                STATEMENTID AS StatementID,
                                EBITDA AS EBITDA,
                                INTERESTEXPENSE AS InterestExpense,
                                CASHANDEQUIVS AS CashAndEquivs,
                                NETTRADEACCTSREC AS NetTradeAcctsRec,
                                TOTALCURLIABS AS TotalCurLiabs,
                                PROFITBEFORETAX AS ProfitBeforeTax,
                                NETSALES AS NetSales,
                                DEBTTOTNW AS DebtToTNW,
                                pd_group_tool,
                                finalrat_ind,
                                quantrat,
                                FINALRAT,
                                r_DebtToTNW1,
                                r_EBITDAoIntrst,
                                r_proftmargin,
                                r_quickRatio,
                                ChangeNetSal      
                            FROM risk_rating_dataset_temp
                        )
                        WHERE
                            (
                                (
                                    FAS114_STATUS = 'A - NOT REQUIRED'
                                    AND
                                    LOCAL_NPL_FLAG = 'N'
                                )
                            )
                            AND
                            UPPER(SOURCEID) NOT IN ('OFFLINE')
                            AND
                            pd_group_tool IN ('MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL')
                        GROUP BY
                            ASOFDATE,
                            ONEOBLIGORNUMBER,
                            CUSTOMERNUMBER,
                            FACILITYNUMBER,
                            LOCAL_NPL_FLAG,
                            SOURCEID,
                            FAS114_STATUS,
                            ALLLCOVERAGE,
                            CONTINGENTRESERVE,
                            EAD,
                            LGD,
                            PD,
                            UNIQUE_FACILITY_ID,
                            TDR,
                            PROPERTY_TYPE_MAP,
                            BINDINGINDICATOR,
                            FACILITYTYPE,
                            SICCODE,
                            RETYPE,
                            COLLATERALCODE,
                            COLLATERAL_DESCRIPTION,
                            CONSOLIDATED_COLLATERAL_CODE,
                            PRI_COLLATSTATE,
                            UNSECURED_INDICATOR,
                            IS_ORIG,
                            StatementDate,
                            DAYSTOSTAT,
                            EBITDA,
                            InterestExpense,
                            CashAndEquivs,
                            NetTradeAcctsRec,
                            TotalCurLiabs,
                            ProfitBeforeTax,
                            NetSales,
                            DebtToTNW,
                            StatementMonths,
                            AuditMethod,
                            StatementID,
                            pd_group_tool,
                            finalrat_ind,
                            quantrat,
                            FINALRAT,
                            r_DebtToTNW1,
                            r_EBITDAoIntrst,
                            r_proftmargin,
                            r_quickRatio,
                            ChangeNetSal
                        HAVING
                            (SUM(UTILIZATIONBOOKBALANCE)+SUM(UTILIZATIONLCAMOUNT)) > 0
                            OR
                            SUM(CALCULATED_LINE) > 0;
                    """)
                                
        # Parse date fields
        parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S.%f')
        mds_mra_financial_ratios["StatementDate"] = mds_mra_financial_ratios["StatementDate"].apply(parse_date)
        mds_mra_financial_ratios["ASOFDATE"] = mds_mra_financial_ratios["ASOFDATE"].apply(parse_date)
        mds_mra_financial_ratios["MAXIMUMMATURITYDATE"] = mds_mra_financial_ratios["MAXIMUMMATURITYDATE"].apply(parse_date)
        mds_mra_financial_ratios["OPENDATE"] = mds_mra_financial_ratios["OPENDATE"].apply(parse_date)
        
#        t_0 = time.time()          
#        query = """
#                    SELECT DISTINCT SOURCEID, ONE_OBLIGOR_NUMBER, CUSTOMERNUMBER, FACILITYNUMBER, LINE_TERM
#                    FROM {}
#                    WHERE AS_OF_DATE = '{}'
#                    AND UPPER(SOURCEID) NOT IN ('OFFLINE')
#                """.format(
#                        CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["LINE_TERM_DATA"],
#                        date2OracleSTR(self.asofdate)
#                        )
#
#        line_term_data = queryRFO(query=query, moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"]) 
#        t_1 = time.time()
#        runtime = round((t_1 - t_0), 4)
#        print('Fetch completed in ' + str(runtime) + ' s.')

        # Merge with MV_CCMIS_ALL_DATA to get LINE_TERM
        if self.line_term_type_dataset is not None:
            line_term_data = self.line_term_type_dataset.copy(deep=True)
            mds_mra_financial_ratios = mds_mra_financial_ratios.merge(
                                                   line_term_data,
                                                   left_on=['SOURCEID', 'ONEOBLIGORNUMBER', 'CUSTOMERNUMBER', 'FACILITYNUMBER'],
                                                   right_on=['SOURCEID', 'ONE_OBLIGOR_NUMBER', 'CUSTOMERNUMBER', 'FACILITYNUMBER'],
                                                   how='left'
                                                   )
            # Check missing LINE_TERM
            if mds_mra_financial_ratios['LINE_TERM'].isnull().values.any():
                print(line_term_data[line_term_data['LINE_TERM'].isnull()])
                raise Exception("Above loans have missing LINE_TERM")

        # Check for duplicates
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Checking for integrity..."
            )
        dups = mds_mra_financial_ratios.duplicated([
            'ASOFDATE',
            'SOURCEID',
            'ONEOBLIGORNUMBER',
            'CUSTOMERNUMBER',
            'FACILITYNUMBER',
            'IS_ORIG'
        ])
        dups_index = list(dups[dups == True].index)
        if len(dups_index) != 0:
            print(
                self.__class__.__name__ + " : " +
                "Found duplicates..."
            )
            print('Found duplicated records in index/indeces: {}'.format(dups_index))

        # Replace None with NaN
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Replace None with NaN..."
            )
        pd.set_option('mode.chained_assignment', None) # Temp removal of warnings
        mds_mra_financial_ratios.fillna(value=np.nan, inplace=True)
        pd.set_option('mode.chained_assignment', 'warn') # Reestablish warning message

        # Remove originations
        if self.debug & (not self.include_originations):
            print(
                self.__class__.__name__ + " : " +
                "Remove originations..."
            )
        if not self.include_originations:
            mds_mra_financial_ratios = mds_mra_financial_ratios[mds_mra_financial_ratios['IS_ORIG'] == 'N']
        
        # Replace PD_GROUP(PD_GROUP_2017) by PD_GROUP_TOOL
        if use_pd_group_tool:
            mds_mra_financial_ratios.drop(['PD_GROUP'], axis = 1, inplace = True)  
            mds_mra_financial_ratios.rename(index=str, columns={'PD_GROUP_TOOL' : 'PD_GROUP'}, inplace = True)
            
        # Rename column names
        mds_mra_financial_ratios.rename(
                     index=str,
                     columns={
                              'STATEMENTID' : 'StatementID',
                              'STATEMENTDATE' : 'StatementDate',
                              'STATEMENTMONTHS' : 'StatementMonths',
                              'AUDITMETHOD' : 'AuditMethod',
                              'EBITDA' : 'EBITDA',
                              'INTERESTEXPENSE' : 'InterestExpense',
                              'CASHANDEQUIVS' : 'CashAndEquivs',
                              'NETTRADEACCTSREC' : 'NetTradeAcctsRec',
                              'TOTALCURLIABS' : 'TotalCurLiabs',
                              'PROFITBEFORETAX' : 'ProfitBeforeTax',
                              'NETSALES' : 'NetSales',
                              'DEBTTOTNW' : 'DebtToTNW'
                     },
                     inplace = True
            )
        
        # Finalize
        self.__mds_mra_financial_ratios = mds_mra_financial_ratios
        
    def processAdditionalFields(self):
        """

        Returns
        -------

        """
        # Checks
        if self.mds_mra_financial_ratios is None:
            raise Exception('`self.mds_mra_financial_ratios` is None.')

        # Prepare data
        mds_additional_fields_tmp = self.mds_mra_financial_ratios.copy(deep=True)

        # add 10/03/2017: mrs_srr conversion
        def SRR_mrs_convert(line):
            mrs_srr = int(2 * line["SRR"]) * 0.5
            return(mrs_srr)
        if self.mrs_srr_switch:
            mds_additional_fields_tmp["SRR"] = mds_additional_fields_tmp.apply(
                func=SRR_mrs_convert,
                axis=1
            )
            
        # Process SRR pass/non-pass
        def SRR_rating_pass(line):
            if line["SRR"] <= self.__pass_SRR:
                return False
            else:
                return True
        mds_additional_fields_tmp["SRR_rating_pass"] = mds_additional_fields_tmp.apply(
            func=SRR_rating_pass,
            axis=1
        )

        # Compute statement age in days
        def statementAgeInDays(line):
            # old code
            # return(utilities.daysDifference(line["ASOFDATE"], line["StatementDate"]))
            if (self.__risk_rating_dataset_input_path != None) and (line['finalrat_ind'] == 1):
                diff = line['DAYSTOSTAT']
            else:
                diff = utilities.daysDifference(line["ASOFDATE"], line["StatementDate"]) 
            # for missing statement date, return -1
            if int(diff) < 0:
                return -1
            else:
                return int(diff)
        
        mds_additional_fields_tmp["asofdate2stmtdate"] = mds_additional_fields_tmp.apply(
            func=statementAgeInDays,
            axis=1
        )
        
        # Maximum maturity date imputation: get new maturity date
        def updateMaturityDate(line):
            mat_d = line["MAXIMUMMATURITYDATE"]
            orig_d = line["OPENDATE"]
            asofdate = line['ASOFDATE']
            facility_type = line['FACILITYTYPE']
            dmdLife = 11*12  # 11 years
            rloc_month_add = 15
            non_rloc_month_add = 46
            def remaining_life(asofdate, maturityDate):
                try:
                    r_delta = relativedelta.relativedelta(maturityDate, asofdate)
                except (TypeError, AssertionError):
                    remainingLife = np.nan
                else:
                    remainingLife = r_delta.years * 12 + r_delta.months
                return(remainingLife)
            
            if mat_d <= asofdate:
                # if maturity date is prior or equal to as_of_date, forecast 12 month
                mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, 12))
            elif pd.isnull(mat_d):
                if pd.isnull(orig_d):
                    if (facility_type.upper() == 'REVOLVING LINE OF CREDIT'):
                        mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, rloc_month_add))
                    else:
                        mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, non_rloc_month_add))
                else:
                    mat_d = utilities.monthEndDate(utilities.addMonths2date(orig_d, dmdLife))
                    remainingLife = remaining_life(asofdate, mat_d)
                    if (facility_type.upper() == 'REVOLVING LINE OF CREDIT') and (remainingLife < 15):
                        mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, rloc_month_add)) 
                    elif (facility_type.upper() != 'REVOLVING LINE OF CREDIT') and (remainingLife < 46):
                        mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, non_rloc_month_add)) 
            else:
                return(mat_d)
            return(mat_d)
        
        if self.maximum_maturity_date_imputation:
            mds_additional_fields_tmp["MAXIMUMMATURITYDATE_NEW"] = mds_additional_fields_tmp.apply(
                func=updateMaturityDate,
                axis=1
            )

        # Compute months to maturity
        def monthsToMaturity(line):
            if not self.maximum_maturity_date_imputation:
                mat_d = line["MAXIMUMMATURITYDATE"]
            else:
                mat_d = line["MAXIMUMMATURITYDATE_NEW"]
            as_of_d = line["ASOFDATE"]

            try:
                monthend_mat_d = utilities.monthEndDate(mat_d)
                r_delta = relativedelta.relativedelta(monthend_mat_d, as_of_d)
            except (TypeError, AssertionError):
                m2mat = np.nan
            else:
                m2mat = r_delta.years * 12 + r_delta.months
            return(m2mat)
        mds_additional_fields_tmp["m2mat"] = mds_additional_fields_tmp.apply(
            func=monthsToMaturity,
            axis=1
        )

        # Compute maturity indicator
        def maturityIndicator(line):
            if pd.isnull(line["m2mat"]):
                return(False)
            elif line["m2mat"] <= 0:
                return(True)
            else:
                return(False)

        mds_additional_fields_tmp["matureInd"] = mds_additional_fields_tmp.apply(
            func=maturityIndicator,
            axis=1
        )

        # Collateral Type
        COLLATERAL_TYPE_MAP = Mapping(
            in_map={
                'IN_VAR': 'COLLATERALCODE',
                'OUT_VAR': 'COLLATERAL_TYPE',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    '14',
                    '30',
                    '38',
                    '123',
                    '140',
                    '170',
                    '199',
                    '204',
                    '219',
                    '230',
                    '253',
                    '257',
                    '258',
                    '259',
                    '260',
                    '264',
                    '265',
                    '269',
                    '270',
                    '310',
                    '402',
                    '406',
                    '502',
                    '552',
                    '800',
                    '812',
                    '816',
                    '899',
                    '001',
                    '1',
                    '10',
                    '100',
                    '103',
                    '104',
                    '106',
                    '12',
                    '120',
                    '127',
                    '20',
                    '200',
                    '208',
                    '209',
                    '210',
                    '212',
                    '22',
                    '232',
                    '235',
                    '240',
                    '250',
                    '251',
                    '252',
                    '254',
                    '255',
                    '256',
                    '261',
                    '262',
                    '263',
                    '266',
                    '267',
                    '268',
                    '271',
                    '272',
                    '273',
                    '274',
                    '275',
                    '276',
                    '290',
                    '300',
                    '304',
                    '308',
                    '312',
                    '318',
                    '321',
                    '34',
                    '400',
                    '404',
                    '419',
                    '50',
                    '52',
                    '60',
                    '61',
                    '999'
                ),
                'MAPPED_VALUES': (
                    'FINANCIAL ASSETS',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'ALL ASSETS/OTHER',
                    'RESIDENTIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'FINANCIAL ASSETS',
                    'RESIDENTIAL PROPERTIES',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'UNSECURED',
                    'UNSECURED',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'RESIDENTIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'HOSPITAL/ MEDICAL CARE PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'COMMERCIAL PROPERTIES',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER'
                ),
                'MISSING': 'ALL ASSETS/OTHER',
                'DEFAULT': 'ALL ASSETS/OTHER'
            },
            debug=False
        )
        mds_additional_fields_tmp['COLLATERAL_TYPE'] = [
            COLLATERAL_TYPE_MAP.apply(item) \
            for item in mds_additional_fields_tmp['COLLATERALCODE']
        ]


        # Finalize
        self.__mds_mra_additional_fields = mds_additional_fields_tmp

    @property
    def pass_SRR(self):
        return(self.__pass_SRR)

    @property
    def statement_days_threshold(self):
        return(self.__statement_days_threshold)

    @property
    def mds_mra(self):
        return(self.__mds_mra)

    @property
    def raw_mra_data(self):
        return (self.__raw_mra_data)

    @property
    def processed_mra_data(self):
        return (self.__processed_mra_data)

    @property
    def sourcesystem_to_mra(self):
        return(self.__sourcesystem_to_mra)

    @property
    def mds_mra_financial_ratios(self):
        return(self.__mds_mra_financial_ratios)

    @property
    def mds_mra_additional_fields(self):
        return(self.__mds_mra_additional_fields)

    @property
    def mra_asofdate(self):
        return (self.__mra_asofdate)

    @property
    def financial_in_rfo(self):
        return (self.__financial_in_rfo)

    @property
    def new_financial_logic(self):
        return (self.__new_financial_logic)
        
    @property
    def maximum_maturity_date_imputation(self):
        return (self.__maximum_maturity_date_imputation)

    @property
    def mrs_srr_switch(self):
        return (self.__mrs_srr_switch)
        
    @property
    def risk_rating_dataset_input_path(self):
        return (self.__risk_rating_dataset_input_path)
    
    @property
    def risk_rating_dataset(self):
        return (self.__risk_rating_dataset)
        
    @property
    def line_term_type_input_path(self):
        return (self.__line_term_type_input_path)
        
    @property
    def line_term_type_dataset(self):
        return (self.__line_term_type_dataset)

##
## C&I MODEL CLASS DEFINITION
##
class CNIModel(CCARModel):
    # Member properties
    __pass_srr = None
    __portfolio_snapshot = None
    __cni_mds_instance = None
    __include_originations_switch = None
    __scenario_severity_level_level = None
    __pd_groups = None
    __results_set = None
    __scenario_period_frequency = None
    __statement_days_threshold = None
    __SRR_overlay_switch = None
    __PD_mapping_switch = None
    __calculation_periods = None
    __LEQ_df = None
    __results_df = None
    __MRS_notch_down_switch = None
    __PD_lag1Q_switch = None
    __portfolio_snapshot_date = None
    __mature_non_pass_locs = None
    __mra_asofdate = None
    __financial_in_rfo = None
    __new_financial_logic = None
    __show_result_plot = None
    __new_LEQ_switch = None
    __discounting_LGD_switch = None
    __add_uat_columns = None
    __staging_dataset_input_path= None
    __maturity_switch = None
    __maximum_maturity_date_imputation = None
    __forecast_result_frequency = None
    __PD_special_set1 = None
    __fix_forecast_period = None
    __stage_diff_switch = None
    __provide_test_facility = None
    __portfolio_average_interestrate = None
    __mrs_srr_switch = None
    __ifrs_switch = None
    __risk_rating_dataset_input_path = None
    __line_term_type_input_path = None

    # Member methods
    def __init__(
        self,
        as_of_date: datetime.datetime,
        scenario: str,
        scenario_context: str,
        scenario_date: datetime.datetime,
        scenario_severity_level: str,
        forecast_periods: int,
        pass_srr: (int, float) = 4.0,
        model_id: str = "2016-SBNA-Loss-Commecial-CI",
        forecast_periods_frequency: str = 'monthly',
        debug: bool = False,
        include_originations_switch: bool = True,
        precision: int = None,
        auto_fetch_macros: bool = True,
        pd_groups: list = CNI_PD_GROUP_LIST,
        limit_contracts=None,
        statement_days_threshold=366,
        SRR_overlay_switch: bool =True,
        PD_mapping_switch: bool =True,
        MRS_notch_down_switch: bool = False,
        PD_lag1Q_switch: bool = True,   # lag 1Q for macro for PD computation
        PD_special_set1: bool = False,  # If SRR in (1.0, 1.1, 1.2) or (SRR<1 and LOCAL_NPL_FLAG=”Y”) then PD=1
        use_RFO_macro_series: bool = True,  # Use macro in SQLite
        new_LEQ_switch: bool = True,    # Use new LEQ factors(44Q)
        discounting_LGD_switch: bool = False,   # discounting LGD using interest rate and nco curve
        add_uat_columns: bool = False,  # add detailed columns for UAT
        staging_dataset_input_path: str = None, # path for staging data(stage/average interest rate)
        stage_diff_switch: bool = False,    # forecast horizon different for stage 1 (4Q) and stage 2/3 (44Q)
        fix_forecast_period: str = True,    # fixed or dynamic decide forecast period for each facility
        maturity_switch: bool = False,  # mature loans (check monthly)
        maximum_maturity_date_imputation: bool = False,  # impuatation for missing maxMaturityDate
        mrs_srr_switch: bool = True,    # convert SRR from 0.1 interval to 0.5 interval (downward)
        forecast_result_frequency: str = 'monthly', # the output dataset is monthly(official run) or quarterly(uat purpose)
        provide_test_facility: bool = False,    # provide specific facilities to test
        ifrs_switch: bool = False,  # whether this is a ifrs run
        portfolio_snapshot_date = None,
        mature_non_pass_locs: bool = True,
        mra_asofdate: datetime.datetime = None,
        financial_in_rfo: bool = True,
        new_financial_logic: bool = True,
        show_result_plot: bool = False,
        risk_rating_dataset_input_path: str = None, # path for risk rating data(finalrat_ind; financial ratios)
        line_term_type_input_path: str = None,  # path for facility type data(LINE_TERM, SOURCEID, ONE_OBLIGOR_NUMBER, CUSTOMERNUMBER, FACILITYNUMBER)
        **kwargs
    ):
        # Starting timer for class initialization
        t0 = time.time()
        
        # Initialize parent class properties
        CCARModel.__init__(
            self,
            as_of_date=as_of_date,
            model_id=model_id,
            scenario=scenario,
            scenario_date=scenario_date,
            scenario_context=scenario_context,
            forecast_periods=forecast_periods,
            forecast_periods_frequency=forecast_periods_frequency,
            precision=precision,
            use_RFO_macro_series = use_RFO_macro_series,
            scenario_combinations=kwargs.get("scenario_combinations")
        )

        # Check data types
        utilities.checkDataType(debug, bool)
        utilities.checkDataType(pass_srr, float)
        utilities.checkDataType(include_originations_switch, bool)
        utilities.checkDataType(auto_fetch_macros, bool)
        utilities.checkDataType(scenario_severity_level, str)
        utilities.checkDataType(pd_groups, list)
        utilities.checkDataType(statement_days_threshold, int)
        utilities.checkDataType(SRR_overlay_switch, bool)
        utilities.checkDataType(PD_mapping_switch, bool)
        utilities.checkDataType(MRS_notch_down_switch, bool)
        utilities.checkDataType(PD_lag1Q_switch, bool)
        utilities.checkDataType(mature_non_pass_locs, bool)
        utilities.checkDataType(financial_in_rfo, bool)
        utilities.checkDataType(new_financial_logic, bool)
        utilities.checkDataType(show_result_plot, bool)
        utilities.checkDataType(use_RFO_macro_series, bool)
        utilities.checkDataType(new_LEQ_switch, bool)
        if forecast_result_frequency not in ['monthly', 'quarterly', 'yearly']: 
            raise ValueError("Invalid input forecast_result_frequency.")
        
        # Process portfolio snapshot date
        if portfolio_snapshot_date is not None:
            utilities.checkDataType(portfolio_snapshot_date, datetime.datetime)
        else:
            portfolio_snapshot_date = self.as_of_date
        
        # Process mra as of date
        if mra_asofdate is not None:
            utilities.checkDataType(mra_asofdate, datetime.datetime)
        else:
            mra_asofdate = self.as_of_date
            
        # Assign default value for IFRS run
        if ifrs_switch:
            PD_special_set1 = True
            discounting_LGD_switch = True

        # Assign member properties
        self.debug = debug
        self.__pass_srr = pass_srr
        self.__include_originations_switch = include_originations_switch
        self.__pd_groups = pd_groups
        self.__statement_days_threshold = statement_days_threshold
        self.__SRR_overlay_switch = SRR_overlay_switch
        self.__PD_mapping_switch = PD_mapping_switch
        self.__MRS_notch_down_switch = MRS_notch_down_switch
        self.__PD_lag1Q_switch = PD_lag1Q_switch
        self.__portfolio_snapshot_date = portfolio_snapshot_date
        self.__mature_non_pass_locs = mature_non_pass_locs
        self.__financial_in_rfo = financial_in_rfo
        self.__new_financial_logic = new_financial_logic
        self.__show_result_plot = show_result_plot
        self.__new_LEQ_switch = new_LEQ_switch
        self.__discounting_LGD_switch = discounting_LGD_switch
        self.__add_uat_columns = add_uat_columns
        self.__staging_dataset_input_path = staging_dataset_input_path
        self.__stage_diff_switch = stage_diff_switch
        self.__maturity_switch = maturity_switch
        self.__maximum_maturity_date_imputation = maximum_maturity_date_imputation
        self.__mrs_srr_switch = mrs_srr_switch
        self.__forecast_result_frequency = forecast_result_frequency
        self.__PD_special_set1 = PD_special_set1
        self.__fix_forecast_period = fix_forecast_period
        self.__provide_test_facility = provide_test_facility
        self.__ifrs_switch = ifrs_switch
        self.__risk_rating_dataset_input_path = risk_rating_dataset_input_path
        self.__line_term_type_input_path = line_term_type_input_path
        
        # Get macro variables during construction
        if auto_fetch_macros:
            self.fetchMacroSeries(scenario_combinations=kwargs.get('scenario_combinations'))

        # Validate scenario severity
        if scenario_severity_level in utilities.SCENARIO_SEVERITY_LEVELS:
            self.__scenario_severity_level = utilities.SCENARIO_SEVERITY_LEVELS[scenario_severity_level]
        else:
            raise ValueError("Invalid input `scenario_severity_level`.")

        # Get scenario period frequency
        self.__scenario_period_frequency = self._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )
        self.__calculation_periods = int(
            self.forecast_periods / utilities.PERIOD_FREQUENCY_MAP[
                self.scenario_period_frequency
            ]
        )

        # Get portfolio snapshot/data
        # self.portfolio_snapshot = pd.read_csv('C:\\Users\\n844639\\Desktop\\MyABL\\cni_data.csv')
        self._logger.add(
            type='INFO',
            message='Fetching portfolio snapshot from RFO for date {}'.format(
                str(self.__portfolio_snapshot_date)
            ),
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        # Starting timer
        t_0 = time.time()
        self.__cni_mds_instance = CNIMasterDataset(
            asofdate=portfolio_snapshot_date,
            pd_groups=pd_groups,
            pass_SRR=pass_srr,
            limit_contracts=limit_contracts,
            include_originations=include_originations_switch,
            statement_days_threshold=statement_days_threshold,
            mra_asofdate = mra_asofdate,
            financial_in_rfo = financial_in_rfo,
            new_financial_logic = new_financial_logic,
            maximum_maturity_date_imputation = maximum_maturity_date_imputation,
            mrs_srr_switch = mrs_srr_switch,
            risk_rating_dataset_input_path = risk_rating_dataset_input_path,
            line_term_type_input_path = line_term_type_input_path
        )
        self.__portfolio_snapshot = self.__cni_mds_instance.mds_mra_additional_fields

        # temp: merge with staging data from modeler
        if self.__staging_dataset_input_path != None:
            staging_data = pd.read_csv(self.__staging_dataset_input_path)
            staging_data['unique_facility_id'] = staging_data['unique_facility_id'].apply(lambda x: x.upper())
            self.__portfolio_snapshot = self.__portfolio_snapshot.merge(
                staging_data,
                left_on = 'UNIQUE_FACILITY_ID',
                right_on = 'unique_facility_id',
                how='left'
            )
            # drop the duplicate columns after merge
            self.__portfolio_snapshot.drop(['unique_facility_id', 'AsOfDate'], axis = 1, inplace = True)   
            
        # 09/29/2017 add: calculate portfolio average interest rate for LGD discounting rate imputation
        if self.__discounting_LGD_switch:
            self.__portfolio_average_interestrate = self.__portfolio_snapshot['avg_interestrate'].mean() / 100

        # 09/28/2017 add: if test specific facility, specify unique facility id below:
        if self.__provide_test_facility:
            self.__portfolio_snapshot = self.__portfolio_snapshot[self.__portfolio_snapshot['UNIQUE_FACILITY_ID'].isin(
                              ['AFS0052456261005245626100524562610000000026',
                               'AFS0052568966005259822900525982290000000018',
                               'AFS0050298145005029814500502981450000000240',
                               'AFS0051022031005102203100510220310000000133',
                               'AFS0052151383005215138300521513830000000109',
                               'AFS0050640833005064083300506408330000000364_O',
                               'AFS0051068851005106885100510688510000000034_O',
                               'AFS0051113582005111358200511135820000000018_O',
                               'AFS0051269178005120408400512040840000000018_O'])]
        # Calculating runtime
        t_1 = time.time()
        runtime = round((t_1 - t_0), 4)
        self._logger.add(
            type='INFO',
            message='Fetching snapshots completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Fetching coverage rates from model property JSON file
        self._logger.add(
            type='INFO',
            message='Fetching Coverage rates from JSON file...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        ## ALLL mapping ##
        alll_all = self._model_properties.getParameters(
                    type = 'property',
                    name = 'alll_coverage',
                    segment = 'all' 
                )[0]   
        # Begin from Mid-cycle 2017, use different ALLL rates for each PD Groups
        if self.as_of_date >= datetime.datetime(2017,6,30):          
            alll_abl = self._model_properties.getParameters(
                                type = 'property',
                                name = 'alll_coverage',
                                segment = 'ABL' 
                            )[0]
            alll_mm = self._model_properties.getParameters(
                                type = 'property',
                                name = 'alll_coverage',
                                segment = 'MIDDLE_MARKET' 
                            )[0]
            alll_ubb = self._model_properties.getParameters(
                                type = 'property',
                                name = 'alll_coverage',
                                segment = 'BUSINESS_BANKING' 
                            )[0]   

            if (alll_abl is None) or (alll_mm is None) or (alll_ubb is None):
                raise Exception('`alll_abl/alll_mm/alll_ubb` is None.')  
            # For mappin table    
            alll_srr_sorted = [float(key) for key in sorted(alll_all, reverse = True)]
            alll_rate_sorted = [alll_all[item] for item in sorted(alll_all, reverse = True)]
    
            alll_abl_srr_sorted = [float(key) for key in sorted(alll_abl, reverse = True)]
            alll_abl_rate_sorted = [alll_abl[item] for item in sorted(alll_abl, reverse = True)]
    
            alll_mm_srr_sorted = [float(key) for key in sorted(alll_mm, reverse = True)]
            alll_mm_rate_sorted = [alll_mm[item] for item in sorted(alll_mm, reverse = True)]
    
            alll_ubb_srr_sorted = [float(key) for key in sorted(alll_ubb, reverse = True)]
            alll_ubb_rate_sorted = [alll_ubb[item] for item in sorted(alll_ubb, reverse = True)]
                                          
        else:
            if alll_all is None:
                raise Exception('`alll_all` is None.')
            alll_srr_sorted = [float(key) for key in sorted(alll_all, reverse = True)]
            alll_rate_sorted = [alll_all[item] for item in sorted(alll_all, reverse = True)]
            # assign portfolio coverage rates to all pd groups
            alll_abl_srr_sorted = alll_mm_srr_sorted = alll_ubb_srr_sorted = alll_srr_sorted
            alll_abl_rate_sorted = alll_mm_rate_sorted = alll_ubb_rate_sorted = alll_rate_sorted


        ## CONTINGENCY mapping ##

        contingent_all = self._model_properties.getParameters(
                            type = 'property',
                            name = 'contingent_reserve',
                            segment = 'all' 
                        )[0]   
        # Begin from Mid-cycle 2017, use different Coverage rates for each PD Groups
        if self.as_of_date >= datetime.datetime(2017,6,30):     
            contingent_abl = self._model_properties.getParameters(
                                type = 'property',
                                name = 'contingent_reserve',
                                segment = 'ABL' 
                            )[0]                                                              
            contingent_mm = self._model_properties.getParameters(
                                type = 'property',
                                name = 'contingent_reserve',
                                segment = 'MIDDLE_MARKET' 
                            )[0]
            contingent_ubb = self._model_properties.getParameters(
                                type = 'property',
                                name = 'contingent_reserve',
                                segment = 'BUSINESS_BANKING' 
                            )[0]   
            if (contingent_abl is None) or (contingent_mm is None) or (contingent_ubb is None):
                raise Exception('`contingent_abl/contingent_mm/contingent_ubb` is None.')    
            # For mapping table
            contingent_srr_sorted = [float(key) for key in sorted(contingent_all, reverse = True)]
            contingent_rate_sorted = [contingent_all[item] for item in sorted(contingent_all, reverse = True)]
    
            contingent_abl_srr_sorted = [float(key) for key in sorted(contingent_abl, reverse = True)]
            contingent_abl_rate_sorted = [contingent_abl[item] for item in sorted(contingent_abl, reverse = True)]
    
            contingent_mm_srr_sorted = [float(key) for key in sorted(contingent_mm, reverse = True)]
            contingent_mm_rate_sorted = [contingent_mm[item] for item in sorted(contingent_mm, reverse = True)]
    
            contingent_ubb_srr_sorted = [float(key) for key in sorted(contingent_ubb, reverse = True)]
            contingent_ubb_rate_sorted = [contingent_ubb[item] for item in sorted(contingent_ubb, reverse = True)]                                         
        else:
            if contingent_all is None:
                raise Exception('`contingent_all` is None.')
            contingent_srr_sorted = [float(key) for key in sorted(contingent_all, reverse = True)]
            contingent_rate_sorted = [contingent_all[item] for item in sorted(contingent_all, reverse = True)]
            # assign portfolio coverage rates to all pd groups
            contingent_abl_srr_sorted = contingent_mm_srr_sorted = contingent_ubb_srr_sorted = contingent_srr_sorted
            contingent_abl_rate_sorted = contingent_mm_rate_sorted = contingent_ubb_rate_sorted = contingent_rate_sorted
                     
        # Fetch mappings
        list_of_mappings = [
            {
                'IN_VAR': 'estimated_PD',
                'OUT_VAR': 'STDR_RR_OPR',
                'TYPE': 'interval_right',
                'IN_VALUES': (
                    0.0008, 0.0013, 0.0021, 0.0034, 0.0054,
                    0.0087, 0.0141, 0.0226, 0.0364, 0.0586, 0.0944,
                    0.1520
                ),
                'MAPPED_VALUES': (
                    8.5, 8.0, 7.5, 7.0, 6.5,
                    6.0, 5.5, 5.0, 4.5, 4.0,
                    3.5, 3.0, 1.5
                ),

                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<=1)"
            },
            {
                'IN_VAR': 'final_rating',
                'OUT_VAR': 'MRS_PD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    1, 1.5, 2, 2.5, 3,
                    3.5, 4, 4.5, 5, 5.5,
                    6, 6.5, 7, 7.5, 8,
                    8.5
                ),
                'MAPPED_VALUES': (
                    1.0, 0.58, 0.58, 0.58,
                    0.1198, 0.0744, 0.0462, 0.0287,
                    0.0178, 0.0111, 0.0069, 0.0043,
                    0.0027, 0.0016, 0.001, 0.0006
                ),
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=1) and (x<=8.5)"

            },
            {
                'IN_VAR': 'r_DebtToTNW1',
                'OUT_VAR': 'V_Debt2TNW',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -1.009854, 0.752294, 2.113506, 3.357537
                ),
                'MAPPED_VALUES': (
                    -0.64, 0.69, 0.54, 0.31, -0.24
                ),

                'MISSING': -0.64,
            },
            {
                'IN_VAR': 'r_EBITDAoIntrst',
                'OUT_VAR': 'V_EBITDA2IntExp',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    1.13793103448275, 3.46031746031746, 8.00684931506849, 20.8333333333333
                ),
                'MAPPED_VALUES': (
                    -0.96, -0.21, 0.09, 0.7, 1.28
                ),

                'MISSING': 0.52,

            },
            {
                'IN_VAR': 'r_quickRatio',
                'OUT_VAR': 'V_QuickR',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    0.46828143021914, 1.06599578750292, 1.61751152073732
                ),
                'MAPPED_VALUES': (
                    -0.51, -0.12, 0.59, 0.79,
                ),

                'MISSING': 0.06,
            },
            {
                'IN_VAR': 'ChgSales',
                'OUT_VAR': 'V_ChgSales',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -0.12697919900651, -0.04720423778693, 0, 0.0835806132542,
                    0.15284210526315, 0.30612244897959
                ),
                'MAPPED_VALUES': (
                    -0.65, -0.11, 0.17, 0.39, 0.7, 0.06, -0.27
                ),

                'MISSING': 0.35,
            },
            {
                'IN_VAR': 'r_proftmargin',
                'OUT_VAR': 'V_ProfitM',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -0.01217656, 0.0040471885, 0.02028458976687, 0.29189044038668,
                ),
                'MAPPED_VALUES': (
                    -0.78, 0.1, 0.19, 0.33, 0.75
                ),

                'MISSING': 0.81,
            },
            {
                'IN_VAR': 'LGD_BASE_BUSINESS_BANKING',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.44, 0.32, 0.26, 0.36, 0.33, 0.18, 0.5, 0.41
                ),
                'MISSING': 0.44,
                'DEFAULT': 0.44
            },
            {
                'IN_VAR': 'LGD_ADVERSE_BUSINESS_BANKING',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.465, 0.36, 0.285, 0.385, 0.355, 0.215, 0.52, 0.435
                ),
                'MISSING': 0.465,
                'DEFAULT': 0.465
            },
            {
                'IN_VAR': 'LGD_STRESS_BUSINESS_BANKING',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.49, 0.38, 0.31, 0.41, 0.38, 0.25, 0.54, 0.46
                ),

                'MISSING': 0.49,
                'DEFAULT': 0.49
            },
            {
                'IN_VAR': 'LGD_BASE_MIDDLE_MARKET',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.37, 0.32, 0.26, 0.36, 0.33, 0.18, 0.5, 0.41
                ),
                'MISSING': 0.37,
                'DEFAULT': 0.37
            },
            {
                'IN_VAR': 'LGD_ADVERSE_MIDDLE_MARKET',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.38, 0.36, 0.285, 0.385, 0.355, 0.215, 0.52, 0.435
                ),
                'MISSING': 0.38,
                'DEFAULT': 0.38
            },
            {
                'IN_VAR': 'LGD_STRESS_MIDDLE_MARKET',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.39, 0.38, 0.31, 0.41, 0.38, 0.25, 0.54, 0.46
                ),

                'MISSING': 0.39,
                'DEFAULT': 0.39
            },
            {
                'IN_VAR': 'LGD_ABL_AR',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'BASE', 'ADVERSE', 'STRESS'
                ),
                'MAPPED_VALUES': (
                    0.125, 0.16, 0.195
                ),
                'MISSING': 0.125
            },
            {
                'IN_VAR': 'LGD_ABL_NonAR',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'BASE', 'ADVERSE', 'STRESS'
                ),
                'MAPPED_VALUES': (
                    0.175, 0.208, 0.241
                ),
                'MISSING': 0.175
            },
            {
                'IN_VAR': 'ALLL_SRR',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_srr_sorted,
                'MAPPED_VALUES': alll_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'ALLL_SRR_ABL',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_abl_srr_sorted,
                'MAPPED_VALUES': alll_abl_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'ALLL_SRR_MM',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_mm_srr_sorted,
                'MAPPED_VALUES': alll_mm_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'ALLL_SRR_UBB',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_ubb_srr_sorted,
                'MAPPED_VALUES': alll_ubb_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'CONTINGENCY_SRR',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_srr_sorted,
                'MAPPED_VALUES': contingent_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
                        {
                'IN_VAR': 'CONTINGENCY_SRR_ABL',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_abl_srr_sorted,
                'MAPPED_VALUES': contingent_abl_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'CONTINGENCY_SRR_MM',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_mm_srr_sorted,
                'MAPPED_VALUES': contingent_mm_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'CONTINGENCY_SRR_UBB',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_ubb_srr_sorted,
                'MAPPED_VALUES': contingent_ubb_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
        ]

        # Processing macro drivers
        self._logger.add(
            type='INFO',
            message='Processing macro drivers...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self.macro_data = self.transformMacroData()


        # Processing all mappings
        self._logger.add(
            type='INFO',
            message='Processing mappings...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self._mappings = self.processMappings(list_of_mappings=list_of_mappings)  
        
        # Calculating runtime; Finalize and clean up
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        self._logger.add(
            type='INFO',
            message='CCAR Model initialization completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

    @property
    def mappings(self):
        return self._mappings

    @property
    def portfolio_snapshot(self):
        return(self.__portfolio_snapshot)

    @property
    def portfolio_snapshot_date(self):
        return(self.__portfolio_snapshot_date)

    @property
    def mra_asofdate(self):
        return(self.__mra_asofdate)
    
    @property
    def pass_srr(self):
        return (self.__pass_srr)

    @property
    def scenario_severity_level(self):
        return(self.__scenario_severity_level)

    @property
    def pd_groups(self):
        return(self.__pd_groups)

    @property
    def results_set(self):
        return(self.__results_set)

    @property
    def scenario_period_frequency(self):
        return(self.__scenario_period_frequency)

    @property
    def statement_days_threshold(self):
        return (self.__statement_days_threshold)

    @property
    def include_originations_switch(self):
        return (self.__include_originations_switch)

    @property
    def SRR_overlay_switch(self):
        return (self.__SRR_overlay_switch)

    @property
    def PD_mapping_switch(self):
        return (self.__PD_mapping_switch)

    @property
    def calculation_periods(self):
        return (self.__calculation_periods)

    @property
    def LEQ_df(self):
        return (self.__LEQ_df)
    
    @property
    def results_df(self):
        return (self.__results_df)
    
    @property
    def MRS_notch_down_switch(self):
        return (self.__MRS_notch_down_switch)
    
    @property
    def PD_lag1Q_switch(self):
        return (self.__PD_lag1Q_switch)
        
    @property
    def PD_special_set1(self):
        return (self.__PD_special_set1)        
    
    @property
    def new_LEQ_switch(self):
        return (self.__new_LEQ_switch)

    @property
    def discounting_LGD_switch(self):
        return (self.__discounting_LGD_switch)
        
    @property
    def add_uat_columns(self):
        return (self.__add_uat_columns)

    @property
    def staging_dataset_input_path(self):
        return (self.__staging_dataset_input_path)    

    @property
    def stage_diff_switch(self):
        return (self.__stage_diff_switch)    
        
    @property
    def maturity_switch(self):
        return (self.__maturity_switch)    

    @property
    def fix_forecast_period(self):
        return (self.__fix_forecast_period)           

    @property
    def maximum_maturity_date_imputation(self):
        return (self.__maximum_maturity_date_imputation)    
        
    @property
    def mrs_srr_switch(self):
        return (self.__mrs_srr_switch)            
 
    @property
    def forecast_result_frequency(self):
        return (self.__forecast_result_frequency)     

    @property
    def provide_test_facility(self):
        return (self.__provide_test_facility) 

    @property
    def portfolio_average_interestrate(self):
        return (self.__portfolio_average_interestrate) 
 
    @property
    def ifrs_switch(self):
        return (self.__ifrs_switch)
            
    @property
    def mature_non_pass_locs(self):
        return (self.__mature_non_pass_locs)
    
    @property
    def financial_in_rfo(self):
        return (self.__financial_in_rfo)
    
    @property
    def new_financial_logic(self):
        return (self.__new_financial_logic)
    
    @property
    def show_result_plot(self):
        return (self.__show_result_plot)

    @property
    def risk_rating_dataset_input_path(self):
        return (self.__risk_rating_dataset_input_path)
        
    @property
    def line_term_type_input_path(self):
        return (self.__line_term_type_input_path)

    def transformMacroData(self):
        """This function computes macro_data from regression, using methods in slide 34 of CCAR/DFAST 2016 Wholesale models

        Return:
            a data frame, row -> different quarters, column -> different macro variables necessary for CNI/ABL models
        """
        macro_coef = {
            'diff_proftmargin': {
                'intercept': -0.00093,
                'FZ_US_p1y': 0.01588
            },
            'pct_chg_netsales': {
                'intercept': 0.00061,
                'FGDPQ_US_p1y': 1.49628
            },
            'PD_mapping_NonPass': {
                'intercept': -0.08708,
                'FLBR_US_d1y_l1q': 0.26289,
                'FHOFHOPIQ_US_p1y': -1.79959
            },
            'PD_mapping_Pass': {
                'intercept': -0.02841,
                'FLBR_US_d1y_l1q': 0.22778,
                'FHOFHOPIQ_US_p1y': -1.68640
            }
        }
        self.transformed_macro_series['intercept'] = 1 # needed for loop computation
        self.transformed_macro_series_include_t0['intercept'] = 1 # needed for loop computation
        self.transformed_macro_series_include_all['intercept'] = 1 # needed for loop computation
                
        temp = []
        for i in range(self.calculation_periods):
            temp.append({})
            for elem in macro_coef.keys():
                temp_sum = 0
                for key, value in macro_coef[elem].items():
                    if self.PD_lag1Q_switch:
                        temp_sum += value * self.transformed_macro_series_include_t0.iloc[i][key]
                    else:
                        temp_sum += value * self.transformed_macro_series.iloc[i][key]
                temp[-1][elem] = temp_sum
        return pd.DataFrame(temp)

    def processMappings(self, list_of_mappings):
        """ This function associates some mappings with the CNI Model

        Args:
            list_of_mapping: a mapping list, which will be the keys of the mapping dictionaries
        Return:
            mapping_dict: a mapping dictionary, key-> 'IN_VAR' of the mapping, value->mapping object corresponding
                             to the key
        """
        mapping_dict = {}
        for mapping in list_of_mappings:
            mapping_dict[mapping['IN_VAR']] = Mapping(
                in_map=mapping,
                precision=self.precision
            )
        return mapping_dict

    def getRegVariables(self, macro_data, input_data):
        """This function transforms data to get ready for mapping, then calls the mapping function 'process_model_inputs',
           finally returns processed regression variable, which will be ready to calculate PD

        Args:
            macro_data: a dataframe containing r_proftmargin, pct_chg_netsales, and PD_mapping, rows corresponding to
                        different quarters
            input_data: the data of one contract, read directly from excel file

        Return:
            dictionary: mapped value as explanatory variables for computing PD

        """
        invariant_data = {}
        invariant_data['asofdate2stmtdate'] = input_data['asofdate2stmtdate']
        invariant_data['r_EBITDAoIntrst'] = input_data['r_EBITDAoIntrst']
        invariant_data['r_quickRatio'] = input_data['r_quickRatio']
        invariant_data['r_DebtToTNW1'] = input_data['r_DebtToTNW1']
        invariant_data['PD_GROUP'] = input_data['PD_GROUP']
        # If given, use ChangeNetSal as initial Change of Net Sale from risk rating dataset
        if self.risk_rating_dataset_input_path != None:
            invariant_data['ChangeNetSal'] = input_data['ChangeNetSal']
            invariant_data['finalrat_ind'] = input_data['finalrat_ind']

        regression_variables = self.process_model_inputs(macro_data, invariant_data)
        return regression_variables

    # apply mapping to input data
    def process_model_inputs(self, macro_data, invariant_data):
        """This function apply mapping to input data, then it is called in the function getRegVariables()

        Args:
            macro_data: same as getRegVariables()
            invariant_data: same as input_data in getRegVariables()

        Return:
            dictionary: mapped value as explanatory variables for computing PD
        """
        regression_variables = []

        ###############################
        V_Debt2TNW = self._mappings['r_DebtToTNW1'].apply(to_map=invariant_data['r_DebtToTNW1'])
        V_EBITDA2IntExp = self._mappings['r_EBITDAoIntrst'].apply(to_map=invariant_data['r_EBITDAoIntrst'])
        V_QuickR = self._mappings['r_quickRatio'].apply(to_map=invariant_data['r_quickRatio'])

        for qtr in range(self.calculation_periods):
            """
            if qtr == 0:
                newm2mat = mapped_data.iloc[qtr][M2MAT] - 3
            else:
                newm2mat = new_m2mat[qtr - 1] - 3
            new_m2mat.append(newm2mat)
            """
            asofdate2stmtdate = invariant_data['asofdate2stmtdate']
            '''
            if qtr < 5:
                V_ProfitM = self._mappings['r_proftmargin'].apply(to_map=invariant_data['r_proftmargin'])
            else:
                V_ProfitM = self._mappings['r_proftmargin'].apply(to_map=(invariant_data['r_proftmargin'] +
                                                                          macro_data.iloc[qtr]['ProfitM']))
            '''
            V_ProfitM = self._mappings['r_proftmargin'].apply(to_map=macro_data.iloc[qtr]['r_proftmargin'])
            # added 12/26/2017: use ChangeNetSal as Q1 Change of Net Sale
            if (qtr == 0) and (self.risk_rating_dataset_input_path != None) and (invariant_data['finalrat_ind'] == 1):
                V_ChgSales = self._mappings['ChgSales'].apply(to_map=invariant_data['ChangeNetSal'])
            else:
                V_ChgSales = self._mappings['ChgSales'].apply(to_map=macro_data.iloc[qtr]['pct_chg_netsales'])
                
            if (pd.isnull(asofdate2stmtdate)) or (asofdate2stmtdate == -1):
                V_days_to_stmt2 = -0.82
            elif asofdate2stmtdate > self.statement_days_threshold:
                V_days_to_stmt2 = -0.82
            else:
                V_days_to_stmt2 = 0.27

            regression_variables.append({
                'V_Debt2TNW': V_Debt2TNW,
                'V_EBITDA2IntExp': V_EBITDA2IntExp,
                'V_QuickR': V_QuickR,
                'V_ProfitM': V_ProfitM,
                'V_ChgSales': V_ChgSales,
                'V_day_to_stmt2': V_days_to_stmt2
            })

        return regression_variables

    def calculatePD(self, input_data, forecast_period_quarterly):
        """This functions computes LGD thru some mappings

            Args:
                macro_data: a dataframe containing r_proftmargin, pct_chg_netsales, and PD_mapping, rows corresponding to
                            different quarters
                input_data: the data of one contract, read directly from excel file
                overlay: True by default
                PDMappingSwitch: determine whether we need to exponentiate the pd_mrs by PDMapping, True by default

            Return:
                PD of all forecast_periods, contained in a list. Each element of the list is a dictionary. Inside the
                dictionary is different measures of PD.
        """

        pd_result = []
        logistic_mapping = lambda ts: round(1 / (1 + np.exp(-ts)), self._precision)

        # Compute contract-specific macro sensitivity
        macro_data = self.macro_data.copy(deep=True)
        temp = []
        init_profit_margin = input_data['r_proftmargin'] #if pd.notnull(input_data['r_proftmargin']) else 0
        for j in range(self.calculation_periods):
            # if lag 1Q, use initial profit margin for T1(No stress), stress it from T2
            if self.PD_lag1Q_switch:
                if j == 0:
                    temp.append(init_profit_margin)
                elif j < 5:
                    temp.append(init_profit_margin + macro_data.iloc[j]['diff_proftmargin'])
                else:
                    temp.append(temp[j - 4] + macro_data.iloc[j]['diff_proftmargin'])
            else:
                if j < 4:
                    temp.append(init_profit_margin + macro_data.iloc[j]['diff_proftmargin'])
                else:
                    temp.append(temp[j - 4] + macro_data.iloc[j]['diff_proftmargin'])
        macro_data['r_proftmargin'] = temp

        # intercept = self.pd_regression_coefficients['intercept']
        # coeff_pairs = self.pd_regression_coefficients['coefficients_pairs']
        intercept = -3.6118
        coeff_pairs = {
            'V_Debt2TNW': -0.4527,
            'V_EBITDA2IntExp': - 0.5294,
            'V_QuickR': -0.4761,
            'V_ProfitM': -0.2426,
            'V_ChgSales': -0.7667,
            'V_day_to_stmt2': -0.8797
        }
        estimated_pd = []

        regression_variables = self.getRegVariables(macro_data, input_data)
        LOCAL_NPL_FLAG = input_data['LOCAL_NPL_FLAG']
        SRR = input_data['SRR']
        if self.risk_rating_dataset_input_path != None:
            finalrat_ind = input_data['finalrat_ind']
            FINALRAT = input_data['FINALRAT']
            quantrat = input_data['quantrat']
            rating_adjustment = input_data['FINALRAT'] - input_data['quantrat']

        # special PD treatment  
        special = False
        if (self.PD_special_set1) and (not pd.isnull(SRR)) and ((SRR in [1.0, 1.1, 1.2]) or (SRR < 1.0 and LOCAL_NPL_FLAG == 'Y')):
            special = True
        
        # Add intermediate dataset for UAT purpuse
        if self.add_uat_columns:
            OPENDATE = input_data['OPENDATE']
            MAXIMUMMATURITYDATE = input_data['MAXIMUMMATURITYDATE']
#            MAXIMUMMATURITYDATE_NEW = input_data['MAXIMUMMATURITYDATE_NEW']
            m2mat = input_data['m2mat']
            StatementDate = input_data['StatementDate']
            StatementMonths = input_data['StatementMonths']
            AuditMethod = input_data['AuditMethod']
            StatementID = input_data['StatementID']
            InterestExpense = input_data['InterestExpense']
            CashAndEquivs = input_data['CashAndEquivs']
            NetTradeAcctsRec = input_data['NetTradeAcctsRec']            
            TotalCurLiabs = input_data['TotalCurLiabs']
            ProfitBeforeTax = input_data['ProfitBeforeTax']
            NetSales = input_data['NetSales']
            DebtToTNW = input_data['DebtToTNW']        
            r_DebtToTNW1 = input_data['r_DebtToTNW1']
            r_EBITDAoIntrst = input_data['r_EBITDAoIntrst']
            r_quickRatio = input_data['r_quickRatio']
            r_proftmargin = input_data['r_proftmargin']
            COLLATERALCODE = input_data['COLLATERALCODE']
            

        # indicator to check maturity
#        MATURITY_INDICATOR = []
        for qtr in range(forecast_period_quarterly):
#            MATURITY_INDICATOR.append(
#                False if (
#                    (input_data['m2mat'] - ((qtr + 1) * 3)) > 0
#                    or
#                    pd.isnull(input_data['m2mat'])
#                ) else True
#            )            
            estimated_pd.append(logistic_mapping(
                (sum([regression_variables[qtr][item] * coeff_pairs[item] for item in coeff_pairs.keys()]) + intercept)
            ))
            rating = self.mappings['estimated_PD'].apply(to_map=estimated_pd[qtr])
            # in mapping above, two keys of same IN_VAR estimated_PD

            # added 12/26/2017: for rated loan, apply adjustment factor
            if (self.risk_rating_dataset_input_path != None) and (finalrat_ind == 1):
                if self.scenario_severity_level in ['STRESS', 'ADVERSE']:
                    final_rating = min(max(1.5, rating + min(rating_adjustment, 0)), 8.5)
                else:
                    final_rating = min(max(1.5, rating + rating_adjustment), 8.5)
            elif not pd.isnull(SRR) and (SRR >= 1.0) and (SRR <= self.pass_srr) and self.SRR_overlay_switch:
                if self.mrs_srr_switch:
                    final_rating = SRR
                else:
                    final_rating = int(2 * SRR) * 0.5
            else:
                final_rating = rating

            # MRS Stress Notch Down: currently off
            if self.MRS_notch_down_switch:
                if (self.scenario_severity_level in ['STRESS', 'ADVERSE']) and (SRR > self.pass_srr or pd.isnull(SRR)):
                    final_rating = max(final_rating - 0.5, 1.5)

            # PD mapping: currently on
            if self.PD_mapping_switch:
                if final_rating > self.pass_srr:
                    pd_mapping = macro_data.iloc[qtr]['PD_mapping_Pass']
                else:
                    pd_mapping = macro_data.iloc[qtr]['PD_mapping_NonPass']
            else:
                pd_mapping = 0
            # map rating to pd_mrs

            # old version
            # pd_mrs = (self.mappings['final_rating'].apply(to_map=final_rating))**pd_mapping
            # pd_1y = pd_mrs

            # new version
            # 09/22/2017 add PD treatment: If SRR in (1.0, 1.1, 1.2) or (SRR<1 and  LOCAL_NPL_FLAG=”Y”) then PD=1 
            if self.PD_special_set1 and special:
                pd_mrs = 1
            else:
                pd_mrs = self.mappings['final_rating'].apply(to_map=final_rating)
                
            if pd_mrs == 1:
                pd_1y = 1
            else:
                pd_1y = min(1, (1 + np.exp(-(np.log(pd_mrs / (1 - pd_mrs)) + pd_mapping))) ** (-1))
            pd_1q = utilities.PDPeriodConverter(
                pd_1y,
                utilities.PERIOD_FREQUENCY_MAP['yearly'],
                utilities.PERIOD_FREQUENCY_MAP['quarterly']
            )
            pd_1m = utilities.PDPeriodConverter(
                pd_1q,
                utilities.PERIOD_FREQUENCY_MAP['quarterly'],
                utilities.PERIOD_FREQUENCY_MAP['monthly']
            )            
#            if MATURITY_INDICATOR[qtr] and self.maturity_switch:
#                pd_1q = 0
#                pd_1m = 0
            
            if not self.add_uat_columns:       
                pd_result.append({
                    'pd_1y': pd_1y,
                    'pd_1q': pd_1q,
                    'pd_1m': pd_1m,
                    'rating': rating,
                    'final_rating': final_rating,
                    'pd_mapping': pd_mapping,
                    'estimated_pd': estimated_pd[qtr],
                    'SRR': SRR,
                    'r_proftmargin': macro_data.iloc[qtr]['r_proftmargin'],
                    'pct_chg_netsales': macro_data.iloc[qtr]['pct_chg_netsales'],
                    'V_Debt2TNW': regression_variables[qtr]['V_Debt2TNW'],
                    'V_EBITDA2IntExp': regression_variables[qtr]['V_EBITDA2IntExp'],
                    'V_QuickR': regression_variables[qtr]['V_QuickR'],
                    'V_ProfitM': regression_variables[qtr]['V_ProfitM'],
                    'V_ChgSales': regression_variables[qtr]['V_ChgSales'],
                    'V_day_to_stmt2': regression_variables[qtr]['V_day_to_stmt2']
                })
            else:
                pd_result.append({
                    'pd_1y': pd_1y,
                    'pd_1q': pd_1q,
                    'pd_1m': pd_1m,
                    'rating': rating,
                    'final_rating': final_rating,
                    'pd_mapping': pd_mapping,
                    'estimated_pd': estimated_pd[qtr],
                    'SRR': SRR,
                    'r_proftmargin': macro_data.iloc[qtr]['r_proftmargin'],
                    'pct_chg_netsales': macro_data.iloc[qtr]['pct_chg_netsales'],
                    'V_Debt2TNW': regression_variables[qtr]['V_Debt2TNW'],
                    'V_EBITDA2IntExp': regression_variables[qtr]['V_EBITDA2IntExp'],
                    'V_QuickR': regression_variables[qtr]['V_QuickR'],
                    'V_ProfitM': regression_variables[qtr]['V_ProfitM'],
                    'V_ChgSales': regression_variables[qtr]['V_ChgSales'],
                    'V_day_to_stmt2': regression_variables[qtr]['V_day_to_stmt2'],
                    'r_DebtToTNW1': r_DebtToTNW1,
                    'r_EBITDAoIntrst': r_EBITDAoIntrst,
                    'r_quickRatio': r_quickRatio,
                    'StatementDate': StatementDate,
                    'StatementMonths': StatementMonths,
                    'AuditMethod': AuditMethod,
                    'StatementID': StatementID,
                    'InterestExpense': InterestExpense,
                    'CashAndEquivs': CashAndEquivs,
                    'NetTradeAcctsRec': NetTradeAcctsRec,
                    'TotalCurLiabs': TotalCurLiabs,
                    'ProfitBeforeTax': ProfitBeforeTax,
                    'NetSales': NetSales,
                    'DebtToTNW': DebtToTNW,
                    'OPENDATE': OPENDATE,
                    'MAXIMUMMATURITYDATE': MAXIMUMMATURITYDATE,
#                    'MAXIMUMMATURITYDATE_NEW': MAXIMUMMATURITYDATE_NEW,
                    'm2mat': m2mat,
                    'LOCAL_NPL_FLAG': LOCAL_NPL_FLAG,
                    'special': special,
                    'diff_proftmargin': macro_data.iloc[qtr]['diff_proftmargin'],
                    'pd_mrs': pd_mrs,
                    'finalrat_ind' : finalrat_ind,
                    'FINALRAT' : FINALRAT,
                    'quantrat': quantrat,
                    'rating_adjustment' : rating_adjustment,
                    'COLLATERALCODE': COLLATERALCODE
                })    
                
        return pd_result
    
    def calculateLGD(self, invariant_data, contract_results, forecast_period_quarterly):
        """This functions computes LGD thru some mappings

        Args:
            macro_data: a dataframe containing r_proftmargin, pct_chg_netsales, and PD_mapping, rows corresponding to
                        different quarters
            invariant_data: the data of one contract, read directly from excel file

        Return:
            LGD of all forecast_periods, contained in a list
        """
        if self.debug: print("BEGIN - LGD Calculation for {}".format(invariant_data["UNIQUE_FACILITY_ID"]))
        lgd = []
        ABL_AR_flag = AR_flag = ['NOT ABL_AR'] * forecast_period_quarterly
        bizseg = invariant_data['PD_GROUP']
        coldesc = str(invariant_data['COLLATERAL_DESCRIPTION'])
        coltyp = str(invariant_data['COLLATERAL_TYPE'])
        exposure = invariant_data['EXPOSURE']
        # get discount rate from portfolio snapshot (if missing, use portfolio average rate)
        if self.discounting_LGD_switch:
            if pd.isnull(invariant_data['avg_interestrate']):
                avg_interestrate = self.portfolio_average_interestrate
            else:
                avg_interestrate = invariant_data['avg_interestrate'] / 100
        
        if self.add_uat_columns:       
            contract_results['COLLATERAL_TYPE'] = [coltyp] * forecast_period_quarterly
#            contract_results['avg_interestrate'] = [avg_interestrate] * forecast_period_quarterly
        
        if bizseg not in self.pd_groups:
            raise ValueError("Invalid Business Segment")
        
        # slice the macros by forecast length
        transformed_macro_series = self.transformed_macro_series.copy(deep=True).iloc[0:forecast_period_quarterly]
        
        if bizseg == ABL_PD_GROUP:
            # if coltyp not in ['AR', 'NonAR'] and (not pd.isnull(coltyp)):
            #    raise ValueError("Invalid collateral type for ABL model")
            # if not isinstance(coltyp, int):
            #    raise ValueError("Invalid collateral type for CNI/ABL model")
            if self.scenario_severity_level not in ['BASE', 'ADVERSE', 'STRESS']:
                raise ValueError("Invalid Scenario")

            if coldesc[:16].lower() == 'accts receivable':
                lgd_value = self._mappings['LGD_ABL_AR'].apply(to_map=self.scenario_severity_level)
                ABL_AR_flag = ['ABL_AR'] * forecast_period_quarterly
            else:
                lgd_value = self._mappings['LGD_ABL_NonAR'].apply(to_map=self.scenario_severity_level)
            lgd = [lgd_value for i in range(0, forecast_period_quarterly)]
            lgd_macro = [None] * forecast_period_quarterly
        elif bizseg == MIDDLE_MARKET_PD_GROUP:
            if coltyp == 'COMMERCIAL PROPERTIES':
                lgd = list(
                    0.30393 - 0.12343 - 3.50762 * transformed_macro_series[
                        "FHOFHOPIQ_US_p2q_l1q"
                    ].as_matrix()
                )
                if self.add_uat_columns: 
                    lgd_macro = transformed_macro_series["FHOFHOPIQ_US_p2q_l1q"].tolist()
                
            elif coltyp in (
                'HOSPITAL/ MEDICAL CARE PROPERTIES',
                'RESIDENTIAL PROPERTIES',
                'FINANCIAL ASSETS',
                'ALL ASSETS/OTHER'
            ):
                lgd = list(
                    0.30393 - 3.50762 * transformed_macro_series[
                        "FHOFHOPIQ_US_p2q_l1q"
                    ].as_matrix()
                )
                if self.add_uat_columns: 
                    lgd_macro = transformed_macro_series["FHOFHOPIQ_US_p2q_l1q"].tolist()
                
            elif coltyp == 'EQUIPMENT/VEHICLE':
                lgd = list(
                    0.35917 - 1.77606 * transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
                if self.add_uat_columns: 
                    lgd_macro = transformed_macro_series["FHOFHOPIQ_US_p1y"].tolist()
            elif coltyp == 'UNSECURED':
                lgd = list(
                    0.35917 + 0.22583 - 1.77606 * transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
                if self.add_uat_columns: 
                    lgd_macro = transformed_macro_series["FHOFHOPIQ_US_p1y"].tolist()
            else:
                raise ValueError("Invalid coltyp for Middle Market loan.")
        elif bizseg == BUSINESS_BANKING_PD_GROUP:
            if coltyp == 'COMMERCIAL PROPERTIES':
                lgd = list(
                    0.35917 - 0.17765 - 1.77606 * transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
                if self.add_uat_columns: 
                    lgd_macro = transformed_macro_series["FHOFHOPIQ_US_p1y"].tolist()
            elif coltyp in (
                'EQUIPMENT/VEHICLE',
                'HOSPITAL/ MEDICAL CARE PROPERTIES',
                'RESIDENTIAL PROPERTIES',
                'FINANCIAL ASSETS',
                'ALL ASSETS/OTHER'
            ):
                lgd = list(
                    0.35917 - 1.77606 * transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
                if self.add_uat_columns: 
                    lgd_macro = transformed_macro_series["FHOFHOPIQ_US_p1y"].tolist()
            elif coltyp == 'UNSECURED':
                lgd = list(
                    0.35917 + 0.22583 - 1.77606 * transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
                if self.add_uat_columns: 
                    lgd_macro = transformed_macro_series["FHOFHOPIQ_US_p1y"].tolist()
            else:
                raise ValueError("Invalid coltyp for Middle Market loan.")
        else:
            raise ValueError("Invalid Business Segment")
            # if pd.isnull(exposure):
            #     exposure = 0.0
            # if coltyp == 'Commercial Properties':
            #     if exposure < 300000.:
            #         coltyp += ' < 300000'
            #     else:
            #         coltyp += ' >= 300000'
            # map_key = 'LGD_' + self.scenario_severity_level + '_' + bizseg
            # if coltyp not in self._mappings[map_key].values_to_map:
            #     #if self.debug:
            #         #print("warning: mapping rule for %s not found, treat it as missing value" % coltyp)
            #     coltyp = None
            # for qtr in range(self.calculation_periods):
            #     # scenario = macro_data.iloc[qtr]['scenario_type']
            #     # scenario = invariant_data['scenario_type']
            #     if self.scenario_severity_level not in ['BASE', 'ADVERSE', 'STRESS']:
            #         raise ValueError("Invalid Scenario")
            #     # map_key = 'LGD_' + self.scenario_severity_level + '_' + bizseg
            #     lgd.append(self._mappings[map_key].apply(to_map=coltyp))

        contract_results['LGD'] = lgd
        if self.add_uat_columns: 
            contract_results['lgd_macro'] = lgd_macro
        # calculate new LGD for IFRS
#        NCO_LIST = [0.065979983741688, 0.110965695477087, 0.0731852524555724, 0.0644457430061961, 0.0643545988560708, 0.0673615635763485, 0.0452784200915209, 0.0436107032691392, 0.0371181553943937, 0.0561668877741468, 0.0224771756403253, 0.038308854529423, 0.0183020283129166, 0.0420653286678194, 0.0228833783307003, 0.0444289516913079, 0.0107061018957696, 0.0133391967478741, 0.0042201460741661, 0.0210402909456084, 0.00392016968960385, 0.0434514613737667, 0.0203414835902086, 0.00936629436389824, 0.0142536147317838, 0.00672939551216778, 0.00285231305478229, 0.00702695523267649, 0.000549838053731988, 0.0085100846480769, 0.00121252491099622, 0.00366162655379398, 0.000511288616941163, 0.00597969524564035, 0.000829403634852843, 0.00725294200592574, -0.0062878813523255, 0.000862753689196305, 0.000623408832464367, 0.00353703441353881, -0.000914611639942553, -0.0012160408458407, 0.0029467084909377, 0.000248348283370614, -0.000773816255231985, -0.000309814592340141, -0.000203600064542453, -0.00146485944763386, 0.000264822791428254]      
        NCO_LIST = [0.066,0.111,0.0732,0.0644,0.0644,0.0674,0.0453,0.0436,0.0371,0.0562,0.0225,0.0383,0.0183,0.0421,0.0229,0.0444,0.0107,0.0133,0.0042,0.021,0.0039,0.0435,0.0203,0.0094,0.0143,0.0067,0.0029,0.007,0.0005,0.0085,0.0012,0.0037,0.0005,0.006,0.0008,0.0073,-0.0063,0.0009,0.0006,0.0035,-0.0009,-0.0012,0.0029,0.0002,-0.0008,-0.0003,-0.0002,-0.0015,0.0003]    

        # Discount LGD
        # test: 
        #    nco_list = [0.065979983741688, 0.110965695477087, 0.0731852524555724, 0.0644457430061961, 0.0643545988560708, 0.0673615635763485, 0.0452784200915209, 0.0436107032691392, 0.0371181553943937, 0.0561668877741468, 0.0224771756403253, 0.038308854529423, 0.0183020283129166, 0.0420653286678194, 0.0228833783307003, 0.0444289516913079, 0.0107061018957696, 0.0133391967478741, 0.0042201460741661, 0.0210402909456084, 0.00392016968960385, 0.0434514613737667, 0.0203414835902086, 0.00936629436389824, 0.0142536147317838, 0.00672939551216778, 0.00285231305478229, 0.00702695523267649, 0.000549838053731988, 0.0085100846480769, 0.00121252491099622, 0.00366162655379398, 0.000511288616941163, 0.00597969524564035, 0.000829403634852843, 0.00725294200592574, -0.0062878813523255, 0.000862753689196305, 0.000623408832464367, 0.00353703441353881, -0.000914611639942553, -0.0012160408458407, 0.0029467084909377, 0.000248348283370614, -0.000773816255231985, -0.000309814592340141, -0.000203600064542453, -0.00146485944763386, 0.000264822791428254]
        #    lgd = 0.4
        #    rate = 0.0393
        #    test_dict = lgdPV(nco_list,lgd,rate,pvfi_period=36,pvnco_period=48)
    
        def lgdPV(nco_list,lgd,rate,pvfi_period=36,pvnco_period=48):
            '''
            :param nco_list: list of NCO curve. e.g [0.066,0.111,0.0732...]
            :param lgd: current lgd rate.
            :param rate: discount rate or avg_InterestRate. e.g. 0.055
            :param pvfi_period: period of PVFI calculation. 
                                e.g pvfi_period = 36-->PVFI1-PVFI36
            :param pvnco_period: period of PVNCO calculation. 
                                 e.g pvnco_period = 48-->PVNCO0-PVNCO48
        
            :returns: dictionary of LGD PV results.
            '''  
            if len(nco_list) < pvnco_period + 1:
                raise ValueError ('Input NCO curve is too short.')
            if rate > 1:
                raise ValueError ('Discount rate is larger than 100%.')                
        
            nco=[lgd*i for i in nco_list]
            discount_time=[i/12 for i in range(pvnco_period+1)]
            pvnco=[i/((1+rate)**t) for i,t in zip(nco,discount_time)]
            pvnco_sum=sum(pvnco)
            
            # e.g pvfi_period = 36
            # AB0-->AB36. AB0=1-NCO0,AB1=AB0-NCO1,AB2=AB1-NCO2
            # FI1-->FI36. FI1=AB0*rate/12,FI36=AB35*rate/12
            # PVFI1-->PVFI36. PVFI1=FI1/((1+rate)**(1/12))
            ab=[]
            fi=[]  
            pvfi=[]
            for i in range(pvfi_period):
                if i == 0:
                    ab_result=1-nco[0]           
                else:
                    ab_result=ab[i-1]-nco[i]
                
                fi_result=ab_result*rate/12
                pvfi_result=fi_result/(1+rate)**(discount_time[i+1])  
                
                ab.append(ab_result)    
                fi.append(fi_result)
                pvfi.append(pvfi_result)   
                
            pvfi_sum=sum(pvfi)
            elgd=pvnco_sum+pvfi_sum
            
            result={
                'nco':nco,
                'discount_time':discount_time,
                'pvnco':pvnco,
                'pvnco_sum':pvnco_sum,
                'ab':ab,
                'fi':fi,     
                'pvfi':pvfi,
                'pvfi_sum':pvfi_sum,          
                'elgd':elgd,                      
               }                  
            return(result)    
        def discountingAdjLGD(lgd):
            result = lgdPV(NCO_LIST, lgd, avg_interestrate, pvfi_period=36, pvnco_period=48)
            return(result['elgd'])
        if self.discounting_LGD_switch:
            contract_results['New_LGD_ifrs'] = list(map(discountingAdjLGD, contract_results['LGD']))
        else:
            contract_results['New_LGD_ifrs'] = contract_results['LGD']
        contract_results['ABL_AR_flag']=ABL_AR_flag
        if self.debug: print(">>>>>> LGD : {}".format(str(lgd)))
        if self.debug: print(">>>>>> ABL_AR_flag : {}".format(str(ABL_AR_flag)))
        return(True)
     
    def estimateLossAmount(self, invariant_data, contract_results, forecast_period_quarterly):
        BOOK_VALUE_Q = []
        LEQ_AMOUNT_Q = []
        EAD_AMOUNT_Q = []
        DEFAULT_AMOUNT_Q = []
        LOSS_AMOUNT_Q = []
        IS_RLOC = []
        FACILITYTYPE = []
        MATURITY_INDICATOR = []
        INITIAL_BOOK_VALUE = []

        if self.debug: print("BEGIN - EAD Amount calculation for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(forecast_period_quarterly):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            # Main info
            FACILITYTYPE.append(invariant_data['FACILITYTYPE'])
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )
            INITIAL_BOOK_VALUE.append(
                max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
            )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(FACILITYTYPE)))


            # Process book value
            if qtr == 0:
                BOOK_VALUE_Q.append(
                    (
                        max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
                    )
                    # * (
                    #     1 - contract_results['pd_1q'][qtr]
                    # )
                )
            else:
                BOOK_VALUE_Q.append(
                    BOOK_VALUE_Q[qtr - 1] * (1 - contract_results['pd_1q'][qtr - 1])
                )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(BOOK_VALUE_Q)))

            # Case REVOLVING LINE OF CREDIT
            if ('REVOLVING LINE OF CREDIT' == FACILITYTYPE[qtr].upper()):
                IS_RLOC.append('RLOC')
                LEQ_AMOUNT_Q.append(contract_results['EAD_TOTAL_LINE'][qtr]*invariant_data['EXPOSURE'])

                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(
                        min(
                            BOOK_VALUE_Q[qtr] + LEQ_AMOUNT_Q[qtr],
                            invariant_data['EXPOSURE']
                        )
                    )
            # Case TERM or NON-REVOLVING LOC
            else:
                IS_RLOC.append('OTHER')
                LEQ_AMOUNT_Q.append(0)
                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(BOOK_VALUE_Q[qtr])
            if self.debug: print(">>>>>> IS_RLOC : {}".format(str(IS_RLOC)))
            if self.debug: print(">>>>>> LEQ_AMOUNT_Q : {}".format(str(LEQ_AMOUNT_Q)))
            if self.debug: print(">>>>>> EAD_AMOUNT_Q : {}".format(str(EAD_AMOUNT_Q)))

        if self.debug: print("EAND - EAD Amount Estimation")

        # Estimate loss amount
        if self.debug: print("BEGIN - Estimate Loss Amount for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(forecast_period_quarterly):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            DEFAULT_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr])
            LOSS_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr] * contract_results['LGD'][qtr])
            if self.debug: print(">>>>>> DEFAULT_AMOUNT_Q : {}".format(str(DEFAULT_AMOUNT_Q)))
            if self.debug: print(">>>>>> LOSS_AMOUNT_Q : {}".format(str(LOSS_AMOUNT_Q)))

        # Write results to contract results container
        contract_results['BOOK_VALUE_Q'] = BOOK_VALUE_Q
        contract_results['LEQ_AMOUNT_Q'] = LEQ_AMOUNT_Q
        contract_results['EAD_AMOUNT_Q'] = EAD_AMOUNT_Q
        contract_results['DEFAULT_AMOUNT_Q'] = DEFAULT_AMOUNT_Q
        contract_results['LOSS_AMOUNT_Q'] = LOSS_AMOUNT_Q
        contract_results['IS_RLOC'] = IS_RLOC
        contract_results['FACILITYTYPE'] = FACILITYTYPE
        contract_results['INITIAL_BOOK_VALUE'] = INITIAL_BOOK_VALUE

    def estimateLossAmountAlt(self, invariant_data, contract_results, forecast_period_quarterly):
        BOOK_VALUE_Q = []
        LEQ_AMOUNT_Q = []
        EAD_AMOUNT_Q = []
        DEFAULT_AMOUNT_Q = []
        LOSS_AMOUNT_Q = []
        IS_RLOC = []
        FACILITYTYPE = []
        MATURITY_INDICATOR = []
        INITIAL_BOOK_VALUE = []

        if self.debug: print("BEGIN - EAD Amount calculation for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(forecast_period_quarterly):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            # Main info
            FACILITYTYPE.append(invariant_data['FACILITYTYPE'])
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )
            INITIAL_BOOK_VALUE.append(
                max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
            )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(FACILITYTYPE)))

            # Process book value
            if qtr == 0:
                BOOK_VALUE_Q.append(
                    (
                        max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
                    )
                    # * (
                    #     1 - contract_results['pd_1q'][qtr]
                    # )
                )
            else:
                BOOK_VALUE_Q.append(
                    BOOK_VALUE_Q[qtr - 1] * (1 - contract_results['pd_1q'][qtr - 1])
                )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(BOOK_VALUE_Q)))

            # Case REVOLVING LINE OF CREDIT
            if ('REVOLVING LINE OF CREDIT' == FACILITYTYPE[qtr].upper()):
                IS_RLOC.append('RLOC')
                LEQ_AMOUNT_Q.append(contract_results['EAD_TOTAL_LINE'][qtr] * invariant_data['EXPOSURE'])

                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(
                        min(
                            BOOK_VALUE_Q[qtr] + LEQ_AMOUNT_Q[qtr],
                            invariant_data['EXPOSURE']
                        )
                    )
            # Case TERM or NON-REVOLVING LOC
            else:
                IS_RLOC.append('OTHER')
                LEQ_AMOUNT_Q.append(0)
                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(BOOK_VALUE_Q[qtr])
            if self.debug: print(">>>>>> IS_RLOC : {}".format(str(IS_RLOC)))
            if self.debug: print(">>>>>> LEQ_AMOUNT_Q : {}".format(str(LEQ_AMOUNT_Q)))
            if self.debug: print(">>>>>> EAD_AMOUNT_Q : {}".format(str(EAD_AMOUNT_Q)))

        if self.debug: print("END - EAD Amount Estimation")

        # Estimate loss amount
        if self.debug: print("BEGIN - Estimate Loss Amount for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(forecast_period_quarterly):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            DEFAULT_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr])
            LOSS_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr] * contract_results['LGD'][qtr])
            if self.debug: print(">>>>>> DEFAULT_AMOUNT_Q : {}".format(str(DEFAULT_AMOUNT_Q)))
            if self.debug: print(">>>>>> LOSS_AMOUNT_Q : {}".format(str(LOSS_AMOUNT_Q)))

        # Write results to contract results container
        contract_results['BOOK_VALUE_Q'] = BOOK_VALUE_Q
        contract_results['LEQ_AMOUNT_Q'] = LEQ_AMOUNT_Q
        contract_results['EAD_AMOUNT_Q'] = EAD_AMOUNT_Q
        contract_results['DEFAULT_AMOUNT_Q'] = DEFAULT_AMOUNT_Q
        contract_results['LOSS_AMOUNT_Q'] = LOSS_AMOUNT_Q
        contract_results['IS_RLOC'] = IS_RLOC
        contract_results['FACILITYTYPE'] = FACILITYTYPE
        contract_results['INITIAL_BOOK_VALUE'] = INITIAL_BOOK_VALUE
    
    def generateLEQFactor(self):
        """ This function generate LEQ factors lists """
        # LEQ Factor List
        if self.new_LEQ_switch:
            # new LEQ factors for 
            # (1)first 27Q number
            # add 10/04/2017: extend LEQ to full length numbers
            PASS_BASE_LEQ = [0, 0, 0, 0.0708420486820261, 0.227793264705619, 0.27424006409816, 0.297347018068309, 0.320453972038457, 0.343560926008606, 0.362255294642499, 0.470602040218569, 0.481144918185811, 0.491687796153053, 0.502230674120294, 0.512773552087536, 0.523316430054777, 0.533859308022019, 0.544402185989261, 0.615271115077682, 0.631536785736694, 0.651922217457255, 0.672307649177815, 0.692693080898376, 0.713078512618937, 0.733463944339498, 0.753849376060059, 0.77423480778062]
            PASS_ADVERSE_LEQ = [0, 0, 0, 0.0708420486820261, 0.233042217245881, 0.27424006409816, 0.305429738695275, 0.336619413292391, 0.367809087889506, 0.396792469818493, 0.470602040218569, 0.487227664187994, 0.503853288157418, 0.520478912126842, 0.534808337943049, 0.549137763759255, 0.563467189575462, 0.577796615391668, 0.622289066768465, 0.639479888930557, 0.658730591623423, 0.677981294316289, 0.697231997009155, 0.716482699702021, 0.735733402394888, 0.754984105087754, 0.77423480778062]
            PASS_STRESS_LEQ = [0, 0, 0, 0.0708420486820261, 0.238291169786142, 0.27424006409816, 0.313512459322242, 0.352784854546324, 0.392057249770406, 0.431329644994487, 0.470602040218569, 0.493310410190176, 0.516018780161783, 0.538727150133391, 0.556843123798562, 0.574959097463734, 0.593075071128905, 0.611191044794076, 0.629307018459248, 0.647422992124419, 0.665538965789591, 0.683654939454762, 0.701770913119934, 0.719886886785105, 0.738002860450277, 0.756118834115448, 0.77423480778062]
            NON_PASS_BASE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.544402185989261, 0.551642576283366, 0.631536785736694, 0.651922217457255, 0.672307649177815, 0.692693080898376, 0.713078512618937, 0.733463944339498, 0.753849376060059, 0.77423480778062]
            NON_PASS_ADVERSE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.0186109351602961, 0.0793455133482351, 0.140080091536174, 0.235301020109285, 0.246655205095088, 0.258009390080892, 0.269363575066695, 0.278421561899281, 0.287479548731867, 0.296537535564453, 0.577796615391668, 0.590474797371307, 0.639479888930557, 0.658730591623423, 0.677981294316289, 0.697231997009155, 0.716482699702021, 0.735733402394888, 0.754984105087754, 0.77423480778062]
            NON_PASS_STRESS_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.0372218703205923, 0.15869102669647, 0.280160183072348, 0.470602040218569, 0.493310410190176, 0.516018780161783, 0.538727150133391, 0.556843123798562, 0.574959097463734, 0.593075071128905, 0.611191044794076, 0.629307018459248, 0.647422992124419, 0.665538965789591, 0.683654939454762, 0.701770913119934, 0.719886886785105, 0.738002860450277, 0.756118834115448, 0.77423480778062]
            ABL_BASE_LEQ = [0] * 27
            
            # (2)add 1 to end of LEQ list if forecast periods larger than 27Q;
            extend_LEQ = lambda x: x.extend([1] * (self.calculation_periods - 27))
            if self.calculation_periods > 27:
                # extend ones to LEQs
                extend_LEQ(PASS_BASE_LEQ)
                extend_LEQ(PASS_ADVERSE_LEQ)
                extend_LEQ(PASS_STRESS_LEQ)
                extend_LEQ(NON_PASS_BASE_LEQ)
                extend_LEQ(NON_PASS_ADVERSE_LEQ)
                extend_LEQ(NON_PASS_STRESS_LEQ)
                # exception: for ABL, extend zeros
                ABL_BASE_LEQ.extend([0] * (self.calculation_periods - 27))
            
            # (3)lagging 1Q(insert Q0 LEQ at the beginning of the list) and remove last one
            Q0_LEQ = [0]
            lag_LEQ = lambda x: Q0_LEQ + x[:-1]
            PASS_BASE_LEQ = lag_LEQ(PASS_BASE_LEQ)
            PASS_ADVERSE_LEQ = lag_LEQ(PASS_ADVERSE_LEQ)
            PASS_STRESS_LEQ = lag_LEQ(PASS_STRESS_LEQ)
            NON_PASS_BASE_LEQ = lag_LEQ(NON_PASS_BASE_LEQ)
            NON_PASS_ADVERSE_LEQ = lag_LEQ(NON_PASS_ADVERSE_LEQ)
            NON_PASS_STRESS_LEQ = lag_LEQ(NON_PASS_STRESS_LEQ)
            ABL_BASE_LEQ = lag_LEQ(ABL_BASE_LEQ)
        
        else: 
            # LEQ factors for CCAR
            PASS_BASE_LEQ = [0, 0, 0, 0, 0.0148, 0.056, 0.056, 0.0694, 0.124]
            PASS_ADVERSE_LEQ = [0, 0, 0, 0, 0.018, 0.0679, 0.0679, 0.0801, 0.1572]
            PASS_STRESS_LEQ = [0, 0, 0, 0, 0.0211, 0.0799, 0.0799, 0.0907, 0.1904]
            NON_PASS_BASE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.017, 0.038]
            NON_PASS_ADVERSE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.0173, 0.0386]
            NON_PASS_STRESS_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.0176, 0.0392]
            ABL_BASE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0, 0]
            
            # when forecast periods larger than 9Q, use the last value to extend the LEQ list
            if self.calculation_periods > 9:
                PASS_BASE_LEQ.extend([PASS_BASE_LEQ[-1]] * (self.calculation_periods - 9))
                PASS_ADVERSE_LEQ.extend([PASS_ADVERSE_LEQ[-1]] * (self.calculation_periods - 9))
                PASS_STRESS_LEQ.extend([PASS_STRESS_LEQ[-1]] * (self.calculation_periods - 9))
                NON_PASS_BASE_LEQ.extend([NON_PASS_BASE_LEQ[-1]] * (self.calculation_periods - 9))
                NON_PASS_ADVERSE_LEQ.extend([NON_PASS_ADVERSE_LEQ[-1]] * (self.calculation_periods - 9))
                NON_PASS_STRESS_LEQ.extend([NON_PASS_STRESS_LEQ[-1]] * (self.calculation_periods - 9))
                ABL_BASE_LEQ.extend([ABL_BASE_LEQ[-1]] * (self.calculation_periods - 9))
        
        # return a dataframe for LEQ factors
        leq_df = pd.DataFrame(
                              {'PASS_BASE_LEQ': PASS_BASE_LEQ, 
                               'PASS_ADVERSE_LEQ': PASS_ADVERSE_LEQ, 
                               'PASS_STRESS_LEQ': PASS_STRESS_LEQ, 
                               'NON_PASS_BASE_LEQ': NON_PASS_BASE_LEQ, 
                               'NON_PASS_ADVERSE_LEQ': NON_PASS_ADVERSE_LEQ, 
                               'NON_PASS_STRESS_LEQ': NON_PASS_STRESS_LEQ, 
                               'ABL_BASE_LEQ': ABL_BASE_LEQ
                              })
        return(leq_df)
            
    def calculateLEQ(self, invariant_data, contract_results, forecast_period_quarterly):
        """This function computes EAD according to Page 34 of the slides CCAR/DFAST 2016 Wholesale Models:
           Upper Business Banking and Middle Market

        Args:
            input_data: the data of one contract, read directly from excel file
        Return: a vector containing EAD of all quarters

        Possible Further Improvement:
            if we allow the mapped value to be lists, then we don't need to use if-else statement block
        """
        # Check LEQ factor available
        if self.LEQ_df is None:
            raise Exception('`self.__LEQ_df` is None.')
            
        # scenario = input_data['scenario_type']
        if self.scenario_severity_level not in ['BASE', 'ADVERSE', 'STRESS']:
            raise ValueError("Invalid Scenario")
        LEQ_FACTOR = []
        MATURITY_INDICATOR = []
        #SRR = invariant_data['SRR']
        bizseg = invariant_data['PD_GROUP']
        # changed 20180123: use LINE_TERM to replace FACILITYTYPE
        facility_type = invariant_data['FACILITYTYPE'] if self.line_term_type_input_path is None else invariant_data['LINE_TERM']

        for qtr in range(forecast_period_quarterly):
            # added 02292018: mature LEQ for loan with final rating <= 4
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )                    
            if ((('LINE' == facility_type.upper()) and (self.line_term_type_input_path is not None)) \
                    or ('REVOLVING LINE OF CREDIT' == facility_type.upper())):
                if (
                    (contract_results['final_rating'][qtr] > self.pass_srr)
                    or
                    (pd.isnull(contract_results['final_rating'][qtr]))
                ):
#                    if self.maturity_switch and MATURITY_INDICATOR[qtr]:
#                        LEQ_FACTOR.append(0)
#                    else:
                    if self.scenario_severity_level == 'BASE':
                        if bizseg == ABL_PD_GROUP:
                            LEQ_FACTOR.append(self.LEQ_df['ABL_BASE_LEQ'][qtr])
                        else:
                            LEQ_FACTOR.append(self.LEQ_df['PASS_BASE_LEQ'][qtr])
                    elif self.scenario_severity_level == 'ADVERSE':
                        LEQ_FACTOR.append(self.LEQ_df['PASS_ADVERSE_LEQ'][qtr])
                    else:
                        LEQ_FACTOR.append(self.LEQ_df['PASS_STRESS_LEQ'][qtr])
                else:
                    if self.mature_non_pass_locs and MATURITY_INDICATOR[qtr]:
                        LEQ_FACTOR.append(0)
                    else:
                        if self.scenario_severity_level == 'BASE':
                            if bizseg == ABL_PD_GROUP:
                                LEQ_FACTOR.append(self.LEQ_df['ABL_BASE_LEQ'][qtr])
                            else:
                                LEQ_FACTOR.append(self.LEQ_df['NON_PASS_BASE_LEQ'][qtr])
                        elif self.scenario_severity_level == 'ADVERSE':
                            LEQ_FACTOR.append(self.LEQ_df['NON_PASS_ADVERSE_LEQ'][qtr])
                        else:
                            LEQ_FACTOR.append(self.LEQ_df['NON_PASS_STRESS_LEQ'][qtr])
            else:
                LEQ_FACTOR.append(0)
                
        return(LEQ_FACTOR)
        
    def calculateMaturedEAD(self, invariant_data, contract_results, forecast_period_quarterly):
        EAD_FACTOR_MATURED = []
        MATURITY_INDICATOR = []
        bizseg = invariant_data['PD_GROUP']
        facility_type = invariant_data['FACILITYTYPE'] if self.line_term_type_input_path is None else invariant_data['LINE_TERM']
        for qtr in range(forecast_period_quarterly):
            # ESTIMATE MATURITY INDICATOR
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )
            if ((('LINE' in facility_type.upper()) and (self.line_term_type_input_path is not None)) \
                    or ('LINE OF CREDIT' in facility_type.upper())):
                if MATURITY_INDICATOR[qtr]:
                    if (
                        (contract_results['final_rating'][qtr] > self.pass_srr)
                        or
                        (pd.isnull(contract_results['final_rating'][qtr]))
                    ):
                        EAD_FACTOR_MATURED.append(1)
                    else:
                        EAD_FACTOR_MATURED.append(0)
                else:
                    EAD_FACTOR_MATURED.append(1)
            else:
                EAD_FACTOR_MATURED.append(1)
        return EAD_FACTOR_MATURED
        
    def matureEADs(self, invariant_data, contract_results):
        EAD_FACTOR_MATURED = []
        MATURITY_INDICATOR = []
        for qtr in range(self.calculation_periods):
            # ESTIMATE MATURITY INDICATOR
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )
            # ESTIMATE MATURITY INDICATOR
            if MATURITY_INDICATOR[qtr]:
                EAD_FACTOR_MATURED.append(0)
            else:
                EAD_FACTOR_MATURED.append(1)
        return EAD_FACTOR_MATURED
        
    def ratePortfolio(self, mature_non_pass_locs: bool= True, return_results: bool= False):
        """This function computes for all contracts in the portfolio

        Return: a 2-D dictionary : key-> UNIQUE_FACILITY_ID, value-> pd, lgd, ead, new_ead
        """
        self._logger.add(
            type='INFO',
            message='Rating portfolio...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Initialize empty portfolio container
        portfolio = {}

        # Determine total number of record and completion meter breakpoints
        items_to_process = len(self.portfolio_snapshot)
        report_breakpoints = list(np.array(list(range(1, 21))) * (items_to_process // 20))
        
        # Generate LEQ Factor lists
        self.__LEQ_df = self.generateLEQFactor()

        # Begin looping through portfolio (rating contracts)
        for i in range(items_to_process):

            # Contract data
            input_data = self.portfolio_snapshot.iloc[i]
            unique_contract_id = input_data['UNIQUE_FACILITY_ID']

            # Check for contract duplicate in portfolio forecast container
            if unique_contract_id in portfolio.keys():
                raise KeyError("duplicate contracts, the UNIQUE_FACILITY_ID already exists in the portfolio")

            # Rate one contract
            portfolio[unique_contract_id] = self.rateOneContract(
                input_data=input_data,
                mature_non_pass_locs=mature_non_pass_locs
            )

            # Show % complete
            if i in report_breakpoints:
                self._logger.add(
                    type='INFO',
                    message='Rating portfolio ' + str(
                        (report_breakpoints.index(i) + 1) * 5) + "% complete...",
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )

        # Accounting checks
        if items_to_process != len(portfolio):
            raise Exception("Initial number of contracts to process is different from portfolio forecast length.")

        # Clean up and finalize
        self.__results_set = portfolio
        del portfolio
        self.resultsToDataFrame()
        self._logger.add(
            type='INFO',
            message='Rating portfolio completed for {} contracts.'.format(str(items_to_process)),
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        if return_results:
            return(self.__results_set)

    def rateOneContract(self, input_data, mature_non_pass_locs: bool= True):
        """

        Args:
            input_data: one row of the portfolio_snapshot data frame
        Return:
             a dictionary: keys-> pd, lgd, ead, new_ead, values-> their coresponding values
        """

        # Initialize empty contract container
        results = {}
        
        # Get staging information  
        if self.stage_diff_switch:
            IS_Stage1 = True if input_data['stage'] == 1 else False

        # Get m2mat information        
        if self.maximum_maturity_date_imputation:                         
            raw_m2mat = int(input_data['m2mat']) 
        else:
            raw_m2mat = input_data['m2mat']
        valid_m2mat_tag = (not pd.isnull(raw_m2mat)) and (raw_m2mat > 0)
        
        # get forecast period quarter using m2mat 
        if valid_m2mat_tag:
            m2mat_qtr = int(raw_m2mat/3) if raw_m2mat%3==0 else int(raw_m2mat/3)+1
            m2mat_month = raw_m2mat
        else:
            m2mat_qtr = self.calculation_periods
            m2mat_month = self.calculation_periods * 3

        # fixed forecast period or maturity information not valid
        if self.fix_forecast_period == True:
            # stop forecasting when loan reaches maturity
            if self.maturity_switch == True:
                forecast_period_quarterly = min(m2mat_qtr, self.calculation_periods) 
                forecast_period_month = min(m2mat_month, self.forecast_periods)
            else:
                forecast_period_quarterly = self.calculation_periods
                forecast_period_month = self.forecast_periods
                
        # dynamic forecast period per facility maturity    
        else:
            forecast_period_quarterly = m2mat_qtr
            forecast_period_month = m2mat_month
        
        # if stage differentiation, forecast horizon different (stage 1: 4Q; stage 2/3: 44Q)
        if self.stage_diff_switch and IS_Stage1:
            forecast_period_quarterly = min(forecast_period_quarterly, 4)
            forecast_period_month = min(forecast_period_month, 12)
            
        # Compute PD
        pd_result = self.calculatePD(
                         input_data=input_data, 
                         forecast_period_quarterly=forecast_period_quarterly
                     )
        for i in range(forecast_period_quarterly):
            for key, value in pd_result[i].items():
                if i == 0:
                    results[key] = []
                results[key].append(value)

        # Compute LGD
        self.calculateLGD(
            invariant_data=input_data,
            contract_results=results,
            forecast_period_quarterly=forecast_period_quarterly
        )

        # Compute EAD
        results['EAD_TOTAL_LINE'] = [0] * forecast_period_quarterly
        results['EAD_AVAILABLE_LINE'] = self.calculateLEQ(
            invariant_data=input_data,
            contract_results=results,
            forecast_period_quarterly=forecast_period_quarterly
        )
            
        # option a: currently open for ifrs: mature loans by forecast_period_quarterly
        if self.maturity_switch:
            results['EAD_BOOK_BALANCE'] = [1] * forecast_period_quarterly
            results['EAD_LETTER_OF_CREDIT'] = [1] * forecast_period_quarterly
            results['EAD'] = [1] * forecast_period_quarterly
        # option b: currently open; mature non-pass + line of credit loans
        elif mature_non_pass_locs:
            EAD_matured = self.calculateMaturedEAD(
                invariant_data=input_data,
                contract_results=results,
                forecast_period_quarterly=forecast_period_quarterly
            )
            results['EAD_BOOK_BALANCE'] = EAD_matured
            results['EAD_LETTER_OF_CREDIT'] = EAD_matured
            results['EAD'] = EAD_matured
#        # option c: do not mature any loan
#        else:
#            results['EAD_BOOK_BALANCE'] = [1] * self.calculation_periods
#            results['EAD_LETTER_OF_CREDIT'] = [1] * self.calculation_periods
#            results['EAD'] = [1] * self.calculation_periods
        
        results['PD_GROUP'] = [input_data['PD_GROUP']] * forecast_period_quarterly
        if self.add_uat_columns:
#            results['IS_Stage1'] = [IS_Stage1] * forecast_period_quarterly
#            results['stage'] = [input_data['stage']] * forecast_period_quarterly
            results['forecast_period_quarterly'] = [forecast_period_quarterly] * forecast_period_quarterly
            results['forecast_period_month'] = [forecast_period_month] * forecast_period_quarterly

        # Checks for coverage rates mapping
        if self._mappings['ALLL_SRR'] is None:
            raise Exception('`self.mappings` for ALLL_SRR is None.')
        if self._mappings['CONTINGENCY_SRR'] is None:
            raise Exception('`self.mappings` for CONTINGENCY_SRR is None.')
            
        # Assign coverage rates using final rating and mapping
        if self.as_of_date >= datetime.datetime(2017,6,30): 
            if input_data['PD_GROUP'] == 'ABL':
                results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR_ABL'].apply(item) \
                    for item in results['final_rating']
                ]
                results['CONTINGENTRESERVE'] = [
                    self._mappings['CONTINGENCY_SRR_ABL'].apply(item) \
                    for item in results['final_rating']
                ]            
            elif input_data['PD_GROUP'] == 'MIDDLE_MARKET':
                results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR_MM'].apply(item) \
                    for item in results['final_rating']
                ]
                results['CONTINGENTRESERVE'] = [
                    self._mappings['CONTINGENCY_SRR_MM'].apply(item) \
                    for item in results['final_rating']
                ]                  
            elif input_data['PD_GROUP'] == 'BUSINESS_BANKING':
                results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR_UBB'].apply(item) \
                    for item in results['final_rating']
                ]
                results['CONTINGENTRESERVE'] = [
                    self._mappings['CONTINGENCY_SRR_UBB'].apply(item) \
                    for item in results['final_rating']
                ]                  
        else:
            results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR'].apply(item) \
                    for item in results['final_rating']
                ]    
            results['CONTINGENTRESERVE'] = [
                self._mappings['CONTINGENCY_SRR'].apply(item) \
                for item in results['final_rating']
            ]

        # Compute NEW EAD ($ loss)
        self.estimateLossAmountAlt(invariant_data=input_data, 
                                   contract_results=results, 
                                   forecast_period_quarterly=forecast_period_quarterly) 
            
        # Convert result dictionary data from quarterly to monthly
        if self.forecast_result_frequency == 'monthly':
            # get the length of forecast period for each contract
            contract_forecast_periods = forecast_period_month
            for key, value in results.items():  
                value_repeat = np.repeat(value, 3).tolist()
                results[key] = value_repeat
            for metric in results:
                results[metric] = results[metric][:contract_forecast_periods]
        
            # Generate monthly period date sequence for uat dataset
            period_date_series = utilities.generateDateSequence(
                    as_of_date = self.as_of_date,
                    forecast_periods = contract_forecast_periods,
                    m_interval = PERIOD_FREQ_MAP[self.forecast_result_frequency],
                    include_init = False
                ).tolist()
        # or: output a quarter dataset
        else:
            contract_forecast_periods = forecast_period_quarterly   
            period_date_series = utilities.generateDateSequence(
                    as_of_date = self.as_of_date,
                    forecast_periods = contract_forecast_periods,
                    m_interval = PERIOD_FREQ_MAP[self.forecast_result_frequency],
                    include_init = False
                ).tolist()        
        results['PeriodDate'] = period_date_series
        results['FORECAST_PERIOD'] = list(range(1,contract_forecast_periods+1))  
   
        return results

    def resultsToDataFrame(self):
        if self.results_set is None:
            raise ValueError('Portfolio has not been rated, `results_set` is null.')

        contract_df_container = []
        for contract_id in self.results_set:
            contract_df = pd.DataFrame(self.results_set[contract_id])
#            if self.forecast_result_frequency == 'monthly':
#                contract_df['FORECAST_PERIOD'] = list(range(1,self.forecast_periods+1))
#            else:
#                contract_df['FORECAST_PERIOD'] = list(range(1,self.calculation_periods+1))                
                
            contract_df['UNIQUE_FACILITY_ID'] = contract_id
            contract_df_container.append(contract_df)
            del contract_df

        self.__results_df = pd.concat(contract_df_container)
        del contract_df_container

    def checkResultRates(self, rate_map):
        """This function checks validility of the rates for all contracts in the portfolio
        """
        self._logger.add(
            type='INFO',
            message='Checking rating results...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        if self.results_df is None:
            raise ValueError('Portfolio has not been rated, `results_df` is null.')
        result_rates = self.results_df.copy(deep=True)
        # convert quarterly PD to monthly PD
        result_rates['pd_1q'] = result_rates['pd_1q'].apply(lambda x: 1-(1-x)**(1/3))
        
        for metric in rate_map:
            statistics = result_rates[metric].describe()
            if ((statistics['min']<0) or (statistics['max']>1)):
                raise ValueError (rate_map[metric]+' result is not within 0 to 1')                            
            self._logger.add(
                      type='INFO',
                      message=rate_map[metric] + ' mean: ' +str(round(statistics['mean']*100,5))+'%',
                      context='CCAR Model : ' + self._model_name,
                      model_id=self._model_id
            )          
            
    def plotResultRates(self, rate_map):
        """This function plots distribution of result rates for all contracts in the portfolio
        """
        self._logger.add(
            type='INFO',
            message='Ploting rating results...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        if self.results_df is None:
            raise ValueError('Portfolio has not been rated, `results_df` is null.')
        result_rates = self.results_df.copy(deep=True)
        # convert quarterly PD to monthly PD
        result_rates['pd_1q'] = result_rates['pd_1q'].apply(lambda x: 1-(1-x)**(1/3))
        # set the zeros in PD to NaN and then call np.nanmean to take the mean, ignoring NaNs
#        result_rates[result_rates['pd_1q'] == 0] = np.nan

        # add additional metrics to plot
        rate_map_copy = copy.deepcopy(rate_map)
        rate_map_copy['final_rating'] = 'FinalRating'

        for metric in sorted(rate_map_copy):
            print('---- Ploting Average Forecasted Rates for: ' + rate_map_copy[metric] + ' ---')
            result_rates['Forecast_Period'] = result_rates.index
            rate_mean = result_rates.groupby('Forecast_Period').mean()
            plt.plot(rate_mean['FORECAST_PERIOD'], rate_mean[metric], 'r-')
            plt.xlabel('Forecast Period')
            plt.ylabel('Rate')
            plt.xticks(np.arange(min(rate_mean['FORECAST_PERIOD']), max(rate_mean['FORECAST_PERIOD'])+1, 1.0))
            plt.title('Average of forecast monthly ' + rate_map_copy[metric] + ' rates')
            plt.show()
            
    def execute(self, session: CCARSession = None):
        """

        Returns
        -------

        """
        self._logger.add(
            type='INFO',
            message='Executing model...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Starting timer
        t0 = time.time()

        # Begin calculation
        if self.__results_set is None:
            self.ratePortfolio(mature_non_pass_locs=self.mature_non_pass_locs)

        rate_map = {
            'pd_1m':"PD",
            'New_LGD_ifrs' if self.discounting_LGD_switch else 'LGD':"LGD",
            'EAD':'EAD',
            'EAD_BOOK_BALANCE':'EADBALANCE',
            'EAD_LETTER_OF_CREDIT':'EADLETTEROFCREDIT',
            'EAD_AVAILABLE_LINE':'EADAVAILABLELINE',
            'EAD_TOTAL_LINE':"EADTOTALLINE",
            'ALLLCOVERAGE':'ALLLCOVERAGE',
            'CONTINGENTRESERVE':'CONTINGENTRESERVE'
        }
        
        # Check result rates
        self.checkResultRates(rate_map)

        # Plot result rates
        if self.show_result_plot: 
            self.plotResultRates(rate_map)
        
        # create contributor file instance only when the result set is already monthly data
        if (session is not None) and (self.forecast_result_frequency == 'monthly'):
            # Set initial completion counter
            items_to_process = len(self.results_set)
            report_breakpoints = list(np.array(list(range(1, 21))) * (items_to_process // 20))

            # Generate period date sequence
#            period_date = utilities.generateDateSequence(
#                as_of_date=self.as_of_date,
#                forecast_periods=self.forecast_periods,
#                m_interval=PERIOD_FREQ_MAP[self.forecast_periods_frequency]
#            )

            # Begin contributor file generation
            self._logger.add(
                type='INFO',
                message='Beginning contributor data generation...',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            cnt = 0
            for unique_facility in self.results_set.keys():
                # Update counter
                if cnt in report_breakpoints:
                    self._logger.add(
                        type='INFO',
                        message='Contributor data generation ' + str((report_breakpoints.index(cnt) + 1) * 5) + "% complete...",
                        context='CCAR Model : ' + self._model_name,
                        model_id=self._model_id
                    )
                # Get period date sequence
                period_date = self.results_set[unique_facility]['PeriodDate']
                
                # Loop over the metrics that needed to be included in contributor file 
                for metric in list(rate_map.keys()):
                    model_output_rate = self.results_set[unique_facility][metric]
                    contract_output_length = len(model_output_rate) 
#                    model_output_rate = (
#                        np.repeat(self.results_set[unique_facility][metric], 3).tolist() \
#                        if rate_map[metric] != "PD" \
#                        else np.apply_along_axis(
#                            lambda x: 1-(1-x)**(1/3),
#                            0,
#                            np.repeat(self.results_set[unique_facility][metric], 3)
#                        ).tolist()
#                    )
                    orig_loan = True if '_O' in unique_facility else False
                    if orig_loan:    
                        if metric == 'EAD_AVAILABLE_LINE':
                            session.contributor_file_generator.addCFChunk(
                                as_of_date=self.as_of_date,
                                forecast_periods=contract_output_length,
                                forecast_periods_frequency=self.forecast_periods_frequency,
                                model_segment="SB"+unique_facility,
                                scenario=self.scenario,
                                rate_name=rate_map[metric],
                                rate_type=4,
                                vintage_differentiation=True,
                                vintage_differentiation_shift=True,
                                model_output_rate=model_output_rate,
                                uncertainty_adjustment_rate=0.0,
                                mgmt_adjustment_rate=0.0,
                                process_additional_ead = False
                            )
                        else:       
                            session.contributor_file_generator.addCFChunk(
                                as_of_date=self.as_of_date,
                                forecast_periods=contract_output_length,
                                forecast_periods_frequency=self.forecast_periods_frequency,
                                model_segment="SB"+unique_facility,
                                scenario=self.scenario,
                                rate_name=rate_map[metric],
                                rate_type=4,
                                vintage_differentiation=True,
                                vintage_differentiation_shift=False,
                                model_output_rate=model_output_rate,
                                uncertainty_adjustment_rate=0.0,
                                mgmt_adjustment_rate=0.0,
                                process_additional_ead = False
                            )                  
                    else:
                        # append loans in anchor table to contributor file generator
                        session.contributor_file_generator.appendCF(
                            scenario=self.scenario,
                            model_segment="SB"+unique_facility,
                            period_date=period_date,
                            vintage=self.as_of_date,
                            rate_type=4,
                            rate_name=rate_map[metric],
                            model_output_rate=model_output_rate,
                            uncertainty_adjustment_rate=0.0,
                            mgmt_adjustment_rate=0.0
                        )
#                        session.contributor_file_generator.addCFChunk(
#                            as_of_date=self.as_of_date,
#                            forecast_periods=self.forecast_periods,
#                            forecast_periods_frequency=self.forecast_periods_frequency,
#                            model_segment="SB"+unique_facility,
#                            scenario=self.scenario,
#                            rate_name=rate_map[metric],
#                            rate_type=4,
#                            vintage_differentiation=False,
#                            vintage_differentiation_shift=False,
#                            model_output_rate=model_output_rate,
#                            uncertainty_adjustment_rate=0.0,
#                            mgmt_adjustment_rate=0.0,
#                            process_additional_ead = False
#                        )
                cnt += 1

        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Dump log data into session instance
        if session is not None:
            if isinstance(session, CCARSession):
                for log_item in self._logger.items:
                    session.logger.addItem(log_item)