# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 16:27:24 2016

@author: n838126
"""

"""
SAMPLE USE
#BASE
adjustment_dictionary={'PD_GROUP':'SBB', 'RATENAME':'PD', 'MGMTADJUSTMENT':-0.1237}

#Set SA scenarios
stress_scen=["STRESS"]




## MODEL ID
# SBB : 37 - Scenario Analysis Model - SBB PD - SBNA
# CEVF : 53 - Scenario Analysis Model - CEVF PD - SBNA
# CRE CONSTRUCTION : 2016-SBNA-Loss-Commercial-CREConstruction

#BASE
ccar_session = CCARSession(
    session_id='2-Factor Logit Model Test',
    session_date=datetime.datetime(2017,12,31),
    user='n881840'
)

cart = ModelShoppingCart(ccar_session=ccar_session)




TwoLogit_base = TwoFLogitModel(
                uncertainty_rate = 0.00,
                as_of_date = datetime.datetime(2017,12,31),
                model_id = '37 - Scenario Analysis Model - SBB PD - SBNA',
                scenario="FRB_BASE",
                scenario_context='CCAR2018',
                forecast_periods =48,
                scenario_date=datetime.datetime(2017,12,31))

cart.addModel(TwoLogit_base)

cart.checkout()


#ADD Overlay
#ccar_session.contributor_file_generator.retailmanagementAdjustment(adjustment_dictionary=adjustment_dictionary,dataset_query_date=datetime.datetime(2017,6,30),model='SBB')

cf_base = ccar_session.contributor_file_generator.generateContributorFileInstance()
sbbcf_data_base=cf_base.getCFData()
base=cf_base.getCFData()



#ADVERSE
ccar_session = CCARSession(
    session_id='2-Factor Logit Model Test',
    session_date=datetime.datetime(2017,12,31),
    user='n881840'
)

cart = ModelShoppingCart(ccar_session=ccar_session)

TwoLogit_ad = TwoFLogitModel(
                uncertainty_rate = 0.00,
                as_of_date = datetime.datetime(2017,12,31),
                model_id = '37 - Scenario Analysis Model - SBB PD - SBNA',
                scenario="FRB_ADVERSE",
                scenario_context='CCAR2018',
                forecast_periods =48,
                scenario_date=datetime.datetime(2017,12,31))
#ADD Overlay
#ccar_session.contributor_file_generator.retailmanagementAdjustment(adjustment_dictionary=adjustment_dictionary,dataset_query_date=datetime.datetime(2017,6,30),model='SBB')

cart.addModel(TwoLogit_ad)

cart.checkout()

cf_ad = ccar_session.contributor_file_generator.generateContributorFileInstance()
sbbcf_data_ad=cf_ad.getCFData()
adverse=cf_ad.getCFData()




#STRESS
ccar_session = CCARSession(
    session_id='2-Factor Logit Model Test',
    session_date=datetime.datetime(2017,12,31),
    user='n881840'
)

cart = ModelShoppingCart(ccar_session=ccar_session)

TwoLogit_st = TwoFLogitModel(
                uncertainty_rate = 0.00,
                as_of_date = datetime.datetime(2017,12,31),
                model_id = '37 - Scenario Analysis Model - SBB PD - SBNA',
                scenario="FRB_STRESS",
                scenario_context='CCAR2018',
                forecast_periods =48,
                scenario_date=datetime.datetime(2017,12,31))
#ADD Overlay
#ccar_session.contributor_file_generator.retailmanagementAdjustment(adjustment_dictionary=adjustment_dictionary,dataset_query_date=datetime.datetime(2017,6,30),model='SBB')

cart.addModel(TwoLogit_st)

cart.checkout()

cf_st = ccar_session.contributor_file_generator.generateContributorFileInstance()
sbbcf_data_st=cf_st.getCFData()
stress=cf_st.getCFData()
stress.to_csv("C:\\Users\\n881840\\Desktop\\SBB_PD_mc2017_test2.csv",date_format="%m/%d/%Y",index=None)



#BHC_SA
ccar_session = CCARSession(
    session_id='2-Factor Logit Model Test',
    session_date=datetime.datetime(2017,12,31),
    user='n881840'
)

cart = ModelShoppingCart(ccar_session=ccar_session)

TwoLogit_st = TwoFLogitModel(
                uncertainty_rate = 0.00,
                as_of_date = datetime.datetime(2017,12,31),
                model_id = '37 - Scenario Analysis Model - SBB PD - SBNA',
                scenario="BHC_SA",
                scenario_context='CCAR2018',
                forecast_periods =48,
                scenario_date=datetime.datetime(2017,12,31))
#ADD Overlay
#ccar_session.contributor_file_generator.retailmanagementAdjustment(adjustment_dictionary=adjustment_dictionary,dataset_query_date=datetime.datetime(2017,6,30),model='SBB')

cart.addModel(TwoLogit_st)

cart.checkout()

cf_bhc = ccar_session.contributor_file_generator.generateContributorFileInstance()
sbbcf_data_bhc=cf_st.getCFData()
bhc=cf_st.getCFData()
bhc.to_csv("C:\\Users\\n881840\\Desktop\\SBB_PD_mc2017_test2.csv",date_format="%m/%d/%Y",index=None)





#GLOBAL_STRESS
ccar_session = CCARSession(
    session_id='2-Factor Logit Model Test',
    session_date=datetime.datetime(2017,12,31),
    user='n881840'
)

cart = ModelShoppingCart(ccar_session=ccar_session)

TwoLogit_st = TwoFLogitModel(
                uncertainty_rate = 0.00,
                as_of_date = datetime.datetime(2017,12,31),
                model_id = '37 - Scenario Analysis Model - SBB PD - SBNA',
                scenario="GLOBAL_STRESS",
                scenario_context='ICAAP2018_CCAR',
                forecast_periods =48,
                scenario_date=datetime.datetime(2017,12,31))
#ADD Overlay
#ccar_session.contributor_file_generator.retailmanagementAdjustment(adjustment_dictionary=adjustment_dictionary,dataset_query_date=datetime.datetime(2017,6,30),model='SBB')

cart.addModel(TwoLogit_st)

cart.checkout()

cf_gs = ccar_session.contributor_file_generator.generateContributorFileInstance()
sbbcf_data_gs=cf_st.getCFData()
gs=cf_st.getCFData()
gs.to_csv("C:\\Users\\n881840\\Desktop\\SBB_PD_mc2017_test2.csv",date_format="%m/%d/%Y",index=None)




all=(((base.append(adverse)).append(stress)).append(bhc)).append(gs)

all["PARTITION_KEY"] = 'S00000000419' 
all["RUN_SIGNATURE"] = '113017_122756' 
all["CONTRIBUTOR_FILE_ID"] = 66
all["FILE_VERSION"] = 1
all.to_csv("I:\\CRMPO\\CCAR\\4Q17\\3 - Contributor Files\\Retail\\DryRun2018\\SBB_PD_DryRun2018_01252018.csv",date_format="%m/%d/%Y",index=None)

all.to_csv("C:\\Users\\n881840\\Desktop\\SBB_PD_jun_ccar_run2.csv",date_format="%m/%d/%Y",index=None)




cf_base.writeToMoodysRFO(
     p_reporting_date= datetime.datetime(2017,12,31),
     moodys_rfo_env="PROD_ENV",
     table_name='STG_CONTRIBUTOR_DATA',
     contributor_file_id=66,
     file_version=1,
     as_of_date=datetime.datetime(2017,12,31),
     overwrite_vintage_asofdate=datetime.datetime(1900,1,31),
     run_signature='123117_122757',
     partition_key='S00000000422'
     )

cf_ad.writeToMoodysRFO(
     p_reporting_date= datetime.datetime(2017,12,31),
     moodys_rfo_env="PROD_ENV",
     table_name='STG_CONTRIBUTOR_DATA',
     contributor_file_id=66,
     file_version=1,
     as_of_date=datetime.datetime(2017,12,31),
     overwrite_vintage_asofdate=datetime.datetime(1900,1,31),
     run_signature='123117_122757',
     partition_key='S00000000422'
     )

cf_st.writeToMoodysRFO(
     p_reporting_date= datetime.datetime(2017,12,31),
     moodys_rfo_env="PROD_ENV",
     table_name='STG_CONTRIBUTOR_DATA',
     contributor_file_id=66,
     file_version=1,
     as_of_date=datetime.datetime(2017,12,31),
     overwrite_vintage_asofdate=datetime.datetime(1900,1,31),
     run_signature='123117_122757',
     partition_key='S00000000422'
     )

cf_bhc.writeToMoodysRFO(
     p_reporting_date= datetime.datetime(2017,12,31),
     moodys_rfo_env="PROD_ENV",
     table_name='STG_CONTRIBUTOR_DATA',
     contributor_file_id=66,
     file_version=1,
     as_of_date=datetime.datetime(2017,12,31),
     overwrite_vintage_asofdate=datetime.datetime(1900,1,31),
     run_signature='123117_122757',
     partition_key='S00000000422'
     )

cf_gs.writeToMoodysRFO(
     p_reporting_date= datetime.datetime(2017,12,31),
     moodys_rfo_env="PROD_ENV",
     table_name='STG_CONTRIBUTOR_DATA',
     contributor_file_id=66,
     file_version=1,
     as_of_date=datetime.datetime(2017,12,31),
     overwrite_vintage_asofdate=datetime.datetime(1900,1,31),
     run_signature='123117_122757',
     partition_key='S00000000422'
     )



twoflogit_CRE_CONS_Base.execute()
pd_series = twoflogit_CRE_CONS_Base.getPDSeries()






**Sensitivity**;
example = SensitivityProcessor(
		class_type =  TwoFLogitModel,
		pd_groups = ["SBB"],
		model_name= None,
		ejm_ind= False,
      uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2017,6,30),
    model_id='37 - Scenario Analysis Model - SBB PD - SBNA',
    scenario=['BASE','ADVERSE'],
    scenario_context='MidCycle2017',
    forecast_periods=27,
    scenario_date=datetime.datetime(2017,6,30))
  
example.ShowVariables
#['FLBR_US', 'FYPEWSQ_US']
example.ChangeVariable(['FYPEWSQ_US','FLBR_US'])
CFG = example.CFGenerator(example._para_dict)
container1 = []
while(True):
    try:
        container1.append(next(CFG))
    except Exception:
        break
        
for i,j in zip(container1,['BASE','CH_1','CH_2','ADVERSE']):
    i['SCENARIO'] = [j]*len(i)

    
    
example = SensitivityProcessor(
		class_type =  TwoFLogitModel,
		pd_groups = ["SBB"],
		model_name= None,
		ejm_ind= False,
      uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2017,6,30),
    model_id='37 - Scenario Analysis Model - SBB PD - SBNA',
    scenario=['ADVERSE','STRESS'],
    scenario_context='MidCycle2017',
    forecast_periods=27,
    scenario_date=datetime.datetime(2017,6,30))
  
example.ShowVariables
#['FLBR_US', 'FYPEWSQ_US']
example.ChangeVariable(['FYPEWSQ_US','FLBR_US'])
CFG = example.CFGenerator(example._para_dict)                
container2 = []
while(True):
    try:
        container2.append(next(CFG))
    except Exception:
        break
       
for i,j in zip(container2,['ADVERSE','CH_3','CH_4','STRESS']):
    i['SCENARIO'] = [j]*len(i)        
    
container2.pop(0)


container=container1+container2
output_pd = pd.concat(container,ignore_index=True)


output_pd.to_csv("C:\\Users\\n881840\\Documents\\sbb_pd_sensitivity_mc17_test.csv",date_format="%m/%d/%Y",index=False)

#############################################################################################################################
"""

import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.metrics import PD
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import pandas as pd
import numpy as np
import time
import copy
import os



class TwoFLogitModel(CCARModel):
    """ This class calculates PD rates for Logit models 
    
    The main methods here are: 
                              func <calculatePD>: use regression to calculates PD rates
                              func <getPDSeries>: get PD objects with forecast dates

    
    :param as_of_date:starting date for model run
    :param model_id:model identification
    :param scenario:name of scenario
    :param scenario_context:execution environment for scenario (e.g'CCAR2016')
    :param forecast_periods:number of forward months to run the model 
                            (e.g 27 if scenario_context = 'CCAR2016')
    :param uncertainty: indicate whether there is uncertainty or not (e.g True or False)                            
    :param uncertainty_rate:adds-on rate
    :param forecast_periods_frequency
    :param precision:precision level for calculation
    :param model_segment: (e.g PD_23)

    
    :type as_of_date:datetime.datetime
    :type model_id:str
    :type scenario:str
    :type scenario_context:str
    :type forecast_periods:int
    :type uncertainty: bool
    :type uncertainty_rate:int or float
    :type forecast_periods_frequency: str
    :type precision:int
    :type model_segment: str
    
   """       
    
    # Properties
    __model_segment = None #"PD_38"
    __uncertainty = None
    __uncertainty_rate = None
    __pd_series = None


    # Methods
    def __init__(
        self,
        as_of_date,
        model_id,
        scenario,
        scenario_context,
        forecast_periods,
        uncertainty_rate,
        scenario_date,
        forecast_periods_frequency='monthly',
        precision=None,
        auto_fetch_macros=True,
        use_RFO_macro_series=True,
        **kwargs
    ):
        #Initialize parent class properties
        CCARModel.__init__(
            self,
            as_of_date=as_of_date,
            model_id=model_id,
            scenario=scenario,
            scenario_date =scenario_date,
            scenario_context=scenario_context,
            forecast_periods=forecast_periods,
            forecast_periods_frequency=forecast_periods_frequency,
            precision=precision,
            use_RFO_macro_series=use_RFO_macro_series,
            scenario_combinations=kwargs.get('scenario_combinations')
        )

        # Assigning model segment key
        model_segment = self._model_properties.getParameters(type='property',name='model_segment')
        self._logger.add(
            type='INFO',
            message='Assigning model segment key/keys : '+str(model_segment)+'...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self.__model_segment = model_segment

        # Process uncertainty
        if isinstance(uncertainty_rate, (int, float)):
            self._logger.add(
                type='INFO',
                message='Assigning uncertainty rate : ' + str(self.__uncertainty_rate) + '...',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            self.__uncertainty_rate = uncertainty_rate
        else:
            self._logger.add(
                type='ERROR',
                message='Input uncertainty rate should be of numeric type, int or float.',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            raise TypeError('Input uncertainty rate should be of numeric type, int or float.')


        # Get model regression coefficients for PD
        self.__regression_coefficients = self._model_properties.getParameters(type='operation',name='regression_coefficients')

        # Get macro variables during construction
        if auto_fetch_macros:
            self.fetchMacroSeries(scenario_combinations=kwargs.get('scenario_combinations'))

        self._logger.add(
            type='INFO',
            message='CCAR Model initialization completed.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )


    ####################################################################################################################
    ## GETTERS
    ####################################################################################################################
    @property
    def model_segment(self):
        '''
        :returns: model segment for logit model (e.g PD_23)        
        '''   
        return(self.__model_segment)

    @property
    def uncertainty_rate(self):
        return(self.__uncertainty_rate)

    @property
    def regression_coefficients(self):
        return(self.__regression_coefficients)

    def getPDSeries(self):
        try:
            return(self.__pd_series)
        except AttributeError:
            self.calculatePD()
            return (self.__pd_series)

    ####################################################################################################################

    def calculatePD(self):
        """This method uses logit regression to calcualte PD rates during forecast periods
        
        :return:pd_series (PD metrics objects and monthly forecaste dates)
        :type pd_series: pandas.core.series.Series
        """
        data = self.transformed_macro_series

        # Run PD regression to get quarterly PD
        logistic_mapping = lambda ts : round(1/(1+np.exp(-ts)),self._precision)
        intercept = self.__regression_coefficients['intercept']
        coeff_pairs = self.__regression_coefficients['coefficients_pairs']
        data['PD_Qtr'] = logistic_mapping(
            (sum([data[item]*coeff_pairs[item] for item in coeff_pairs.keys()])+intercept)
        )

        # Generate monthly time series object
        date_index = utilities.generateDateSequence(
            as_of_date=self.as_of_date,
            forecast_periods=self.forecast_periods,
            m_interval=utilities.PERIOD_FREQUENCY_MAP[self._forecast_periods_frequency]
        )
        scenario_period_frequency = self._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )

        # Generate PD metrics
        self.__pd_series = pd.core.series.Series(
            np.repeat(
                [
                    PD(
                        metric_value=pd_value,#adjust for P20 May Stress
                        metric_segment_key=self.__model_segment,
                        time_horizon=scenario_period_frequency,
                        metric_uncertainty=(pd_value / (1 - self.__uncertainty_rate)) - pd_value,
                        metric_adjustment=0,
                        metric_adjustment_justification='',
                        precision=self._precision
                    ) for pd_value in data['PD_Qtr']
                ],
                utilities.PERIOD_FREQUENCY_MAP[
                    scenario_period_frequency
                ] / utilities.PERIOD_FREQUENCY_MAP[
                    self._forecast_periods_frequency
                ]
            ),
            index=date_index
        )

        # Transform PD time scale
        self.__pd_series.apply(lambda pd_metric : pd_metric.convertPDTimeHorizon(
            self._forecast_periods_frequency,
            inplace=True
        ))


    def execute(self, session=None):
        """

        :param session: an optional CCARSession instance to write contributor and log data to, default is None
        :return:
        """
        self._logger.add(
            type='INFO',
            message='Executing model...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Starting timer
        t0 = time.time()
        global stress_scen
        # Model process
        self.calculatePD()

        if session is not None:
            for model_segment_key in self.__pd_series[0].model_segment_key:
                session.contributor_file_generator.addCFChunk(
                    as_of_date=self._as_of_date,
                    forecast_periods=self._forecast_periods,
                    forecast_periods_frequency=self._forecast_periods_frequency,
                    scenario=self._scenario,
                    model_segment=model_segment_key,
                    rate_name=[metric.name for metric in self.__pd_series],
                    rate_type=[metric.type for metric in self.__pd_series],
                    vintage_differentiation=True if self.__pd_series[0].name == "PD" else False,
                    model_output_rate=[metric.metric_value*1.5 if self._scenario in stress_scen else metric.metric_value for metric in self.__pd_series],
                    uncertainty_adjustment_rate=[metric.uncertainty for metric in self.__pd_series],
                    mgmt_adjustment_rate=[metric.adjustment for metric in self.__pd_series]
                )
                
        session.contributor_file_generator.replace_vintage(as_of_date=self.as_of_date)           


        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Dump log data into session instance
        if session is not None:
            if isinstance(session, CCARSession):
                for log_item in self._logger.items:
                    session.logger.addItem(log_item)
















