# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 16:27:24 2016

@author: n838126
"""

"""
SAMPLE USE

ccar_session = CCARSession(
    session_id='2-Factor Logit Model Test',
    session_date=datetime.datetime(2016,3,31),
    user='n813863'
)

cart = ModelShoppingCart(ccar_session=ccar_session)


## MODEL ID
# SBB : 37 - Scenario Analysis Model - SBB PD - SBNA
# CEVF : 53 - Scenario Analysis Model - CEVF PD - SBNA
# CRE CONSTRUCTION : 2016-SBNA-Loss-Commercial-CREConstruction

-----------P20------
TwoLogit = TwoFLogitModel(
                uncertainty_rate = 0.00,
                as_of_date = datetime.datetime(2017,3,31),
                model_id = '53 - Scenario Analysis Model - CEVF PD - SBNA',
                scenario="BASE",
                scenario_context='STRATPLAN_2017',
                forecast_periods =45,
                scenario_date=datetime.datetime(2017,3,31))
--------------------
twoflogit_CRE_CONS_Base = TwoFLogitModel(
    uncertainty_rate=0.10,
    as_of_date=datetime.datetime(2015,12,31),
    model_id='34 - Scenario Analysis Model - CRE PD - SBNA',
    scenario='Base',
    scenario_context='CCAR2016',
    forecast_periods=27,
    use_RFO_macro_series=False
)

cart.addModel(TwoLogit)



cart.checkout()

cf = ccar_session.contributor_file_generator.generateContributorFileInstance()

cf.getCFData().to_clipboard()


twoflogit_CRE_CONS_Base.execute()
pd_series = twoflogit_CRE_CONS_Base.getPDSeries()


#############################################################################################################################
"""

import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.metrics import PD
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import pandas as pd
import numpy as np
import time
import copy
import os



class TwoFLogitModel(CCARModel):
    """ This class calculates PD rates for Logit models 
    
    The main methods here are: 
                              func <calculatePD>: use regression to calculates PD rates
                              func <getPDSeries>: get PD objects with forecast dates

    
    :param as_of_date:starting date for model run
    :param model_id:model identification
    :param scenario:name of scenario
    :param scenario_context:execution environment for scenario (e.g'CCAR2016')
    :param forecast_periods:number of forward months to run the model 
                            (e.g 27 if scenario_context = 'CCAR2016')
    :param uncertainty: indicate whether there is uncertainty or not (e.g True or False)                            
    :param uncertainty_rate:adds-on rate
    :param forecast_periods_frequency
    :param precision:precision level for calculation
    :param model_segment: (e.g PD_23)

    
    :type as_of_date:datetime.datetime
    :type model_id:str
    :type scenario:str
    :type scenario_context:str
    :type forecast_periods:int
    :type uncertainty: bool
    :type uncertainty_rate:int or float
    :type forecast_periods_frequency: str
    :type precision:int
    :type model_segment: str
    
   """       
    
    # Properties
    __model_segment = None #"PD_38"
    __uncertainty = None
    __uncertainty_rate = None
    __pd_series = None


    # Methods
    def __init__(
        self,
        as_of_date,
        model_id,
        scenario,
        scenario_context,
        forecast_periods,
        uncertainty_rate,
        scenario_date,
        forecast_periods_frequency='monthly',
        precision=None,
        auto_fetch_macros=True,
        use_RFO_macro_series=True,
        **kwargs
    ):
        #Initialize parent class properties
        CCARModel.__init__(
            self,
            as_of_date=as_of_date,
            model_id=model_id,
            scenario=scenario,
            scenario_date =scenario_date,
            scenario_context=scenario_context,
            forecast_periods=forecast_periods,
            forecast_periods_frequency=forecast_periods_frequency,
            precision=precision,
            use_RFO_macro_series=use_RFO_macro_series,
            scenario_combinations=kwargs.get('scenario_combinations')
        )

        # Assigning model segment key
        model_segment = self._model_properties.getParameters(type='property',name='model_segment')
        self._logger.add(
            type='INFO',
            message='Assigning model segment key/keys : '+str(model_segment)+'...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self.__model_segment = model_segment

        # Process uncertainty
        if isinstance(uncertainty_rate, (int, float)):
            self._logger.add(
                type='INFO',
                message='Assigning uncertainty rate : ' + str(self.__uncertainty_rate) + '...',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            self.__uncertainty_rate = uncertainty_rate
        else:
            self._logger.add(
                type='ERROR',
                message='Input uncertainty rate should be of numeric type, int or float.',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            raise TypeError('Input uncertainty rate should be of numeric type, int or float.')


        # Get model regression coefficients for PD
        self.__regression_coefficients = self._model_properties.getParameters(type='operation',name='regression_coefficients')

        # Get macro variables during construction
        if auto_fetch_macros:
            self.fetchMacroSeries(scenario_combinations=kwargs.get('scenario_combinations'))

        self._logger.add(
            type='INFO',
            message='CCAR Model initialization completed.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )


    ####################################################################################################################
    ## GETTERS
    ####################################################################################################################
    @property
    def model_segment(self):
        '''
        :returns: model segment for logit model (e.g PD_23)        
        '''   
        return(self.__model_segment)

    @property
    def uncertainty_rate(self):
        return(self.__uncertainty_rate)

    @property
    def regression_coefficients(self):
        return(self.__regression_coefficients)

    def getPDSeries(self):
        try:
            return(self.__pd_series)
        except AttributeError:
            self.calculatePD()
            return (self.__pd_series)

    ####################################################################################################################

    def calculatePD(self):
        """This method uses logit regression to calcualte PD rates during forecast periods
        
        :return:pd_series (PD metrics objects and monthly forecaste dates)
        :type pd_series: pandas.core.series.Series
        """
        data = self.transformed_macro_series

        # Run PD regression to get quarterly PD
        logistic_mapping = lambda ts : round(1/(1+np.exp(-ts)),self._precision)
        intercept = self.__regression_coefficients['intercept']
        coeff_pairs = self.__regression_coefficients['coefficients_pairs']
        data['PD_Qtr'] = logistic_mapping(
            (sum([data[item]*coeff_pairs[item] for item in coeff_pairs.keys()])+intercept)
        )

        # Generate monthly time series object
        date_index = utilities.generateDateSequence(
            as_of_date=self.as_of_date,
            forecast_periods=self.forecast_periods,
            m_interval=utilities.PERIOD_FREQUENCY_MAP[self._forecast_periods_frequency]
        )
        scenario_period_frequency = self._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )

        # Generate PD metrics
        self.__pd_series = pd.core.series.Series(
            np.repeat(
                [
                    PD(
                        metric_value=pd_value,
                        metric_segment_key=self.__model_segment,
                        time_horizon=scenario_period_frequency,
                        metric_uncertainty=(pd_value / (1 - self.__uncertainty_rate)) - pd_value,
                        metric_adjustment=0,
                        metric_adjustment_justification='',
                        precision=self._precision
                    ) for pd_value in data['PD_Qtr']
                ],
                utilities.PERIOD_FREQUENCY_MAP[
                    scenario_period_frequency
                ] / utilities.PERIOD_FREQUENCY_MAP[
                    self._forecast_periods_frequency
                ]
            ),
            index=date_index
        )

        # Transform PD time scale
        self.__pd_series.apply(lambda pd_metric : pd_metric.convertPDTimeHorizon(
            self._forecast_periods_frequency,
            inplace=True
        ))


    def execute(self, session=None):
        """

        :param session: an optional CCARSession instance to write contributor and log data to, default is None
        :return:
        """
        self._logger.add(
            type='INFO',
            message='Executing model...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Starting timer
        t0 = time.time()

        # Model process
        self.calculatePD()

        if session is not None:
            for model_segment_key in self.__pd_series[0].model_segment_key:
                session.contributor_file_generator.addCFChunk(
                    as_of_date=self._as_of_date,
                    forecast_periods=self._forecast_periods,
                    forecast_periods_frequency=self._forecast_periods_frequency,
                    scenario=self._scenario,
                    model_segment=model_segment_key,
                    rate_name=[metric.name for metric in self.__pd_series],
                    rate_type=[metric.type for metric in self.__pd_series],
                    vintage_differentiation=True if self.__pd_series[0].name == "PD" else False,
                    model_output_rate=[metric.metric_value for metric in self.__pd_series],
                    uncertainty_adjustment_rate=[metric.uncertainty for metric in self.__pd_series],
                    mgmt_adjustment_rate=[metric.adjustment for metric in self.__pd_series]
                )

        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Dump log data into session instance
        if session is not None:
            if isinstance(session, CCARSession):
                for log_item in self._logger.items:
                    session.logger.addItem(log_item)
















