"""
'''
                            "PD": PD(
                                    metric_value=current_pd,
                                    metric_segment_key="Group" + str(rating + 1) +"_"+ industryname,
                                    time_horizon=scenario_period_frequency,
                                    metric_uncertainty=0,
                                    precision=self._precision
                                    ).convertPDTimeHorizon(self._forecast_periods_frequency,inplace=True).metric_value,
                            "ALLLCOVERAGE": ALLLCOVERAGE(
                                                         metric_value=alll_result,
                                                        metric_segment_key="Group" + str(rating + 1) +"_"+ industryname,
                                                        metric_uncertainty=0,
                                                        metric_adjustment=0,
                                                        precision=self._precision
                                                  ).metric_value,
                            "CONTINGENTRESERVE": CONTINGENTRESERVE(
                                                         metric_value=contingent_result,
                                                        metric_segment_key="Group" + str(rating + 1) +"_"+ industryname,
                                                        metric_uncertainty=0,
                                                        metric_adjustment=0,
                                                        precision=self._precision
                                                  ).metric_value,
'''
uat_develop=pd.melt(data_rating,['CustomerNumber', 'CustomerName', 'CostCenter', 'MCID',
       'FacilityNumber', 'FacilityType', 'F_BookBalAmt', 'F_LCAmt', 'F_Util',
       'F_bExpoAmt', 'CollateralCode', 'PF', 'NAICS', 'SRR', 'Cntry_Of_Risk',
       'Industry_Name', 'RatingGroup', 'Industry', 'NonFin_Rating',
       'Fin_Rating'],var_name=['PD'])
uat_develop.to_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\GCB\\GCB_Developer_result.xlsx')
       
'''                   
AFS0052530966005253096600525309660000000117_O
AFS0052624710005262471000526247100000000018_O
AFS0052514150005251415000525141500000000018_O
AFS0052345167005234516700523451670000000018_O

'''

###########################
Developer_dataset
###########################
data=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\GCB\\UAT\\9Q_PD_SA_v2.xlsx')
data=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\GCB\\UAT\\LossAmount.xlsx')
data_melt=pd.melt(data,id_vars=['Customer_Facility_Number'],var_name=['Period'],value_name='LossAmount')
data_melt.to_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\GCB\\UAT\\LossAmount_melt.xlsx')
###########################

###############################################################################
#####################              UAT               ##########################
Update Version: 6/30/2016
Use SQLite Datebase GCB
#% Reminder Update lgd scale and initial counts%#
###############################################################################
GCB = GCBModel(
    as_of_date=datetime.datetime(2016,6,30),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='SA',
    scenario_context='GCB_SA',
    forecast_periods=27,
    lgd_scale={'ConsumerAndIndustrial_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'ConsumerAndIndustrial_USCAN':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_USCAN': 
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'OilAndGas_Global':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0}
         },
    uat=True
)

loan=GCB.getLoanLevelResult(MASTERDATA_PATH)

  
lgd_scale=GCB.returnLgdScaling()

############
####LGD#####
############
lgd=GCB.calculateLgd(GCB.relative_initial_counts_all,lgd_scale)
lgd[['Industry','LGD_Secured','LGD_Unsecured']].drop_duplicates().to_clipboard(index=False)

########################
#### Pull RFO data #####
########################
gcb_dataset= CCMISMasterDataset(
                            asofdate=GCB.as_of_date,
                            pd_groups=['GCB'],
                            debug=True
                      ).data
 gcb_dataset.to_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\GCB\\UAT\\GCB_RFO_June.xlsx',index=False)
###############################################################################
#####################              Para Run              #######################
ccar_session = CCARSession(
    session_id='GCB',
    session_date=datetime.datetime(2016,6,30),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)
GCB = GCBModel(
    as_of_date=datetime.datetime(2016,6,30),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='ICP_Adverse',
    scenario_context='ICAAP2016',
    forecast_periods=27,
    lgd_scale={'ConsumerAndIndustrial_USCAN':
                      {'lgd_secured_scaling': 0.969960,
                       'lgd_unsecured_scaling': 0.977930},
               'Finance_USCAN':
                      {'lgd_secured_scaling': 0.94694,
                       'lgd_unsecured_scaling': 0.95973},
               'OilAndGas_Global':
                      {'lgd_secured_scaling': 0.85657,
                       'lgd_unsecured_scaling': 0.88846},
               'ConsumerAndIndustrial_RoW':
                      {'lgd_secured_scaling': 0.96232,
                       'lgd_unsecured_scaling': 0.97229},
               'Finance_RoW':
                      {'lgd_secured_scaling': 0.86936,
                       'lgd_unsecured_scaling': 0.89885}
             }
)

cart.addModel(GCB)
cart.checkout()
cf = ccar_session.contributor_file_generator.contributor_file
GCB_result=cf.getCFData()

#############
#####################              Dry Run              #######################
ccar_session = CCARSession(
    session_id='GCB',
    session_date=datetime.datetime(2016,12,31),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)

GCB = GCBModel(
    as_of_date=datetime.datetime(2017,12,31),
    dataset_query_date=datetime.datetime(2016,11,30),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='DR_BASE',
    scenario_context='DryRun2017',
    scenario_severity_level='BASE',
    forecast_periods=27,
    industrytag_file='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\DryRun2017\\GCB_MV_LOSS_COMMERCIAL_Nov_DR_01132017.xlsx',
    lgd_scale={'ConsumerAndIndustrial_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'ConsumerAndIndustrial_USCAN':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_USCAN': 
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'OilAndGas_Global':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0}
         }
)

GCB = GCBModel(
    as_of_date=datetime.datetime(2016,12,31),
    dataset_query_date=datetime.datetime(2016,11,30),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='DR_SA',
    scenario_context='DryRun2017',
    scenario_severity_level='STRESS',
    forecast_periods=27,
    industrytag_file='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\DryRun2017\\GCB_MV_LOSS_COMMERCIAL_Nov_DR_01132017.xlsx',
    lgd_scale={'ConsumerAndIndustrial_RoW': {'lgd_secured_scaling': 1.013593752198398,
                'lgd_unsecured_scaling': 1.0118112332522349},
              'ConsumerAndIndustrial_USCAN': {'lgd_secured_scaling': 1.0118538291962909,
                'lgd_unsecured_scaling': 1.0103546493140005},
              'Finance_RoW': {'lgd_secured_scaling': 0.90145054101376876,
                'lgd_unsecured_scaling': 0.92408902092041934},
              'Finance_USCAN': {'lgd_secured_scaling': 1.0082577733985443,
                'lgd_unsecured_scaling': 1.0071365247963386},
              'OilAndGas_Global': {'lgd_secured_scaling': 0.9236948119310443,
                'lgd_unsecured_scaling': 0.94211862965609594}}

)
cart.addModel(GCB)
cart.checkout()
cf = ccar_session.contributor_file_generator.contributor_file
GCB_result=cf.getCFData()


lgd_scale=GCB.returnLgdScaling()
gcb_result_melt=GCB.getLoanLevelResult(GCB.industrytag_file)

relative_initial_counts_all=pd.DataFrame({'ConsumerAndIndustrial_USCAN':[6,209,255,194,406,338,138,78,0],
                                             'Finance_USCAN':[55,274,139,68,42,45,11,7,0],
                                             'OilAndGas_Global':[10,97,93,90,66,29,29,96,0],
                                             'ConsumerAndIndustrial_RoW':[15,149,228,151,214,109,48,33,0],
                                             'Finance_RoW':[31,363,129,57,80,16,21,1,0]
                                            })
#####################              Maturity Treatment          #######################    
ccar_session = CCARSession(
    session_id='GCB',
    session_date=datetime.datetime(2017,11,30),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)
GCB_MC = GCBModel(
    as_of_date=datetime.datetime(2017,12,31),
    dataset_query_date=datetime.datetime(2017,12,31),
    scenario_date=datetime.datetime(2017,12,31),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='BHC_STRESS',
    scenario_severity_level='STRESS',
    scenario_context='DryRun2018',
    forecast_periods=27,
    utilization_switch=False,
    industrytag_file='I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx',
    maturity_switch=False
)

cart.addModel(GCB_MC)
cart.checkout()

cf_inventory= ccar_session.contributor_file_generator.generateContributorFileInstance()
cf_data=cf_inventory.getCFData()    

cf_data=cf_data[cf_data['VINTAGE']==datetime.datetime(2017,6,30)]
cf_data=cf_data[~cf_data['MODELSEGMENT'].str.contains('_O')]
#####################              MidCycle          #######################
ccar_session = CCARSession(
    session_id='GCB',
    session_date=datetime.datetime(2017,6,30),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)
GCB_MC = GCBModel(
    as_of_date=datetime.datetime(2017,9,30),
    dataset_query_date=datetime.datetime(2017,9,30),
    scenario_date=datetime.datetime(2017,9,30),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='BASE',
    scenario_severity_level='BASE',
    scenario_context='MidCycle2017',
    forecast_periods=27,
    utilization_switch=False,
    industrytag_file='I:\\CRMPO\\CCAR\\3Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Sep.xlsx',
    intermediate_dataset_path='I:\\CRMPO\\CCAR\\3Q17\\4 - Models\\Wholesale\\GCB\\'
)

cart.addModel(GCB_MC)
cart.checkout()

cf_inventory= ccar_session.contributor_file_generator.generateContributorFileInstance()
cf_data=cf_inventory.getCFData()

cont=GCB_MC.get
#####################              SP20            #######################
ccar_session = CCARSession(
    session_id='GCB',
    session_date=datetime.datetime(2017,3,31),
    user='n818126'
)

GCB_SP = GCBModel(
    as_of_date=datetime.datetime(2017,3,31),
    dataset_query_date=datetime.datetime(2017,2,28),
    scenario_date=datetime.datetime(2017,3,31),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='BASE',
    scenario_severity_level='BASE',
    scenario_context='P20',
    forecast_periods=45,
    industrytag_file='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\CCAR\\GCB_MV_LOSS_COMMERCIAL_Feb.xlsx',
)
#####################              CCAR R1              #######################
ccar_session = CCARSession(
    session_id='GCB',
    session_date=datetime.datetime(2016,12,31),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)

GCB_BHC = GCBModel(
    as_of_date=datetime.datetime(2016,12,31),
    dataset_query_date=datetime.datetime(2016,12,31),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='BHC_SA',
    scenario_date=datetime.datetime(2016,12,31),
    scenario_severity_level='STRESS',
    scenario_context='CCAR2017',
    forecast_periods=27,
    industrytag_file='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\CCAR\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx',
)

GCB_SA = GCBModel(
    as_of_date=datetime.datetime(2016,12,31),
    dataset_query_date=datetime.datetime(2016,12,31),
    scenario_date=datetime.datetime(2016,12,31),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='FRB_SA',
    scenario_severity_level='STRESS',
    scenario_context='CCAR2017',
    forecast_periods=27,
    industrytag_file='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\CCAR\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx',
)

GCB_B = GCBModel(
    as_of_date=datetime.datetime(2016,12,31),
    dataset_query_date=datetime.datetime(2016,12,31),
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario='FRB_BASE',
    scenario_severity_level='BASE',
    scenario_context='CCAR2017',
    forecast_periods=27,
    industrytag_file='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\CCAR\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx',
)

cart.addModel(GCB_SA)
cart.checkout()
cf = ccar_session.contributor_file_generator.contributor_file
GCB_result=cf.getCFData()


lgd_scale=GCB.returnLgdScaling()

lgd_scale={'ConsumerAndIndustrial_RoW': {'lgd_secured_scaling': 0.9661599594226048,
  'lgd_unsecured_scaling': 0.97515653050652717},
 'ConsumerAndIndustrial_USCAN': {'lgd_secured_scaling': 0.96368894751979195,
  'lgd_unsecured_scaling': 0.97304276437446335},
 'Finance_RoW': {'lgd_secured_scaling': 0.84803816760526152,
  'lgd_unsecured_scaling': 0.88161557311571259},
 'Finance_USCAN': {'lgd_secured_scaling': 0.94757953325506206,
  'lgd_unsecured_scaling': 0.96022906993464263},
 'OilAndGas_Global': {'lgd_secured_scaling': 0.87576415064705915,
  'lgd_unsecured_scaling': 0.90423786478220414}}

{'ConsumerAndIndustrial_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'ConsumerAndIndustrial_USCAN':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_USCAN': 
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'OilAndGas_Global':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0}
         }

gcb_result_melt=GCB.getLoanLevelResult(GCB.industrytag_file)

relative_initial_counts_all=pd.DataFrame({'ConsumerAndIndustrial_USCAN':[5,210,261,181,395,331,139,71,0],
                                             'Finance_USCAN':[53,273,138,65,40,46,4,12,0],
                                             'OilAndGas_Global':[10,97,93,88,65,28,30,83,0],
                                             'ConsumerAndIndustrial_RoW':[21,144,219,153,212,98,44,35,0],
                                             'Finance_RoW':[28,369,127,59,75,14,19,1,0]
                                            })
                                            
##################################
CCAR R1 Adjustment
##################################
db.update({
'value': [
          {
          'rating_group_1': 0.00176896805752849,
          'rating_group_2': 0.00176896805752849,
          'rating_group_3': 0.00176896805752849,
          'rating_group_4': 0.00265421198658557,
          'rating_group_5': 0.00653703336970459,
          'rating_group_6': 0.00653703336970459,
          'rating_group_7': 0.00653703336970459,
          'rating_group_8': 0.104824039178035,
          'rating_group_9': 1
          }
        ]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='alll_coverage')))

db.update({
'value': [{
    'rating_group_1': 0,
    'rating_group_2': 0.0016420031382933,
    'rating_group_3': 0.00199330525161995,
    'rating_group_4': 0.00255004492422892,
    'rating_group_5': 0.00921542130241626,
    'rating_group_6': 0.00921542130241626,
    'rating_group_7': 0.00921542130241626,
    'rating_group_8': 0.0628261806209023,
    'rating_group_9': 1
    }]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='contingent_reserve')))

#############

m_factor=GCB.mFactorSeries()

cart.addModel(GCB)
cart.checkout()

dr=GCB.calculateDR(industryname='ConsumerAndIndustrial_USCAN',
                   relative_initial_counts=[1,2,3,4,5,6,7,8,9])
                   
                   
lgd=GCB.calculateLgdIndustry(industryname='ConsumerAndIndustrial_USCAN',relative_initial_counts=[1,2,3,4,5,6,7,8,9])
lgd_all=GCB.calculateLgd(relative_initial_counts_all)

rates=GCB.calculateRates('ConsumerAndIndustrial_USCAN')
rates_CI=GCB.uatCalculateRates('ConsumerAndIndustrial_USCAN')
rates_FI=GCB.calculateRates('Finance_USCAN')
rates_OIL=GCB.calculateRates('OilAndGas_Global')

result = pd.DataFrame()
for industry in GCB.industryList():
    rates = GCB.uatCalculateRates(industry)
    rates['Industry']=industry
    result=result.append(rates)

result_mer.to_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\GCB\\result_python.xlsx')
##########################################
# Specify initial counts for all industry#
##############################################################################################################################
relative_initial_counts_all=pd.DataFrame({'ConsumerAndIndustrial_USCAN':[6,210,250,193,390,326,131,72,0],
                                         'Finance_USCAN':[52,244,135,68,42,43,10,7,0],
                                         'OilAndGas_Global':[5,84,87,68,82,34,32,45,0],
                                         'ConsumerAndIndustrial_RoW':[16,149,226,151,208,110,50,26,0],
                                         'Finance_RoW':[31,363,124,55,82,17,20,1,0]
                                        })
self.calculateLgd(relative_initial_counts_all)                                                                             
##############################################################################################################################

##########################################
# Coefficient industry#
 Industry Name:
         'ConsumerAndIndustrial_USCAN'
         'Finance_USCAN'
         'OilAndGas_Global'
         'ConsumerAndIndustrial_RoW'
         'Finance_RoW'

##############################################################################################################################
mev_data=GCB.transformed_macro_series
linear_regression_dict=GCB._model_properties.getParameters(
                    type='operation',
                    name="regression_coefficients",
                    industry='ConsumerAndIndustrial_RoW')

##########################################    
#Matrix:
##########################################
ci=GCB.getTransitionMatrixSeries('ConsumerAndIndustrial_USCAN')   
ci1=GCB.printTransitionMatrixSeries('Finance_USCAN')  
all_tm=GCB.printTransitionMatrixSeriesAll() 
##############################################################################################################################                                        
                                        
cf = ccar_session.contributor_file_generator.contributor_file
cf_data=cf.getCFData()

cf.getCFData()[pd.isnull(cf.getCFData().Vintage)].ModelOutputRate.plot()
---------------------------------------------------------------------------------------------

result_object_master=GCB.getResult('I:\\CRMPO\\DEPT\\Tracy\\GCB\\py\\data\\GCB_Master.xlsx')

result_object_master=GCB.getResult('I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI\\docs\\GCB - CCAR 2017\\PRODUCTION_INPUT.xlsx')


result_object_oil=GCB.calculateRates('oil')
result_object_gas=GCB.calculateRates('gas')

rates_all=GCB.getBalanceWalkPD(relative_initial_balance= {'oil':[   0,
                                                                    960723897.86,
                                                                    1370838637.2,
                                                                    3178570684.74,
                                                                    442825467.6,
                                                                    0,
                                                                    22586206.9,
                                                                    0,
                                                                    0],
                                                                           
                                                          'gas':[   0, 
                                                                    960723897.86,
                                                                    1370838637.2,
                                                                    3178570684.74,
                                                                    442825467.6,
                                                                    0,
                                                                    22586206.9,
                                                                    0,
                                                                    0]})

GCB.execute()



matrix=GCB.getTransitionMatrix('oil')
rates=GCB.calculateRates('oil')



tmat = TransitionMatrix(
    [
        [0.9674116, np.NaN, 0.0009131, 0, 0, 0, 0.0001875, 0, 0],
        [0.0020598, 0.9834943, 0.0130996, 0.0009721, 0.0001044, 0.0000559, 0, 0.0001067, 0.0001074],
        [0.0002927, 0.0099443, 0.9754448, 0.0126949, 0.0010207, 0.0002671, 0.0000604, 0.0001617, 0.0001135],
        [0.0002563, 0.0009906, 0.02181, 0.9605335, 0.0142455, 0.0007515, 0.0006082, 0.0004514, 0.000353],
        [0.0000574, 0.0002355, 0.0009304, 0.0135884, 0.960534, 0.0169535, 0.0058268, 0.0015075, 0.0003664],
        [0, 0.0003659, 0, 0.0004667, 0.0344484, 0.9113922, 0.0399766, 0.011554, 0.001796],
        [0, 0.0000629, 0.0001369, 0.0002373, 0.0050865, 0.0240042, 0.9214539, 0.0469601, 0.0020583],
        [0, 0.0000828, 0.0001148, 0.0002304, 0.0010908, 0.0039304, 0.0245545, 0.9388549, 0.0311414],
        [0, 0, 0, 0, 0, 0, 0, 0, 1]
    ]
)

##########################################
            # Model Property #
##########################################

to_insert = [{'industry': 'all',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'model_name',
  'type': 'property',
  'value': 'GCB Trasition Matrix Model',
  'version_date': '6/30/2016'},
 {'industry': 'all',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'allowed_rating_levels',
  'type': 'property',
  'value': [8, 9],
  'version_date': '6/30/2016'},  
 {'industry': 'ConsumerAndIndustrial_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'regression_coefficients',
  'type': 'operation',
  'value': {'coefficients_pairs': {'FCBC_US_p1y_l1q': 2.3849,
    'FSPVOL_US_log': -0.8393},
   'intercept': -0.058642,
   'regression_variable': 'm_factor'},
  'version_date': '6/30/2016'},  
 {'industry': 'Finance_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'regression_coefficients',
  'type': 'operation',
  'value': {'coefficients_pairs': {'FSPVOL_US_log_l1q': -1.3103,
    'FLBR_US_d1q_l1q': -1.0843},
   'intercept': -0.10133,
   'regression_variable': 'm_factor'},
  'version_date': '6/30/2016'},   
 {'industry': 'OilAndGas_Global',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'regression_coefficients',
  'type': 'operation',
  'value': {'coefficients_pairs': {'FSPVOL_US_log': -0.84111,
    'FCPWTI_US_log1y': 1.414,
    'FCPWTI_US_log1y_l4q': 1.162},
   'intercept': -0.095329,
   'regression_variable': 'm_factor'},
  'version_date': '6/30/2016'},   
 {'industry': 'ConsumerAndIndustrial_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'regression_coefficients',
  'type': 'operation',
  'value': {'coefficients_pairs': {'FTWDBRDxxx_US_log1y_l1q': -5.4827,
    'FSPVOL_US_log1y': -0.82128,
    'FIRBAACI7SPRQ_US_log1y': -0.4224},
   'intercept': -0.1172,
   'regression_variable': 'm_factor'},
  'version_date': '6/30/2016'},   
 {'industry': 'Finance_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'regression_coefficients',
  'type': 'operation',
  'value': {'coefficients_pairs': {'FTWDBRD_US_p1y': -6.6499,
    'FSPVOL_US_log_l1q': -1.0416},
   'intercept': -0.11952,
   'regression_variable': 'm_factor'},
  'version_date': '6/30/2016'},  
 {'industry': 'all',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'alll_coverage',
  'type': 'property',
  'value': [{'rating_group_1': 0.0003,
    'rating_group_2': 0.0013895866553,
    'rating_group_3': 0.0013895866553,
    'rating_group_4': 0.0019588879787,
    'rating_group_5': 0.0029405954188,
    'rating_group_6': 0.0029405954188,
    'rating_group_7': 0.0029405954188,
    'rating_group_8': 0.1363240514031,
    'rating_group_9': 1}],
  'version_date': '6/30/2016'},
 {'industry': 'all',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'contingent_reserve',
  'type': 'property',
  'value': [{'rating_group_1': 0.0003000000000,
    'rating_group_2': 0.0012384018368,
    'rating_group_3': 0.0012384018368,
    'rating_group_4': 0.0026503263283,
    'rating_group_5': 0.0115388363970,
    'rating_group_6': 0.0115388363970,
    'rating_group_7': 0.0115388363970,
    'rating_group_8': 0.0638669687933,
    'rating_group_9': 1}],
  'version_date': '6/30/2016'},
 {'industry': 'ConsumerAndIndustrial_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'asset_correlation',
  'type': 'property',
  'value': 0.0445,
  'version_date': '6/30/2016'},
 {'industry': 'Finance_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'asset_correlation',
  'type': 'property',
  'value': 0.0705,
  'version_date': '6/30/2016'},
 {'industry': 'OilAndGas_Global',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'asset_correlation',
  'type': 'property',
  'value': 0.123,
  'version_date': '6/30/2016'},
   {'industry': 'ConsumerAndIndustrial_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'asset_correlation',
  'type': 'property',
  'value': 0.075,
  'version_date': '6/30/2016'},
   {'industry': 'Finance_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'asset_correlation',
  'type': 'property',
  'value': 0.1355,
  'version_date': '6/30/2016'},
 {'industry': 'ConsumerAndIndustrial_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'historical_transition_matrix',
  'type': 'property',
  'value': [
      [0.9606276470,0.0370219580,0.0023052270,0.0000313000,0.0000092900,0.0000002440,0.0000001330,0.0000024100,0.0000017900],
      [0.0004350000,0.9812524360,0.0169175020,0.0007710490,0.0004170000,0.0000053700,0.0000030700,0.0001190000,0.0000797000],
      [0.0000032600,0.0086658200,0.9721650630,0.0171580930,0.0015333730,0.0000199000,0.0000076800,0.0000882000,0.0003590000],
      [0.0001490000,0.0011118450,0.0204152360,0.9552383620,0.0217304630,0.0005681470,0.0003980000,0.0002540000,0.0001340000],
      [0.0000007510,0.0002910000,0.0005564110,0.0088334060,0.9611303940,0.0214489190,0.0040483050,0.0025270330,0.0011635330],
      [0.0000000494,0.0001950000,0.0002180000,0.0001317230,0.0263256800,0.9057328850,0.0389587450,0.0199830640,0.0084553960],
      [0.0000000998,0.0003490000,0.0001390000,0.0003000000,0.0093380410,0.0298843450,0.8685244570,0.0708931080,0.0205708100],
      [0.0000001250,0.0004700000,0.0006410000,0.0002380000,0.0023600000,0.0096226780,0.0304856200,0.8235152880,0.1326687060]
    ],
  'version_date': '6/30/2016'},
 {'industry': 'Finance_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'historical_transition_matrix',
  'type': 'property',
  'value': [
      [0.9797734190,0.0195094010,0.0003817740,0.0000112000,0.0002020000,0.0001130000,0.0000020400,0.0000031100,0.0000037100],
      [0.0031600000,0.9870000000,0.0088000000,0.0007130000,0.0003160000,0.0001190000,0.0000032400,0.0000465000,0.0002600000],
      [0.0002980000,0.0118000000,0.9700000000,0.0156000000,0.0018900000,0.0001100000,0.0000182000,0.0003630000,0.0004400000],
      [0.0004280000,0.0011000000,0.0239000000,0.9540000000,0.0172000000,0.0019500000,0.0009060000,0.0002100000,0.0006450000],
      [0.0004420000,0.0005670000,0.0019100000,0.0181000000,0.9440000000,0.0183000000,0.0065600000,0.0066900000,0.0034600000],
      [0.0000160000,0.0036600000,0.0001160000,0.0017935560,0.0416318530,0.8859961490,0.0221017660,0.0315087290,0.0131724890],
      [0.0000020000,0.0001020000,0.0034200000,0.0001160000,0.0062900000,0.0395000000,0.8900000000,0.0443000000,0.0161000000],
      [0.0000017400,0.0000355000,0.0000460000,0.0000830000,0.0073800000,0.0166000000,0.0205000000,0.8780000000,0.0774000000]
    ],
  'version_date': '6/30/2016'},
 {'industry': 'OilAndGas_Global',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'historical_transition_matrix',
  'type': 'property',
  'value': [
      [0.98534696700,0.01452646900,0.00011500000,0.00000986000,0.00000060300,0.00000004480,0.00000129000,0.00000010900,0.00000000529],
      [0.00339746700,0.97955892700,0.01545265300,0.00136829900,0.00004080000,0.00000306000,0.00017100000,0.00000732000,0.00000041600],
      [0.00029200000,0.01132305600,0.96835150000,0.01625866200,0.00349063200,0.00012600000,0.00001320000,0.00014000000,0.00000567000],
      [0.00000918000,0.00220775200,0.02574029700,0.95169949600,0.01906841200,0.00042761700,0.00006220000,0.00065100000,0.00013400000],
      [0.00018300000,0.00004190000,0.00295086600,0.01332359500,0.95500100600,0.01583636800,0.00519157800,0.00632904000,0.00114244200],
      [0.00000424000,0.00071300000,0.00012600000,0.00148382800,0.03126085600,0.91117963300,0.03027891700,0.02158431800,0.00336876700],
      [0.00000379000,0.00128000000,0.00344000000,0.00164000000,0.01118275000,0.02024075800,0.89584625500,0.06259555000,0.00376859100],
      [0.00000011700,0.00002000000,0.00008140000,0.00320000000,0.00057800000,0.00671136800,0.02015740400,0.92944622800,0.03980228800]
    ],
  'version_date': '6/30/2016'},
 {'industry': 'ConsumerAndIndustrial_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'historical_transition_matrix',
  'type': 'property',
  'value': [
      [0.9775277300,0.0211323470,0.0006568000,0.0006700000,0.0000114000,0.0000003700,0.0000008780,0.0000004270,0.0000002060],
      [0.0009590000,0.9800521390,0.0175837790,0.0011000000,0.0002950000,0.0000044200,0.0000044500,0.0000013400,0.0000012300],
      [0.0000048100,0.0098199640,0.9708481960,0.0172083060,0.0015506140,0.0001650000,0.0002850000,0.0000285000,0.0000892000],
      [0.0000006760,0.0014000000,0.0151618660,0.9551173630,0.0232769890,0.0009630850,0.0022800000,0.0012400000,0.0005570000],
      [0.0000000965,0.0002010000,0.0006064190,0.0132942990,0.9565801740,0.0179466060,0.0056145560,0.0042089600,0.0015482560],
      [0.0000000202,0.0000205000,0.0006750000,0.0011905730,0.0359522180,0.8853400350,0.0429565290,0.0287830200,0.0050816330],
      [0.0000000403,0.0000404000,0.0000185000,0.0001210000,0.0144977330,0.0377683440,0.8445465750,0.0846929130,0.0183147500],
      [0.0000004020,0.0008020000,0.0000091700,0.0000115000,0.0014200000,0.0041708690,0.0456692830,0.8542004780,0.0937116250]
    ],
  'version_date': '6/30/2016'},
 {'industry': 'Finance_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'historical_transition_matrix',
  'type': 'property',
  'value': [
      [0.9739811940,0.0256388180,0.0002212080,0.0000153000,0.0001410000,0.0000010200,0.0000000597,0.0000003190,0.0000009470],
      [0.0034800000,0.9870000000,0.0087800000,0.0009990000,0.0001350000,0.0000059000,0.0000006220,0.0000003030,0.0000592000],
      [0.0000458000,0.0233000000,0.9560000000,0.0190000000,0.0006010000,0.0010000000,0.0000345000,0.0000024600,0.0000142000],
      [0.0004420000,0.0004200000,0.0340000000,0.9330000000,0.0294000000,0.0011300000,0.0010300000,0.0000873000,0.0000578000],
      [0.0000049200,0.0000093000,0.0008900000,0.0210000000,0.9580000000,0.0124000000,0.0004650000,0.0043000000,0.0025700000],
      [0.0000003410,0.0000005170,0.0000253000,0.0007249660,0.0609385550,0.8690270970,0.0431738250,0.0025791410,0.0235302420],
      [0.0000004460,0.0000005080,0.0000344000,0.0018600000,0.0026800000,0.0577000000,0.8880000000,0.0343000000,0.0159000000],
      [0.0000000313,0.0000000328,0.0000024100,0.0000658000,0.0000727000,0.0020800000,0.0636000000,0.8800000000,0.0541000000]
    ],
  'version_date': '6/30/2016'}, 
 {'industry': 'all',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'macro_variables',
  'type': 'operation',
  'value': [
   {'lag': 1,
    'macro_variable_name': 'FCBC_US',
    'macro_variables_group': 'FCBC_US_p1y_l1q',
    'transformation_type': 'p1y'},
   {'lag': 0,
    'macro_variable_name': 'FSPVOL_US',
    'macro_variables_group': 'FSPVOL_US_log',
    'transformation_type': 'log'},      
   {'lag': 1,
    'macro_variable_name': 'FSPVOL_US',
    'macro_variables_group': 'FSPVOL_US_log_l1q',
    'transformation_type': 'log'},        
   {'lag': 1,
    'macro_variable_name': 'FLBR_US',
    'macro_variables_group': 'FLBR_US_d1q_l1q',
    'transformation_type': 'd1q'},   
   {'lag': 0,
    'macro_variable_name': 'FCPWTI_US',
    'macro_variables_group': 'FCPWTI_US_log1y',
    'transformation_type': 'log1y'},    
   {'lag': 4,
    'macro_variable_name': 'FCPWTI_US',
    'macro_variables_group': 'FCPWTI_US_log1y_l4q',
    'transformation_type': 'log1y'},    
   {'lag': 1,
    'macro_variable_name': 'FTWDBRDxxx_US',
    'macro_variables_group': 'FTWDBRDxxx_US_log1y_l1q',
    'transformation_type': 'log1y'},     
   {'lag': 0,
    'macro_variable_name': 'FSPVOL_US',
    'macro_variables_group': 'FSPVOL_US_log1y',
    'transformation_type': 'log1y'},     
   {'lag': 0,
    'macro_variable_name': 'FIRBAACI7SPRQ_US',
    'macro_variables_group': 'FIRBAACI7SPRQ_US_log1y',
    'transformation_type': 'log1y'},   
   {'lag': 0,
    'macro_variable_name': 'FTWDBRD_US',
    'macro_variables_group': 'FTWDBRD_US_p1y',
    'transformation_type': 'p1y'},    
    ],
  'version_date': '6/30/2016'},   
 {'industry': 'all',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'macro_variable_combinations',
  'type': 'operation',
  'value': [
   {'combination': 'FCBC_US_p1y_l1q',
    'operand_1': 'FCBC_US_p1y_l1q',
    'operand_2': None,
    'operator': None},
   {'combination': 'FSPVOL_US_log',
    'operand_1': 'FSPVOL_US_log',
    'operand_2': None,
    'operator': None},    
   {'combination': 'FSPVOL_US_log_l1q',
    'operand_1': 'FSPVOL_US_log_l1q',
    'operand_2': None,
    'operator': None},    
   {'combination': 'FLBR_US_d1q_l1q',
    'operand_1': 'FLBR_US_d1q_l1q',
    'operand_2': None,
    'operator': None},    
   {'combination': 'FCPWTI_US_log1y',
    'operand_1': 'FCPWTI_US_log1y',
    'operand_2': None,
    'operator': None},    
   {'combination': 'FCPWTI_US_log1y_l4q',
    'operand_1': 'FCPWTI_US_log1y_l4q',
    'operand_2': None,
    'operator': None},    
   {'combination': 'FTWDBRDxxx_US_log1y_l1q',
    'operand_1': 'FTWDBRDxxx_US_log1y_l1q',
    'operand_2': None,
    'operator': None},    
   {'combination': 'FSPVOL_US_log1y',
    'operand_1': 'FSPVOL_US_log1y',
    'operand_2': None,
    'operator': None},  
   {'combination': 'FIRBAACI7SPRQ_US_log1y',
    'operand_1': 'FIRBAACI7SPRQ_US_log1y',
    'operand_2': None,
    'operator': None},    
   {'combination': 'FTWDBRD_US_p1y',
    'operand_1': 'FTWDBRD_US_p1y',
    'operand_2': None,
    'operator': None}],
  'version_date': '6/30/2016'},   
 {'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'scenario_period_frequency',
  'type': 'property',
  'value': 'quarterly',
  'version_date': '6/30/2016'},
 {'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'scenario_geo_scope',
  'type': 'property',
  'value': 'National&Regional',
  'version_date': '6/30/2016'},
 {'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'industry_list',
  'type': 'property',
  'value': [
    'ConsumerAndIndustrial_USCAN',
    'Finance_USCAN',
    'OilAndGas_Global',
    'ConsumerAndIndustrial_RoW',
    'Finance_RoW'
    ],
  'version_date': '6/30/2016'}]

to_insert=[ 
{'industry': 'ConsumerAndIndustrial_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'lgd_rho',
  'type': 'property',
  'value': 0.088,
  'version_date': '6/30/2016'},
 {'industry': 'Finance_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'lgd_rho',
  'type': 'property',
  'value': 0.08,
  'version_date': '6/30/2016'},
 {'industry': 'OilAndGas_Global',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'lgd_rho',
  'type': 'property',
  'value': 0.126,
  'version_date': '6/30/2016'},
   {'industry': 'ConsumerAndIndustrial_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'lgd_rho',
  'type': 'property',
  'value': 0.119,
  'version_date': '6/30/2016'},
   {'industry': 'Finance_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'lgd_rho',
  'type': 'property',
  'value': 0.103,
  'version_date': '6/30/2016'}, 
  {'industry': 'ConsumerAndIndustrial_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'average_pd',
  'type': 'property',
  'value': 0.0273,
  'version_date': '6/30/2016'},
 {'industry': 'Finance_USCAN',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'average_pd',
  'type': 'property',
  'value': 0.0064,
  'version_date': '6/30/2016'},
 {'industry': 'OilAndGas_Global',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'average_pd',
  'type': 'property',
  'value': 0.0156,
  'version_date': '6/30/2016'},
   {'industry': 'ConsumerAndIndustrial_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'average_pd',
  'type': 'property',
  'value': 0.0144,
  'version_date': '6/30/2016'},
   {'industry': 'Finance_RoW',
  'model_id': '35 - Scenario Analysis Model - GBM PD - SBNA',
  'name': 'average_pd',
  'type': 'property',
  'value': 0.0057,
  'version_date': '6/30/2016'}]
                                                                             
lgd_scale={'ConsumerAndIndustrial_RoW':
                  {'lgd_secured_scaling': 1.1131725795643845,
                   'lgd_unsecured_scaling': 1.0874494694973302},
           'ConsumerAndIndustrial_USCAN':
                  {'lgd_secured_scaling': 1.1603006375317353,
                   'lgd_unsecured_scaling': 1.1224966884145511},
           'Finance_RoW':
                  {'lgd_secured_scaling': 1.0348004830000792,
                   'lgd_unsecured_scaling': 1.0271792741715311},
           'Finance_USCAN': 
                  {'lgd_secured_scaling': 1.1714305635731666,
                   'lgd_unsecured_scaling': 1.1292761932544051},
           'OilAndGas_Global':
                  {'lgd_secured_scaling': 1.0438397616495396,
                   'lgd_unsecured_scaling': 1.0345633437725013}
         }  
### UAT SA ####         
lgd_scale={'ConsumerAndIndustrial_USCAN':
                  {'lgd_secured_scaling': 0.969960,
                   'lgd_unsecured_scaling': 0.977930},
           'Finance_USCAN':
                  {'lgd_secured_scaling': 0.94694,
                   'lgd_unsecured_scaling': 0.95973},
           'OilAndGas_Global':
                  {'lgd_secured_scaling': 0.85657,
                   'lgd_unsecured_scaling': 0.88846},
           'ConsumerAndIndustrial_RoW':
                  {'lgd_secured_scaling': 0.96232,
                   'lgd_unsecured_scaling': 0.97229},
           'Finance_RoW':
                  {'lgd_secured_scaling': 0.86936,
                   'lgd_unsecured_scaling': 0.89885}
         }



                                         
lgd_scale={'ConsumerAndIndustrial_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'ConsumerAndIndustrial_USCAN':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_USCAN': 
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'OilAndGas_Global':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0}
         }                                  
##############################################################################################################################



"""

#MASTERDATA_PATH='I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\GCB\\UAT\\PRODUCTION_INPUT.xlsx'
#MASTERDATA_PATH='I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI\\docs\\GCB - CCAR 2017\\PRODUCTION_INPUT_RFO_para.xlsx'

# Define finance segment for SRR Mapping
FINANCE_INDUSTRY=['Finance_USCAN','Finance_RoW']

# EXCEL TAB NAMES
MASTER_DATA='GCB_List'
INDUSTRY='industry'
RatingGroup='RatingGroup'

#Used in raw data comes from RFO
BOOKBALANCEAMOUNT='BOOKBALANCE'
EXPOSURE='EXPOSURE'
UNIQUE_FACILITY_ID='UNIQUE_FACILITY_ID'
EXISTING_NEW='IS_ORIG'
NEW='Y'
PD_GROUP='PD_GROUP'
SRR='SRR'
GCB='GCB'
GCB_SRR='GCB_SRR'
UNSECURED_INDICATOR='UNSECURED_INDICATOR'
FACILITYTYPE='FACILITYTYPE'
MAXIMUMMATURITYDATE='MAXIMUMMATURITYDATE'
UTILIZATIONOPENDATE='OPENDATE'
FINAL_MATURITY= 'FINAL_MATURITY'

import os
import sys
#wd = 'C:\\Users\\n838126\\git\\dryrun\\CIFI'
#wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)    
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.metrics import PD,LGD,EAD,ALLLCOVERAGE,CONTINGENTRESERVE
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.riskratingmodel import Mapping
from dateutil.relativedelta import relativedelta
from tinydb import TinyDB, Query
import datetime
import dateutil.relativedelta as dateutilrelativedelta
import pandas as pd
import numpy as np
import scipy.stats as st
import time
import copy


class MFactor:
    """ This class gives a M factor Object
    
    :param m_factor: The calculated m factor value given time and scenario
    :type m_factor: int or float
    :returns: m_factor object
    
    """    
    __m_factor = None

    def __init__(self, m_factor):
        if isinstance(m_factor, (int, float)):
            self.__m_factor = m_factor
        else:
            raise TypeError("Input `m_factor` is not of numeric type.")

    @property
    def m_factor(self):
        return (self.__m_factor)

class MFactorSeries:
    """ This class calculates M factor series
    
    The methods here are: func <getMFactor>,func <calculateMFactor>
    
    :param mev_data:(quarterly) time series of transformed macro variables as inputs for M factor regression  
    :param linear_regression_dict:linear regession dictionary providing: 
                                          intercept value,
                                          coefficient name and value pairs
                                          regression variable name = 'm_factor'
                                          
    :type mev_data:pandas.core.frame.DataFrame;index:(quarterly) forecasted datetime 
    :type linear_regression_dict:dictionary of float(intercept),
                                               dictionary(coefficients_pairs),
                                               str(regression_variable)        
    """
    __m_factor_series = None
    __mev_data = None
    __linear_regression_dict = None
    __precision = None

    def __init__(self, mev_data, linear_regression_dict):
        # transformed macro variables
        self.__mev_data = mev_data
        # linear_regression_dict
        self.__linear_regression_dict = linear_regression_dict
        # Calculate m-factor
        self.__calculateMFactor()
        
    @property
    def m_factor_series(self):
        return (self.__m_factor_series)

    @property
    def linear_regression_dict(self):
        return (self.__linear_regression_dict)

    @property
    def mev_data(self):
        return (self.__mev_data)

    def getMFactor(self, effective_date):
        """
        This method validates date type and value (within range and quarter end),
        then returns m factor at specific effective date
        
        :param effective_date: one of the quarterly forecast time series
        :type effective_date: datetime.datetime
        :returns: m factor object at an effective date
        
        """        
        # Validate date type and value (within range and quarter end) and returns m factor at the effective date
        if isinstance(effective_date, datetime.datetime):
            if effective_date in self.__m_factor_series.index:
                return (MFactor(self.__m_factor_series.ix[effective_date]))
            else:
                raise ValueError()
        else:
            raise TypeError()

    def __calculateMFactor(self):
        """
        This method uses regression dictionary and macro variables as inputs,
        then applies regression formulas to calculate M factor series
         
        :returns: quarterly forecasted m factor series
        
        """
        mev_data = copy.deepcopy(self.__mev_data)

        intercept = self.__linear_regression_dict['intercept']
        coeff_pairs = self.__linear_regression_dict['coefficients_pairs']
        mev_data['MFactor'] = sum([mev_data[item] * coeff_pairs[item] for item in coeff_pairs.keys()]) + intercept

        self.__m_factor_series = mev_data['MFactor']

class TransitionMatrix:
    """ This class provides transition matrix related calculation
    
    The methods here are: func <getCumulativeProbabilityTransitionMatrix>:calculates the Cumulative Probability Migration Matrix (CPMM)
                          func <revertCumulativeProbabilityTransitionMatrix>:revert CPMM,                               
                          func <getStressedTransitionMatrix>:Stressed Transition Matrix
    
    :param array_2d:historical transition matrix for one industry
    :param precision:precision level for calculation
    :type array_2d:list of list (matrix)
    :type precision:int
      
   """
    __matrix = None
    __precision = None

    def __init__(self, array_2d, precision=2):
        
        # Validate precision type
        if isinstance(precision, int):
            self.__precision = precision
        else:
            raise TypeError("Input `precision` is not an int.")
            
        # Validate input matrix(array_2d)
        if (np.array([isinstance(item, list) for item in array_2d]).all()) & isinstance(array_2d, list):
            tmp_matrix = np.matrix(array_2d)
            if np.isreal(tmp_matrix).all():
                if pd.notnull(tmp_matrix).all():
                    if tmp_matrix.shape[0] == tmp_matrix.shape[1]:
                        if round(tmp_matrix.sum(), self.__precision) == tmp_matrix.shape[0]:
                            if (np.array(tmp_matrix.max(1)).transpose()==tmp_matrix.diagonal()).all():
                                self.__matrix = tmp_matrix
                            else:
                                raise Exception("Input matrix is not an acceptable transition matrix (non-stable "
                                                "diagonal).")
                        else:
                            raise Exception("Input matrix is not an acceptable transition matrix (rows don't add to "
                                            "1).")
                    else:
                        raise Exception("Input matrix is not square.")
                else:
                    raise ValueError("Input matrix contains NAs.")
            else:
                raise ValueError("Input matrix contains non-numeric types.")
        else:
            raise TypeError("Input `array_2d` is not a list of lists.")

    @property
    def matrix(self):
        return (self.__matrix)

    @property
    def rating_levels(self):
        return (self.__matrix.shape[0])

    def getCumulativeProbabilityTransitionMatrix(self, m):
        """
        This method returns the Cumulative Probability Migration Matrix (CPMM)
        of a given migration matrix

        :param m: raw initial matrix (np.matrix)
        :returns: cumulative migration matrix given m
        """
        if not isinstance(m, np.matrix):
            raise TypeError("Input `m` is not of type Numpy.matrix.")

        result_m = np.matrix(np.empty([m.shape[0], m.shape[1]], dtype=float))
        for i in range(m.shape[0]):
            for j in range(m.shape[1]):
                result_m[i, j] = m[i, j:m.shape[1]].sum()
        return result_m

    def revertCumulativeProbabilityTransitionMatrix(self, m):
        """
        This method returns the non-cumulative version of a given migration matrix

        :param m: raw initial matrix (np.matrix)
        :returns: reverted matrix object (matrix)
        """
        if not isinstance(m, np.matrix):
            raise TypeError("Input `m` is not of type Numpy.matrix.")

        result_m = np.matrix(np.empty([m.shape[0], m.shape[1]], dtype=float))
        for i in range(m.shape[0]):
            for j in range(m.shape[1] - 1):
                result_m[i, j] = m[i, j] - m[i, j + 1]
        result_m[:, m.shape[1] - 1] = m[:, m.shape[1] - 1]
        return result_m

    def getOldStressedTransitionMatrix(self, m_factor, asset_corr, debug=False):
        """
        This method returns the non-cumulative stressed migration matrix (MM) for given
        industry and date
        
        :param m_factor: m_factor 
        :param asset_corr
        :param debug: default value is 'False'
        :returns:  non-cumulative stressed matrix (matrix) 
        """
        if not isinstance(asset_corr, (float, int)):
            raise TypeError("Input `asset_corr` is not of numeric type.")
        if not isinstance(m_factor, MFactor):
            raise TypeError("Input `m_factor` is not of MFactor type.")

        cpmm = self.getCumulativeProbabilityTransitionMatrix(m=self.__matrix)
        q_norm = lambda val, ac, m: st.norm.ppf(val) - np.sqrt(ac) * m
        p_norm = lambda val, ac: st.norm.cdf(val / np.sqrt(1 - ac))

        result_m = np.matrix(
            np.empty(
                [self.__matrix.shape[0], self.__matrix.shape[1]],
                dtype=float
            )
        )

        for i in range(cpmm.shape[0]):
            for j in range(cpmm.shape[1]):
                if cpmm[i, j] == 0:
                    if debug:
                        print(str("empty-0") + ' -> [' + str(i) + ', ' + str(j) + ']')
                    result_m[i, j] = 0
                else:
                    tmp_value = p_norm(
                        q_norm(
                            cpmm[i, j],
                            asset_corr,
                            m_factor.m_factor
                        ),
                        asset_corr
                    )
                    if np.isnan(tmp_value):
                        tmp_value = 1
                    if debug:
                        print(str(tmp_value) + ' -> [' + str(i) + ', ' + str(j) + ']')
                    result_m[i, j] = tmp_value

        return (self.revertCumulativeProbabilityTransitionMatrix(result_m))

    def getStressedTransitionMatrix(self, m_factor, asset_corr, debug=False):
        """
        This method returns the non-cumulative stressed migration matrix (MM) for given
        industry and date
        
        :param m_factor: m_factor 
        :param asset_corr
        :param debug: default value is 'False'
        :returns:  non-cumulative stressed matrix (matrix) 
        """
        INF=20     
        if not isinstance(asset_corr, (float, int)):
            raise TypeError("Input `asset_corr` is not of numeric type.")
        if not isinstance(m_factor, MFactor):
            raise TypeError("Input `m_factor` is not of MFactor type.")


        cpmm = self.getCumulativeProbabilityTransitionMatrix(m=self.__matrix)        
        tm = st.norm.ppf(cpmm)
        # replace nan and inf
        tm[np.isnan(tm)]=INF
        tm[(tm==np.inf)]=INF
        '''        
        tm[(tm==np.inf)]=INF
        # reset first column to default Infinite number
        tm[:,0]=INF
                
        upper_tm = tm
        lower_tm = tm[:,[1,2,3,4,5,6,7,8,0]]
        
        # Formula
        transition = lambda tm, ac, m: st.norm.cdf((tm-np.sqrt(ac)*m)/np.sqrt(1-ac))        
        result_m = np.matrix(
            np.empty(
                [self.__matrix.shape[0], self.__matrix.shape[1]],
                dtype=float
            )
        )

        for i in range(cpmm.shape[0]):
            for j in range(cpmm.shape[1]):
                if cpmm[i, j] == 0:
                    if debug:
                        print(str("empty-0") + ' -> [' + str(i) + ', ' + str(j) + ']')
                    result_m[i, j] = 0
                else:
                    tmp_value = transition(upper_tm[i, j],asset_corr,m_factor.m_factor)-transition(lower_tm[i, j],asset_corr,m_factor.m_factor)      

                    if np.isnan(tmp_value):
                        tmp_value = np.nan
                    if debug:
                        print(str(tmp_value) + ' -> [' + str(i) + ', ' + str(j) + ']')
                    result_m[i, j] = tmp_value

        return (result_m)
        '''
        tm[(tm==-np.inf)]=INF
        # reset first column to default Infinite number
        tm[:,0]=INF
                
        upper_tm = tm
        #tm[:,[1,2,3,4,5,6,7,8,-0]]
        lower_tm = np.column_stack((tm[:,[1,2,3,4,5,6,7,8]],-tm[:,0]))
        
        # Formula
        transition = lambda tm, ac, m: st.norm.cdf((tm-np.sqrt(ac)*m)/np.sqrt(1-ac))        
        tmp_value = transition(upper_tm,asset_corr,m_factor.m_factor)-transition(lower_tm,asset_corr,m_factor.m_factor)      
        return (tmp_value)


class GCBModel(CCARModel):
    """ This class calculates rates including: PD,LGD,EAD,ALLLCOVERAGE,CONTINGENTRESERVE for GCB model 
    
    The main methods here are: 
                              func <historicalTransitionMatrixIndustry>:get historical Transition Matrix for specific industry 
                              func <getTransitionMatrixSeries>: cache stressed transition matrices during forecasting periods for given industry 
                              func <calculateRates>:generate rates for specific industry
                              func <getResult>:merge model results with masterdataset
    
    :param as_of_date:starting date for model run
    :param model_id:model identification
    :param scenario:name of scenario
    :param scenario_context:execution environment for scenario (e.g'CCAR2016')
    :param forecast_periods:number of forward months to run the model 
                            (e.g 27 if scenario_context = 'CCAR2016')
    :param forecast_periods_frequency
    :param precision:precision level for calculation
    
    :type as_of_date:datetime.datetime
    :type model_id:str
    :type scenario:str
    :type scenario_context:str
    :type forecast_periods:int
    :type forecast_periods_frequency: str
    :type precision:int    
    
   """      
    
    # Properties
    __coverage_rates_file_path = None

    # Methods
    def __init__(
            self,
            as_of_date,
            dataset_query_date,
            model_id,
            scenario,
            scenario_context,
            scenario_date,
            scenario_severity_level,
            forecast_periods,
            industrytag_file,
            auto_fetch_macros=True,
            forecast_periods_frequency='monthly',
            precision=None,
            uat=None,
            **kwargs
    ):

        # Initialize parent class properties
        CCARModel.__init__(
            self,
            as_of_date=as_of_date,
            model_id=model_id,
            scenario=scenario,
            scenario_date=scenario_date,
            scenario_context=scenario_context,
            forecast_periods=forecast_periods,
            forecast_periods_frequency=forecast_periods_frequency,
            precision=precision,
            scenario_combinations=kwargs.get("scenario_combinations")
        )
        # Autofetching macro variables
        if auto_fetch_macros:
#            self.fetchMacroSeries()
            self.fetchMacroSeries(scenario_combinations=kwargs.get('scenario_combinations'))
        
        self._logger.add(
            type='INFO',
            message='CCAR Model initialization completed.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
       
       # Check length of the result meets expectation (e.g forecast_periods=27, record_per_segment = 27+(27*28)/2)
        self.record_per_segment = lambda n : n+(n*(n+1))/2
        self.uat=uat
        self.industrytag_file=industrytag_file
        self.dataset_query_date=dataset_query_date
        self.scenario_severity_level=scenario_severity_level
        self.intermediate_dataset_path=kwargs.get('intermediate_dataset_path') 
        self.maturity_switch = kwargs.get('maturity_switch')
        self.utilization_switch = kwargs.get('utilization_switch')         
        if self.utilization_switch == True:
            self.ID = 'UNIQUEID'
        else:
            self.ID = UNIQUE_FACILITY_ID          
    ####################################################################################################################
    # Set relative initial_counts
    ####################################################################################################################   
        relative_initial_counts_all=pd.DataFrame({'ConsumerAndIndustrial_USCAN':[5,209,264,177,386,339,141,76,0],
                                             'Finance_USCAN':[48,244,135,65,36,36,14,7,0],
                                             'OilAndGas_Global':[10,93,106,90,59,33,34,63,0],
                                             'ConsumerAndIndustrial_RoW':[23,148,230,163,186,98,43,25,0],
                                             'Finance_RoW':[29,368,127,60,59,16,14,1,0]
                                            })
        if len(relative_initial_counts_all)==9:                                                                       
          if len(relative_initial_counts_all.columns)==len(self.industryList()):
            self.relative_initial_counts_all=relative_initial_counts_all     
          else:
              raise ValueError('Initial counts for LGD does not match industry group length')            
        else:
            raise ValueError('Initial counts for LGD does not match rating group length')
    ####################################################################################################################
    # Get and update lgd scale
    ####################################################################################################################  
        if self.scenario_severity_level=='BASE':
            self.lgd_scale={ 'ConsumerAndIndustrial_RoW':
                                    {'lgd_secured_scaling': 0,
                                     'lgd_unsecured_scaling': 0},
                             'ConsumerAndIndustrial_USCAN':
                                    {'lgd_secured_scaling': 0,
                                     'lgd_unsecured_scaling': 0},
                             'Finance_RoW':
                                    {'lgd_secured_scaling': 0,
                                     'lgd_unsecured_scaling': 0},
                             'Finance_USCAN': 
                                    {'lgd_secured_scaling': 0,
                                     'lgd_unsecured_scaling': 0},
                             'OilAndGas_Global':
                                    {'lgd_secured_scaling': 0,
                                     'lgd_unsecured_scaling': 0}
                           }  
            self.returnLgdScaling()  
            self._logger.add(
                    type='INFO',
                    message='Updated LGD scaler under ' +str(self.scenario_severity_level),
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )                         
        else:     
            self.lgd_scale=self._model_properties.getParameters(
                            type='property',
                            name='lgd_scale',
                            industry='all'
                        )[0]              
    @property    
    def forecast_time_series(self):
        return(utilities.generateDateSequence(
                        self.as_of_date, 
                        int(self.forecast_periods/3), 
                        m_interval=3, 
                        include_init=False)
               )
    
    def industryList(self):
        '''
        :returns: industry lists        
        '''        
        return(
            self._model_properties.getParameters(
                    type='property',
                    name="industry_list"
            )            
       )
   
    
    def mFactorSeries(self):
        '''
        :returns: M factor for all industries       
        '''
        m_factor_series = pd.DataFrame()        
        for industry in self.industryList():
            m_factor_series['m_factor_'+industry] = self.getMFactorSeries(industry).m_factor_series
        return(m_factor_series)
             
    def historicalTransitionMatrixIndustry(self,industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: historical transition matrix (list of lists) for one specific industry         
        '''         
        return (
                        self._model_properties.getParameters(
                    type='property',
                    name='historical_transition_matrix',
                    industry=industryname
                )
            )
            
    def historicalTransitionMatrix(self):
        '''
        :returns: historical transition matrix (pandas.core.frame.DataFrame) for all industries
        '''        
        historical_transitionMatrix = pd.DataFrame()
        for industry in self.industryList():
            Matrix = pd.DataFrame(self.historicalTransitionMatrixIndustry(industry))
            Matrix[INDUSTRY] = industry
            historical_transitionMatrix = historical_transitionMatrix.append(Matrix)
        try:
            return (historical_transitionMatrix)
        except AttributeError:
            print('=> can not get combined historical transition matrix' )
       
    def getBalanceWalkPD(self,initial_balance):
        '''
        :param initial_balance:the initial balance     
        :type initial_balance:dictionary of lists 
                              (keys:industryname,
                               value:list of initial balance for that industry)
        :returns: calculate monthly and quarterly PD given initial balance input for all industries
        '''        
        result = pd.DataFrame()
        for industry in self.industryList():
            rates = self.calculateAggregatedRates(industry,initial_balance[industry])
            rates[INDUSTRY]=industry
            result=result.append(rates)
        self.result=result
        return(self.result)        

    def getTransitionMatrix(self,industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: transition matrix object for given industry        
        '''                 
        return(
            TransitionMatrix(
                self._model_properties.getParameters(
                    type='property',
                    name='historical_transition_matrix',
                    industry=industryname
                )
            )
        )
 
    def getMFactorSeries(self, industryname):
        '''
        :returns: M factor series object for given industry given transformed macro series 
                  and regression coefficients
        '''          
        return(
            MFactorSeries(
                mev_data=self.transformed_macro_series,
                linear_regression_dict=self._model_properties.getParameters(
                    type='operation',
                    name="regression_coefficients",
                    industry=industryname)
            )
        )

    def getAssetCorrelation(self, industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: asset correlation for specific industry
        '''        
        return(
            self._model_properties.getParameters(
                type='property',
                name='asset_correlation',
                industry=industryname
            )
        )

    def getLgdRho(self, industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: lgd rho for specific industry
        '''        
        return(
            self._model_properties.getParameters(
                type='property',
                name='lgd_rho',
                industry=industryname
            )
        )

    def getAveragePd(self, industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: average_pd for specific industry
        '''        
        return(
            self._model_properties.getParameters(
                type='property',
                name='average_pd',
                industry=industryname
            )
        )
  
    def getAlllCoverage(self, industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: Alll coverage rates(dictionary)for each rating group within specific industry
        '''               
        alll_coverage = self._model_properties.getParameters(
                            type='property',
                            name='alll_coverage',
                            industry=industryname
                        )[0]
        return([alll_coverage[item] for item in sorted(alll_coverage)])

    def getContingentReserve(self, industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: contingent reserve rates(dictionary)for each rating group within specific industry
        '''         
        
        # Get contingent reserve rates for each rating group (dictionary)
        contingent_reserve = self._model_properties.getParameters(
                            type='property',
                            name='contingent_reserve',
                            industry=industryname
                        )[0]
        return([contingent_reserve[item] for item in sorted(contingent_reserve)])

    def printTransitionMatrixSeries(self,industryname):
        tm=self.getTransitionMatrixSeries(industryname)
        result=pd.DataFrame()
        for date in self.forecast_time_series:
            forecast_matrix=pd.DataFrame(tm[date]) 
            forecast_matrix[INDUSTRY]=industryname
            result=result.append(forecast_matrix)
        return(result)    

    def printTransitionMatrixSeriesAll(self):        
        result=pd.DataFrame()
        for industry in self.industryList():
            result=result.append(self.printTransitionMatrixSeries(industry))
        return(result)
    
    def printDRrates(self):
        result=pd.DataFrame()
        result['PeriodDate']=self.forecast_time_series        
        for industry in self.industryList():
            result[industry]=self.calculateDR(industryname=industry,
                       relative_initial_counts=self.relative_initial_counts_all[industry])['DR']
        return(result)
            
    def getTransitionMatrixSeries(self,industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: Cache stressed transition matrices during forecasting periods for given industry 
        '''        
        transition_matrices_series = {}
        asset_correlation = self.getAssetCorrelation(industryname=industryname)
        mfs = self.getMFactorSeries(industryname)
        tm = self.getTransitionMatrix(industryname)
        for origination_date in mfs.m_factor_series.index:
            transition_matrices_series[origination_date] = tm.getStressedTransitionMatrix(
                    m_factor=mfs.getMFactor(effective_date=origination_date),
                    asset_corr=asset_correlation
                    )
        return(transition_matrices_series)

    def getAnnualizedTransitionMatrixSeries(self,industryname):
        '''
        :param industryname:specify the industry     
        :type industryname:str
        :returns: Cache stressed transition matrices during forecasting periods for given industry 
        '''        
        annualized_transition_matrices_series = {}
        asset_correlation = self.getAssetCorrelation(industryname=industryname)
        mfs = self.getMFactorSeries(industryname)
        tm = self.getTransitionMatrix(industryname)
        for origination_date in mfs.m_factor_series.index:
            annualized_transition_matrices_series[origination_date] = np.matrix(tm.getStressedTransitionMatrix(
                    m_factor=mfs.getMFactor(effective_date=origination_date),
                    asset_corr=asset_correlation
                    ))**4
        return(annualized_transition_matrices_series)

    def calculateLgd(self,relative_initial_counts_all,lgd_scale):
        '''
        calcualte LGD result for all industries
        '''
        lgd=pd.DataFrame()
        for industry in self.industryList():
            lgd=lgd.append(self.calculateStressedLgdIndustry(
                            industry,relative_initial_counts_all[industry],lgd_scale)
                          )
        return(lgd)
        
    def returnLgdScaling(self):
        '''
        Return LGD scaling factor calculated in base scenario
        '''
        if self.scenario_severity_level =='BASE': 
          lgd=self.calculateLgd(self.relative_initial_counts_all,self.lgd_scale)
          lgd=lgd[[INDUSTRY,'lgd_secured_scaling','lgd_unsecured_scaling']].drop_duplicates()        
          lgd.set_index(INDUSTRY,drop=True,inplace=True)   
          self._model_properties.db.update({'value': [lgd.to_dict(orient='index')]},(Query().name=='lgd_scale'))
          return(lgd.to_dict(orient='index'))
        elif self.scenario_severity_level in ['ADVERSE','STRESS']:
          print('No need to return scaling factor in scenario other than BASE')
        else:
          raise ValueError('Scenario severity is not in BASE/ADVERSE/STRESS')
                    
    def lgdResult(self): 
        '''
        Format LGD result for all industries 
        Add LGD_Segment: 1 means unsecured segment, 0 means secured segment
        '''      
        lgd=self.calculateLgd(self.relative_initial_counts_all,self.lgd_scale)

        lgd_melt=pd.melt(
                             lgd[[INDUSTRY,'PeriodDate','LGD_Secured','LGD_Unsecured']],
                             id_vars=[INDUSTRY,'PeriodDate'],
                             var_name=['LGD_Segment'],
                             value_name='LGD'
                             ) 
#        def unsecureIndicator(row):
#            if row['LGD_Segment'] == 'LGD_Secured':
#                return(0)
#            elif row['LGD_Segment'] == 'LGD_Unsecured':
#                return(1)                             
        #lgd_melt[UNSECURED_INDICATOR]=lgd_melt.apply(lambda row: unsecureIndicator(row),axis=1)
        lgd_melt[UNSECURED_INDICATOR]=lgd_melt['LGD_Segment'].apply(lambda x:(1 if x=='LGD_Unsecured' else 0))                                        
        return(lgd_melt)
        
    def calculateLgdIndustry(self,industryname,relative_initial_counts):          
        '''
        This method calculates LGD rates for specific industry.
        Generate rates for all segments with secured and unsecured groups 
        
        :param industryname:specify the industry     
        :type industryname:str        
        
        @return: LGD rates
        ''' 
        lgd_rates = pd.DataFrame(columns=[
            "PeriodDate",
            "LGD_Secured",
            "LGD_Unsecured"
        ])            
      
        dr_rate=self.calculateDR(industryname=industryname,
                   relative_initial_counts=relative_initial_counts)
        # Get LGD rho
        lgd_rho = self.getLgdRho(industryname=industryname)
        # Get average PD
        average_pd = self.getAveragePd(industryname=industryname)
        # Specify elgd for secured and unsecured groups
        elgd={'secured':0.35,'unsecured':0.45}
        for period_date in self.forecast_time_series:
            dr=dr_rate['DR'][dr_rate['PeriodDate']==period_date].values[0]
#            if len(dr)==0:
#                raise ValueError('Period Date in DR calculation is wrong')
            lgd_secured=st.norm.cdf(
                            st.norm.ppf(dr)
                            -(st.norm.ppf(average_pd)
                            -st.norm.ppf(average_pd*elgd['secured'])
                            )/np.sqrt(1-lgd_rho))/dr
            lgd_unsecured=st.norm.cdf(
                            st.norm.ppf(dr)
                            -(st.norm.ppf(average_pd)
                            -st.norm.ppf(average_pd*elgd['unsecured'])
                            )/np.sqrt(1-lgd_rho))/dr  
            for monthly_period_date in (utilities.generateDateSequence(
                        period_date + relativedelta(months=-3),
                        3,
                        m_interval=1,
                        include_init=False)
               ):
                lgd_rates = lgd_rates.append({
                                "PeriodDate": monthly_period_date,
                                 INDUSTRY:industryname,
                                "LGD_Secured":lgd_secured,
                                "LGD_Unsecured":lgd_unsecured
                            }, ignore_index=True)
                                                                 
        return(lgd_rates)                                  
        '''
        lgd=normcdf(norminv(fdr) - (norminv(pd_hat(3))-norminv( pd_hat(3)*secELGD ))/sqrt(1-rho_hat(3)) ) ./ fdr
        
        lgd=st.norm.cdf(st.norm.ppf(pd)-(st.norm.ppf(pd_avg)-st.norm.ppf(pd_avg*elgd))/sqrt(1-rho))/pd

        '''        

    def calculateStressedLgdIndustry(self,industryname,relative_initial_counts,lgd_scale):
        '''
        In base scenario:
          get LGD scaling factor to make average LGD of secured segment equals 0.35, and unsecured segment equals 0.45
        In other scenarios:
          use LGD scaling factor computed under base scenario to get stressed LGD
        '''
        avg_lgd={'secured':0.35,'unsecured':0.45}
        lgd=self.calculateLgdIndustry(industryname,relative_initial_counts)
        
        if self.scenario_severity_level == 'BASE':  
            lgd['lgd_secured_scaling']=lgd['LGD_Secured'].mean()/avg_lgd['secured']
            lgd['lgd_unsecured_scaling']=lgd['LGD_Unsecured'].mean()/avg_lgd['unsecured']          
            lgd['LGD_Secured']=lgd['LGD_Secured']/lgd['lgd_secured_scaling']
            lgd['LGD_Unsecured']=lgd['LGD_Unsecured']/lgd['lgd_unsecured_scaling']
        else:
            lgd['LGD_Secured']=lgd['LGD_Secured']/lgd_scale[industryname]['lgd_secured_scaling']
            lgd['LGD_Unsecured']=lgd['LGD_Unsecured']/lgd_scale[industryname]['lgd_unsecured_scaling']
        return(lgd)            
        
         
        
    def calculateRates(self,industryname):          
        '''
        This method calculates PD, ALLL coverage and Contingent reserve rates for specific industry.
        Generate rates for each segments with all possible combination pairs of origination date and forecast date. 
        (Set each month as origination date for each forecast month after origination)
        
        :param industryname:specify the industry     
        :type industryname:str        
        
        @return: rates_container with PD/ALLL/Contingent objects 
                 per origination,forecast date and rating level (pandas.core.frame.DataFrame) 
        '''   
        
        scenario_period_frequency = self._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )          
        
        # Initialize transition matrix
        tm = self.getTransitionMatrix(industryname)

        # Cache stressed matrices
        transition_matrices_series = self.getTransitionMatrixSeries(industryname=industryname)    
        # Get ALLL Coverage and Contingent Reserve
        alll_coverage = self.getAlllCoverage(industryname='all')
        contingent_reserve = self.getContingentReserve(industryname='all')
        
        if self.scenario_severity_level in ['BASE']:
          ead_available=0.75
        elif self.scenario_severity_level in ['STRESS']:
           ead_available=1   
        elif self.scenario_severity_level in ['ADVERSE']:
           ead_available=0.875 
        else:
          raise ValueError('Scenario severity is not in BASE/ADVERSE/STRESS')
          
        #start calculation    
        rating_level_identity = np.diag([1] * tm.rating_levels)  
        relative_initial_balance = copy.deepcopy(rating_level_identity)
        calculate_relative_end_balance = lambda balance, tm: np.dot(balance, tm)
        rates_container = pd.DataFrame()

        for origination_date in sorted(transition_matrices_series):
            for rating in range(tm.rating_levels):
                relative_initial_balance = rating_level_identity[rating]
                for forecast_date in [
                        date for date in sorted(transition_matrices_series) 
                            if date >= origination_date
                ]:
                    relative_end_balance = calculate_relative_end_balance(
                        relative_initial_balance, transition_matrices_series[forecast_date]
                    )
                    current_pd = (relative_end_balance.item(tm.rating_levels - 1) / relative_initial_balance.sum())                    

                    # update the endbalance of next period inital balance
                    relative_initial_balance = relative_end_balance
                    # remove prior defaults
                    np.put(relative_initial_balance, [tm.rating_levels - 1], [0])
                    # Normalize relative_initial_balance vector for ALLL/Contingent reserve calculation
                    norm = relative_initial_balance / relative_initial_balance.sum()
                    
                    alll_result = (np.dot(norm, alll_coverage)).item()
                    contingent_result = (np.dot(norm, contingent_reserve)).item()
                    
                    # Coverage rates for default rating group (rating group 9)
                    if rating == tm.rating_levels-1:
                        alll_result = alll_coverage[rating]
                        contingent_result = contingent_reserve[rating]  
                    # Check NA
                    if (rating != tm.rating_levels-1)&(True in [pd.isnull(x) for x in [current_pd,alll_result,contingent_result]]):
                        raise ValueError('There is NA in rating group other than 9')

                    # Generate monthly vintage period date pair from quarterly pair
                    dates=utilities.monthlyVintagePeriodDatePairFromQuarterly(self.as_of_date,forecast_date,origination_date)
#                    dates=pd.DataFrame(data={
#                                        'PeriodDate': utilities.generateDateSequence(self.as_of_date, 9, m_interval=3, include_init=False),
#                                        'Vintage': [self.as_of_date] * 9
#                                    })
                    # append record to container   
                    
                    # transform quarterly pd to monthly pd
                    pd_monthly=utilities.PDPeriodConverter(
                        current_pd,
                        utilities.PERIOD_FREQUENCY_MAP['quarterly'],
                        utilities.PERIOD_FREQUENCY_MAP['monthly'])
                        
                    for index,row in dates.iterrows():
                        rates_container = rates_container.append({
                            'PeriodDate': row['PeriodDate'],
                            'Vintage': row['Vintage'],
                            'PD':pd_monthly,
                            'EAD':1,
                            'EADAVAILABLELINE':ead_available,
                            'EADBALANCE':1,
                            'EADLETTEROFCREDIT':1,
                            'EADTOTALLINE':0,                            
                            'ALLLCOVERAGE': alll_result,
                            'CONTINGENTRESERVE':contingent_result,
                            RatingGroup: int(rating + 1)
                        }, ignore_index=True)
        # Fill default group
        #rates_container = rates_container.fillna(1)
                    
        # Check whether the length of the result meets expectation         
        if len(rates_container) != tm.rating_levels*self.record_per_segment(self._forecast_periods):
            raise ValueError("number of forecast length with in "+industryname+ "was not correct")
        else:
            return (rates_container)        

    def uatCalculateRates(self,industryname):          
        '''
        This method calculates PD, ALLL coverage and Contingent reserve rates for specific industry.
        Generate rates for each segments with all possible combination pairs of origination date and forecast date. 
        (Set each month as origination date for each forecast month after origination)
        
        :param industryname:specify the industry     
        :type industryname:str        
        
        @return: rates_container with PD/ALLL/Contingent objects 
                 per origination,forecast date and rating level (pandas.core.frame.DataFrame) 
        '''   
        
        scenario_period_frequency = self._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )          
        
        # Initialize transition matrix
        tm = self.getTransitionMatrix(industryname)

        # Cache stressed matrices
        transition_matrices_series = self.getTransitionMatrixSeries(industryname=industryname)    
        # Get ALLL Coverage and Contingent Reserve
        alll_coverage = self.getAlllCoverage(industryname='all')
        contingent_reserve = self.getContingentReserve(industryname='all')

        #start calculation    
        rating_level_identity = np.diag([1] * tm.rating_levels)  
        relative_initial_balance = copy.deepcopy(rating_level_identity)
        calculate_relative_end_balance = lambda balance, tm: np.dot(balance, tm)
        rates_container = pd.DataFrame(columns=[
            "PeriodDate",
            "Vintage",
            "PD",
            "EAD",
            "ALLLCOVERAGE",
            "CONTINGENTRESERVE",
            "RatingGroup"
        ])


        for rating in range(tm.rating_levels):
            relative_initial_balance = rating_level_identity[rating]
            for forecast_date in sorted(transition_matrices_series): 
                relative_end_balance = calculate_relative_end_balance(
                    relative_initial_balance, transition_matrices_series[forecast_date]
                )
                current_pd = (relative_end_balance.item(tm.rating_levels - 1) / relative_initial_balance.sum())                    
                # update the endbalance of next period inital balance
                relative_initial_balance = relative_end_balance
                # remove prior defaults
                np.put(relative_initial_balance, [tm.rating_levels - 1], [0])
                # Normalize relative_initial_balance vector for ALLL/Contingent reserve calculation
                norm = relative_initial_balance / relative_initial_balance.sum()
                
                alll_result = (np.dot(norm, alll_coverage)).item()
                contingent_result = (np.dot(norm, contingent_reserve)).item()

                # append record to container                    
                rates_container = rates_container.append({
                    "PeriodDate": forecast_date,
                    "Vintage": self.as_of_date,
                    "PD":current_pd,
                    "ALLLCOVERAGE": alll_result,
                    "CONTINGENTRESERVE":contingent_result,
                    "RatingGroup": int(rating + 1)
                }, ignore_index=True)
        # Fill default group
        rates_container = rates_container.fillna(1)
        return (rates_container)  
        
    def getUatResult(self):
        result = pd.DataFrame()
        for industry in self.industryList():
            rates = self.uatCalculateRates(industry)
            rates[INDUSTRY]=industry
            result=result.append(rates)
        return(result)
        
    def getResult(self):
        result = pd.DataFrame()
        for industry in self.industryList():
            rates = self.calculateRates(industry)
            rates[INDUSTRY]=industry
            result=result.append(rates,ignore_index=True)
        return(result)        
        
#    def getSegmentRatingData(self,industrytag_file):
#        # read in excel file         
#        if os.path.exists(industrytag_file) & os.path.isfile(industrytag_file):
#            master = pd.ExcelFile(industrytag_file)
#            master_data = master.parse(MASTER_DATA)
#            #srr_rating_nonfin = master.parse(SRR_to_Gr1to8_Mapping_NonFin)
#            #srr_rating_fin = master.parse(SRR_to_Gr1to8_Mapping_Fin)
#            
#            #naics_map=master.parse(NAICS_MAP)
#        else:
#            raise Exception('Input master datset file does not exist or is not reachable.')  
#        srr_mapping_path='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\SRR_Mapping.xlsx'    
#        if os.path.exists(srr_mapping_path) & os.path.isfile(srr_mapping_path):                    
#          srr_rating =pd.read_excel(srr_mapping_path)        
#        # get NAICS code
#        #data=pd.merge(left=master_data,right=naics_map,on='NAICS')
##        def defineIndustry(row):
##            if row[Industry_Name]==ConsumerAndIndustrial:
##                if (row['Cntry_Of_Risk']=='USA') or (row['Cntry_Of_Risk']=='Canada'): 
##                    return('ConsumerAndIndustrial_USCAN')
##                else:
##                    return('ConsumerAndIndustrial_RoW')
##            elif row[Industry_Name]==Finance:
##                if (row['Cntry_Of_Risk']=='USA') or (row['Cntry_Of_Risk']=='Canada'):
##                    return('Finance_USCAN')
##                else:
##                    return( 'Finance_RoW')
##            elif row[Industry_Name]==OilAndGas:
##                return('OilAndGas_Global')                  
##            else:
##                raise ValueError('Industry is not in category')
#        # get industry name for each facility        
#        #data['Industry']=data.apply(lambda row: defineIndustry(row),axis=1)
#        # get SRR for finance and non-finance industry
#        #data_rating=pd.merge(left=data,right=srr_rating,on='SRR')     
#        data_rating=pd.merge(left=master_data,right=srr_rating)         
#        # get rating for each facility        
#        data_rating['RatingGroup']=data_rating['Fin_Rating'].where(
#                                                  data_rating[Industry_Name]==Finance,
#                                                  other=data_rating['NonFin_Rating']
#                                                )
#        return(master_data)
    def getUtilizationDataset(self):    
        # load Utilization level data from RFO
        utilization_dataset = CCMISMasterDataset(
                        asofdate=self.dataset_query_date,
                        pd_groups=['GCB'],
                        utilization_switch = True,
                        debug=False
                  ).data 
        utilization_dataset=utilization_dataset[utilization_dataset['TDR']!='Y']        
        return(utilization_dataset)
        
    def processDataset(self, industrytag_file):
        t0 = time.time()        
        # load data from RFO
        if self.uat != True:
            dataset= CCMISMasterDataset(
                            asofdate=self.dataset_query_date,
                            pd_groups=['GCB'],
                            debug=False
                      ).data

                                        
            # Filter out TDR
            dataset=dataset[dataset['TDR']!='Y']
            
            column_name=[    
                             'ASOFDATE',                         
                             'COLLATERALCODE',                        
                             'SOURCEID',
                             'ONEOBLIGORNUMBER',
                             'CUSTOMERNUMBER',
                             'FACILITYNUMBER',
                             'LCAMOUNT',
                             FACILITYTYPE,
                             MAXIMUMMATURITYDATE,
                             UTILIZATIONOPENDATE,
                             EXPOSURE,
                             UNSECURED_INDICATOR,
                             UNIQUE_FACILITY_ID,
                             PD_GROUP,
                             SRR,
                             BOOKBALANCEAMOUNT,
                             EXISTING_NEW]
            dataset=dataset[column_name] 

            self._logger.add(
                    type='INFO',
                    message='RFO data length ' + str(len(dataset)),
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )

        t1 = time.time()
        runtime = round((t1 - t0), self._precision)
        self._logger.add(
            type='INFO',
            message='Fetch RFO data completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        
        # Maturity treatment
        # Get Month to maturity                                                   
        def calculateM2mat(row):
#            if pd.isnull(row[MAXIMUMMATURITYDATE]):
#                return(np.nan)
#            else:
#                monthend_maxmaturity = utilities.monthEndDate(row[MAXIMUMMATURITYDATE])
#                m2mat = dateutilrelativedelta.relativedelta(monthend_maxmaturity, self.as_of_date)
#                return(m2mat.years*12 + m2mat.months)            

            if pd.isnull(row[MAXIMUMMATURITYDATE]):
                if pd.isnull(row[UTILIZATIONOPENDATE]) or row[UTILIZATIONOPENDATE] == '.':
                    return(0)
                else:
                    # add 11 years to origination_date 
                    monthend_maxmaturity = utilities.addMonths2date(row[UTILIZATIONOPENDATE],132)
                    m2mat = dateutilrelativedelta.relativedelta(monthend_maxmaturity,self._as_of_date)  
                    m2mat = m2mat.years*12 + m2mat.months  
                    
                if row.loc[FACILITYTYPE].upper() == 'REVOLVING LINE OF CREDIT':
                    return(max(15,m2mat))
                else:
                    return(max(46,m2mat)) 
                    
            elif row[MAXIMUMMATURITYDATE] <= self._as_of_date:
                # forecast 12 month for maxmaturity date less than as of date
                return(12)
                           
            else:
                monthend_maxmaturity = utilities.monthEndDate(row[MAXIMUMMATURITYDATE])
                m2mat = dateutilrelativedelta.relativedelta(monthend_maxmaturity,self._as_of_date)  
                return(m2mat.years*12 + m2mat.months)

        dataset['m2mat'] = dataset.apply(lambda row: calculateM2mat(row),axis = 1)
        
        
        dataset[FINAL_MATURITY] = dataset['m2mat'].apply(lambda x : utilities.addMonths2date(self._as_of_date,x))
        
        # get rating and segment for each facility        
        # read in excel file to get industry segments         
        if os.path.exists(industrytag_file) & os.path.isfile(industrytag_file):
            industrytag = pd.ExcelFile(industrytag_file)
            industrytag_data = industrytag.parse(MASTER_DATA)
        else:
            raise Exception('Input master datset file does not exist or is not reachable.')  
        
#        # Check origination get the same industry and srr  
#        origination_tags=industrytag_data[industrytag_data[UNIQUE_FACILITY_ID].str.contains('_O')]
#        origination_tags[UNIQUE_FACILITY_ID]=origination_tags[UNIQUE_FACILITY_ID].str.strip('_O')
#        
#        raw_tags=(
#          industrytag_data[industrytag_data[UNIQUE_FACILITY_ID].isin(
#              [item.strip('_O') for item in origination_tags[UNIQUE_FACILITY_ID]])])
#        
#        check=origination_tags.sort(UNIQUE_FACILITY_ID).reset_index(drop=True)==raw_tags.sort(UNIQUE_FACILITY_ID).reset_index(drop=True)
#        if len(check[(check['industry']==False) | (check['GCB_SRR']==False)])!=0:
#          raise ValueError('New Origination tag is different than original')
          
        srr_rating=pd.DataFrame({GCB_SRR:[
                                         1,1.1,1.2,1.5,
                                         2,2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,
                                         3,3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,
                                         4,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,
                                         5,5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9,
                                         6,6.1,6.2,6.3,6.4,6.5,6.6,6.7,6.8,6.9,
                                         7,7.1,7.2,7.3,7.4,7.5,7.6,7.7,7.8,7.9,
                                         8,8.1,8.2,8.3,8.4,8.5,8.6,8.7,8.8,8.9,
                                         9,9.1,9.2,9.3
                                        ],
                                 'NonFin_Rating':[
                                     9,9,9,
                                     8,8,8,8,8,8,8,8,8,8,8,
                                     7,7,7,7,
                                     6,6,6,6,6,
                                     5,5,5,5,5,5,5,5,5,5,5,5,5,
                                     4,4,4,4,4,4,4,    4,4,
                                     3,3,3,3,3,3,3,3,3,
                                     2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                                     1,1,1,1,1,1
                                       ],
                                 'Fin_Rating':[
                                     9,9,9,
                                     8,
                                     7,7,7,7,7,
                                     6,6,6,6,6,
                                     5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
                                     4,4,4,4,4,4,4,4,4,4,
                                     3,3,3,3,3,3,3,3,3,3,
                                     2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                                     1,1,1,1,1,1,1,1,1
                                 ]})
        # get industry segment for each facility   
                                 
#        data_segment=pd.merge(left=dataset,right=industrytag_data,how='left',on=UNIQUE_FACILITY_ID)
                                 
        # Creat New column for origination in order to merge with the file provided                        
        dataset['UNIQUE_FACILITY_ID_NO']= dataset[UNIQUE_FACILITY_ID].map(lambda x: x.strip('_O'))                       
        data_segment=pd.merge(
                    left=dataset,right=industrytag_data,
                    how='left',left_on='UNIQUE_FACILITY_ID_NO',right_on='Unique_Facility_ID')
        data_segment=data_segment.drop(['UNIQUE_FACILITY_ID_NO','Unique_Facility_ID'],axis=1)

        # Check origination get the same industry and srr  
        origination_tags=data_segment[data_segment[UNIQUE_FACILITY_ID].str.contains('_O')]
        
        raw_tags=(
          data_segment[data_segment[UNIQUE_FACILITY_ID].isin(
              [item.strip('_O') for item in origination_tags[UNIQUE_FACILITY_ID]])])
        
        check=(
            origination_tags[[UNIQUE_FACILITY_ID,'industry','GCB_SRR']].sort(UNIQUE_FACILITY_ID).reset_index(drop=True)\
            ==\
            raw_tags[[UNIQUE_FACILITY_ID,'industry','GCB_SRR']].sort(UNIQUE_FACILITY_ID).reset_index(drop=True)
              )
        if len(check[(check['industry']==False) | (check['GCB_SRR']==False)])!=0:
          raise ValueError('New Origination tag is different than original')
         
        untaged_industry_positive_exposure=(
                    data_segment[pd.isnull(data_segment[INDUSTRY])&(data_segment[EXPOSURE]>0)])
        if len(untaged_industry_positive_exposure)!=0:
          raise ValueError('There is untaged industry besides 0 exposure loans')
          
        # get RatingGroup from SRR  
        data_segment['SRR']=data_segment['SRR'].round(1)
        data_segment[GCB_SRR]=data_segment[GCB_SRR].round(1)
        
        if self.dataset_query_date==datetime.datetime(2016,11,30):
            data_rating=pd.merge(left=data_segment,right=srr_rating,how='left',left_on='SRR',right_on=GCB_SRR)
        else:
          data_rating=pd.merge(left=data_segment,right=srr_rating,how='left',on=GCB_SRR)

        untaged_f_rating_positive_exposure=(
                    data_rating[pd.isnull(data_rating['Fin_Rating'])&(data_rating[EXPOSURE]>0)])
        if len(untaged_f_rating_positive_exposure)!=0:
          raise ValueError('There is untaged financial rating besides 0 exposure loans')                       
        untaged_nf_rating_positive_exposure=(
                    data_rating[pd.isnull(data_rating['NonFin_Rating'])&(data_rating[EXPOSURE]>0)])                    
        if len(untaged_nf_rating_positive_exposure)!=0:
          raise ValueError('There is untaged non-financial rating besides 0 exposure loans')        
        # overwrite default segment
#        data_rating[INDUSTRY].fillna(DEFAULT_INDUSTRY,inplace=True)
#        data_rating['Fin_Rating'].fillna(DEFAULT_RATING,inplace=True)
#        data_rating['NonFin_Rating'].fillna(DEFAULT_RATING,inplace=True)        
        #data_segment=pd.merge(left=dataset,right=srr_rating)         
        
        # get rating for each facility        
        data_rating['RatingGroup']=data_rating['Fin_Rating'].where(
                                      (
                                    (
                           data_rating[INDUSTRY]== FINANCE_INDUSTRY[0]
                                    )|(
                           data_rating[INDUSTRY]==FINANCE_INDUSTRY[1])
                                      ),
                      other=data_rating['NonFin_Rating']
                                                )   
        # check tagged data length
        if len(data_rating)!= len(dataset):
            raise ValueError('Tagged data is not the same length as original master dataset.')                            
        return (data_rating)     

    def getFinalResult(self,industrytag_file):
        '''This method merge with masterdataset and provideoan level rates
        :returns final results
        '''  
        # Get RFO dataset and required tags
        data_rating=self.processDataset(industrytag_file)
        
        t0 = time.time()               
        # final master data for uat test                             
        if self.uat == True:                            
            data_rating = data_rating 
        # get all industry pd                          
        if self.uat != True:                            
            result = self.getResult()
        if self.uat == True:                            
            result = self.getUatResult()   
            
        t1 = time.time()
        runtime = round((t1 - t0), self._precision)
        self._logger.add(
            type='INFO',
            message='GCB segment level result completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )             

        loan_level_pd_result=pd.merge(data_rating,result,how='left',on=[INDUSTRY,RatingGroup])

        # Get LGD
        lgd_result=self.lgdResult()
        final_result=pd.merge(loan_level_pd_result,lgd_result,how='inner',on=['PeriodDate',INDUSTRY,UNSECURED_INDICATOR])
        return(final_result)
        
    def getLoanLevelResult(self,industrytag_file):
        '''This method merge with masterdataset and provideoan level rates
        :returns: loan level PD,EAD,ALLL coverage and Contingent reserve rates
        '''  
        # Get RFO dataset and required tags
        data_rating=self.processDataset(industrytag_file)
     
        t0 = time.time()               
        # final master data for uat test                             
        if self.uat == True:                            
            data_rating = data_rating 
        # get all industry pd                          
        if self.uat != True:                            
            result = self.getResult()
        if self.uat == True:                            
            result = self.getUatResult()   
            
        t1 = time.time()
        runtime = round((t1 - t0), self._precision)
        self._logger.add(
            type='INFO',
            message='GCB segment level result completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )             

        loan_level_pd_result=pd.merge(data_rating,result,how='left',on=[INDUSTRY,RatingGroup])
        # Check whether merge is correct
#        if len(loan_level_pd_result)!=len(data_rating):
#            raise ValueError('Master dataset merge is not correct')
            
        # Get LGD
        lgd_result=self.lgdResult()
        final_result=pd.merge(loan_level_pd_result,lgd_result,how='inner',on=['PeriodDate',INDUSTRY,UNSECURED_INDICATOR])
        # Check whether the length of the result is correct
        if len(final_result) != len(data_rating)*self.record_per_segment(self._forecast_periods):
            raise ValueError("Number of forecasts for master dataset was not correct") 
            
        # filter for current portfolio or origination loans
        final_result = final_result[(final_result['Vintage'] == self.as_of_date)|(final_result['UNIQUE_FACILITY_ID'].str.contains('_O'))]
        final_result['LINEGROWTH'] = [-pd if srr<=2.0 and srr>1.2 else 0 for srr,pd in zip(final_result['GCB_SRR'], final_result['PD'])]
        if self.uat != True:
            # Maturity Treatment
            if self.maturity_switch == True:
                for unique_id in final_result['UNIQUE_FACILITY_ID'].unique():
                    final_result = final_result[~((final_result['UNIQUE_FACILITY_ID']==unique_id)&(final_result['PeriodDate']>final_result[FINAL_MATURITY]))]
           
            gcb_result = final_result[[
                                    UNIQUE_FACILITY_ID,
                                    'PeriodDate',
                                    'Vintage',
                                    'PD',
                                    'LGD',
                                    'EAD',
                                    'EADAVAILABLELINE',
                                    'EADBALANCE',
                                    'EADLETTEROFCREDIT',
                                    'EADTOTALLINE',
                                    'ALLLCOVERAGE',
                                    'CONTINGENTRESERVE',
                                    'LINEGROWTH']]
            
            gcb_result_melt = pd.melt(
                               gcb_result,
                               id_vars=[UNIQUE_FACILITY_ID, 'Vintage', 'PeriodDate'],
                               var_name=['RateName'],
                               value_name='ModelOutputRate'
                               )             
            
            if self.utilization_switch == True:
                utilization_dataset = self.getUtilizationDataset()[['UNIQUE_FACILITY_ID','UNIQUEID']]       
                
                ead_list = ['EAD','EADAVAILABLELINE','EADBALANCE','EADLETTEROFCREDIT','EADTOTALLINE']
                
                gcb_result_melt_ead = gcb_result_melt[gcb_result_melt['RateName'].isin(ead_list)]
                ead_result = pd.merge(
                                utilization_dataset,
                                gcb_result_melt_ead,
                                on = UNIQUE_FACILITY_ID,
                                how = 'left')
                
                ead_result = ead_result.drop(UNIQUE_FACILITY_ID,axis = 1)
                ead_result.columns = ead_result.columns.str.replace('UNIQUEID', 'MODELSEGMENT')
                                
                # Keep results other than EADs
                gcb_result_melt_other = gcb_result_melt[~gcb_result_melt['RateName'].isin(ead_list)]
                gcb_result_melt_other.columns = gcb_result_melt_other.columns.str.replace(UNIQUE_FACILITY_ID, 'MODELSEGMENT')

                gcb_result_melt = gcb_result_melt_other.append(ead_result)                             
        else:
          gcb_result_melt=final_result                                            

#        #Check whether the length of the result meets expectation         
#        if len(gcb_result) != len(final_master)*self.record_per_segment(self._forecast_periods):
#            raise ValueError("number of forecasts for master dataset was not correct"
        return (gcb_result_melt)
           
    def calculateDR(self,industryname,relative_initial_counts):        
        '''
        :param indust@@@ryname:specify the industry         
        :param relative_initial_counts:the initial counts
    
        :type industryname:str        
        :type relative_initial_counts:list of initial counts for specific industry
        :returns: calculate monthly and quarterly PD given initial counts input for all industries
        '''   
 
 
        # Initialize transition matrix
        tm = self.getTransitionMatrix(industryname)
        
        calculate_relative_end_counts = lambda counts, tm: np.dot(counts, tm)
        dr_rates = pd.DataFrame(columns=[
            "PeriodDate",
            "DR"
        ])
        # Cache stressed matrices
        transition_matrices_series = self.getTransitionMatrixSeries(industryname=industryname)        
        # Annualizedtransition matrix
        annualized_tm = self.getAnnualizedTransitionMatrixSeries(industryname=industryname) 
        
        for date in sorted(transition_matrices_series):
            relative_end_counts = calculate_relative_end_counts(
                relative_initial_counts, transition_matrices_series[date]
            )
            # last column of the annu
            annualized_default_prob=annualized_tm[date][:,tm.rating_levels - 1]
            dr=(
                np.dot(
                        relative_initial_counts,annualized_default_prob
                       )/np.sum(relative_initial_counts)
               ).item()
            
            # update the end counts of next period inital counts
            relative_initial_counts = relative_end_counts
            
            # remove prior defaults
            np.put(relative_initial_counts, [tm.rating_levels - 1], [0])
            
            dr_rates = dr_rates.append({
                            "PeriodDate": date,
                            "DR": dr
                        }, ignore_index=True)
        
        return (dr_rates)  

    def calculateAggregatedRates(self,industryname,relative_initial_balance):        
        '''
        :param industryname:specify the industry         
        :param relative_initial_balance:the initial balance
    
        :type industryname:str        
        :type relative_initial_balance:list of initial balance for specific industry
        :returns: calculate monthly and quarterly PD given initial balance input for all industries
        '''   
        # Initialize transition matrix
        tm = self.getTransitionMatrix(industryname)
        
        calculate_relative_end_balance = lambda balance, tm: np.dot(balance, tm)
        rates = pd.DataFrame(columns=[
            "PeriodDate",
            "PD_Quarterly"
        ])
        # Cache stressed matrices
        transition_matrices_series = self.getTransitionMatrixSeries(industryname=industryname)        

        for date in sorted(transition_matrices_series):
            relative_end_balance = calculate_relative_end_balance(
                relative_initial_balance, transition_matrices_series[date]
            )

            current_pd = relative_end_balance.item(tm.rating_levels - 1) / np.sum(relative_initial_balance)
            # update the endbalance of next period inital balance
            relative_initial_balance = relative_end_balance
            
            # remove prior defaults
            np.put(relative_initial_balance, [tm.rating_levels - 1], [0])
            
            rates = rates.append({
                            "PeriodDate": date,
                            "PD_Quarterly": current_pd
                        }, ignore_index=True)
  
        #Quarterly to monthly test
        rates["PD_Monthly"] = utilities.PDPeriodConverter(
                    rates["PD_Quarterly"],
                    utilities.PERIOD_FREQUENCY_MAP['quarterly'],
                    utilities.PERIOD_FREQUENCY_MAP['monthly'])
        
        return (rates)        

    def getLossEstimate(self):
        gcb_result=self.getFinalResult(self.industrytag_file)
        result=gcb_result.copy()
        # get the right order
        result=result.sort(['UNIQUE_FACILITY_ID','Vintage','PeriodDate'])
        result=result[['EXPOSURE','BOOKBALANCE', 'LCAMOUNT','UNSECURED_INDICATOR',
               'UNIQUE_FACILITY_ID', 'PD_GROUP', 'SRR', 
               'industry', 'GCB_SRR', 'RatingGroup','EAD', 'EADAVAILABLELINE',
               'EADBALANCE', 'EADLETTEROFCREDIT', 'EADTOTALLINE', 'PD', 'PeriodDate',
               'Vintage', 'LGD_Segment', 'LGD']]
               
        result['InitialBalance']=gcb_result['BOOKBALANCE']+\
                                 gcb_result['LCAMOUNT']+\
                                (gcb_result['EXPOSURE']-gcb_result['BOOKBALANCE']-gcb_result['LCAMOUNT'])*\
                                 gcb_result['EADAVAILABLELINE']
        result['Default']=0
        result['Loss']=0
        result['Month']=[i for i in range(27)]*int(len(result)/27)
        
        result=result[result['Vintage']==self.as_of_date]
        result.reset_index(inplace=True)
      
        t0=time.time()
        for i in range(len(result)):
          if result.loc[i,'Month']==0:
            result.loc[i,'InitialBalance']=result.loc[i,'InitialBalance']
          else:
            result.loc[i,'InitialBalance']=result.loc[(i-1),'InitialBalance']-result.loc[(i-1),'Default']
          result.loc[i,'Default']=result.loc[i,'InitialBalance']*result.loc[i,'PD']   
          result.loc[i,'Loss']=result.loc[i,'Default']*result.loc[i,'LGD']
        print('Get result in ' + str(time.time()-t0) + ' s.') 
        print(result.sum())
        return (result)         
          
    def execute(self, session=None):
        """

        :param session: an optional CCARSession instance to write contributor and log data to, default is None

        """
        self._logger.add(
            type='INFO',
            message='Executing model...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Starting timer
        t0 = time.time()

        # Model process
        gcb_result_melt=self.getLoanLevelResult(self.industrytag_file)
        # Check na
        if gcb_result_melt.isnull().values.any()==True:
            raise ValueError('There is na in result')     
            
        for rate in gcb_result_melt['RateName'].unique():
          if rate == 'LINEGROWTH':
              continue
          rate_mean= gcb_result_melt[
                            (gcb_result_melt['RateName']==rate)
                            &
                            (gcb_result_melt['Vintage']==self.as_of_date)]['ModelOutputRate'].describe()
                            
          if ((rate_mean['min']<0) or (rate_mean['max']>1)):
              raise ValueError (str(rate)+' result is not within 0 to 1')          
              
          self._logger.add(
                              type='INFO',
                              message=str(rate)+'_current vintage mean: '+str(round(rate_mean['mean']*100,5))+'%',
                              context='CCAR Model : ' + self._model_name,
                              model_id=self._model_id
                )
                                        
        self._logger.add(
                    type='INFO',
                    message='Final result length: ' + str(len(gcb_result_melt)),
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )
        '''
        if session is not None:
                session.contributor_file_generator.appendCF(
                    as_of_date=self._as_of_date,
                    forecast_periods=len(rate_container),
                    forecast_periods_frequency=self._forecast_periods_frequency,
                    scenario=self._scenario,
                    model_segment=[metric.model_segment_key for metric in rate_container['ModelOutputRate']],
                    rate_name=[metric.name for metric in rate_container['ModelOutputRate']],
                    rate_type=[metric.type for metric in rate_container['ModelOutputRate']],
                    vintage_differentiation=False,
                    model_output_rate=[metric.metric_value for metric in rate_container['ModelOutputRate']],
                    uncertainty_adjustment_rate=[metric.uncertainty for metric in rate_container['ModelOutputRate']],
                    mgmt_adjustment_rate=[metric.adjustment for metric in rate_container['ModelOutputRate']]
        '''        
        if session is not None:
                session.contributor_file_generator.appendCF(
                            period_date=gcb_result_melt['PeriodDate'].tolist(),
                            scenario=self._scenario,
                            model_segment=('SB'+gcb_result_melt[UNIQUE_FACILITY_ID]).tolist(),
                            rate_name=gcb_result_melt['RateName'].tolist(),
                            rate_type=4,
                            vintage=gcb_result_melt['Vintage'].tolist(),
                            model_output_rate=gcb_result_melt['ModelOutputRate'].tolist(),
                            uncertainty_adjustment_rate=0.0,
                            mgmt_adjustment_rate=0.0
                        )
        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), self._precision)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        if self.intermediate_dataset_path != None:
            # Output transition matrix
            self.printTransitionMatrixSeriesAll().to_excel(self.intermediate_dataset_path+'GCB_TM_{}.xlsx'.format(self.scenario),index=False)
            # Output default rate
            self.printDRrates().to_excel(self.intermediate_dataset_path+'GCB_DR_{}.xlsx'.format(self.scenario),index=False)
            # Output lgd rate
            #self.calculateLgd(self.relative_initial_counts_all,self.lgd_scale).to_excel(self.intermediate_dataset_path+'GCB_LGD_{}.xlsx'.format(self.scenario),index=False)
          # Dump log data into session instance
        if session is not None:
            if isinstance(session, CCARSession):
                for log_item in self._logger.items:
                    session.logger.addItem(log_item)

