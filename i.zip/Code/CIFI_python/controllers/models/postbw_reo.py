# -*- coding: utf-8 -*-
"""
@author: n838126
"""
            #file_path='I:\\CRMPO\\CCAR\\2Q16\\4 - Models\\Wholesale\\REO\\SAS_BW_Output\\SBNA_Base_ROLL_20160908.xlsx'
            #file_path='I:\\CRMPO\\CCAR\\2Q16\\4 - Models\\Wholesale\\REO\\Round 3\\New_Commercial REO Tool Adverse.xlsx'

#########CHECK##########

'''
reo = ReoModel(
            current_reo = 9534488,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,6,30),
            forecast_periods = 9, #quarterly
            scenario='MC_Base',
            file_path='I:\\CRMPO\\CCAR\\3Q16\\4 - Models\\Wholesale\\REO\\check\\Commercial REO Tool Base.xlsx'
        )
'''

'''
################
### Warning ####
make sure the SAS output file 'SAS_OUTPUT' Sheet has the datetime format(e.g 6/1/2016,7/1/2016(EOMONTH(X,0)+1))
################################################################V################################################
# Assumptions 
################
ICAAP 2018
################
reo = ReoModel(
            current_reo = 3668875,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2017,12,31),
            forecast_periods = 16, 
            context='ICAAP2018_CCAR',                                                                                                                                
            scenario='GLOBAL_STRESS',
            file_path='I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\REO\\CCAR 2018\\REO NPL Balance.xlsx',
            result_path='I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\REO\\',
            use_rfo=True,
            forecast_periods_frequency='monthly',
            use_direct_input = True
        )    
result=reo.reoResult() 
################
CCAR 2018
################
reo = ReoModel(
            current_reo = 3668875,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2017,12,31),
            forecast_periods = 16, 
            context='CCAR2018',                                                                                                                                
            scenario='FRB_SA',
            file_path='I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\REO\\CCAR 2018\\REO NPL Balance.xlsx',
            result_path='I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\REO\\',
            use_rfo=True,
            forecast_periods_frequency='monthly',
            use_direct_input = True
        )    
result=reo.reoResult()     
################
Dry Run 2018
################
reo = ReoModel(
            current_reo = 3668875,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2017,12,31),
            forecast_periods = 9, 
            context='DryRun2018',                                                                                                                                
            scenario='BHC_STRESS',
            file_path='I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\REO\\DryRun 2018\\SBNA_DryRun2018_STRESS_ROLL_20180204.xlsx',
            result_path='I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\REO\\',
            use_rfo=True,
            forecast_periods_frequency='monthly',
            use_direct_input = False
        )
    
result=reo.reoResult()                
################################################################V################################################
reo = ReoModel(
            current_reo = 9534488,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,6,30),
            forecast_periods = 14, #quarterly
            scenario='ICP_Adverse',
            file_path='I:\\CRMPO\\CCAR\\3Q16\\4 - Models\\Wholesale\\REO\\SBNA_ADVERSE_ROLL_20161203.xlsx'
        )



################
reo = ReoModel(
            current_reo = 9534488,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,6,30),
            forecast_periods = 9, #quarterly
            scenario='MC_Base',
            file_path='I:\\CRMPO\\CCAR\\3Q16\\4 - Models\\Wholesale\\REO'

        )
    
result=reo.reoResult()                                                                                                                                                                                                                                                                                                                                                                                                  
################
Dry Run
################
reo = ReoModel(
            current_reo = 7334625.00,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,12,31),
            forecast_periods = 9, #quarterly
            context='DryRun2017',                                                                                                                                
            scenario='DR_BASE',
            file_path='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\SBNA_DR_BASE_ROLL_20170208.xlsx',
            use_rfo=True,
            forecast_periods_frequency='monthly'
        )
    
result=reo.reoResult()
result.to_csv('I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\SBNA_LOSS_REOCOM.csv',index=False)                                                                                                                                

reo = ReoModel(
            current_reo = 7334625.00,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,12,31),
            forecast_periods = 9, #quarterly
            context='DryRun2017',                                                                                                                                
            scenario='DR_SA',
            file_path='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\SBNA_DR_SA_ROLL_20170208.xlsx',
            use_rfo=True,
            forecast_periods_frequency='monthly'
        )
        
result=reo.reoResult()

################
CCAR R1
################
reo = ReoModel(
            current_reo = 7334625.00,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,12,31),
            forecast_periods = 9, #quarterly
            context='CCAR2017',                                  
            scenario='FRB_BASE',
            file_path="I:\\CRMPO\\CCAR\\4Q16\\7 - Results\\CCAR\\Roll\\20170220\\SBNA_CCAR_BASE_ROLL_20170219.xlsx",
            result_path='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\CCAR',
            use_rfo=True,
            forecast_periods_frequency='monthly'
        )
    
result=reo.reoResult()
result.to_csv('I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\SBNA_LOSS_REOCOM_FRB_BASE.csv',index=False)                                                                                                                                


reo = ReoModel(
            current_reo = 7334625.00,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,12,31),
            forecast_periods = 9, #quarterly
            context='CCAR2017',                                                                                                                                
            scenario='FRB_ADVERSE',
            file_path="I:\\CRMPO\\CCAR\\4Q16\\7 - Results\\CCAR\\Roll\\20170220\\SBNA_CCAR_ADVERSE_ROLL_20170219.xlsx",
            result_path='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\CCAR',
            use_rfo=True,
            forecast_periods_frequency='monthly'
        )
        
result_ADVERSE=reo.reoResult()                                                                                                                                                          

reo = ReoModel(
            current_reo = 7334625.00,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,12,31),
            forecast_periods = 9, #quarterly
            context='CCAR2017',                                                                                                                                
            scenario='FRB_SA',
            file_path="I:\\CRMPO\\CCAR\\4Q16\\7 - Results\\CCAR\\Roll\\20170220\\SBNA_CCAR_SA_ROLL_20170219.xlsx",
            result_path='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\CCAR',
            use_rfo=True,
            forecast_periods_frequency='monthly'
        )
        
result_SA=reo.reoResult()                                                                                                                                                           

reo = ReoModel(
            current_reo = 7334625.00,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = datetime.datetime(2016,12,31),
            forecast_periods = 9, #quarterly
            context='CCAR2017',                                                                                                                                
            scenario='BHC_SA',
            file_path="I:\\CRMPO\\CCAR\\4Q16\\7 - Results\\CCAR\\Roll\\20170220\\SBNA_CCAR_BHC_SA_ROLL_20170219.xlsx",
            result_path='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\CCAR',
            use_rfo=True,
            forecast_periods_frequency='monthly'
        )
        
result_BHC_SA=reo.reoResult()                                                                                                                                                                                                                                                                                                                                                           
result.to_csv('I:\\CRMPO\\CCAR\\3Q16\\4 - Models\\Wholesale\\REO\\REO_ICP_Adverse_ContributorFile.csv',index=False)
    
monthly_balance=reo.reoMonthlyBalance()
monthly_expense=getREO.reoMonthlyExpense()
monthly_collateral_loss=reo.reoMonthlyCollateralLoss()
'''
import os
import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)   
import CIFI.controllers.utilities.utilities as utilities
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
import pandas as pd
import numpy as np
from os import path
import datetime
import bisect

# change global variables depend on scenarios
#SAS_OUTPUT_TABLE_NAME ='Balance Walk Output' 
#SAS_OUTPUT_TABLE_NAME ='SAS_OUTPUT'  
SAS_OUTPUT_TABLE_NAME ='CRE' 
SCENARIO_PATH='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Scenarios\\' 
#RESULT_PATH='I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\CCAR'
FZFL075035503Q_US='FZFL075035503Q_US'

class ReoModel:
    # Properties 
    current_reo = None
    percent_npl_to_reo = None
    time_in_reo  = None
    ltv = None
    reo_expenses = None 
    lag_into_reo = None 
    as_of_date = None 
    forecast_periods = None 
    scenario = None
    file_path = None
    result_path=None
    forecast_periods_frequency='monthly'
    context=None
    use_rfo=True
    use_direct_input = False
       
    # Methods
    def __init__(
            self,
            current_reo, 
            percent_npl_to_reo, 
            time_in_reo, 
            ltv, 
            reo_expenses, 
            lag_into_reo, 
            as_of_date,
            forecast_periods, 
            scenario,
            file_path,
            result_path,
            forecast_periods_frequency,
            context,
            use_rfo,
            use_direct_input
            
    ):   
        self.current_reo = current_reo         
        self.percent_npl_to_reo = percent_npl_to_reo
        self.time_in_reo = time_in_reo
        self.ltv = ltv
        self.reo_expenses = reo_expenses
        self.lag_into_reo = lag_into_reo
        self.result_path=result_path
        if isinstance(as_of_date, datetime.datetime):
            self.as_of_date = as_of_date
            
        self.forecast_periods = forecast_periods
        self.scenario = scenario
        self.context=context
        self.file_path  = file_path
        self.use_rfo = use_rfo
        self.use_direct_input = use_direct_input
        '''
        # sepecify crepi series
        self.crepi = pd.Series([ 291.73277,
                    295.42159,
                    299.1104,
                    302.90462,
                    306.69883,
                    310.59844,
                    314.49804,
                    318.39765,
                    320.82173,
                    323.24581,
                    325.66989,
                    328.19936,
                    330.62344,
                    346.82011],index=utilities.generateDateSequence(as_of_date, forecast_periods+time_in_reo, m_interval=3, include_init=False))
        '''

#        indicator,
#        context,
#        geo_scope,
#        period_frequency,
#        as_of_date=None,
#        forecast_periods=None,
#        lag=0,
#        transformation_type='none'
#    ):
#        # Process sqlite query with input parameters
#        if self.use_RFO:
#            cursor = ScenarioMacroSeries.__connection.cursor()
#            query = """
#                SELECT DISTINCT
#                    MEV.PERIOD_END_DATE AS "Period",
#                    MEV.INDICATOR AS "Indicator",
#                    MEV.SCENARIO AS "Scenario",
#                    MEV.VALUE AS "Value"
#                FROM
#                    @table_name MEV
#                WHERE
#                    UPPER(MEV.SCENARIO) = UPPER('@scenario')
#                    AND
#                    UPPER(MEV.CYCLE) = UPPER('@context')
#                    AND
#                    @table_name.Indicator = '@indicator'
#                    AND
#                    UPPER(MEV.GEOGRAPHYSCOPE) = UPPER('@geo_scope')
#                    AND
#                    UPPER(MEV.FREQUENCY) = UPPER('@period_frequency')
#                """
#            query = query.replace('@scenario',self.scenario)
#            query = query.replace('@context',self.__context)
#            query = query.replace('@indicator',self.__indicator)
#            query = query.replace('@geo_scope',self.__geo_scope)
#            query = query.replace('@period_frequency',self.__period_frequency)
#            query = query.replace('@table_name',CONFIG['SQLITE_DB']['MACRO_VARIABLES_TABLE_NAME'])
#        
       
    def crepi(self):
#        file_path = path.join('I:\\CRMPO\\CCAR\\4Q15\\4 - Models\\Wholesale\\Macro Data\\',self.scenario+'_CCAR2016_quarterly_full.csv')
    
        # path of the scenarios
        if self.use_rfo==False:
            file_path = path.join(SCENARIO_PATH,self.scenario+'_quarterly_full.csv')
    
            if os.path.exists(file_path) & os.path.isfile(file_path):
                file=pd.read_csv(file_path)
                # select CREPI (cre price index) from scenarios
                crepi=(file[['Period',FZFL075035503Q_US]]).set_index(['Period'])
                # convert as_of_date to match the date format in scenario file (e.g 2016Q2)
                start_month = self.as_of_date.strftime("%Y")+"Q" + str(
                      bisect.bisect(range(1,12,3), 1+int(self.as_of_date.strftime("%m"))))
                crepi = crepi[start_month:]
                
        if self.use_rfo==True:                
          reo_macro_vars = ScenarioMacroSeries(
              mv_dict_list=[
                  {
                      "macro_variable_name": FZFL075035503Q_US,
                      "lag": 0,
                      "transformation_type": "none",
                      "macro_variables_group": FZFL075035503Q_US
                  }
              ],
              mv_group_dict_list=[
                  {
                      "combination" : FZFL075035503Q_US,
                      "operand_1" : FZFL075035503Q_US,
                      "operand_2" : None,
                      "operator" : None
                  }
              ],
              mv_as_of_date=self.as_of_date,
              mv_forecast_periods=self.forecast_periods,
              mv_context=self.context,
              mv_scenario=self.scenario,
              mv_geo_scope='National&Regional',
              mv_period_frequency='quarterly',
              debug=False
          )
          reo_macro_data = reo_macro_vars.fetchSQLiteMacroSeries()  
          reo_macro = reo_macro_data.sort_values(['Period'], ascending=[True])
          crepi=reo_macro[reo_macro['Period']>self.as_of_date].set_index(['Period'])['Value']
          
        return(crepi)
        
    def getBalanceWalkOutput(self):
        '''
        # get raw input--balance walk output (singel excel sheet)
        bw_output_file_path = path.join(self.file_path+self.scenario+'.xlsx')
        if os.path.exists(bw_output_file_path) & os.path.isfile(bw_output_file_path):
            bw_initial = pd.read_excel(bw_output_file_path)
        else:
            raise Exception('Input balance walk file does not exist or is not reachable.')
        '''
        # Directly get result from SAS_ROLL_UP Result
        if os.path.exists(self.file_path) & os.path.isfile(self.file_path):
            bw_roll_up = pd.ExcelFile(self.file_path)
            bw_initial = bw_roll_up.parse(SAS_OUTPUT_TABLE_NAME)
        else:
            raise Exception('Input balance walk file does not exist or is not reachable.')    
        if self.use_direct_input == False:
            # Filter raw input
            # --find loss model segment in ('CRE OTHERS','CRE MULTIFAMILY') and metric is 'nplBalance'
            bw_output = bw_initial.loc[(bw_initial['METRIC']=='NPLBALANCE')
                        &
                      (
                          (bw_initial['LOSSMODELSEGMENT']=='CRE_OTHER')|(bw_initial['LOSSMODELSEGMENT']=='CRE_MULTIFAMILY')
                       )]
        else:      
            bw_output = bw_initial[bw_initial['Scenario'] == self.scenario] 
            bw_output.set_index('Scenario',inplace = True) 
        return bw_output
    
    def getQuarterSumNpl(self):
        bw_output = self.getBalanceWalkOutput()
        if self.use_direct_input == False:
            # Get the sum of monthly npl
            # filter out unused columns
            #monthly_sum_npl=(bw_output.drop(SAS_OUTPUT_UNUSED_COLUMNS,axis=1)).sum(axis=0)
            periods=utilities.generateDateSequence(
                      self.as_of_date, self.forecast_periods, m_interval=3, include_init=False)
            col=[item.replace(day=1) for item in periods]
            quarter_sum_npl=(bw_output[col]).sum(axis=0)        
            '''
            Format the date index and select quarterly data
            quarter_npl=monthly_sum_npl.rename(lambda x: (
                                                        datetime.datetime.strptime(x,'%b-%y')
                                                        +
                                                        pd.offsets.MonthEnd(0)
                                                      ).to_datetime()
                                           ).loc[utilities.generateDateSequence(self.as_of_date, self.forecast_periods, m_interval=3, include_init=False)]
    
            quarter_npl=quarter_sum_npl.rename(lambda x: (
                                                                x
                                                                +
                                                                pd.offsets.MonthEnd(0)
                                                              ).to_datetime()
                                                   ).loc[utilities.generateDateSequence(self.as_of_date, self.forecast_periods, m_interval=3, include_init=False)]
            '''                                               
            quarter_npl=quarter_sum_npl.rename(lambda x: (
                                                                x
                                                                +
                                                                pd.offsets.MonthEnd(0)
                                                              ).to_datetime()
                                                   )    
        else:          
             quarter_npl = pd.Series(bw_output.values[0][1:]) 
             
        return(quarter_npl)               
    
    def getEntry(self):
        quarter_npl = self.getQuarterSumNpl()        
        entry=(quarter_npl*self.percent_npl_to_reo).to_frame('REO Entry')    
        return(entry)                       
    
    def getReoBalance(self):
        entry=self.getEntry()
        matrix = np.matrix(np.zeros((self.forecast_periods,self.forecast_periods+self.time_in_reo-1)))
        for row in range(self.forecast_periods):
            for col in range(row, row+self.time_in_reo):
                matrix[row,col]=entry['REO Entry'][row]/self.time_in_reo
        return(matrix)
        
    def sumReoBalance(self):
        reo_balance = self.getReoBalance()
        if sum(reo_balance).shape == (1,self.forecast_periods+self.time_in_reo-1):
            sum_reo_balance = np.ravel(sum(reo_balance)).T  
        else:
            raise ValueError('Length of reo balance is not correct')  
        return(sum_reo_balance)

    
    def allocateReoBalance(self):
        sum_reo_balance=self.sumReoBalance()
        matrix = np.matrix(np.zeros((self.forecast_periods,self.forecast_periods+self.time_in_reo-1)))       
        # allocate current reo
        matrix[0,0]=self.current_reo-self.current_reo/self.time_in_reo
        for col in range(1,self.time_in_reo):
            matrix[0,col]=matrix[0,col-1]-self.current_reo/self.time_in_reo
        reo=[]    
        # allocate future reo balance
        for row in range(1,self.forecast_periods):
            for col in range(row, row+self.time_in_reo):
                if col == row:
                    matrix[row,col]=sum_reo_balance[row-1]-sum_reo_balance[row-1]/self.time_in_reo
                else:            
                    matrix[row,col]=matrix[row,col-1]-sum_reo_balance[row-1]/self.time_in_reo                    
        allocated_reo_balance=np.ravel(sum(matrix)).T  
        for i in range(self.forecast_periods+self.time_in_reo-1):            
            reo.append(sum_reo_balance[i]+allocated_reo_balance[i])           
        return(reo) 

        
    '''Old Logic    
    def allocateReoBalance(self):
        reo_balance = self.getReoBalance()
        if sum(reo_balance).shape == (1,self.forecast_periods+self.time_in_reo-1):
            sum_npl = np.ravel(sum(reo_balance)).T  
        else:
            raise ValueError('Length of reo balance is not correct')
        reo = []
        
        # Allocate current reo with in time in reo
        # e.g time in REO = 5 allocate to 4 period
        for i in range(self.time_in_reo-1):
            if i == 0:
                reo.append(sum_npl[i]+self.current_reo-self.current_reo/self.time_in_reo) 
            else:
                reo.append(sum_npl[i]+reo[i-1]-self.current_reo/self.time_in_reo)
        # Get the reo balance after time in reo
        for i in range(self.time_in_reo-1,self.forecast_periods+self.time_in_reo-1):
            reo.append(sum_npl[i])  
        return(reo)
    '''       
        
    def getCollateralValueReo(self):
        reo_balance = self.getReoBalance()
        '''
        # sum rates (old version)
        sum_collateral_value_reo = sum(reo_balance/self.ltv)
        return (np.ravel(sum_collateral_value_reo).T)
        '''
        # metric output for Collateral Value
        return(reo_balance/self.ltv)
            
    def getCollateralWithDepreciation(self): 
        # CREPI difference impact on collateral
        collaterl_value = self.getCollateralValueReo()
        crepi=self.crepi()
        matrix = np.matrix(np.zeros((self.forecast_periods,self.forecast_periods+self.time_in_reo-1)))
        for row in range(self.forecast_periods):
            for col in range(row, row+self.time_in_reo):
                matrix[row,col]=collaterl_value[row,col]*(crepi.iloc[col]/crepi.iloc[row])
        return(matrix)    
        
    def getSumCollateralWithDepreciation(self):
        collateral_with_dep = self.getCollateralWithDepreciation()
        sum_collateral_value_reo = sum(collateral_with_dep)
        return(np.ravel(sum_collateral_value_reo).T)    
         
    def getLossDueToCollateralValueDecline(self):
        collateral_with_dep = self.getCollateralWithDepreciation()
        matrix = np.matrix(np.zeros((self.forecast_periods,self.forecast_periods+self.time_in_reo-1)))
        for row in range(self.forecast_periods):
            for col in range(row+1, row+self.time_in_reo):
                matrix[row,col]=collateral_with_dep[row,col]-collateral_with_dep[row,col-1]
        return(np.ravel(sum(matrix)).T)
           
    def reoExpense(self): 
        collateral_with_dep = self.getSumCollateralWithDepreciation()
        return(np.ravel(collateral_with_dep*self.reo_expenses).T)  
        
    def allocateReoExpense(self):
        reo_expense = self.reoExpense()
        allocated_reo_balance = self.allocateReoBalance()
        total_reo_expense = []
        # Allocate current reo with in time in reo
        for i in range(self.time_in_reo-1):
            if i == 0:
                total_reo_expense.append(reo_expense[i]+(self.current_reo-self.current_reo/self.time_in_reo)*self.reo_expenses)
            else:
                total_reo_expense.append(reo_expense[i]+(allocated_reo_balance[i-1]-self.current_reo/self.time_in_reo)*self.reo_expenses)
        # Get the reo balance after time in reo
        for i in range(self.time_in_reo-1,self.forecast_periods+self.time_in_reo-1):
            total_reo_expense.append(reo_expense[i])           
        return(total_reo_expense)
        
    def reoMonthlyBalance(self):
        '''
        :returns: monthly REO Balance result for forecaste periods
        
        '''
        allocated_reo_balance = self.allocateReoBalance()
        result = [0]* self.forecast_periods*3
        # Set quarter end data and beginning period
        for i in range(self.forecast_periods*3):
            if i == 0:
                result[i]=(allocated_reo_balance[i]-self.current_reo)/3+self.current_reo
            if i == 1:
                result[i]=(allocated_reo_balance[i-1]-self.current_reo)/3+result[i-1]
            if ((i+1)%3 == 0) & (i>0):
                result[i]=allocated_reo_balance[int((i+1)/3-1)]
                
        for i in range(self.forecast_periods*3):
            if (i%3 == 0) & (i>0):
                result[i]=(result[i+2]-result[i-1])/3+result[i-1]
            if ((i-1)%3 == 0) & (i>1):
                result[i]=(result[i+1]-result[i-2])/3+result[i-1] 
        return result
        
    def reoMonthlyExpense(self):
        '''
        :returns: monthly REO Expense result for forecaste periods
        '''   
        reo_quarterly_expense=self.allocateReoExpense()[0:self.forecast_periods]
        reo_monthly_expense=[item/3 for item in reo_quarterly_expense]
        return(list(np.repeat(reo_monthly_expense,3)))  

    def reoMonthlyCollateralLoss(self):
        '''
        :returns: monthly REO Expense result for forecaste periods
        '''   
        loss_due_to_collateral_decline=self.getLossDueToCollateralValueDecline()[0:self.forecast_periods]
        reo_monthly_collater_loss=[item/3 for item in loss_due_to_collateral_decline]
        return(list(np.repeat(reo_monthly_collater_loss,3)))          
        
    def reoResult(self):
        '''
        :returns: aggregated REO result
        '''
        print('>>> Calculate reo monthly balance')                               
        # return balance,expense and gain/loss
        monthly_balance=self.reoMonthlyBalance()
        print('>>> Calculate reo monthly expense')
        monthly_expense=self.reoMonthlyExpense()
        print('>>> Calculate reo reo gain/loss')
        monthly_collateral_loss=self.reoMonthlyCollateralLoss()

        
        #append balance,expense and gain/loss together
        monthly_balance.extend(monthly_expense)  
        monthly_balance.extend(monthly_collateral_loss)  
        
        # repeat one input to monthly frequency (e.g forecast_periods=9, get monthly frequency:9*3)
        forecast_month=self.forecast_periods*3
        processList = lambda item,n: (
            list(item) * n
        )
        
        line_item = ['OREO Balance - Commercial',
                     'Other Real Estate Owned Expense',
                     'Net Gains/(Losses) on Sales of Other Real Estate Owned']
        y14a_code = ['Y14A_49A','Y14A_35','Y14A_52']          
        MDRM_code = ['SBP729','SNQ252','SNQ201']

        def creatList(inputs):  
            result=[]          
            for item in inputs:
                result.extend([item]*forecast_month)
            return(result)        
                        
        forecast_timeperiod=utilities.generateDateSequence(self.as_of_date, self.forecast_periods*3, m_interval=1, include_init=False)
                
        print('>>> Generating contributor file')   
        
        # 3 here is for 3 category (balance,expense,gain/loss)                  
        result=pd.DataFrame(data={
                         'FileID':processList([2],forecast_month*3),
                         'Scenario':processList([self.scenario],forecast_month*3),
                         'PeriodDate':processList(forecast_timeperiod,3),
                         'RateType':processList([2],forecast_month*3),
                         'LegalEntity':processList(['SBNA'],forecast_month*3),
                         'GranularLineItem':processList([np.nan],forecast_month*3),
                         'GLCode':processList([np.nan],forecast_month*3),
                         'MDRMCode':creatList(MDRM_code),
                         '14AWorksheet':processList(['PPNRProjections'],forecast_month*3),
                         '14ALineItemDescription':creatList(line_item),                                                   
                         '14ACode':creatList(y14a_code),
                         'ModelBalance':monthly_balance,
                         'UncertaintyAdjustmentRate':processList([0],forecast_month*3),
                         'MgmtAdjustmentRate':processList([0],forecast_month*3),
                         'IdiosyncraticRate1':processList([0],forecast_month*3),
                         'IdiosyncraticRate2':processList([0],forecast_month*3),
                         'IdiosyncraticRate3':processList([0],forecast_month*3),
                         'IdiosyncraticRate4':processList([0],forecast_month*3),
                         'IdiosyncraticRate5':processList([0],forecast_month*3),
                         'AdjustmentOverlayJustification':processList([np.nan],forecast_month*3)})        
        # Order of Contributor file column names
        header_names = [ 
                         'FileID',
                         'Scenario',
                         'PeriodDate',
                         'RateType',
                         'LegalEntity',
                         'GranularLineItem',
                         'GLCode',
                         'MDRMCode',
                         '14AWorksheet',
                         '14ALineItemDescription',
                         '14ACode',
                         'ModelBalance',
                         'UncertaintyAdjustmentRate',
                         'MgmtAdjustmentRate',
                         'IdiosyncraticRate1',
                         'IdiosyncraticRate2',
                         'IdiosyncraticRate3',
                         'IdiosyncraticRate4',
                         'IdiosyncraticRate5',
                         'AdjustmentOverlayJustification']  
                         
        result_path=path.join(self.result_path, 'SBNA_LOSS_REOCOM_'+ self.scenario+'.csv')                 
        result[header_names].to_csv(result_path,date_format='%m/%d/%Y',index=False)             
        return(result[header_names])                  