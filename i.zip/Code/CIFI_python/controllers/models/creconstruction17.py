"""

SAMPLE USE
----------
from CIFI.models.modelproperties.modelproperties import ModelProperties
mp = ModelProperties(
	model_id = '2016-SBNA-Loss-Commercial-CREConstruction',
	version_date=datetime.datetime(2016,12,31)
)
rc = mp.getParameters(
    type='operation',
    name='regression_coefficients',
    retype='residential'
)



ccar_session = CCARSession(
    session_id='CRE Construction Test',
    session_date=datetime.datetime(2016,12,31),
    user='n813863'
)
cart = ModelShoppingCart(ccar_session=ccar_session)

CREConst_instance = CREConstruction(
    uncertainty_rate=0.,
    as_of_date=datetime.datetime(2016,12,31),
    model_id="2016-SBNA-Loss-Commercial-CREConstruction",
    scenario="FRB_BASE",
    scenario_context='CCAR2017',
    forecast_periods=27,
    scenario_date=datetime.datetime(2016,12,31)
)

CREConst_instance.calculateLoss()
CREConst_instance.loss_results.to_clipboard()

cart.addModel(CREConst_instance)
cart.checkout()
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
cf.getCFData().to_clipboard(index=False)

# macros = CREConst_instance.transformed_macro_series.to_clipboard()
# d = CREConst_instance.calculate()

----- P20 RUN------------
CREConst_instance = CREConstruction(
                uncertainty_rate = 0.00,
                as_of_date = datetime.datetime(2017,3,31),
                model_id = "2016-SBNA-Loss-Commercial-CREConstruction",
                scenario="BASE",
                scenario_context='STRATPLAN_2017',
                forecast_periods =45,
                scenario_date=datetime.datetime(2017,3,31))
ccar_session = CCARSession(
    session_id='CRE Construction Test',
    session_date=datetime.datetime(2017,3,31),
    user='n886528')
cart = ModelShoppingCart(ccar_session=ccar_session)
cart.addModel(CREConst_instance)
cart.checkout()
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
cf.getCFData().to_clipboard()

"""
import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.config import CONFIG
from CIFI.controllers.utilities.metrics import PD, LGD, EAD
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import pandas as pd
import numpy as np
import time
import copy
import os

LGD_MODEL_SEGMENTS = [
    'LGD_C_CRE_CONSTRUCTION_RESIDENTIAL',
    'LGD_C_CRE_CONSTRUCTION_OTHER',
    'LGD_B_CRE_CONSTRUCTION_RESIDENTIAL',
    'LGD_B_CRE_CONSTRUCTION_OTHER',
    'LGD_A_CRE_CONSTRUCTION_RESIDENTIAL',
    'LGD_A_CRE_CONSTRUCTION_OTHER'
]

RESI_PD_MODEL_SEGMENTS = [
    'PD_C_CRE_CONSTRUCTION_RESIDENTIAL',
    'PD_B_CRE_CONSTRUCTION_RESIDENTIAL',
    'PD_A_CRE_CONSTRUCTION_RESIDENTIAL'
]

OTHER_PD_MODEL_SEGMENTS = [
    'PD_C_CRE_CONSTRUCTION_OTHER',
    'PD_B_CRE_CONSTRUCTION_OTHER',
    'PD_A_CRE_CONSTRUCTION_OTHER'
]

EAD_MODEL_SEGMENTS = [
    'EAD_C_CRE_CONSTRUCTION_RESIDENTIAL',
    'EAD_C_CRE_CONSTRUCTION_OTHER',
    'EAD_B_CRE_CONSTRUCTION_RESIDENTIAL',
    'EAD_B_CRE_CONSTRUCTION_OTHER',
    'EAD_A_CRE_CONSTRUCTION_RESIDENTIAL',
    'EAD_A_CRE_CONSTRUCTION_OTHER'
]


class CREConstruction(CCARModel):
    """
    This class derives from the base class CIFI.controllers.models.ccarmodel.CCARModel and provides an
    interface to the 2017 CRE Construction loss model.

    As a brief summary, this model calculates a yearly expected loss rate based on purely
    macro-economic inputs for both the residential and non-residential branches of the portfolio.
    Using a fixed LGD rate, probabilities of default are backed out.

    Attributes
    ----------
    __uncertainty_rate : (float, int)

    __lgd : (float, int)

    __residential_regression_coefficients :

    __other_regression_coefficients :

    __loss_results :


    """

    # Properties
    __uncertainty_rate = None
    __lgd = None
    __residential_regression_coefficients = None
    __other_regression_coefficients = None
    __loss_results = None


    # Methods
    def __init__(
        self,
        as_of_date: datetime.datetime,scenario_date,
        model_id: str,
        scenario: str,
        scenario_context: str,
        forecast_periods: int,
        uncertainty_rate: float = 0.,
        forecast_periods_frequency: str = 'monthly',
        precision: int = None,
        auto_fetch_macros: bool = True,
        **kwargs
    ):
        """
        The __init__() method serves as the class constructor for the CREConstruction class.

        Parameters
        ----------
        as_of_date : datetime.datetime
            The as-of-date of the start portfolio position.
        model_id : str
            The Model Risk Management Group unique model identifier.
        scenario : str
            The specific scenario to run (FRB_Adverse, FRB_SA, MC_Base, MD_SA, ...).
        scenario_context : str
            The stress testing cycle (CCAR2016, MidCycle16, ICP16, ...).
        forecast_periods : int
            Number of forecast periods at the forecast_periods_frequency value.
        uncertainty_rate : float
            An uncertainty rate to process and pass to the contributor files.
        forecast_periods_frequency : str
            The frequency (yearly, quarterly, monthly) of the model time-series outputs.
        precision : int
            The precision at which outputs are rounded.
        auto_fetch_macros : bool
            Whether or not to automatically fetch the input macro-series.

        Raises
        ------
        TypeError
            If the input `uncertainty_rate` is not a numeric type, float or int.
        TypeError
            If the input `auto_fetch_macros` is not of bool type.
        """

        # Call the parent class constructor
        CCARModel.__init__(
            self,
            as_of_date=as_of_date,
            model_id=model_id,
            scenario=scenario,
            scenario_context=scenario_context,
            forecast_periods=forecast_periods,
            forecast_periods_frequency=forecast_periods_frequency,
            precision=precision,
            scenario_date = scenario_date,
            scenario_combinations=kwargs.get('scenario_combinations')
        )

        # # Assigning model segment key
        # model_segment = self._model_properties.getParameters(
        #     type='property',
        #     name='model_segment'
        # )
        # self._logger.add(
        #     type='INFO',
        #     message='Assigning model segment key : ' + model_segment + '...',
        #     context='CCAR Model : ' + self._model_name,
        #     model_id=self._model_id
        # )
        # self.__model_segment = model_segment

        # Process uncertainty
        if isinstance(uncertainty_rate, (int, float)):
            self._logger.add(
                type='INFO',
                message='Assigning uncertainty rate : ' + str(self.__uncertainty_rate) + '...',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            self.__uncertainty_rate = uncertainty_rate
        else:
            self._logger.add(
                type='ERROR',
                message='Input uncertainty rate should be of numeric type, int or float.',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            raise TypeError('Input uncertainty rate should be of numeric type, int or float.')

        # Get model regression coefficients for PD and LGD values
        self.__residential_regression_coefficients = self._model_properties.getParameters(
            type='operation',
            name='regression_coefficients',
            retype='residential'
        )
        self.__other_regression_coefficients = self._model_properties.getParameters(
            type='operation',
            name='regression_coefficients',
            retype='other'
        )
        self.__lgd = LGD(
            metric_value = self._model_properties.getParameters(
                type='property',
                name='lgd'
            ),
            downturn_stress_level=0,
            metric_segment_key=LGD_MODEL_SEGMENTS
        )



        # Get macro variables during construction
        utilities.checkDataType(auto_fetch_macros, bool) # raises TypeError if False
        if auto_fetch_macros:
            self.fetchMacroSeries(scenario_combinations=kwargs.get('scenario_combinations'))

        # Finalize and clean up
        self._logger.add(
            type='INFO',
            message='CCAR Model initialization completed.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

    @property
    def uncertainty_rate(self) -> (float, int):
        return(self.__uncertainty_rate)

    @property
    def lgd(self) -> LGD:
        return(self.__lgd)

    @property
    def residential_regression_coefficients(self) -> dict:
        return(self.__residential_regression_coefficients)

    @property
    def other_regression_coefficients(self) -> dict:
        return(self.__other_regression_coefficients)

    @property
    def loss_results(self) -> dict:
        return (self.__loss_results)

    def calculateLoss(self) -> pd.DataFrame:
        """
        This function calculates loss, lgd and probability of default rates
        for the CRE Construction portfolio.

        Returns
        -------
        pandas.Dataframe
            Dataframe containing input macro scenarios and EL, LGD and PD results.

        Raises
        ------
        ValueError
            If `transformed_macro_series` is of None type.
        """
        # Define lambda helpers
        self._logger.add(
            type='INFO',
            message='Begin loss calculation...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        logistic_mapping = lambda ts: round(1 / (1 + np.exp(-ts)), self.precision)

        # Fetch macro data
        self._logger.add(
            type='INFO',
            message='Getting macro series...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self.__loss_results = self.transformed_macro_series.copy(deep=True)
        if self.__loss_results is None:
            raise ValueError("`transformed_macro_series` is of None type.")

        # Get RESIDENTIAL regression coefficients and compute loss
        self._logger.add(
            type='INFO',
            message='Estimating RESIDENTIAL expected loss for all forecast periods...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        coeff_pairs_resi = self.__residential_regression_coefficients['coefficients_pairs']
        self.__loss_results['EL_Yr_resi'] = logistic_mapping(
            (
                sum(
                    [
                        self.__loss_results[item] * coeff_pairs_resi[item]
                        for item in coeff_pairs_resi.keys()
                    ]
                ) + self.__residential_regression_coefficients['intercept']
             )
        )
        self.__loss_results['EL_Qtr_resi'] = self.__loss_results['EL_Yr_resi'].apply(
            lambda x: utilities.PDPeriodConverter(x, 12, 3)
        )

        # Get OTHER regression coefficients and compute loss
        self._logger.add(
            type='INFO',
            message='Estimating OTHER expected loss for all forecast periods...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        coeff_pairs_other = self.__other_regression_coefficients['coefficients_pairs']
        self.__loss_results['EL_Yr_other'] = logistic_mapping(
            (
                sum(
                    [
                        self.__loss_results[item] * coeff_pairs_other[item]
                        for item in coeff_pairs_other.keys()
                    ]
                ) + self.__other_regression_coefficients['intercept']
            )
        )
        self.__loss_results['EL_Qtr_other'] = self.__loss_results['EL_Yr_other'].apply(
            lambda x: utilities.PDPeriodConverter(x, 12, 3)
        )

        # Make a vector with LGD values
        self.__loss_results['LGD'] = self.__lgd

        self._logger.add(
            type='INFO',
            message='Calculating PD for all forecast periods...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self.__loss_results['PD_Qtr_resi'] = self.__loss_results['EL_Qtr_resi'] / \
                                             self.__loss_results['LGD'].apply(lambda x : x.metric_value)
        self.__loss_results['PD_Qtr_other'] = self.__loss_results['EL_Qtr_other'] / \
                                              self.__loss_results['LGD'].apply(lambda x : x.metric_value)

        # Clean up and finalize
        return (self.__loss_results)

    def calculate(self) -> pd.DataFrame:
        # Check for calculated loss resutls
        if self.__loss_results is None:
            self.calculateLoss()

        # Generate monthly time series object
        date_index = utilities.generateDateSequence(
            as_of_date=self.as_of_date,
            forecast_periods=self.forecast_periods,
            m_interval=utilities.PERIOD_FREQUENCY_MAP[self._forecast_periods_frequency]
        )

        # Generate PD metrics
        scenario_period_frequency = "quarterly"
        monthly_resi_pd_series = pd.core.series.Series(
            np.repeat(
                [
                    PD(
                        metric_value=pd_value,
                        time_horizon=scenario_period_frequency,
                        metric_uncertainty=(pd_value / (1 - self.__uncertainty_rate)) - pd_value,
                        metric_adjustment=0,
                        metric_adjustment_justification='',
                        precision=self.precision,
                        metric_segment_key=RESI_PD_MODEL_SEGMENTS
                    ) for pd_value in self.loss_results['PD_Qtr_resi']
                    ],
                utilities.PERIOD_FREQUENCY_MAP[
                    scenario_period_frequency
                ] / utilities.PERIOD_FREQUENCY_MAP[
                    self._forecast_periods_frequency
                ]
            ),
            index=date_index,
            name="PD_Mon_resi"
        )
        # Transform PD time scale
        monthly_resi_pd_series.apply(lambda pd_metric: pd_metric.convertPDTimeHorizon(
            self._forecast_periods_frequency,
            inplace=True
        ))

        monthly_other_pd_series = pd.core.series.Series(
            np.repeat(
                [
                    PD(
                        metric_value=pd_value,
                        time_horizon=scenario_period_frequency,
                        metric_uncertainty=(pd_value / (1 - self.__uncertainty_rate)) - pd_value,
                        metric_adjustment=0,
                        metric_adjustment_justification='',
                        precision=self.precision,
                        metric_segment_key=OTHER_PD_MODEL_SEGMENTS
                    ) for pd_value in self.loss_results['PD_Qtr_other']
                    ],
                utilities.PERIOD_FREQUENCY_MAP[
                    scenario_period_frequency
                ] / utilities.PERIOD_FREQUENCY_MAP[
                    self._forecast_periods_frequency
                ]
            ),
            index=date_index,
            name="PD_Mon_other"
        )
        # Transform PD time scale
        monthly_other_pd_series.apply(lambda pd_metric: pd_metric.convertPDTimeHorizon(
            self._forecast_periods_frequency,
            inplace=True
        ))

        monthly_lgd_series = pd.core.series.Series(
            np.repeat(
                self.lgd,
                self.forecast_periods
            ),
            index=date_index,
            name="LGD_Mon"
        )

        monthly_ead_series = pd.core.series.Series(
            np.repeat(
                EAD(
                    metric_value=1.0,
                    metric_segment_key=EAD_MODEL_SEGMENTS
                ),
                self.forecast_periods
            ),
            index=date_index,
            name="EAD_Mon"
        )

        return(
            pd.DataFrame({
                    'PD_Mon_resi': monthly_resi_pd_series,
                    'PD_Mon_other':monthly_other_pd_series
                    # 'LGD_Mon':monthly_lgd_series,
                    # 'EAD_Mon':monthly_ead_series
                },
                index=date_index
            )
        )

    def execute(self, session: CCARSession = None):
        """

        Returns
        -------

        """
        self._logger.add(
            type='INFO',
            message='Executing model...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Starting timer
        t0 = time.time()

        # Begin calculation
        forecast_series = self.calculate()


        if session is not None:
            for metric in forecast_series.columns:
                for model_segment_key in forecast_series[metric][0].model_segment_key:
                    session.contributor_file_generator.addCFChunk(
                        as_of_date=self._as_of_date,
                        forecast_periods=self._forecast_periods,
                        forecast_periods_frequency=self._forecast_periods_frequency,
                        scenario=self._scenario,
                        model_segment=model_segment_key,
                        rate_name=[metric.name for metric in forecast_series[metric]],
                        rate_type=[metric.type for metric in forecast_series[metric]],
                        vintage_differentiation=True if forecast_series[metric][0].name == "PD" else False,
                        model_output_rate=[metric.metric_value for metric in forecast_series[metric]],
                        uncertainty_adjustment_rate=[metric.uncertainty for metric in forecast_series[metric]],
                        mgmt_adjustment_rate=[metric.adjustment for metric in forecast_series[metric]]
                    )

        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Dump log data into session instance
        if session is not None:
            if isinstance(session, CCARSession):
                for log_item in self._logger.items:
                    session.logger.addItem(log_item)

























