"""
SAMPLE USAGE
------------
session = CCARSession(
    session_id='test session'
)

sample_model = CCARModel(
    as_of_date=datetime.datetime(2015,12,31),
    model_id='37 - Scenario Analysis Model - SBB PD - SBNA',
    scenario='FRB_SA',
    scenario_context='CCAR2016',
    forecast_periods=27
)

sample_model.fetchMacroSeries()
macro_series = sample_model.transformed_macro_series


##
## Testing ModelShoppingCart class
##
cart = ModelShoppingCart(ccar_session=session)
cart.addModel(sample_model)
print(cart.getModelCartInfo())



mp = ModelProperties(
	model_id = '35 - Scenario Analysis Model - GBM PD - SBNA',
	version_date=datetime.datetime(2015,12,31)
)
industry_name = 'oil'
mp.getParameters(type='property',name='historical_transition_matrix', industry=industry_name)


##
## Getting All Macros for a Given Model
##

sample_model = CCARModel(
    as_of_date=datetime.datetime(2016,12,31),
    model_id='743 - Commercial Rating Model - C&I PD - SBNA',
    scenario='BHC_SA',
    scenario_context='CCAR2017',
    forecast_periods=27
)
sample_model.fetchMacroSeries()
sample_model.transformed_macro_series
sample_model._macro_series_object.generateTransformedData(return_data=True, truncate_result=False).to_clipboard()


"""
import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.controllers.ejm.ejmmaster import EJMGenerator
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
from CIFI.models.modelproperties.modelproperties import ModelProperties
from CIFI.config import CONFIG
import datetime
import time
import pandas as pd


class CCARModel:
    """
    """
    # Properties
    _as_of_date = None
    _model_id = None
    _model_name = None
    _scenario = None
    _scenario_context = None
    _forecast_periods = None
    _forecast_periods_frequency = None
    _transformed_macro_series = None
    _transformed_macro_series_include_t0 = None
    _precision = None
    _model_properties = None
    _logger = None
    __use_RFO_macro_series = None
    scenario_combinations = None


    # Methods
    def __init__(
        self,
        as_of_date,
        model_id,
        scenario: (str, list),
        scenario_context,
        forecast_periods,
        forecast_periods_frequency='monthly',
        precision=None,
        use_RFO_macro_series=True,
        use_most_recent_model_properties: bool= False,
        scenario_combinations=None,
        scenario_date=None
    ):
        # Initialize model properties and validate model_id
        if use_most_recent_model_properties:
            self._model_properties = ModelProperties(
                model_id=model_id,
                version_date="MAX"
            )
        else:
            self._model_properties = ModelProperties(
                model_id=model_id,
                version_date=as_of_date
            )
        self._model_id = model_id
        self.scenario_date = scenario_date
        # Create logger instance
        self._logger = Logger(logger_id=self._model_id)
        self._logger.add(
            type='INFO',
            message='Initializing model...',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )

        # Validating inputs data types
        self._logger.add(
            type='INFO',
            message='Validating input data types...',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )
        utilities.checkDataType(as_of_date, datetime.datetime)
        utilities.checkDataType(model_id, str)
        utilities.checkDataType(scenario, (str, list))
        utilities.checkDataType(scenario_context, str)
        utilities.checkDataType(forecast_periods, int)
        utilities.checkDataType(forecast_periods_frequency, str)
        utilities.checkDataType(use_RFO_macro_series, bool)
        if scenario_combinations is not None:
            utilities.checkDataType(scenario_combinations, dict)
        self.scenario_combinations = scenario_combinations

        # Validating input values and assigning to member properties
        self._logger.add(
            type='INFO',
            message='Validating input values and assigning to member properties...',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )

        if self.isValidAsOfDate(as_of_date):
            self._as_of_date = as_of_date
        self._scenario = scenario

        self._scenario_context = scenario_context
        if self.isValidForecastPeriods(
            some_forecast_periods=forecast_periods,
            some_forecast_periods_frequency=forecast_periods_frequency
        ):
            self._forecast_periods = forecast_periods
            self._forecast_periods_frequency = forecast_periods_frequency

        # Get model name from model properties
        try:
            self._model_name = self._model_properties.getParameters(
                type='property',
                name='model_name'
            )
        except Exception:
            self._logger.add(
                type='INFO',
                message='Could not find `model_name` in model properties...',
                context='CCAR Model : ' + self._model_id,
                model_id=self._model_id
            )
            self._model_name = self._model_id

        # Process model precision
        self._logger.add(
            type='INFO',
            message='Establishing model numerical precision...',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )
        if precision is None:
            self._precision = CONFIG['MODEL_PRECISION']
        else:
            if isinstance(precision, int):
                if 0<=precision<=20:
                    self._precision = precision
                else:
                    raise ValueError('Input `precision` is not within range (0 to 20).')
            else:
                raise TypeError('Input `precision` is not an int.')


        self.__use_RFO_macro_series = use_RFO_macro_series


        # Wrapping up
        self._logger.add(
            type='INFO',
            message='Verification completed! Model class ready for use.',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )

    def isValidAsOfDate(self, some_as_of_date):
        """
        This function validates correct data type and range for as_of_date.
        Date ranges have been defined within a 1 year range from "now" or runtime.
        """
        self._logger.add(
            type='INFO',
            message='Validating input as_of_date range...',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )
        if(
            (some_as_of_date >= utilities.addMonths2date(datetime.datetime.now(),-12)) &
            (some_as_of_date <= utilities.addMonths2date(datetime.datetime.now(),12))
        ):
            return (True)
        else:
            raise ValueError('Input date is out of range. Date ranges are defined within a year from `now`.')

    def isValidForecastPeriods(self, some_forecast_periods, some_forecast_periods_frequency):
        self._logger.add(
            type='INFO',
            message='Validating input forecast periods type, frequency and range...',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )

        if isinstance(some_forecast_periods, int):
            if some_forecast_periods_frequency  == 'monthly':
                if (some_forecast_periods > 0) & (some_forecast_periods <= 132):
                    return (True)
                else:
                    raise ValueError('Input forecast periods is out of range. Range is 1 to 132, inclusive.')
            elif some_forecast_periods_frequency == 'quarterly':
                if (some_forecast_periods > 1) & (some_forecast_periods <= 44):
                    return (True)
                else:
                    raise ValueError('Input forecast periods is out of range. Range is 1 to 44, inclusive.')
            elif some_forecast_periods_frequency == 'annually':
                if (some_forecast_periods > 1) & (some_forecast_periods <= 11):
                    return (True)
                else:
                    raise ValueError('Input forecast periods is out of range. Range is 1 to 11, inclusive.')
            else:
                raise ValueError('Input forecast periods frequency is invalid. Expects monthly, quarterly or annually.')
        else:
            raise TypeError('Input forecast periods is of the wrong data type. Expects type <int>.')

    ####################################################################################################################
    ## GETTERS
    ####################################################################################################################
    @property
    def as_of_date(self):
        return(self._as_of_date)

    @property
    def model_id(self):
        return (self._model_id)

    @property
    def scenario(self):
        return (self._scenario)

    @property
    def scenario_context(self):
        return (self._scenario_context)

    @property
    def forecast_periods(self):
        return (self._forecast_periods)

    @property
    def forecast_periods_frequency(self):
        return(self._forecast_periods_frequency)

    @property
    def precision(self):
        return(self._precision)

    @property
    def transformed_macro_series(self):
        try:
            return(self._transformed_macro_series)
        except AttributeError:
            self.fetchMacroSeries(scenario_combinations=self.scenario_combinations)
            return(self._transformed_macro_series)

    @property
    def transformed_macro_series_include_t0(self):
        try:
            return(self._transformed_macro_series_include_t0)
        except AttributeError:
            self.fetchMacroSeries(scenario_combinations=self.scenario_combinations)
            return(self._transformed_macro_series_include_t0)

    @property
    def transformed_macro_series_include_all(self):
        try:
            return(self._transformed_macro_series_include_all)
        except AttributeError:
            self.fetchMacroSeries(scenario_combinations=self.scenario_combinations)
            return(self._transformed_macro_series_include_all)
   
    @property
    def use_RFO_macro_series(self):
        return(self.__use_RFO_macro_series)

    ####################################################################################################################

    def fetchMacroSeries(self, scenario_combinations=None):
        self._logger.add(
            type='INFO',
            message='Fetching transformed macro series...',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )

        # Get scenario parameters
        mv_dict_list = self._model_properties.getParameters(
            type='operation',
            name='macro_variables'
        )
        mv_group_dict_list=self._model_properties.getParameters(
            type='operation',
            name='macro_variable_combinations'
        )
        mv_forecast_periods=utilities.convertForecastPeriods(
            n=self._forecast_periods,
            freq_0=self._forecast_periods_frequency,
            freq_1=self._model_properties.getParameters(
                type='property',
                name='scenario_period_frequency'
            )
        )
        mv_geo_scope=self._model_properties.getParameters(
            type='property',
            name='scenario_geo_scope'
        )
        mv_period_frequency=self._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )


        if isinstance(self._scenario, str):
            self._macro_series_object = ScenarioMacroSeries(
                mv_dict_list=mv_dict_list,
                mv_group_dict_list=mv_group_dict_list,
                mv_as_of_date=self.scenario_date,
                mv_forecast_periods=mv_forecast_periods,
                mv_context=self._scenario_context,
                mv_scenario=self._scenario,
                mv_geo_scope=mv_geo_scope,
                mv_period_frequency=mv_period_frequency,
                logger=self._logger,
                use_RFO=self.use_RFO_macro_series
            )
            self._macro_series_object.generateTransformedData(return_data = False)
            self._transformed_macro_series = self._macro_series_object.getTransformedMacroData()
            self._transformed_macro_series_include_t0 = self._macro_series_object.getTransformedMacroDataIncludeT0()
            self._transformed_macro_series_include_all = self._macro_series_object.getTransformedMacroDataIncludeAll()

        elif isinstance(self._scenario, list):

            # Check scenario_combinations
            if scenario_combinations is None:
                raise ValueError('scenario_combinations CANNOT be None if multiple scenarios are provided.')

            # Validate scenario_combinations format
            macro_combinations = set(scenario_combinations.keys())
            macro_groups = set([i['macro_variable_name'] if i["macro_variable_name"] in i["macro_variables_group"] else i["macro_variables_group"] for i in mv_dict_list])
            if macro_combinations != macro_groups:
                differences = (macro_combinations - macro_groups) | (macro_groups - macro_combinations)
                raise ValueError("The list of macro variable combinations does not match the macro groups found in model properties: {}".format(str(differences)))

            scenarios_a = set(scenario_combinations.values())
            scenarios_b = set(self._scenario)
            if not scenarios_a.issubset(scenarios_b):
                differences = scenarios_a - scenarios_b
                raise ValueError("The list of scenario combinations does not match the input list of scenarios: {}".format(str(differences)))


            def scenario_sensitivity(self,function):
                scenario_container = {}
                for scenario in self._scenario:
                    current_scenario = ScenarioMacroSeries(
                        mv_dict_list=mv_dict_list,
                        mv_group_dict_list=mv_group_dict_list,
                        mv_as_of_date=self._as_of_date,
                        mv_forecast_periods=mv_forecast_periods,
                        mv_context=self._scenario_context,
                        mv_scenario=scenario, # replace with loop scenario value
                        mv_geo_scope=mv_geo_scope,
                        mv_period_frequency=mv_period_frequency,
                        logger=self._logger,
                        use_RFO=self.use_RFO_macro_series
                    )
                    current_scenario.generateTransformedData(return_data = False)
                    scenario_container[scenario] = getattr(current_scenario,function)()
                                      
                # Create combinations
                series_container = []
                for comb_mv_name, comb_scenario in scenario_combinations.items():
                    for col in scenario_container[comb_scenario].keys():
                        if comb_mv_name in col:
                            series_container.append(
                                scenario_container[comb_scenario][col]
                            )
                return(series_container)

            # FINALIZE
            self._transformed_macro_series = pd.concat(scenario_sensitivity(self,'getTransformedMacroData'), axis=1)
            self._transformed_macro_series_include_t0 = pd.concat(scenario_sensitivity(self,'getTransformedMacroDataIncludeT0'), axis=1)
            self._transformed_macro_series_include_all = pd.concat(scenario_sensitivity(self,'getTransformedMacroDataIncludeAll'), axis=1)                
        else:
            raise TypeError("`self._scenario` data type is not valid. Expects str or list.")


    def execute(self, session=None):
        t0 = time.time()

        # some process

        t1 = time.time()
        runtime = round((t1 - t0), 5)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )

        self._logger.add(
            type='ERROR',
            message='VirtualException: execute() method not implemented in derived model class.',
            context='CCAR Model : ' + self._model_id,
            model_id=self._model_id
        )
        if session is not None:
            if isinstance(session, CCARSession):
                for logitem in self._logger.items:
                    session.logger.addItem(logitem)

        raise utilities.VirtualException()

class ModelShoppingCart:
    # Properties
    __model_container = None
    __ccar_session = None

    # Methods
    def __init__(self,ccar_session):
        self.__model_container = {}

        if isinstance(ccar_session, CCARSession):
            self.__ccar_session = ccar_session
        else:
            raise TypeError("Input ccar_session is not of type CCARSession.")

        self.__ccar_session.logger.add(
            type='INFO',
            message='Model shopping cart initialized.',
            context='Model Shopping Cart'
        )

    @property
    def model_container(self):
        return (self.__model_container)

    def getModelCartInfo(self):
        cart = []
        for id, model in enumerate(self.__model_container):
            cart.append({
                'as_of_date': model.as_of_date,
                'model_id': model.model_id,
                'scenario': model.scenario,
                'scenario_context': model.scenario_context,
                'forecast_periods': model.forecast_periods
            })
        return(cart)

    def addModel(self,model):
        if isinstance(model, (CCARModel, EJMGenerator)):
            if id(model) not in self.__model_container.keys():
                self.__model_container[id(model)]=model
                self.__ccar_session.logger.add(
                    type='INFO',
                    message='Added model to cart : '+model.model_id,
                    context='Model Shopping Cart',
                    model_id=model.model_id
                )
                #return(id(model))
            else:
                raise ValueError("Input `model` already in cart.")
        else:
            self.__ccar_session.logger.add(
                type='ERROR',
                message="Couldn't add model to cart. Wrong data type.",
                context='Model Shopping Cart'
            )

            raise TypeError("Input model not of type CCARModel or EJMGenerator.")

    def resetCart(self):
        self.__ccar_session.logger.add(
            type='INFO',
            message='Resetting model shopping cart.',
            context='Model Shopping Cart'
        )

        self.__model_container = {}

    def dropFromCart(self,model_address):
        try:
            if model_address in self.__model_container:
                del self.__model_container[model_address]
            #self.__model_container.remove(some_model)
        except ValueError:
            self.__ccar_session.logger.add(
                type='INFO',
                message='Added model to cart : ' + str(model_address),
                context='Model Shopping Cart'
            )

    def checkout(self):
        # Execute shopping cart items
        self.__ccar_session.logger.add(
            type='INFO',
            message="Beginning checkout process...",
            context='Model Shopping Cart'
        )
        for model_address in self.__model_container:
            try:
                self.__model_container[model_address].execute(self.__ccar_session)
            except Exception as e:
                self.__ccar_session.logger.add(
                    type='ERROR',
                    message=str(e),
                    context='Main Run Script',
                    model_id=self.__model_container[model_address].model_id
                )
                if utilities.userInputPrompt(
                        message="{} model execution failed. Would you like to continue? [Y/N]".format(
                            self.__model_container[model_address].model_id
                        ),
                        valid_options=('Y', 'N')
                ) == 'N':
                    raise e




