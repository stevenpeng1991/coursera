"""

PD

pd = PD(0.12,'quarterly').convertPDTimeHorizon('monthly')
pd.metric_value
print(pd.convertPDTimeHorizon('annual')) # ERROR
print(pd.convertPDTimeHorizon('yearly'))
print(pd.convertPDTimeHorizon('monthly'))
print("Current time horizon: "+pd.time_horizon)

pd.convertPDTimeHorizon('monthly', inplace=True)
print("Current time horizon: "+pd.time_horizon)

import pandas as pd
s = pd.core.series.Series([
	PD(0.12,'quarterly'),
	PD(0.15,'quarterly'),
	PD(0.09,'quarterly'),
	PD(0.07,'quarterly')
])

LGD

stressLGD = lambda lgd, intercpt, factor, stress_level: lgd + stress_level * (intercpt + (lgd * (factor - 1)))
relaxLGD = lambda lgd, intercpt, factor, stress_level: (lgd - stress_level * intercpt) / (1 + stress_level * (factor - 1))

lgd = LGD(
	metric_value=0.40,
	downturn_stress_level=0
)
a = [lgd]*10

lgd.metric_value == round(stressLGD(0.4,0.08,0.92,0),CONFIG['MODEL_PRECISION'])
lgd.setDownturnStressLevel(0.5)== round(stressLGD(0.4,0.08,0.92,0.5),CONFIG['MODEL_PRECISION'])

lgd.setDownturnStressLevel(0.6,inplace=True)==stressLGD(0.4,0.08,0.92,0.6)
lgd.metric_value == round(stressLGD(0.4,0.08,0.92,0.6),CONFIG['MODEL_PRECISION'])

lgd.setDownturnStressLevel(0.45,inplace=True)==round(stressLGD(0.4,0.08,0.92,0.45),CONFIG['MODEL_PRECISION'])
lgd.metric_value == round(stressLGD(0.4,0.08,0.92,0.45),CONFIG['MODEL_PRECISION'])

"""
import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
import datetime

global METRICS
METRICS = {
    'ALLLCOVERAGE':{
        'Definition':'ALLL coverage rate to be applied to appropriate balances',
        'RateType':4
    },
    'ALLLCOVERAGECUR':{
        'Definition':'ALLL coverage rate to be applied to appropriate balances, by delinquency bucket (Current). Retail mortgage/HELOC only.',
        'RateType':4
    },
    'ALLLCOVERAGEDEL120':{
        'Definition':'ALLL coverage rate to be applied to appropriate balances, by delinquency bucket (120 DPD). Retail mortgage/HELOC only.',
        'RateType':4
    },
    'ALLLCOVERAGEDEL150':{
        'Definition':'ALLL coverage rate to be applied to appropriate balances, by delinquency bucket (150 DPD). Retail mortgage/HELOC only.',
        'RateType':4
    },
    'ALLLCOVERAGEDEL30':{
        'Definition':'ALLL coverage rate to be applied to appropriate balances, by delinquency bucket (30 DPD). Retail mortgage/HELOC only.',
        'RateType':4
    },
    'ALLLCOVERAGEDEL60':{
        'Definition':'ALLL coverage rate to be applied to appropriate balances, by delinquency bucket (60 DPD). Retail mortgage/HELOC only.',
        'RateType':4
    },
    'ALLLCOVERAGEDEL90':{
        'Definition':'ALLL coverage rate to be applied to appropriate balances, by delinquency bucket (90 DPD). Retail mortgage/HELOC only.',
        'RateType':4
    },
    'ATTRITION':{
        'Definition':'Attrition % on deposit balances',
        'RateType':4
    },
    'CAPCOST':{
        'Definition':'Net capital cost of leases',
        'RateType':2
    },
    'CLOSURE':{
        'Definition':'The probability of line closure (only applies for SCUSA Unsecured)',
        'RateType':4
    },
    'CONTINGENTRESERVE':{
        'Definition':'Reserve applied to unfunded against future losses',
        'RateType':4
    },
    'CURRENT':{
        'Definition':'Balances that are current (i.e. not delinquent)',
        'RateType':4
    },
    'DEALERDISCOUNTACCRETION':{
        'Definition':'Accretion curve applied to dealer discount amount',
        'RateType':4
    },
    'DEALERDISCOUNTAMOUNT':{
        'Definition':'Dealer discount amount per period',
        'RateType':2
    },
    'DEL120':{
        'Definition':'120 days past due bucket',
        'RateType':4
    },
    'DEL150':{
        'Definition':'150 days past due bucket',
        'RateType':4
    },
    'DEL30':{
        'Definition':'30 days past due bucket',
        'RateType':4
    },
    'DEL60':{
        'Definition':'60 days past due bucket',
        'RateType':4
    },
    'DEL90':{
        'Definition':'90 days past due bucket',
        'RateType':4
    },
    'EAD':{
        'Definition':'Exposure at Default factor',
        'RateType':4
    },
    'EARLYTERMINATION':{
        'Definition':'Percent of lease balances that terminate early',
        'RateType':4
    },
    'EXPOSURE':{
        'Definition':'Partial prepayment factor (only applies to SCUSA Auto)',
        'RateType':4
    },
    'LGD':{
        'Definition':'Loss given default rate',
        'RateType':4
    },
    'LINEGROWTH':{
        'Definition':'Growth rate on exposure balances',
        'RateType':1
    },
    'LTV':{
        'Definition':'Loan to value, segment specific weighted average index',
        'RateType':4
    },
    'MODELRESIDUAL':{
        'Definition':'Modeled auto residual values for SCUSA leases (% of starting MSRP)',
        'RateType':4
    },
    'MODELRESIDUALEOL':{
        'Definition':'End of lease modeled auto residual values (% of starting MSRP)',
        'RateType':4
    },
    'MONEYFACTOR':{
        'Definition':'Factor used for calculating lease income',
        'RateType':4
    },
    'MSRPDOLLARAMOUNT':{
        'Definition':'Manufacturer suggested retail price for new vehicles',
        'RateType':2
    },
    'NETCHARGEOFFCURVE':{
        'Definition':'Attrition curve applied against Net Charge-off balances. Commerical portfolio only.',
        'RateType':4
    },
    'NPLATTRITION':{
        'Definition':'Attrition curve applied to non-performing loan stock per period',
        'RateType':4
    },
    'NPLREOCONVERSION':{
        'Definition':'Percent of NPL balances converted to REOs',
        'RateType':4
    },
    'ORIGINATION':{
        'Definition':'Originations (growth rate, percent of balances, dollar amounts)',
        'RateType':3
    },
    'PAYDOWN':{
        'Definition':'Percent of loans that fully pay off utilized balances',
        'RateType':4
    },
    'PD':{
        'Definition':'Probability of default',
        'RateType':4
    },
    'PERCENTAUCTION':{
        'Definition':'Portion of collaterals sent to auction. For leases.',
        'RateType':4
    },
    'PERCENTCHANGEHPI':{
        'Definition':'Percent drop/increase in HPI used for post charge-off calculations. Residential only.',
        'RateType':4
    },
    'PERCENTCREPICHANGE':{
        'Definition':'Percent drop/increase in CREPI used for post charge-off calculations. CRE only.',
        'RateType':4
    },
    'PERCENTRETAINED':{
        'Definition':'Portion of balances that are retained by originating entity',
        'RateType':4
    },
    'PREPAYMENT':{
        'Definition':'Percent of loans that fully pay of balances before maturity. Inclusive of payoff rates as well',
        'RateType':4
    },
    'PRICINGRESIDUAL':{
        'Definition':'Residual value of auto leases set at origination as a %',
        'RateType':4
    },
    'RECOVERY':{
        'Definition':'Percent of balances recovered. Applied to gross charge-off amounts',
        'RateType':4
    },
    'RENEWAL':{
        'Definition':'Percent of time deposit balances renewed at maturity',
        'RateType':4
    },
    'REOEXPENSE':{
        'Definition':'REO Expense Incurred (only applies to Residential Mortgage and HELOC)',
        'RateType':4
    },
    'SUBVENTIONAMOUNT':{
        'Definition':'Contra asset used to offset depreciation',
        'RateType':2
    },
    'TIMEINREO':{
        'Definition':'Number of months loans stay in REO',
        'RateType':4
    },
    'TOTALBALANCEGROWTH':{
        'Definition':'Total balance growth rate of balances. For Deposits only.',
        'RateType':1
    },
    'UNITSORIGINATED':{
        'Definition':'Number of lease units originated',
        'RateType':2
    },
    'UTILIZATION':{
        'Definition':'Rate applied to exposures for utilized balances',
        'RateType':4
    },
    'YIELD':{
        'Definition':'Pricing inputs (should be provided at an annualized level)',
        'RateType':4
    }
}


class Metric:
	"""

	"""

	# Properties
	_name = None # The model segment group name
	_type = None # RateType indicates how inputs are to be applied in the SAS engine
	_model_segment_key = None
	_metric_value = None # The model/NMA outputs from model developers/owners (inputs into the SAS Engine/Balance Walk)
	_adjustment = None
	_adjustment_justification = None
	_uncertainty = None
	_precision = None


	# Methods
	def __init__(
		self,
		metric_name,
		metric_value,
		metric_segment_key=None,
		metric_uncertainty=0,
		metric_adjustment=0,
		metric_adjustment_justification='',
		precision=None
	):

		# Validate input data types
		utilities.checkDataType(metric_name, str)
		utilities.checkDataType(metric_value, (int,float))
		if metric_segment_key is not None:
			utilities.checkDataType(metric_segment_key, (str,list))
		utilities.checkDataType(metric_uncertainty, (int,float))
		utilities.checkDataType(metric_adjustment, (int,float))
		utilities.checkDataType(metric_adjustment_justification, str)
		if precision is not None:
			utilities.checkDataType(precision, int)
		else:
			precision = CONFIG['MODEL_PRECISION']

		# Validate metric_name

		if metric_name in METRICS.keys():
			self._name = metric_name
			self._metric_value = round(metric_value, precision)
			self._type = METRICS[metric_name]['RateType']
			self._model_segment_key = metric_segment_key
			self._adjustment = round(metric_adjustment,precision)
			self._adjustment_justification = metric_adjustment_justification
			self._uncertainty = round(metric_uncertainty,precision)
			self._precision = precision
		else:
			raise ValueError("Input `metric_name`: "+metric_name+" is not valid.")

	def __str__(self):
		return (self._name + ' : ' + str(self._metric_value))

	@property
	def name(self):
		return(self._name)

	@property
	def type(self):
		return (self._type)

	@property
	def model_segment_key(self):
		return (self._model_segment_key)

	@property
	def metric_value(self):
		return (self._metric_value)

	@property
	def adjustment(self):
		return (self._adjustment)

	@property
	def adjustment_justification(self):
		return (self._adjustment_justification)

	@property
	def uncertainty(self):
		return (self._uncertainty)

	@property
	def precision(self):
		return (self._precision)

	def setMetricValue(self,new_value):
		self._metric_value = round(new_value,self._precision)

	def setModelSegment(self,metric_segment_key):
		utilities.checkDataType(metric_segment_key, (str,list))
		self._model_segment_key = metric_segment_key

	def setUncertainty(self,input_uncertainty):
		self._uncertainty = round(input_uncertainty,self._precision)

class PD(Metric):
	# Properties
	__time_horizon = None

	# Methods
	def __init__(
		self,
		metric_value,
		time_horizon,
		metric_segment_key=None,
		metric_uncertainty=0,
		metric_adjustment=0,
		metric_adjustment_justification='',
		precision=None
	):
		# Initialize parent class properties
		Metric.__init__(
			self,
			metric_name='PD',
			metric_value=metric_value,
			metric_segment_key=metric_segment_key,
			metric_uncertainty=metric_uncertainty,
			metric_adjustment=metric_adjustment,
			metric_adjustment_justification=metric_adjustment_justification,
			precision=precision
		)

		# Validate metric value range
		if (metric_value<0) or (metric_value>1):
			raise ValueError('Input `metric_value` is NOT a percent.')

		# Assign member properties
		utilities.checkDataType(time_horizon, str)
		if time_horizon in utilities.PERIOD_FREQUENCY_MAP.keys():
			self.__time_horizon = time_horizon
		else:
			raise ValueError('Incorrect input `time_horizon`.')

	@property
	def time_horizon(self):
		return (self.__time_horizon)

	def convertPDTimeHorizon(self,target_time_horizon, inplace=False):
		if isinstance(target_time_horizon,int):
			if target_time_horizon in list(utilities.PERIOD_FREQUENCY_MAP.values()):
				new_pd = utilities.PDPeriodConverter(
					self.metric_value,
					utilities.PERIOD_FREQUENCY_MAP[self.__time_horizon],
					target_time_horizon
				)
				if inplace:
					self.setMetricValue(new_pd)
					self.__time_horizon = [
						item for item in utilities.PERIOD_FREQUENCY_MAP if utilities.PERIOD_FREQUENCY_MAP[item]==1
					][0]
				return(new_pd)
			else:
				raise ValueError("Input `target_time_horizon` is not recognized.")
		elif isinstance(target_time_horizon, str):
			if target_time_horizon in utilities.PERIOD_FREQUENCY_MAP.keys():
				new_pd = utilities.PDPeriodConverter(
					self.metric_value,
					utilities.PERIOD_FREQUENCY_MAP[self.__time_horizon],
					utilities.PERIOD_FREQUENCY_MAP[target_time_horizon]
				)
				if inplace:
					self.setMetricValue(new_pd)
					self.__time_horizon = target_time_horizon
				return (self)
			else:
				raise ValueError("Input `target_time_horizon` is not recognized.")
		else:
			raise ValueError("Input `target_time_horizon` is of the wrong data type. Expects str of int.")

class LGD(Metric):
	# Properties
	__downturn_stress_level = None
	__downturn_lgd_intercept = None
	__downturn_lgd_factor = None

	# Methods
	def __init__(
		self,
		metric_value,
		downturn_stress_level=0,
		downturn_lgd_intercept=None,
		downturn_lgd_factor=None,
		metric_segment_key=None,
		metric_uncertainty=0,
		metric_adjustment=0,
		metric_adjustment_justification='',
		precision=None
	):
		# Initialize parent class properties
		Metric.__init__(
			self,
			metric_name='LGD',
			metric_value=metric_value,
			metric_segment_key=metric_segment_key,
			metric_uncertainty=metric_uncertainty,
			metric_adjustment=metric_adjustment,
			metric_adjustment_justification=metric_adjustment_justification,
			precision=precision
		)

		# Validate metric value range
		if (metric_value < 0) or (metric_value > 1):
			raise ValueError('Input `metric_value` is NOT a percent.')

		# Validate downturn LGD intercept
		if downturn_lgd_intercept is not None:
			utilities.checkDataType(downturn_lgd_intercept, (int, float))
			if not (0 <= downturn_lgd_intercept <= 1):
				raise ValueError("Input `downturn_lgd_intercept` is not a percent.")
		else:
			downturn_lgd_intercept = CONFIG['DOWNTURN_LGD_INTERCEPT']
		self.__downturn_lgd_intercept = downturn_lgd_intercept

		# Validate downturn LGD factor
		if downturn_lgd_factor is not None:
			utilities.checkDataType(downturn_lgd_factor, (int, float))
			if not (0 <= downturn_lgd_factor <= 1):
				raise ValueError("Input `downturn_lgd_factor` is not a percent.")
		else:
			downturn_lgd_factor = CONFIG['DOWNTURN_LGD_FACTOR']
		self.__downturn_lgd_factor = downturn_lgd_factor

		# Validate downturn stress level
		utilities.checkDataType(downturn_stress_level, (int, float))
		if not (0 <= downturn_stress_level <= 1):
			raise ValueError("Input `downturn_stress_level` is not a percent.")
		else:
			self.__downturn_stress_level = downturn_stress_level

	def setDownturnStressLevel(self,downturn_stress_level, inplace=False):

		stressLGD = lambda lgd, intercpt, factor, stress_level: lgd + stress_level * (intercpt + (lgd * (factor - 1)))
		relaxLGD = lambda lgd, intercpt, factor, stress_level: (lgd - stress_level * intercpt) / (
		1 + stress_level * (factor - 1))


		if not (0 <= downturn_stress_level <= 1):
			raise ValueError("Input `downturn_stress_level` is not a percent.")

		lgd_relax_0 = relaxLGD(
			self.metric_value,
			self.__downturn_lgd_intercept,
			self.__downturn_lgd_factor,
			self.__downturn_stress_level
		)
		lgd_temp = stressLGD(
			lgd_relax_0,
			self.__downturn_lgd_intercept,
			self.__downturn_lgd_factor,
			downturn_stress_level
		)

		if inplace:
			self.__downturn_stress_level = downturn_stress_level
			self.setMetricValue(lgd_temp)

		return(round(lgd_temp,self.precision))

class EAD(Metric):
	# Properties

	# Methods
	def __init__(
		self,              
		metric_value,
		metric_segment_key=None,
		metric_uncertainty=0,
		metric_adjustment=0,
		metric_adjustment_justification='',
		precision=None
	):
		# Initialize parent class properties
		Metric.__init__(
			self,
			metric_name='EAD',
			metric_value=metric_value,
			metric_segment_key=metric_segment_key,
			metric_uncertainty=metric_uncertainty,
			metric_adjustment=metric_adjustment,
			metric_adjustment_justification=metric_adjustment_justification,
			precision=precision
		)

		# Validate metric value range
		if (metric_value<0):
			raise ValueError('Input `metric_value` is not bounded.')

   
class ALLLCOVERAGE(Metric):
	# Properties

	# Methods
	def __init__(
		self,
		metric_value,
		metric_segment_key=None,
		metric_uncertainty=0,
		metric_adjustment=0,
		metric_adjustment_justification='',
		precision=None
	):
		# Initialize parent class properties
		Metric.__init__(
			self,
			metric_name='ALLLCOVERAGE',
			metric_value=metric_value,
			metric_segment_key=metric_segment_key,
			metric_uncertainty=metric_uncertainty,
			metric_adjustment=metric_adjustment,
			metric_adjustment_justification=metric_adjustment_justification,
			precision=precision
		)

		# Validate metric value range
		if (metric_value<0) or (metric_value>1):
			raise ValueError('Input `metric_value` is not a percent.')   

class CONTINGENTRESERVE(Metric):
	# Properties

	# Methods
	def __init__(
		self,
		metric_value,
		metric_segment_key=None,
		metric_uncertainty=0,
		metric_adjustment=0,
		metric_adjustment_justification='',
		precision=None
	):
		# Initialize parent class properties
		Metric.__init__(
			self,
			metric_name='CONTINGENTRESERVE',
			metric_value=metric_value,
			metric_segment_key=metric_segment_key,
			metric_uncertainty=metric_uncertainty,
			metric_adjustment=metric_adjustment,
			metric_adjustment_justification=metric_adjustment_justification,
			precision=precision
		)

		# Validate metric value range
		if (metric_value<0) or (metric_value>1):
			raise ValueError('Input `metric_value` is not a percent.')






































