#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
This module contains a series of utility functions that support the package.

Example
-------
Here is a useful example

"""
import sys
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import datetime
import dateutil
import math
import re
import os
import pandas as pd
import numpy as np

# MAPPINGS
PERIOD_FREQUENCY_MAP = {
    'monthly': 1,
    'quarterly': 3,
    'yearly': 12
}

SCENARIO_SEVERITY_LEVELS = {
    "BL":"BASE",
    "BA":"BASE",
    "Base":"BASE",
    "BASE":"BASE",
    "IC":"ADVERSE",
    "AD":"ADVERSE",
    "Adverse":"ADVERSE",
    "ADVERSE":"ADVERSE",
    "SA":"STRESS",
    "STRESS":"STRESS"
}


# LAMBDA HELPERS
str2date = lambda x : np.nan if x == '.' else datetime.datetime.strptime(x, '%m/%d/%Y')
"""Returns a string object representing a date(%m/%d/%Y) to a datetime.datetime instance. """

date2str = lambda x : x.strftime("%m/%d/%Y")
"""Returns a datetime.datetime instance into a string formatted date(%m/%d/%Y)"""

float2str = lambda x : str('%8.10f' % x) if isinstance(x,(float, np.float, np.float16, np.float32, np.float64)) else None
"""Returns a string representing a float in plain notation, not scientific up to 10 decimal places."""

addMonths2date = lambda in_date,m : monthEndDate(in_date+dateutil.relativedelta.relativedelta(months=m))
"""Given a datetime.datetime instance and a number of months, it returns the result of adding both."""

PDPeriodConverter = lambda pd,in_period,out_period : round(1-((1-pd)**(float(out_period/in_period))),10)
"""Returns converted PD rate from a number of input periods to output periods(ex: quarterly to month PD rate)."""

checkDataType = lambda var,data_type : (
    True
    if isinstance(var,data_type)
    else raise_(TypeError("Expected "+str(data_type)+". Got "+str(type(var))+"."))
)
"""Returns whether or not a variable is of a given type."""

format_percent = lambda x : '{:3.2f}%'.format(x*100) if isinstance(x,(int,float)) else None
"""Returns the formatted percent of an int or float."""

listToHTMLWrapperTag = lambda ls,wrapper_tag : ''.join(['<'+str(wrapper_tag)+'>' + item + '</'+str(wrapper_tag)+'>' for item in ls])
"""Returns the string represenation of a list of elements `ls` wrapped around a given html `wrapper_tag`."""

def monthEndDate(date):
    if date.month == 12:
        return (date.replace(day=31))
    return (date.replace(month=date.month+1, day=1) - datetime.timedelta(days=1))
"""Returns month end date """

def make_path(path):
    if not os.path.exists(path):
        os.makedirs(path)
"""create path if path doesn't exist """


def userInputPrompt(message: str, valid_options: (tuple, list)=None):
    response=None
    checkDataType(message, str)
    if valid_options is not None:
        checkDataType(valid_options, (tuple, list))

    # Case when there are restricted choices
    if valid_options is not None:
        response = input(message)
        while response not in valid_options:
            print("Input is not a valid option {}".format(str(valid_options)))
            response = input(message)
    else:
        response = input(message)

    return(response)


def to_sql_array(A: list) -> str:
    """
    This function transforms an input array into a str representation
    of the corresponding SQL array

    Parameters
    ----------
    A: (list) some input array

    Returns
    -------
    (str) str containing the SQL array
    """
    s = '('
    for h in A:
        wrap_char = ("'" if isinstance(h, str) else "")
        s += (wrap_char + str(h) + wrap_char + ',')
    s = s.strip(',')
    s += ')'
    return(s)


def daysDifference(date_a, date_b):
    """

    Parameters
    ----------
    date_a
    date_b

    Returns
    -------

    """
    if isinstance(date_a, datetime.datetime):
        diff = (date_a - date_b)
        if pd.isnull(diff):
            return pd.NaT
        else:
            return(int(diff.days))
    else:
        raise(Exception("Expected 2 datetime.datetime instances."))

def datetimeDiffInMonth(date_a, date_b):
    """
    This function calculates difference of two dates in months
    """
    if (isinstance(date_a, datetime.datetime) and isinstance(date_b, datetime.datetime)):
        if date_a <= date_b:
            diff_month = (date_b.month + 12 * date_b.year) - (date_a.month + 12 * date_a.year) 
            return(int(diff_month))
        else:
            raise ValueError("date_a should be a earlier date than date_b")
    else:
        raise ValueError("date_a or date_b is not datetime type")
             
def datetimeDiffInQuarter(date_a, date_b):
    """
    This function calculates difference of two dates in quarters
    (note: both dates should be end of quarter date)   
    """
    diff_month = datetimeDiffInMonth(date_a, date_b)
    if (date_a.month in (3,6,9,12)) and (date_b.month in (3,6,9,12)):
        return(int(diff_month/3))
    else:
        raise ValueError("Invalid date_a or date_b: should be end-of-quarter date(Mar, Jun, Sep, Dec)")     

##
## Handling exceptions
##
def raise_(ex):
    """
    This function raises a passed-in exception.

    Parameters
    ----------
    ex (Exception) : any kind of exception
    """
    raise ex

class VirtualException(BaseException):
    """
    This class provides an abstraction of a virtual exception. This exception is raised when the derived classes
    of a given parent don't implement a specific required method.
    """
    def __init__(self):
        BaseException.__init__(self,"Missing derived class implementation.")

##
## Date functions and classes
##
def str2numeric(s):
    """
    This function transforms a string representing a numeric value into a number type instance.

    Parameters
    ----------
    s (str) : input str representing a numeric type

    Returns
    -------
    (int,float) : the numeric type instance of the given input str `s`
    """
    try:
        return int(s)
    except ValueError:
        return float(s)

def date2XQYY(s):
    """
    This function converts a given datetime instance to a string 
    with corresponding quarter and year.

    Parameters
    ----------
     (datetime.datetime) : an end-of-month end-of-quarter datetime instance 

    Returns
    -------
    s (str) : string in the following date format yyyyQq (ex: `4Q15`)

    Examples
    --------
    >>> date2XQYY(datetime.datetime(2015, 12, 31, 0, 0))
    '4Q15'
    """
    if isinstance(s, datetime.datetime):
        quarter = math.ceil(s.month/3)
        year = int(str(s.year)[-2:])
        response = '{:d}Q{:d}'.format(quarter,year)
    else:
        raise TypeError('Input date is not a datetime.')
        
    return response

def YYYYQ2Date(s):
    """
    This function converts a given string representing a year quarter date to a datetime instance
    corresponding with the end-of-month end-of-quarter of the input string.

    Parameters
    ----------
    s (str) : string in the following date format yyyyQq (ex: `2015Q4`)

    Returns
    -------
    (datetime.datetime) : an end-of-month end-of-quarter datetime instance for yyyyQq

    Examples
    --------
    >>> YYYYQ2Date('2015Q4')
    datetime.datetime(2015, 12, 31, 0, 0)
    """
    if not bool(re.search(
        pattern='[0-9]{4}[Q][1-4]',
        string=s,
        flags=re.IGNORECASE
    )):
        raise ValueError('Regex check failed.')
    y = int(s.split('Q')[0])
    if y < 1800 or y > 2500:
        raise ValueError('Year out of range.')
    m = int(s.split('Q')[1])*3
    if m not in [3,6,9,12]:
        raise ValueError('Invalid month value.')

    response = datetime.datetime(y, m, 1)
    response = (response + pd.offsets.MonthEnd(0)).to_datetime()
    return response
    
def generateDateSequence(as_of_date, forecast_periods, m_interval=1, include_init=False):
    """
    This function generates a sequence of dates in `m_interval` monthly
    intervals given a starting date and a number of periods.

    Parameters
    ----------
    as_of_date (datetime, str) : start date of the sequence, if str use format %m/%d/%Y
    forecast_periods (int) : number of periods to generate
    m_interval (int) : interval in months between dates
    include_init (bool) : whether or not to include the starting date

    Returns
    -------
    (list(datetime)) :  list of consecutive datetime objects

    Example
    -------
    >>> generateDateSequence('12/31/2015', 2, include_init=True)
    [datetime.datetime(2015, 12, 31, 0, 0),
     datetime.datetime(2016, 1, 31, 0, 0)]
    """
    # Ensure correct input value types
    if not isinstance(forecast_periods, (int, np.int, np.int0, np.int8, np.int16, np.int32, np.int64)):
        raise TypeError('Input forecast_periods is not an instance of type int.')
    if not isinstance(m_interval, (int, np.int, np.int0, np.int8, np.int16, np.int32, np.int64)):
        raise TypeError('Input m_interval is not an instance of type int.')
    if not isinstance(include_init, (int, np.int, np.int0, np.int8, np.int16, np.int32, np.int64)):
        raise TypeError('Input include_init is not an instance of type bool.')

    # Ensure correct  month end input date and data type
    if isinstance(as_of_date, datetime.datetime):
        as_of_date = (as_of_date + pd.offsets.MonthEnd(0)).to_datetime()
    elif isinstance(as_of_date, str):
        as_of_date = (
                    str2date(as_of_date) +
                    pd.offsets.MonthEnd(0)
                    ).to_datetime()
    else:
        raise TypeError('Input as_of_date is not of datetime or str(%m/%d/%Y) types.')

    response =  pd.date_range(
                        as_of_date,
                        periods=forecast_periods+1,
                        freq=str(m_interval)+'M'
                        ).to_pydatetime()

    if include_init:
        return response
    else:
        return response[1:]

def convertForecastPeriods(n, freq_0, freq_1):
    if isinstance(n, int) and isinstance(freq_0, str) and isinstance(freq_1, str):
        if freq_0 == 'monthly':
            if freq_1 == 'monthly':
                return (n)
            elif freq_1 == 'quarterly':
                if n >= 3 and n % 3 == 0:
                    return (int(n / 3))
            elif freq_1 == 'annually':
                if n >= 12 and n % 12 == 0:
                    return (int(n / 12))
            else:
                raise ValueError('Incorrect freq_1 value. Expects monthly, quarterly or annually.')
        elif freq_0 == 'quarterly':
            if freq_1 == 'monthly':
                return (n * 3)
            elif freq_1 == 'quarterly':
                return (n)
            elif freq_1 == 'annually':
                if n >= 4 and n % 4 == 0:
                    return (int(n / 4))
            else:
                raise ValueError('Incorrect freq_1 value. Expects monthly, quarterly or annually.')
        elif freq_0 == 'annually':
            if freq_1 == 'monthly':
                return (n * 12)
            elif freq_1 == 'quarterly':
                return (n * 4)
            elif freq_1 == 'annually':
                return (n)
            else:
                raise ValueError('Incorrect freq_1 value. Expects monthly, quarterly or annually.')
        else:
            raise ValueError('Incorrect freq_0 value. Expects monthly, quarterly or annually.')
    else:
        raise TypeError('Inputs are of the wrong data type.')


def vintagePeriodDateMonthlyPairGeneratorFromQuarterly(as_of_date,current_vintage):
    if addMonths2date(current_vintage, -3) == as_of_date:
        s_1 = generateDateSequence(addMonths2date(current_vintage, -3), 3, m_interval=1, include_init=True)
    else:
        s_1 = generateDateSequence(addMonths2date(current_vintage, -2), 2, m_interval=1, include_init=True)
    s_2 = generateDateSequence(addMonths2date(current_vintage, -2), 2, m_interval=1, include_init=True)
    df = pd.DataFrame(columns=['PeriodDate', 'Vintage'])

    for vintage in s_1:
        if vintage == as_of_date:
            sub_period_date = s_2[s_2 > vintage]
        else:
            sub_period_date = s_2[s_2 >= vintage]

        df_to_append = pd.DataFrame(data={
            'PeriodDate': sub_period_date,
            'Vintage': [vintage] * len(sub_period_date)
        })
        df = df.append(
            other=df_to_append,
            ignore_index=True
        )

    return(df)

def monthlyVintagePeriodDatePairFromQuarterly(as_of_date,period_date,current_vintage):    
    if monthEndDate(addMonths2date(current_vintage, -3)) == as_of_date:
        vintage_date = generateDateSequence(addMonths2date(current_vintage, -3), 3, m_interval=1, include_init=True)
    else:
        vintage_date = generateDateSequence(addMonths2date(current_vintage, -2), 2, m_interval=1, include_init=True)
        
    period_date = generateDateSequence(addMonths2date(period_date, -2), 2, m_interval=1, include_init=True)   
    df = pd.DataFrame(columns=['PeriodDate', 'Vintage'])

    for date in vintage_date:
        if date == as_of_date:
            sub_period_date = period_date[period_date > date]
        else:
            sub_period_date = period_date[period_date >= date]

        df_to_append = pd.DataFrame(data={
            'PeriodDate': sub_period_date,
            'Vintage': [date] * len(sub_period_date)
        })
        df = df.append(
            df_to_append,
            ignore_index=True
        )
    return(df) 

# File IO
def readJSON(path_to_json_file):
    import os
    import json
    if os.path.exists(path_to_json_file) & os.path.isfile(path_to_json_file):
        file = open(path_to_json_file, 'r')
        if not file._checkSeekable():
            raise Exception("Input file '" + file.name + "' is not seekable.")
        if not file._checkReadable():
            raise Exception("Input file '" + file.name + "' is not readable.")
        with file as data_file:
            parsed_dict = json.load(fp=data_file, encoding='utf-8')
        return parsed_dict
    else:
        raise Exception('Input JSON file does not exist or is not reachable.')

def aggregateCF(
    working_directory: str,
    output_file_path: str = None,
    file_ending: str = "SB_COMM_LOSS",
    debug=True
) -> pd.DataFrame:
    """
    This function aggregates all contributor files that have the specified
    `file_ending` in a given `working_directory`. Files are expected to be in
    csv format. If an optional `output_filename` is provided, the aggregated
    dataframe will be saved as a csv file in the specified `working_directory`.
    ---------------------------------------------------------------------------

    Args
    ----
        working_directory (str) : path to contributor files location
        output_filename (str) : name for the output aggregated file,
                                default is an empty string
        file_ending (str) : file ending character for filtering,
                            default 'SB_COMM_LOSS'

    Returns
    -------
        (DataFrame) : returns a DataFrame that aggregates all contributor files
    """
    # Declare empty dataframe
    agg_cf = pd.DataFrame()

    # Clean working directory
    if working_directory[-1] != '/':
        working_directory += '/'
    if debug:
        print("Working directory : " + working_directory)

    # Process aggregation
    files = [f for f in os.listdir(working_directory) if os.path.isfile(working_directory+f)]
    if debug:
        print("All files:")
        print(files)
    for f in files:
        if bool(re.search("(" + file_ending + ".csv)$", f, re.IGNORECASE)):
            if debug:
                print("Selected file : " + str(f))
            agg_cf = agg_cf.append(pd.read_csv(working_directory+f))

    # Output file
    if output_file_path is not None:
        agg_cf.to_csv(
            path_or_buf=output_file_path,
            index=False
        )

    # Return results
    return(agg_cf)