"""
SAMPLE USE


session = CCARSession(
    session_id='test session'
)

session.logger.addItem(LogItem(type='INFO',message='Adding PD_23 chunk',context='CCAR SBB Logit Model'))

session.logger.data

# session.logger.reset()


session.contributor_file_generator.addCFChunk(
    as_of_date=datetime.datetime(2016,3,31),
    forecast_periods=27,
    forecast_periods_frequency='monthly',
    model_segment='PD_23',
    rate_name='PD',
    rate_type='4',
    vintage_differentiation=True,
    model_output_rate=[0.0019373875],
    uncertainty_adjustment_rate=0.0,
    mgmt_adjustment_rate=0.0,
    scenario='Base'
)

session.contributor_file_generator.data

"""

import sys
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.contributorfile.contributorfile import ContributorFile, ContributorFileGenerator
import datetime
import subprocess

class Session:
    """

    """
    # Properties
    _session_id = None
    _logger = None
    _session_date = None
    _user = None

    # Methods
    def __init__(
        self,
        session_id='default_session_id',
        session_date=None,
        user=None
    ):
        if isinstance(session_id, str):
            self._session_id = session_id
            if isinstance(session_date,datetime.datetime) and (session_date is not None):
                self._session_date = session_date
            else:
                self._session_date = datetime.datetime.now()
            self._logger = Logger(
                logger_id=self._session_id,
                logger_date=self._session_date,
                user=user
            )
            self._logger.reset()
            self._logger.add(
                type='INFO',
                message='Starting new session for date {}'.format(str(self._session_date)),
                context='CCAR Session Initialization : ' + session_id
            )
            try:
                current_git_hash = subprocess.check_output(["git", "describe", "HEAD"]).decode("utf-8").strip("\n")
                self._logger.add(
                    type='INFO',
                    message='Current GIT commit hash: {}'.format(current_git_hash),
                    context='CCAR Session Initialization : ' + session_id
                )
            except:
                pass
        else:
            raise TypeError("Input session_name is not a str instance.")

    @property
    def session_id(self):
        return self._session_id

    @property
    def session_date(self):
        return self._session_date

    @property
    def logger(self):
        return self._logger

    @property
    def user(self):
        return self._user


class CCARSession(Session):
    """

    """
    # Properties
    __contributor_file_generator = None

    # Methods
    def __init__(
        self,
        session_id='default_session_id',
        session_date=None,
        user=None,
        contributor_file_meta_content=True
    ):
        # Initialize parent class properties
        Session.__init__(
            self,
            session_id=session_id,
            session_date=session_date,
            user=user
        )

        self._logger.add(
            type='INFO',
            message='Creating new contributor file generator...',
            context='CCAR Session Initialization : '+session_id
        )
        if isinstance(contributor_file_meta_content,bool):
            if contributor_file_meta_content:
                self._logger.add(
                    type='INFO',
                    message='Contributor file meta content allowed.',
                    context='CCAR Session Initialization : ' + session_id
                )
        else:
            raise TypeError("Input contributor_file_meta_content is not a bool type.")

        self.__contributor_file_generator = ContributorFileGenerator(
            run_id=self._session_id,
            allow_meta_content=contributor_file_meta_content,
            verbose=False,
            logger=self._logger
        )

    @property
    def contributor_file_generator(self):
        return self.__contributor_file_generator