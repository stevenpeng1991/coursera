"""


loggr = Logger(logger_id="testing logger 3")

loggr.addItem(LogItem(type='INFO',message='some info message',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='INFO',message='some info message2',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='INFO',message='some info message3',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='INFO',message='some info message4',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='INFO',message='some info message5',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='INFO',message='some info message6',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='WARN',message='some warn message2',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='WARN',message='some warn message3',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='WARN',message='some warn message4',context='CCAR SBB Logit Model'))
loggr.addItem(LogItem(type='ERROR',message='some error happened',context='CCAR SBB Logit Model'))

loggr.data

loggr.printItems()

loggr.reset()


loggr.toFile(path_to_directory="C:/Users/n813863/Documents/", debug=True)

"""


import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import datetime
import getpass
import time
import os
import pandas as pd


class LogItem:
    """
    """
    # Properties
    __type = None
    __message = None
    __user = None
    __timestamp = None
    __context = None
    __context_max_len = None
    __model_id = None
    __valid_types = ['DEBUG','INFO','WARN','ERROR']

    # Methods
    def __init__(
        self,
        type,
        message,
        context,
        user=None,
        context_max_len=50,
        model_id=None,
        verbose=True
    ):
        if isinstance(type, str):
            if type in self.__valid_types:
                self.__type = type
            else:
                raise ValueError("Invalid message type.")
        else:
            raise TypeError("Invalid message type data type. Expects a str.")

        if isinstance(message,str):
            self.__message = message
        else:
            raise TypeError("Invalid message data type. Expects a str.")

        if model_id is not None:
            if isinstance(model_id, str):
                self.__model_id = model_id
            else:
                raise TypeError("Invalid model_id data type. Expects a str.")

        if isinstance(context, str):
            self.__context = context
        else:
            raise TypeError("Invalid context data type. Expects a str.")

        if (user is None) or (not isinstance(user,str)):
            self.__user = getpass.getuser()
        else:
            self.__user = user
        self.__timestamp = datetime.datetime.now()

        if isinstance(context_max_len,int):
            self.__context_max_len = context_max_len
        else:
            raise TypeError("Input max context length is not an int instance.")

        if verbose:
            print(str(self))

    def __str__(self):
        return(
            self.__user +
            " | " +
            "[" +
            self.__timestamp.strftime("%Y-%m-%d %H:%M:%S") +
            "] | " +
            str(self.__model_id) +
            " | " +
            self.__context[0:self.__context_max_len] +
            " | " +
            self.__type +
            " | " +
            self.__message
        )

    @property
    def type(self):
        return self.__type

    @property
    def message(self):
        return self.__message

    @property
    def user(self):
        return self.__user

    @property
    def timestamp(self):
        return self.__timestamp

    @property
    def context(self):
        return self.__context

    @property
    def model_id(self):
        return self.__model_id

    @property
    def valid_types(self):
        return self.__valid_types

    def getDict(self):
        return {
            "USER": self.__user,
            "TIMESTAMP": self.__timestamp,
            "MODEL_ID": self.__model_id,
            "CONTEXT": self.__context,
            "TYPE":self.__type,
            "MESSAGE":self.__message
        }


class Logger:
    """

    """
    # Properties
    __items = None
    __logger_id = None
    __logger_date = None
    __user = None

    # Methods
    def __init__(self,logger_id='default', logger_date=None, user=None):
        if isinstance(logger_id,str):
            self.__logger_id = logger_id
        else:
            raise TypeError("Input logger_id is not a str instance.")

        if logger_date is None:
            self.__logger_date = datetime.datetime.now()
        elif isinstance(logger_date,datetime.datetime):
            self.__logger_date = logger_date
        else:
            raise TypeError('Input logger_date is of the wrong type.')

        self.__items = []

        if user is not None:
            if isinstance(user, str):
                self.__user = user
            else:
                raise TypeError("Input user should be of str type.")
        else:
            self.__user = None


    def addItem(self,item):
        if isinstance(item,LogItem):
            self.__items.append(item)
        else:
            raise TypeError("Input item is not of type LogItem.")

    def add(
        self,
        type,
        message,
        context,
        user=None,
        context_max_len=50,
        model_id=None,
        verbose=True
    ):
        if user is None:
            tmp_user = self.__user
        else:
            tmp_user = None

        self.addItem(LogItem(
            type=type,
            message=message,
            context=context,
            user=tmp_user,
            model_id=model_id,
            context_max_len=context_max_len,
            verbose=verbose
        ))

    @property
    def items(self):
        return self.__items

    @property
    def logger_id(self):
        return self.__logger_id

    def printItems(self):
        print("="*(len(self.__logger_id)+6))
        print("Log : "+self.__logger_id)
        print("=" * (len(self.__logger_id) + 6))
        for i in self.__items:
            print(i)

    def reset(self):
        self.__items = []

    @property
    def data(self):
        df = pd.DataFrame([i.getDict() for i in self.items])
        df['RUN_ID'] = self.__logger_id
        df['RUN_DATE'] = self.__logger_date
        return(df)

    def toFile(self,path_to_directory, debug=False):
        dir_name = path_to_directory
        if debug: print("dir_name: "+str(dir_name))
        if not (os.path.exists(dir_name) & os.path.isdir(dir_name)):
            if debug: print("Creating new directory folder for : {}".format(dir_name))
            os.makedirs(dir_name)
        dir = dir_name + '/' if dir_name[-1] != '/' else dir_name
        if debug: print("dir: " + str(dir))
        filename = self.logger_id + \
            '_' + \
             datetime.datetime.now().strftime("%d-%m-%y_%H-%M%p") + \
            "_log.csv"
        if debug: print("filename: " + str(filename))
        path_to_save_location = dir+filename
        if debug: print("path_to_save_location: " + str(path_to_save_location))
        data_to_save = self.data
        data_to_save.to_csv(
            path_or_buf=path_to_save_location,
            index=False
        )


def timer(logger_instance=None, model_id = None, context=None):
    """
    This function server as a timer clock decorator for any given function.

    Parameters
    ----------
    f (function) : some function

    Returns
    -------
    (function) : timing clock wrapper function for `f`

    Examples
    --------
    some_logger = Logger()
    @timer(logger_instance=some_logger)
    def some_f(n):
        num_list = []
        for num in (range(0, n)):
            num_list.append(num)
        return sum(num_list)
    """
    def first_wrapper(f):
        def second_wrapper(*args, **kwargs):
            if logger_instance is None or context is None:
                return f(*args, **kwargs)
            else:
                t0 = time.time()
                result = f(*args, **kwargs)
                t1 = time.time()
                runtime = round((t1 - t0),5)
                logger_instance.addItem(LogItem(
                    type='INFO',
                    message='Execution completed in '+str(runtime)+' s.',
                    model_id=model_id,
                    context=context
                ))
                return result
        return second_wrapper
    return first_wrapper










































