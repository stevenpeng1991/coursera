#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
SAMPLE USE

CREATE TABLE `MacroVariables` (
	`Period`	NUMERIC NOT NULL,
	`Indicator`	TEXT NOT NULL,
	`Value`	NUMERIC,
	`Scenario`	TEXT NOT NULL,
	`Title`	TEXT NOT NULL,
	`AsOfBookDate`	NUMERIC NOT NULL,
	`GeographicalScope`	TEXT NOT NULL,
	`Frequency`	TEXT NOT NULL,
	`Source`	TEXT NOT NULL,
	PRIMARY KEY(Period,Indicator,Scenario,Title,AsOfBookDate,GeographicalScope,Frequency)
);

SELECT 
	MacroVariables.Period, 
	MacroVariables.Value,
	MacroVariables.AsOfBookDate
FROM MacroVariables
WHERE 
	MacroVariables.Period BETWEEN '2016-03-31' AND '2019-12-31'
	AND 
	MacroVariables.Indicator = 'FLBU_US'
	AND
	MacroVariables.Scenario = 'Base'
	AND
	MacroVariables.GeographicalScope = 'National&Regional'
	AND
	MacroVariables.Frequency = 'quarterly'
	AND
	MacroVariables.AsOfBookDate = '2016-03-31'
 
"""
import sys
wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
if wd not in sys.path:
    sys.path.append(wd)
import datetime
import CIFI.controllers.utilities.utilities as utilities
import CIFI.models.macrovariables.macrovariables as macrovariables


macrovariables.uploadMacroVariablesSQLite(
    sqlite_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/ccar.db',
    sqlite_table_name='MacroVariables',
    csv_file_path='I:/CRMPO/CCAR/2Q16/2 - Scenarios/MC_SA_quarterly_full.csv',
    input_scenario='MC_SA',
    input_title='MidCycle16',
    input_as_of_book_date=datetime.datetime(2016, 6, 30),
    input_geo_scope='National&Regional', 
    input_frequency='quarterly', 
    input_source='Moodys'
)


