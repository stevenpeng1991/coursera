"""
SAMPLE USE
----------
SP20_ccarBASE_BW = balancewalk.balanceWalk(
    cf_data = cf_101,
    anchor_data=anchor_data,
    scenario_list=['STAGF'],
nco_data_path=CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_PATH"],
    process_ALLL_balances = True,
    debug = True
)

AS_OF_DATE=datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,3,31)
SCENARIO_DATE = datetime.datetime(2017,3,31)
SCENARIO='STAGF'
SCENARIO_SEVERITY_LEVEL='ADVERSE'
EJM_SCENARIO_SEVERITY_LEVEL='ADVERSE'
STRESS_TESTING_CYCLE='IFRS92017'
FORECAST_PERIODS=27
FILE_VERSION=1
EJM_MASTER_FILE_PATH='I:/CRMPO/CCAR/1Q17/5 - EJMs/Commercial/COMMERCIAL_EJM_MASTER_1Q17.xlsm'
INDUSTRYTAG_FILE='I:\\CRMPO\\CCAR\\1Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Mar.xlsx'

USER_N_NUMBER='N'
SESSION_ID_NAME='TEST'
--------------------------
 Dump and load container
--------------------------
# Dump 
_pickle.dump(bw_output, open("C:/Users/n000000/Documents/bw_output.p", 'wb'))
# Load
cf_inventory = _pickle.load(open("C:/Users/n000000/Documents/xxx.p", 'rb'))

"""
import os
import sys
global WD
WD = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if WD not in sys.path:
    sys.path.append(WD)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import getpass
import _pickle
import time
import pandas as pd
from CIFI.config import CONFIG

##
## IMPORT MODULES (MODELS AND EJMS)
##
from CIFI.controllers.models.creconstruction17 import CREConstruction
from CIFI.controllers.models.logitmodel import TwoFLogitModel
from CIFI.controllers.ejm.ejmmaster import EJMGenerator, ejmDictionaryGenerator
from CIFI.controllers.models.riskratingmodel import RiskRatingModel
from CIFI.controllers.models.gcbindustry import GCBModel
from CIFI.controllers.models.cniriskrating import CNIModel

## IMPORT Balance Walk module
from CIFI.sensitivity import balancewalk

def main():
    ##
    ## GLOBAL PARAMS
    ##
    while True:
        try:
            AS_OF_DATE = datetime.datetime.strptime(
                input(
                    "Enter run as-of-date (%Y-%m-%d): "
                ),
                "%Y-%m-%d"
            )
        except ValueError as e:
            print(str(e))
            continue
        else:
            break
    while True:
        try:
            PORTFOLIO_SNAPSHOT_DATE = datetime.datetime.strptime(
                input(
                    "Enter run portfolio snapshot date (%Y-%m-%d): "
                ),
                "%Y-%m-%d"
            )
        except ValueError as e:
            print(str(e))
            continue
        else:
            break
    while True:
        try:
            SCENARIO_DATE = datetime.datetime.strptime(
                input(
                    "Enter run scenario date (%Y-%m-%d): "
                ),
                "%Y-%m-%d"
            )
        except ValueError as e:
            print(str(e))
            continue
        else:
            break
    while True:
        try:
            SCENARIO = str(input("Enter scenario name: "))  # DR_SA, DR_BASE
        except ValueError as e:
            print(str(e))
            continue
        else:
            break

    SCENARIO_SEVERITY_LEVEL = utilities.userInputPrompt(
        message="Enter scenario severity type (BASE, ADVERSE, STRESS): ",
        valid_options=('BASE', 'ADVERSE', 'STRESS')
    )

    EJM_SCENARIO_SEVERITY_LEVEL = utilities.userInputPrompt(
        message="Enter EJM scenario severity type (BASE, ADVERSE, STRESS, BHC_STRESS, BHC_ADVERSE, BHC_BASE): ",
        valid_options=('BASE', 'ADVERSE', 'STRESS', 'BHC_STRESS', 'BHC_ADVERSE', 'BHC_BASE')
    )
    
    while True:
        try:
            STRESS_TESTING_CYCLE = str(input("Enter stress testing cycle: "))
        except ValueError as e:
            print(str(e))
            continue
        else:
            break

    FORECAST_PERIODS = int(utilities.userInputPrompt(
        message="Enter number of forecast periods: ",
        valid_options=('3','27', '30', '36', '39', '42', '45')
    ))

    FILE_VERSION = int(utilities.userInputPrompt(
        message="Enter general file version: "
    ))                                                                           
        
    PROMPT_FOR_BLOCK_RUN_OPTION = True if utilities.userInputPrompt(
        message="Enter if you'd like to be prompted for each block run: [Y/N]",
        valid_options=('Y', 'N')
    ) == 'Y' else False

    # AS_OF_DATE = datetime.datetime(2016,12,31)
    # PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2016,11,30)
    # SCENARIO='DR_BASE' # DR_SA, DR_BASE
    # SCENARIO_SEVERITY_LEVEL="BASE" # BASE, ADVERSE, STRESS
    # STRESS_TESTING_CYCLE='DryRun2017'
    # FORECAST_PERIODS=27
    # PROMPT_FOR_BLOCK_RUN_OPTION = True


    USER_N_NUMBER = getpass.getuser()
    SESSION_ID_NAME = STRESS_TESTING_CYCLE + \
                        " - " + \
                        SCENARIO + \
                        " [" + \
                        SCENARIO_SEVERITY_LEVEL + \
                        "]" + \
                        " - V{}".format(str(FILE_VERSION))


    ##
    ## CREATE SESSION AND SHOPPING CART
    ##
    ccar_session = CCARSession(
        session_id=SESSION_ID_NAME,
        session_date=AS_OF_DATE,
        user=USER_N_NUMBER
    )
    cart = ModelShoppingCart(ccar_session=ccar_session)
    cf_inventory = {}

    # check if run_log directory exists
    utilities.make_path(WD + '/CIFI/Execution/run_log')
    utilities.make_path(WD + '/CIFI/Execution/cf_files')
    utilities.make_path(WD + '/CIFI/Execution/BalanceWalk')
        
    ##
    ## EJM_LOGIT SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Woud you like to run block ID 101? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
        (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
        try:
            CRE_construction_model_instance = CREConstruction(
                uncertainty_rate=0.,
                as_of_date=AS_OF_DATE,
                model_id="2016-SBNA-Loss-Commercial-CREConstruction",
                scenario=SCENARIO,
                scenario_date=SCENARIO_DATE,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS
            )
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="CRE Construction model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(CRE_construction_model_instance)

        try:
            TwoFLogitModel_CEVF_model_instance = TwoFLogitModel(
                uncertainty_rate=0.,
                as_of_date=AS_OF_DATE,
                scenario_date=SCENARIO_DATE,
                model_id='53 - Scenario Analysis Model - CEVF PD - SBNA',
                scenario=SCENARIO,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS,
            )
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="CEVF model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(TwoFLogitModel_CEVF_model_instance)
            
        # utilities.date2XQYY(PORTFOLIO_SNAPSHOT_DATE)    
        # Either enter the entire file path >>>I:/CRMPO/CCAR/1Q17/5 - EJMs/Commercial/COMMERCIAL_EJM_MASTER_1Q17.xlsm
        # or
        # just enter the file name >>> COMMERCIAL_EJM_MASTER_1Q17
        #   use PORTFOLIO_SNAPSHOT_DATE to get the corresponding foler 
        #   e.g PORTFOLIO_SNAPSHOT_DATE=datetime.datetime(2017,3,31)--> 1Q17 folder
        
        while True:
            EJM_MASTER_FILE_PATH=os.path.join("I:\\CRMPO\\DEPT\\CCAR\\",
                                              utilities.userInputPrompt(
                                                      message="Enter the EJM master file folder name (%QYY): "
                                              ),
                                              "5 - EJMs\\Commercial",
                                              "COMMERCIAL_EJM_MASTER_"+
                        utilities.userInputPrompt(
                        message="Enter the EJM master file suffix (%QYY): "
                    )+".xlsm") if utilities.userInputPrompt(
                        message="Would you like to specify the entire file path for EJM master file[Y/N]",
                        valid_options=('Y', 'N')
                    ) == 'N' else utilities.userInputPrompt(
                                    message="Enter the entire file path for EJM file: "
                                )        
            if os.path.exists(EJM_MASTER_FILE_PATH) & os.path.isfile(EJM_MASTER_FILE_PATH)==True:   
                break             
            else:
                print('File path entry is not valid. Please try again.')
                continue  
                           
        ccar_session.logger.add(
                type='INFO',
                message='EJM master file path : {}'.format(EJM_MASTER_FILE_PATH),
                context='SBNA-Loss-Commercial-EJM Model Specifics'
            )            

        try:
            commercial_ejm_generator = EJMGenerator(
                as_of_date = AS_OF_DATE,
                ejm_dictionary=ejmDictionaryGenerator(
                    asofdate = PORTFOLIO_SNAPSHOT_DATE,
                    version_date=AS_OF_DATE,
                    scenario_pairs = {
                        EJM_SCENARIO_SEVERITY_LEVEL:SCENARIO
                    },
                    pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
                    rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
                    ejm_master_file_path = EJM_MASTER_FILE_PATH,
                    debug=False,
                    logger=ccar_session._logger
                ),
                forecast_periods=FORECAST_PERIODS,
                process_additional_ead=False,
                debug=False,
                logger=ccar_session._logger
            )
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="EJM Generator initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(commercial_ejm_generator)
        cart.checkout()
        
        ###############  Add Overlay for EJM  #####################
        adjustment_dictionary={'PD_GROUP':['ENERGY_FINANCE','MWH', 'DFP_CHRYSLER', 'DFP_FOOTPRINT'], 'RATENAME':['PD','PD','PD','PD'], 'MGMTADJUSTMENT':[-0.4509,36.0049,-0.2132,-0.0672]}
        ccar_session.contributor_file_generator.managementAdjustment(adjustment_dictionary = adjustment_dictionary, 
                                                                     dataset_query_date = AS_OF_DATE,
                                                                     pd_group_switch = True)

        cf_inventory[101] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[101] is not None:
            cf_inventory[101].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del CRE_construction_model_instance
        except NameError:
            pass
        try:
            del TwoFLogitModel_CEVF_model_instance
        except NameError:
            pass
        try:
            del commercial_ejm_generator
        except NameError:
            pass


    ##
    ## C&I SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Woud you like to run block ID 102? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
        (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
        while True:
            try:
                MRA_ASOFDATE = datetime.datetime.strptime(
                    input(
                        "Enter MRA as of date for C&I model (%Y-%m-%d): "
                    ),
                    "%Y-%m-%d"
                )
            except ValueError as e:
                print(str(e))
                continue
            else:
                break     
            
        ccar_session.logger.add(
                type='INFO',
                message='MRA as of date : {}'.format(MRA_ASOFDATE),
                context='SBNA-Loss-Commercial-C&I Model Specifics'
            ) 
              
        STATEMENT_DAYS_THRESHOLD = int(utilities.userInputPrompt(
            message="Enter statement days threshold for C&I model: "
        ))   
        
        FINANCIAL_IN_RFO_SWITCH = True if utilities.userInputPrompt(
            message="Would you like to use financials in MV_LOSS_COMMERCIAL table? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y' else False
        
        ccar_session.logger.add(
                type='INFO',
                message='Statement days threshold : {}'.format(STATEMENT_DAYS_THRESHOLD),
                context='SBNA-Loss-Commercial-C&I Model Specifics'
            )            
        try:
            CI_ABL_risk_rating_model_instance = CNIModel(
                as_of_date=AS_OF_DATE,
                scenario=SCENARIO,
                scenario_context=STRESS_TESTING_CYCLE,
                scenario_date=SCENARIO_DATE,
                scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                forecast_periods=FORECAST_PERIODS,
                forecast_periods_frequency='monthly',
                pass_srr=4.0,
                model_id="743 - Commercial Rating Model - C&I PD - SBNA",
                debug=False,
                include_originations_switch=True,
                auto_fetch_macros=True,
                limit_contracts=None,
                statement_days_threshold=STATEMENT_DAYS_THRESHOLD,
                portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,
                mature_non_pass_locs=True,
                mra_asofdate = MRA_ASOFDATE,
                scenario_combinations = None,
                financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
                new_financial_logic = True
            )

        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="C&I/ABL model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(CI_ABL_risk_rating_model_instance)
        cart.checkout()
        
        ###############  Add Overlay for C&I  #####################
        adjustment_dictionary={'PD_GROUP':['ABL','BUSINESS_BANKING', 'MIDDLE_MARKET'], 'RATENAME':['PD','PD','PD'], 'MGMTADJUSTMENT':[-0.6752,-0.4128,-0.3977]}
        ccar_session.contributor_file_generator.managementAdjustment(adjustment_dictionary = adjustment_dictionary, 
                                                                     dataset_query_date = AS_OF_DATE,
                                                                     pd_group_switch = True)
        
        cf_inventory[102] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[102] is not None:
            cf_inventory[102].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del CI_ABL_risk_rating_model_instance
        except NameError:
            pass


    ##
    ## CRE SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Woud you like to run block ID 103? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
        (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
        CRE_MF_STRESS_SWITCH = True if utilities.userInputPrompt(
            message="Would you like to apply the CRE MF NE macro series? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y' else False
        
        ccar_session.logger.add(
                type='INFO',
                message='Multifamily stress switch : {}'.format(CRE_MF_STRESS_SWITCH),
                context='SBNA-Loss-Commercial-CRE Model Specifics'
            )      
        
        CREPI_MULTIFAMILY_SCALAR = None if utilities.userInputPrompt(
            message="Would you like to specify CRE MF scalar series? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'N' else eval(utilities.userInputPrompt(
                        message="Enter CRE MF scalar series: "
                    ))   
        ccar_session.logger.add(
                type='INFO',
                message='Multifamily CREPI series : {}'.format(CREPI_MULTIFAMILY_SCALAR),
                context='SBNA-Loss-Commercial-CRE Model Specifics'
            )           
        try:
            CRE_risk_rating_instance = RiskRatingModel(
                        uncertainty_rate=0.00,
                        as_of_date=AS_OF_DATE,
                        dataset_query_date=PORTFOLIO_SNAPSHOT_DATE,
                        scenario_date=SCENARIO_DATE,
                        model_id='2016-SBNA-Loss-Commercial-CRE',
                        scenario=SCENARIO,
                        scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                        scenario_context=STRESS_TESTING_CYCLE,
                        forecast_periods=FORECAST_PERIODS,
                        ne_scalar=CRE_MF_STRESS_SWITCH,
                        crepi_multifamily_scalar=CREPI_MULTIFAMILY_SCALAR,
                        debug=True,
                        bau=None,
                        origination=True,
                        book_balance_filter=None,
                        gl_filter=True,
                        path_dependent=True,
                        read_input=False
                    )                       
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="CRE Risk Rating model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(CRE_risk_rating_instance)
        cart.checkout()
        
        ###############  Add Overlay for CRE  #####################
        adjustment_dictionary={'PD_GROUP':['CRE_MULTIFAMILY','CRE_OTHER'], 'RATENAME':['PD','PD'], 'MGMTADJUSTMENT':[-0.8202,-0.7040]}
        ccar_session.contributor_file_generator.managementAdjustment(adjustment_dictionary = adjustment_dictionary, 
                                                                     dataset_query_date = AS_OF_DATE,
                                                                     pd_group_switch = True)
        
        cf_inventory[103] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[103] is not None:
            cf_inventory[103].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del CRE_construction_model_instance
        except NameError:
            pass



    ##
    ## GCB SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Woud you like to run block ID 104? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
            (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
        # Either enter the entire file path >>>I:\\CRMPO\\CCAR\\1Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Mar.xlsx
        # or
        # just enter the file name >>> GCB_MV_LOSS_COMMERCIAL_Mar
        #   use PORTFOLIO_SNAPSHOT_DATE to get the corresponding foler 
        #   e.g PORTFOLIO_SNAPSHOT_DATE=datetime.datetime(2017,3,31)--> 1Q17 folder
        while True:
            INDUSTRYTAG_FILE=os.path.join("I:\\CRMPO\\DEPT\\CCAR\\",
                                          utilities.date2XQYY(PORTFOLIO_SNAPSHOT_DATE),
                                          "4 - Models\\Wholesale\\GCB",
                                          "GCB_MV_LOSS_COMMERCIAL_"+
                                          utilities.userInputPrompt(
                        message="Enter the file suffix (Mar/Jun/Sep/Dec): "
                    )+".xlsx") if utilities.userInputPrompt(
                        message="Would you like to specify the entire file path for GCB industry tag[Y/N]",
                        valid_options=('Y', 'N')
                    ) == 'N' else utilities.userInputPrompt(
                                    message="Enter the entire file path for GCB industry tag: "
                                )        
            if os.path.exists(INDUSTRYTAG_FILE) & os.path.isfile(INDUSTRYTAG_FILE)==True:   
                break             
            else:
                print('File path entry is not valid. Please try again.')
                continue  
                           
        ccar_session.logger.add(
                type='INFO',
                message='Industry tag file path : {}'.format(INDUSTRYTAG_FILE),
                context='SBNA-Loss-Commercial-GCB Model Specifics'
            )    
        try:
            GCB_model_instance = GCBModel(
                as_of_date=AS_OF_DATE,
                dataset_query_date=PORTFOLIO_SNAPSHOT_DATE,
                scenario_date=SCENARIO_DATE,
                model_id = '2016-SBNA-Loss-Commercial-GCB',
                scenario=SCENARIO,
                scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS,
                industrytag_file=INDUSTRYTAG_FILE
            )

        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="GCB model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(GCB_model_instance)
        cart.checkout()
        cf_inventory[104] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[104] is not None:
            cf_inventory[104].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del GCB_model_instance
        except NameError:
            pass



    ##
    ## Write CF to RFO
    ##
    # Test if cf_inventory is empty
    if len(cf_inventory)>0:
        ccar_session.logger.add(
            type='INFO',
            message="Begin writing to RFO...",
            context='Run Session'
        )
        run_sig_test = cf_inventory[list(cf_inventory.keys())[0]].testCurrentEnvGetRunSignature(
            p_reporting_date=PORTFOLIO_SNAPSHOT_DATE,
            p_rerun='N',
            p_engine='ME_LOSS_ENGINE',
            p_cycle='CCAR'
        )
        ccar_session.logger.add(
            type='INFO',
            message="Fetching run parameters... partition_key : {}, run_signature : {}".format(
                run_sig_test['partition_key'],
                run_sig_test['run_signature']
            ),
            context='Run Session'
        )

        if utilities.userInputPrompt(
                message="Would you like to begin writing...? [Y/N]",
                valid_options=('Y', 'N')
        ) == 'Y':
            ccar_session.logger.add(
                type='INFO',
                message="Begin writing ...",
                context='Run Session'
            )
        
            # Save contributor file inventory
            while True:
                if utilities.userInputPrompt(
                        message="Would you like to save entire contributor file instance? [Y/N] ",
                        valid_options=('Y', 'N')
                ) == 'Y':                      
                    cf_name = utilities.userInputPrompt(
                        message="Enter name for contributor file instance: "
                    )        
                    cf_path = os.path.join(
                            WD+"/CIFI/Execution/cf_files/","cf_inventory_"
                            +cf_name+"_"
                            +SCENARIO
                            +"_version_"+str(FILE_VERSION)
                            +".p")
                    
                    if not os.path.exists(cf_path):
                        _pickle.dump(cf_inventory, open(cf_path, 'wb')) 
                        break
                    else:
                        print('File path entry is not valid. Please try again.')
                        continue                                   
                else:
                    break
                
            for contributor_file_id in cf_inventory:
                ccar_session.logger.add(
                    type='INFO',
                    message="Begin writing file ID {} ...".format(str(contributor_file_id)),
                    context='Run Session'
                )

                # Write to disk
                if utilities.userInputPrompt(
                        message="Would you like to write file ID {} to disk? [Y/N] ".format(
                            str(contributor_file_id)
                        ),
                        valid_options=('Y', 'N')
                ) == 'Y':
                    ccar_session.logger.add(
                        type='INFO',
                        message="Writing file ID {} to disk...".format(str(contributor_file_id)),
                        context='Run Session'
                    )

                    # Write to disk location
                    cf_inventory[contributor_file_id].toCSV(output_file_path=WD + '/CIFI/Execution/cf_files/cf_id_{}_{}_Version_{}.csv'.format(
                        str(contributor_file_id),SCENARIO,str(FILE_VERSION)
                    ))

                # Write to RFO
                if utilities.userInputPrompt(
                        message="Would you like to write file ID {} to remote database? [Y/N] ".format(
                            str(contributor_file_id)
                        ),
                        valid_options=('Y', 'N')
                ) == 'Y':
                    ccar_session.logger.add(
                        type='INFO',
                        message="Writing file ID {} to remote database...".format(str(contributor_file_id)),
                        context='Run Session'
                    )
                    while(True):
                        RUN_SIGNATURE = utilities.userInputPrompt(
                            message="Enter run signature for RFO uploading: "
                        )
                        PARTITION_KEY = utilities.userInputPrompt(
                            message="Enter partition key for RFO uploading: "
                        )
                        try:
                            cf_inventory[contributor_file_id].writeToMoodysRFO(
                                p_reporting_date=PORTFOLIO_SNAPSHOT_DATE,
                                as_of_date=AS_OF_DATE,
                                p_rerun='N',
                                p_engine='ME_LOSS_ENGINE',
                                p_cycle='CCAR',
                                debug=True,
                                moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
                                table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
                                overwrite_vintage_asofdate=CONFIG['CONTRIBUTOR_FILE']["VINTAGE_ASOFDATE_VALUE"],
                                contributor_file_id=contributor_file_id,
                                file_version=FILE_VERSION,
                                run_signature=RUN_SIGNATURE,
                                partition_key=PARTITION_KEY
                            )
                        except Exception as e:
                            ccar_session.logger.add(
                                type='ERROR',
                                message="Could NOT write file ID {} to remote database.".format(str(contributor_file_id)),
                                context='Run Session'
                            )
                            ccar_session.logger.add(
                                type='ERROR',
                                message=str(e),
                                context='Run Session'
                            )
                            if utilities.userInputPrompt(
                                    message="Could NOT write file ID {} to remote. Would you like to try again? [Y/N]".format(
                                        str(contributor_file_id)
                                    ),
                                    valid_options=('Y', 'N')
                            ) == 'Y':
                                continue
                            else:
                                ccar_session.logger.add(
                                    type='WARN',
                                    message="Unable to write file ID {} to remote database.".format(
                                        str(contributor_file_id)),
                                    context='Run Session'
                                )
                                break
                        else:
                            ccar_session.logger.add(
                                type='INFO',
                                message="Completed writing file ID {} to remote database.".format(str(contributor_file_id)),
                                context='Run Session'
                            )
                            break
    else:
        ccar_session.logger.add(
            type='INFO',
            message="Contributor file inventory is empty. Nothing to write to remote database.",
            context='Run Session'
        )

    ##
    ## OUTPUT RUN LOG
    ##
    if utilities.userInputPrompt(
            message="Execution completed. Would you like to save the run log to file? [Y/N]",
            valid_options=('Y', 'N')
    ) == 'Y':
        ccar_session.logger.add(
            type='INFO',
            message="Execution completed. Saving log to file.",
            context='Run Session'
        )
        ccar_session.logger.toFile(path_to_directory=WD+'/CIFI/Execution/run_log/')
        
    ##
    ## Balance Walk
    ##
    if utilities.userInputPrompt(
            message="Would you like to start balance walk? [Y/N]",
            valid_options=('Y', 'N')
    ) == 'Y':
        
        ccar_session.logger.add(
            type='INFO',
            message="Start balance walk...",
            context='Balance Walk Session'
        ) 
        
#        cf_entire_inventory=pd.concat(
#                    [cf_inventory[101].getCFData(),
#                     cf_inventory[102].getCFData(),
#                     cf_inventory[103].getCFData(),
#                     cf_inventory[104].getCFData()])
                            
        cf_entire_inventory=pd.DataFrame()
        for contributor_file_id in cf_inventory:  
            data=cf_inventory[contributor_file_id].getCFData()
            # Filter for current vintage
            data=data[data['VINTAGE']==AS_OF_DATE]
            # Filter for current book (no origination)
            if contributor_file_id != 101:
                data=data[~data['MODELSEGMENT'].str.contains('_O')]
                
            cf_entire_inventory=pd.concat([cf_entire_inventory,data])
        
        anchor_query, anchor_data=balancewalk.getBWFormatAnchorData(
            as_of_date= PORTFOLIO_SNAPSHOT_DATE,
            pd_groups=[],
            debug=False
            )      

        while True:
            EJM_MASTER_FILE_PATH=os.path.join("I:\\CRMPO\\DEPT\\CCAR\\",
                                              utilities.userInputPrompt(
                                                      message="Enter the EJM master file folder name (%QYY): "
                                              ),
                                              "5 - EJMs\\Commercial",
                                              "COMMERCIAL_EJM_MASTER_"+
                        utilities.userInputPrompt(
                        message="Enter the EJM master file suffix (%QYY): "
                    )+".xlsm") if utilities.userInputPrompt(
                        message="Would you like to specify the entire file path for EJM master file[Y/N]",
                        valid_options=('Y', 'N')
                    ) == 'N' else utilities.userInputPrompt(
                                    message="Enter the entire file path for EJM file: "
                                )            
            if os.path.exists(EJM_MASTER_FILE_PATH) & os.path.isfile(EJM_MASTER_FILE_PATH)==True:   
                break             
            else:
                print('File path entry is not valid. Please try again.')
                continue   

        segfield2_to_nco_timing_curve=balancewalk.getNCOCurve(        
                forecast_period=FORECAST_PERIODS,
                nco_data_path = EJM_MASTER_FILE_PATH,
                timing_curve_switch = True   
            )      
        t0=time.time()
        
        bw_output = balancewalk.balanceWalk(
            cf_data = cf_entire_inventory,
            anchor_data=anchor_data,
            scenario_list=[SCENARIO],
            segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
            process_ALLL_balances = True,
            debug = True
        )  
        print('Blance walk completed in ' + str(time.time()-t0) + ' s.')
        
        bw_output.to_csv(WD+'/CIFI/Execution/BalanceWalk/'+'BW_output_'+SCENARIO+"_version_"+str(FILE_VERSION)+'.csv')
        
        # Pivot balance walk output
        pivot_bw=balancewalk.balanceWalkPivot(bw_output,FORECAST_PERIODS)        
        pivot_bw.to_csv(WD+'/CIFI/Execution/BalanceWalk/'+'BW_Pivot_'+SCENARIO+"_version_"+str(FILE_VERSION)+'.csv')


if __name__ == "__main__":
    main()





























