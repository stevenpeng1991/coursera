import sys
import os
wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
if wd not in sys.path:
    sys.path.append(wd)
import datetime
import pandas as pd
import numpy as np
import cx_Oracle
import time
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.models.masterdataset.rfoplayground import queryRFO

query_MV_MEV_NATIONAL="""
SELECT
	*
	FROM MACCAR.MV_MEV_NATIONAL
"""

MV_MEV_NATIONAL_df = queryRFO(
	query=query_MV_MEV_NATIONAL,
	moodys_rfo_env="UAT_ENV"
)

query_MV_MEV_NORMALIZED="""
SELECT
	*
	FROM MACCAR.MV_MEV_NORMALIZED
"""

MV_MEV_NORMALIZED_df = queryRFO(
	query=query_MV_MEV_NORMALIZED,
	moodys_rfo_env="UAT_ENV"
)