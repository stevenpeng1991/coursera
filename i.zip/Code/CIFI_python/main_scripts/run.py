"""
SAMPLE USE
----------
SP20_ccarBASE_BW = balancewalk.balanceWalk(
    cf_data = cf_101,
    anchor_data=anchor_data,
    scenario_list=['STAGF'],
nco_data_path=CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_PATH"],
    process_ALLL_balances = True,
    debug = True
)

AS_OF_DATE=datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,3,31)
SCENARIO_DATE = datetime.datetime(2017,3,31)
SCENARIO='STAGF'
SCENARIO_SEVERITY_LEVEL='ADVERSE'
EJM_SCENARIO_SEVERITY_LEVEL='ADVERSE'
STRESS_TESTING_CYCLE='IFRS92017'
FORECAST_PERIODS=27
FILE_VERSION=1
EJM_MASTER_FILE_PATH='I:/CRMPO/CCAR/1Q17/5 - EJMs/Commercial/COMMERCIAL_EJM_MASTER_1Q17.xlsm'
INDUSTRYTAG_FILE='I:\\CRMPO\\CCAR\\1Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Mar.xlsx'

USER_N_NUMBER='N'
SESSION_ID_NAME='TEST'
--------------------------
 Dump and load container
--------------------------
# Dump 
_pickle.dump(bw_output, open("C:/Users/n000000/Documents/bw_output.p", 'wb'))
# Load
cf_inventory = _pickle.load(open("C:/Users/n000000/Documents/xxx.p", 'rb'))

"""
import os
import sys
global WD
WD = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if WD not in sys.path:
    sys.path.append(WD)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import getpass
import _pickle
import time
import pandas as pd
from CIFI.config import CONFIG

##
## IMPORT MODULES (MODELS AND EJMS)
##
from CIFI.controllers.models.creconstruction17 import CREConstruction
from CIFI.controllers.models.logitmodel import TwoFLogitModel
from CIFI.controllers.ejm.ejmmaster import EJMGenerator, ejmDictionaryGenerator
from CIFI.controllers.models.riskratingmodel import RiskRatingModel
from CIFI.controllers.models.gcbindustry import GCBModel
from CIFI.controllers.models.cniriskrating import CNIModel

## IMPORT Balance Walk module
from CIFI.sensitivity import balancewalk

def main():
    ##
    ## GLOBAL PARAMS
    ##
    while True:
        try:
            AS_OF_DATE = datetime.datetime.strptime(
                input(
                    "Enter run as-of-date (%Y-%m-%d): "
                ),
                "%Y-%m-%d"
            )
        except ValueError as e:
            print(str(e))
            continue
        else:
            break
    while True:
        try:
            PORTFOLIO_SNAPSHOT_DATE = datetime.datetime.strptime(
                input(
                    "Enter run portfolio snapshot date (%Y-%m-%d): "
                ),
                "%Y-%m-%d"
            )
        except ValueError as e:
            print(str(e))
            continue
        else:
            break
    while True:
        try:
            SCENARIO_DATE = datetime.datetime.strptime(
                input(
                    "Enter run scenario date (%Y-%m-%d): "
                ),
                "%Y-%m-%d"
            )
        except ValueError as e:
            print(str(e))
            continue
        else:
            break
    while True:
        try:
            STRESS_TESTING_CYCLE = str(input("Enter stress testing cycle: "))
        except ValueError as e:
            print(str(e))
            continue
        else:
            break
    while True:
        try:
            SCENARIO = str(input("Enter scenario name: "))  # DR_SA, DR_BASE
        except ValueError as e:
            print(str(e))
            continue
        else:
            break

    SCENARIO_SEVERITY_LEVEL = utilities.userInputPrompt(
        message="Enter scenario severity type (BASE, ADVERSE, STRESS): ",
        valid_options=('BASE', 'ADVERSE', 'STRESS')
    )

    EJM_SCENARIO_SEVERITY_LEVEL = utilities.userInputPrompt(
        message="Enter EJM scenario severity type (BASE, ADVERSE, STRESS, BHC_STRESS, BHC_ADVERSE, BHC_BASE): ",
        valid_options=('BASE', 'ADVERSE', 'STRESS', 'BHC_STRESS', 'BHC_ADVERSE', 'BHC_BASE')
    )

    FORECAST_PERIODS = int(utilities.userInputPrompt(
        message="Enter number of forecast periods: ",
        valid_options=('3','27', '30', '36', '39', '42', '45', '48', '132')
    ))

    FILE_VERSION = int(utilities.userInputPrompt(
        message="Enter general file version: "
    ))            
                                                               
    RUN_VERSION = int(utilities.userInputPrompt(
        message="Enter run version (first run is 1, rerun is 2) : "
    ))         
    PROMPT_FOR_BLOCK_RUN_OPTION = True if utilities.userInputPrompt(
        message="Enter if you'd like to be prompted for each block run: [Y/N]",
        valid_options=('Y', 'N')
    ) == 'Y' else False
    
    if STRESS_TESTING_CYCLE == 'CCAR2018':
        if SCENARIO == 'BHC_STRESS':
            CREPI_MULTIFAMILY_SCALAR=[
                                            215.7,
                                            220.7,
                                            212.91060155,
                                            188.50509395,
                                            173.19332673,
                                            151.04388494,
                                            142.79066312,
                                            127.63307239,
                                            121.17749675,
                                            109.06475059,
                                            116.03725928,
                                            117.6368452,
                                            122.34079311,
                                            126.53543839,
                                            131.10649631,
                                            134.44560066,
                                            140.2107775,
                                            144.56752945
                                      ]    
        elif SCENARIO == 'FRB_ADVERSE':
            CREPI_MULTIFAMILY_SCALAR=[
                                            215.7,
                                            220.7,
                                            193.64108719,
                                            185.32623251,
                                            178.75353785,
                                            173.76462504,
                                            169.64679225,
                                            167.1127413,
                                            165.52895945,
                                            165.52895945,
                                            165.52895945,
                                            166.16247219,
                                            167.03355221,
                                            168.1421995,
                                            169.40922497,
                                            170.72794611,
                                            172.09927378,
                                            173.52415999
                                      ]
        elif SCENARIO == 'FRB_SA':
            CREPI_MULTIFAMILY_SCALAR=[
                                            215.7,
                                            220.7,
                                            185.32623251,
                                            163.31166487,
                                            145.65249731,
                                            132.42791891,
                                            121.341446,
                                            114.76875135,
                                            110.33416218,
                                            110.33416218,
                                            110.41335127,
                                            112.1555113,
                                            114.37280588,
                                            117.3028023,
                                            120.86631145,
                                            123.89024991,
                                            126.3256783,
                                            128.12950444
                                      ]   
        else:
            CREPI_MULTIFAMILY_SCALAR = None
    elif STRESS_TESTING_CYCLE == 'DryRun2018' and SCENARIO == 'BHC_STRESS': 
        CREPI_MULTIFAMILY_SCALAR=[
                                      213.81051192,
                                      213.24711154,
                                      205.72075576,
                                      182.13940551,
                                      167.34470622,
                                      145.94323597,
                                      137.96871982,
                                      123.32299060,
                                      117.08541534,
                                      105.38170835,
                                      112.1187602
                                  ]     
    elif STRESS_TESTING_CYCLE == 'CCAR2017' and SCENARIO == 'BHC_STRESS': 
        CREPI_MULTIFAMILY_SCALAR=[
                                    290.3,
                                    294,
                                    290.945098985984,
                                    265.793702550437,
                                    240.470453137935,
                                    216.942528567195,
                                    199.865965980898,
                                    185.77279303871,
                                    172.563832110162,
                                    168.601335302004,
                                    169
                                  ]
    else:
         CREPI_MULTIFAMILY_SCALAR = None                       
         
    # AS_OF_DATE = datetime.datetime(2016,12,31)
    # PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2016,11,30)
    # SCENARIO='DR_BASE' # DR_SA, DR_BASE
    # SCENARIO_SEVERITY_LEVEL="BASE" # BASE, ADVERSE, STRESS
    # STRESS_TESTING_CYCLE='DryRun2017'
    # FORECAST_PERIODS=27
    # PROMPT_FOR_BLOCK_RUN_OPTION = True


    USER_N_NUMBER = getpass.getuser()
    SESSION_ID_NAME = STRESS_TESTING_CYCLE + \
                        " - " + \
                        SCENARIO + \
                        " [" + \
                        SCENARIO_SEVERITY_LEVEL + \
                        "]" + \
                        " - V{}".format(str(FILE_VERSION))


    ##
    ## CREATE SESSION AND SHOPPING CART
    ##
    ccar_session = CCARSession(
        session_id=SESSION_ID_NAME,
        session_date=AS_OF_DATE,
        user=USER_N_NUMBER
    )
    cart = ModelShoppingCart(ccar_session=ccar_session)
    cf_inventory = {}

    # check if run_log directory exists
    utilities.make_path(WD + '/CIFI/Execution/run_log')
    utilities.make_path(WD + '/CIFI/Execution/cf_files')
    utilities.make_path(WD + '/CIFI/Execution/BalanceWalk')
       
    ##
    ## EJM_LOGIT SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Woud you like to run block ID 101? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
        (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
        # For EJM, check if only run cre_construction/cevf part, or run whole ejm
        ONLY_RUN_CEVF_CRECONSTRUCTION = True if utilities.userInputPrompt(
            message="For EJM master file, would you like to ONLY run CEVF/CREConstruction part: [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y' else False
        
        # For Energy Finance, choose if assign facility-level PD/LGD rates
        ENERGY_FINANCE_FACILITY_RATE = True if utilities.userInputPrompt(
            message="For Energy Finance, would you like to assign facility-level PD/LGD rates: [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y' else False
        
        # utilities.date2XQYY(PORTFOLIO_SNAPSHOT_DATE)    
        # Either enter the entire file path >>>I:/CRMPO/CCAR/1Q17/5 - EJMs/Commercial/COMMERCIAL_EJM_MASTER_1Q17.xlsm
        # or
        # just enter the file name >>> COMMERCIAL_EJM_MASTER_1Q17
        #   use PORTFOLIO_SNAPSHOT_DATE to get the corresponding foler 
        #   e.g PORTFOLIO_SNAPSHOT_DATE=datetime.datetime(2017,3,31)--> 1Q17 folder
        
        while True:
            EJM_MASTER_FILE_PATH=os.path.join("I:\\CRMPO\\CCAR\\",
                                              utilities.userInputPrompt(
                                                      message="Enter the EJM master file folder name (%QYY): "
                                              ),
                                              "5 - EJMs\\Commercial",
                                              "COMMERCIAL_EJM_MASTER_"+
                        utilities.userInputPrompt(
                        message="Enter the EJM master file suffix (%QYY): "
                    )+".xlsm") if utilities.userInputPrompt(
                        message="Would you like to specify the entire file path for EJM master file[Y/N]",
                        valid_options=('Y', 'N')
                    ) == 'N' else utilities.userInputPrompt(
                                    message="Enter the entire file path for EJM file: "
                                )        
            if os.path.exists(EJM_MASTER_FILE_PATH) & os.path.isfile(EJM_MASTER_FILE_PATH)==True:   
                break             
            else:
                print('File path entry is not valid. Please try again.')
                continue  
                           
        ccar_session.logger.add(
                type='INFO',
                message='EJM master file path : {}'.format(EJM_MASTER_FILE_PATH),
                context='SBNA-Loss-Commercial-EJM Model Specifics'
            )            

        try:
            commercial_ejm_generator = EJMGenerator(
                as_of_date = AS_OF_DATE,
                ejm_dictionary=ejmDictionaryGenerator(
                    asofdate = PORTFOLIO_SNAPSHOT_DATE,
                    version_date=AS_OF_DATE,
                    scenario_pairs = {
                        EJM_SCENARIO_SEVERITY_LEVEL:SCENARIO
                    },
                    pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
                    rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
                    ejm_master_file_path = EJM_MASTER_FILE_PATH,
                    only_run_cevf_creconstruction = ONLY_RUN_CEVF_CRECONSTRUCTION,
                    energy_finance_facility_rate = ENERGY_FINANCE_FACILITY_RATE,
                    forecast_periods = FORECAST_PERIODS,
                    debug=False,
                    logger=ccar_session._logger
                ),
                forecast_periods=FORECAST_PERIODS,
                process_additional_ead=False,
                debug=False,
                logger=ccar_session._logger
            )
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="EJM Generator initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(commercial_ejm_generator)
        
        try:
            CRE_construction_model_instance = CREConstruction(
                uncertainty_rate=0.,
                as_of_date=AS_OF_DATE,
                model_id="2016-SBNA-Loss-Commercial-CREConstruction",
                scenario=SCENARIO,
                scenario_date=SCENARIO_DATE,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS
            )
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="CRE Construction model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(CRE_construction_model_instance)

        try:
            TwoFLogitModel_CEVF_model_instance = TwoFLogitModel(
                uncertainty_rate=0.,
                as_of_date=AS_OF_DATE,
                scenario_date=SCENARIO_DATE,
                model_id='53 - Scenario Analysis Model - CEVF PD - SBNA',
                scenario=SCENARIO,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS,
            )
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="CEVF model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(TwoFLogitModel_CEVF_model_instance)
            

        cart.checkout()
        cf_inventory[101] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[101] is not None:
            cf_inventory[101].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del CRE_construction_model_instance
        except NameError:
            pass
        try:
            del TwoFLogitModel_CEVF_model_instance
        except NameError:
            pass
        try:
            del commercial_ejm_generator
        except NameError:
            pass


    ##
    ## C&I SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Would you like to run block ID 102? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
        (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
              
        STATEMENT_DAYS_THRESHOLD = int(utilities.userInputPrompt(
            message="Enter statement days threshold for C&I model: "
        ))   
        
        while True:
            CNI_RISK_RATING_DATASET_INPUT_PATH=os.path.join("I:\\CRMPO\\CCAR\\",
                                              utilities.userInputPrompt(
                                                      message="Enter the C&I risk rating file folder name (%QYY): "
                                              ),
                                              "1 - Data\\Risk Rating",
                                              "rfo_cni_"+
                        utilities.userInputPrompt(
                        message="Enter the C&I staging file suffix (nov_2017, dec_2017): "
                    )+".xlsx") if utilities.userInputPrompt(
                        message="Would you like to specify the entire file path for C&I risk rating file[Y/N]",
                        valid_options=('Y', 'N')
                    ) == 'N' else utilities.userInputPrompt(
                                    message="Enter the entire file path for C&I risk rating file: "
                                )        
            if os.path.exists(CNI_RISK_RATING_DATASET_INPUT_PATH) & os.path.isfile(CNI_RISK_RATING_DATASET_INPUT_PATH)==True:   
                break             
            else:
                print('File path entry {' + CNI_RISK_RATING_DATASET_INPUT_PATH + '} is not valid. Please try again.')
                continue  
            
        ccar_session.logger.add(
                type='INFO',
                message='Statement days threshold : {}'.format(STATEMENT_DAYS_THRESHOLD),
                context='SBNA-Loss-Commercial-C&I Model Specifics'
            )            
        try:
            CI_ABL_risk_rating_model_instance = CNIModel(
                as_of_date=AS_OF_DATE,
                scenario=SCENARIO,
                scenario_context=STRESS_TESTING_CYCLE,
                scenario_date=SCENARIO_DATE,
                scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                forecast_periods=FORECAST_PERIODS,
                forecast_periods_frequency='monthly',
                pass_srr=4.0,
                model_id="743 - Commercial Rating Model - C&I PD - SBNA",
                debug=False,
                include_originations_switch=True,
                auto_fetch_macros=True,
                limit_contracts=None,
                statement_days_threshold=STATEMENT_DAYS_THRESHOLD,
                portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,
                mature_non_pass_locs=True,
                scenario_combinations = None,
                financial_in_rfo = True,
                new_financial_logic = True,
                risk_rating_dataset_input_path = CNI_RISK_RATING_DATASET_INPUT_PATH
            )

        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="C&I/ABL model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(CI_ABL_risk_rating_model_instance)
        cart.checkout()
        cf_inventory[102] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[102] is not None:
            cf_inventory[102].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del CI_ABL_risk_rating_model_instance
        except NameError:
            pass



    ##
    ## CRE SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Would you like to run block ID 103? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
        (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
        CRE_MF_STRESS_SWITCH = True if utilities.userInputPrompt(
            message="Would you like to apply the CRE MF NE macro series? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y' else False
        
        ccar_session.logger.add(
                type='INFO',
                message='Multifamily stress switch : {}'.format(CRE_MF_STRESS_SWITCH),
                context='SBNA-Loss-Commercial-CRE Model Specifics'
            )      

        while True:
            CRE_RISK_RATING_DATASET_INPUT_PATH=os.path.join("I:\\CRMPO\\CCAR\\",
                                              utilities.userInputPrompt(
                                                      message="Enter the CRE risk rating file folder name (%QYY): "
                                              ),
                                              "1 - Data\\Risk Rating",
                                              "rfo_cre_"+
                        utilities.userInputPrompt(
                        message="Enter the CRE staging file suffix (nov_2017, dec_2017): "
                    )+".xlsx") if utilities.userInputPrompt(
                        message="Would you like to specify the entire file path for CRE risk rating file[Y/N]",
                        valid_options=('Y', 'N')
                    ) == 'N' else utilities.userInputPrompt(
                                    message="Enter the entire file path for CRE risk rating file: "
                                )        
            if os.path.exists(CRE_RISK_RATING_DATASET_INPUT_PATH) & os.path.isfile(CRE_RISK_RATING_DATASET_INPUT_PATH)==True:   
                break             
            else:
                print('File path entry {' + CRE_RISK_RATING_DATASET_INPUT_PATH + '} is not valid. Please try again.')
                continue  
        
        try:
            CRE_risk_rating_instance = RiskRatingModel(
                        uncertainty_rate=0.00,
                        as_of_date=AS_OF_DATE,
                        dataset_query_date=PORTFOLIO_SNAPSHOT_DATE,
                        scenario_date=SCENARIO_DATE,
                        model_id='2016-SBNA-Loss-Commercial-CRE',
                        scenario=SCENARIO,
                        scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                        scenario_context=STRESS_TESTING_CYCLE,
                        forecast_periods=FORECAST_PERIODS,
                        ne_scalar=CRE_MF_STRESS_SWITCH,
                        crepi_multifamily_scalar=CREPI_MULTIFAMILY_SCALAR,
                        debug=True,
                        bau=None,
                        origination=True,
                        book_balance_filter=None,
                        gl_filter=True,
                        path_dependent=True,
                        read_input=True,
                        dataset_path=CRE_RISK_RATING_DATASET_INPUT_PATH,
                        final_rating_switch = True
                    )                       
        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="CRE Risk Rating model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(CRE_risk_rating_instance)
        cart.checkout()
        cf_inventory[103] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[103] is not None:
            cf_inventory[103].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del CRE_construction_model_instance
        except NameError:
            pass



    ##
    ## GCB SETUP
    ##
    if (
        (PROMPT_FOR_BLOCK_RUN_OPTION and (utilities.userInputPrompt(
            message="Would you like to run block ID 104? [Y/N]",
            valid_options=('Y', 'N')
        ) == 'Y')) or \
            (not PROMPT_FOR_BLOCK_RUN_OPTION)
    ):
        # Either enter the entire file path >>>I:\\CRMPO\\CCAR\\1Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Mar.xlsx
        # or
        # just enter the file name >>> GCB_MV_LOSS_COMMERCIAL_Mar
        #   use PORTFOLIO_SNAPSHOT_DATE to get the corresponding foler 
        #   e.g PORTFOLIO_SNAPSHOT_DATE=datetime.datetime(2017,3,31)--> 1Q17 folder
        while True:
            INDUSTRYTAG_FILE=os.path.join("I:\\CRMPO\\CCAR\\",
                                          utilities.date2XQYY(PORTFOLIO_SNAPSHOT_DATE),
                                          "4 - Models\\Wholesale\\GCB",
                                          "GCB_MV_LOSS_COMMERCIAL_"+
                                          utilities.userInputPrompt(
                        message="Enter the file suffix (Mar/Jun/Sep/Dec): "
                    )+".xlsx") if utilities.userInputPrompt(
                        message="Would you like to specify the entire file path for GCB industry tag[Y/N]",
                        valid_options=('Y', 'N')
                    ) == 'N' else utilities.userInputPrompt(
                                    message="Enter the entire file path for GCB industry tag: "
                                )        
            if os.path.exists(INDUSTRYTAG_FILE) & os.path.isfile(INDUSTRYTAG_FILE)==True:   
                break             
            else:
                print('File path entry is not valid. Please try again.')
                continue  
                                       
        ccar_session.logger.add(
                type='INFO',
                message='Industry tag file path : {}'.format(INDUSTRYTAG_FILE),
                context='SBNA-Loss-Commercial-GCB Model Specifics'
            ) 
        
        
        INTERMEDIATE_DATASET_PATH = os.path.join("I:\\CRMPO\\CCAR\\",
                    utilities.date2XQYY(PORTFOLIO_SNAPSHOT_DATE),
                    "4 - Models\\Wholesale\\GCB\\intermediate dataset_" + utilities.date2XQYY(PORTFOLIO_SNAPSHOT_DATE))    
        
        utilities.make_path(INTERMEDIATE_DATASET_PATH)
            
        ccar_session.logger.add(
                type='INFO',
                message='Intermediate dataset path : {}'.format(INTERMEDIATE_DATASET_PATH),
                context='SBNA-Loss-Commercial-GCB Model Specifics'
            )         
        try:
            GCB_model_instance = GCBModel(
                as_of_date=AS_OF_DATE,
                dataset_query_date=PORTFOLIO_SNAPSHOT_DATE,
                scenario_date=SCENARIO_DATE,
                model_id = '2016-SBNA-Loss-Commercial-GCB',
                scenario=SCENARIO,
                scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS,
                industrytag_file=INDUSTRYTAG_FILE,
                intermediate_dataset_path = INTERMEDIATE_DATASET_PATH
            )

        except Exception as e:
            ccar_session.logger.add(
                type='ERROR',
                message=str(e),
                context='Main Run Script'
            )
            if utilities.userInputPrompt(
                message="GCB model initialization failed. Would you like to continue? [Y/N]",
                valid_options=('Y', 'N')
            ) == 'N':
                raise e
        else:
            cart.addModel(GCB_model_instance)
        cart.checkout()
        cf_inventory[104] = ccar_session.contributor_file_generator.generateContributorFileInstance()
        if cf_inventory[104] is not None:
            cf_inventory[104].checkCFIntegrity().getResponse()
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        try:
            del GCB_model_instance
        except NameError:
            pass

    ##
    ## Write CF to local drive
    ##
    # Test if cf_inventory is empty
    if len(cf_inventory)>0:
        if utilities.userInputPrompt(
                message="Would you like to begin writing...? [Y/N]",
                valid_options=('Y', 'N')
        ) == 'Y':
            ccar_session.logger.add(
                type='INFO',
                message="Begin writing ...",
                context='Run Session'
            )
        
            # Save contributor file inventory
            while True:
                if utilities.userInputPrompt(
                        message="Would you like to save entire contributor file instance? [Y/N] ",
                        valid_options=('Y', 'N')
                ) == 'Y':                      
                    cf_name = utilities.userInputPrompt(
                        message="Enter name for contributor file instance: "
                    )        
                    cf_path = os.path.join(
                            WD+"/CIFI/Execution/cf_files/","cf_inventory_"
                            +cf_name+"_"
                            +SCENARIO
                            +"_version_"+str(FILE_VERSION)
                            +".p")
                    
                    if not os.path.exists(cf_path):
                        _pickle.dump(cf_inventory, open(cf_path, 'wb')) 
                        break
                    else:
                        print('File path entry is not valid. Please try again.')
                        continue                                   
                else:
                    break
                
            for contributor_file_id in cf_inventory:
                ccar_session.logger.add(
                    type='INFO',
                    message="Begin writing file ID {} ...".format(str(contributor_file_id)),
                    context='Run Session'
                )

                # Write to disk
                if utilities.userInputPrompt(
                        message="Would you like to write file ID {} to disk? [Y/N] ".format(
                            str(contributor_file_id)
                        ),
                        valid_options=('Y', 'N')
                ) == 'Y':
                    ccar_session.logger.add(
                        type='INFO',
                        message="Writing file ID {} to disk...".format(str(contributor_file_id)),
                        context='Run Session'
                    )

                    # Write to disk location
                    cf_inventory[contributor_file_id].toCSV(output_file_path=WD + '/CIFI/Execution/cf_files/cf_id_{}_{}_Version_{}.csv'.format(
                        str(contributor_file_id),SCENARIO,str(FILE_VERSION)
                    ))
    else:
        ccar_session.logger.add(
            type='INFO',
            message="Contributor file inventory is empty. Nothing to write to remote database.",
            context='Run Session'
        )

    ##
    ## OUTPUT RUN LOG
    ##
    if utilities.userInputPrompt(
            message="Execution completed. Would you like to save the run log to file? [Y/N]",
            valid_options=('Y', 'N')
    ) == 'Y':
        ccar_session.logger.add(
            type='INFO',
            message="Execution completed. Saving log to file.",
            context='Run Session'
        )
        ccar_session.logger.toFile(path_to_directory=WD+'/CIFI/Execution/run_log/')
        
    ##
    ## Balance Walk
    ##
    if utilities.userInputPrompt(
            message="Balance Walk Instruction: Contributor file inventory must contain either all(4) or one file id. \
            Would you like to start balance walk? [Y/N]",
            valid_options=('Y', 'N')
    ) == 'Y':
        
        PIVOT_LENGTH = int(utilities.userInputPrompt(
            message="Enter number of forecast periods for Balance Walk pivot table: ",
            valid_options=('27','45','48')
        ))
        
        if utilities.userInputPrompt(
                        message="Would you like to use timing curve for balance walk[Y/N]",
                        valid_options=('Y', 'N')
                        ) == 'Y':
            while True:
                EJM_MASTER_FILE_PATH=os.path.join("I:\\CRMPO\\CCAR\\",
                                                  utilities.userInputPrompt(
                                                          message="Enter the EJM master file folder name (%QYY): "
                                                  ),
                                                  "5 - EJMs\\Commercial",
                                                  "COMMERCIAL_EJM_MASTER_"+
                            utilities.userInputPrompt(
                            message="Enter the EJM master file suffix (%QYY): "
                        )+".xlsm") if utilities.userInputPrompt(
                            message="Would you like to specify the entire file path for EJM master file[Y/N]",
                            valid_options=('Y', 'N')
                        ) == 'N' else utilities.userInputPrompt(
                                        message="Enter the entire file path for EJM file: "
                                    )            
                if os.path.exists(EJM_MASTER_FILE_PATH) & os.path.isfile(EJM_MASTER_FILE_PATH)==True:   
                    break             
                else:
                    print('File path entry is not valid. Please try again.')
                    continue   

            segfield2_to_nco_timing_curve=balancewalk.getNCOCurve(        
                    forecast_period=FORECAST_PERIODS,
                    nco_data_path = EJM_MASTER_FILE_PATH,
                    timing_curve_switch = True   
                )              
        else:
            segfield2_to_nco_timing_curve = None
        
        ccar_session.logger.add(
            type='INFO',
            message="Start balance walk...",
            context='Balance Walk Session'
        ) 
        
#        cf_entire_inventory=pd.concat(
#                    [cf_inventory[101].getCFData(),
#                     cf_inventory[102].getCFData(),
#                     cf_inventory[103].getCFData(),
#                     cf_inventory[104].getCFData()])
                            
        cf_entire_inventory=pd.DataFrame()
        for contributor_file_id in cf_inventory:  
            data=cf_inventory[contributor_file_id].getCFData()
            # Filter for current vintage
            data=data[data['VINTAGE']==AS_OF_DATE]
            # Filter for current book (no origination)
            if contributor_file_id != 101:
                data=data[~data['MODELSEGMENT'].str.contains('_O')]
                
            cf_entire_inventory=pd.concat([cf_entire_inventory,data])
        
        # Getting tags from RFO anchor table    
        ccar_session.logger.add(
            type='INFO',
            message="Fetching facility tags from RFO anchor table...",
            context='Balance Walk Session'
        )
        t0=time.time()
        
        cf_id_list = list(cf_inventory.keys())
        if len(cf_id_list) == 4:
            anchor_data=balancewalk.getBWFormatAnchorData(
                as_of_date= PORTFOLIO_SNAPSHOT_DATE,
                pd_groups=[],
                risk_rating_switch = True,
                cni_dataset_path = CNI_RISK_RATING_DATASET_INPUT_PATH, 
                cre_dataset_path = CRE_RISK_RATING_DATASET_INPUT_PATH,
                overwrite_calculated_line = True,
                debug=False
                )      
        # for id 101 (EJM/CEVF/CRE Construction)
        elif (len(cf_id_list) == 1) and (cf_id_list[0] == 101):
            if ONLY_RUN_CEVF_CRECONSTRUCTION:
                anchor_data = balancewalk.getBWFormatAnchorData(
                                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                                debug=False,
                                pd_groups=['CEVF_RETAIL', 'CRE_CONSTRUCTION'],
                                overwrite_calculated_line = True
                                )       
            else:
                anchor_data = balancewalk.getBWFormatAnchorData(
                                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                                debug=False,
                                pd_groups=['CEVF_RR','CI_OTHERS','CI_RR','CRE_REITS',
                                           'CRE_UNSECURED','DFP_CHRYSLER','DFP_FOOTPRINT',
                                           'ENERGY_FINANCE','EQUIPMENT_FINANCE_LEASING','GOVERNMENT_BANKING','MWH','RUNOFF_CCRC',
                                           'CEVF_RETAIL', 'CRE_CONSTRUCTION'],
                                overwrite_calculated_line = True
                                )      
        # for id 102 (C&I)
        elif (len(cf_id_list) == 1) and (cf_id_list[0] == 102):
            anchor_data=balancewalk.getBWFormatAnchorData(
                as_of_date= PORTFOLIO_SNAPSHOT_DATE,
                pd_groups=[],
                risk_rating_switch = True,
                only_risk_rating = True,
                cni_dataset_path = CNI_RISK_RATING_DATASET_INPUT_PATH, 
                overwrite_calculated_line = True,
                debug=False
                )     
        # for id 103 (CRE)
        elif (len(cf_id_list) == 1) and (cf_id_list[0] == 103):
            anchor_data=balancewalk.getBWFormatAnchorData(
                as_of_date= PORTFOLIO_SNAPSHOT_DATE,
                pd_groups=[],
                risk_rating_switch = True,
                only_risk_rating = True,
                cre_dataset_path = CRE_RISK_RATING_DATASET_INPUT_PATH,
                overwrite_calculated_line = True,
                debug=False
                )   
        # for id 104 (GCB)
        elif (len(cf_id_list) == 1) and (cf_id_list[0] == 104):
            anchor_data = balancewalk.getBWFormatAnchorData(
                            as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                            debug=False,
                            pd_groups=['GCB'],
                            overwrite_calculated_line = True
                            )                                                
        else:
            raise Exception('Contributor file inventory must contain either all(4) or one file id for balance walk')

        ccar_session.logger.add(
            type='INFO',
            message="Finish fetching facility tags from RFO anchor table...",
            context='Balance Walk Session'
        )
        print('Fetching facility tags completed in ' + str(time.time()-t0) + ' s.')

        t0=time.time()
        
        bw_output = balancewalk.balanceWalk(
            cf_data = cf_entire_inventory,
            anchor_data=anchor_data,
            scenario_list=[SCENARIO],
            segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
            process_ALLL_balances = True,
            debug = True
        )  
        print('Balance walk completed in ' + str(time.time()-t0) + ' s.')
        
        bw_output.to_csv(WD+'/CIFI/Execution/BalanceWalk/'+'BW_output_'+SCENARIO+"_version_"+str(FILE_VERSION)+'.csv')
        
        # Pivot balance walk output
        pivot_bw=balancewalk.balanceWalkPivot(bw_output,PIVOT_LENGTH,AS_OF_DATE,bw_output_from_csv = False)        
        pivot_bw.to_csv(WD+'/CIFI/Execution/BalanceWalk/'+'BW_Pivot_'+SCENARIO+"_version_"+str(FILE_VERSION)+'.csv')


    # Write to RFO
    ccar_session.logger.add(
        type='INFO',
        message="Prepare writing to RFO...",
        context='Run Session'
    )          
    run_sig_test = cf_inventory[list(cf_inventory.keys())[0]].testCurrentEnvGetRunSignature(
        p_reporting_date= PORTFOLIO_SNAPSHOT_DATE,
        p_run_id= RUN_VERSION
    )
    ccar_session.logger.add(
        type='INFO',
        message="Fetching run parameters... partition_key : {}, run_signature : {}".format(
            run_sig_test['partition_key'],
            run_sig_test['run_signature']
        ),
        context='Run Session'
    )
        
    for contributor_file_id in cf_inventory:
        if utilities.userInputPrompt(
                message="Would you like to write file ID {} to remote database? [Y/N] ".format(
                    str(contributor_file_id)
                ),
                valid_options=('Y', 'N')
        ) == 'Y':
            ccar_session.logger.add(
                type='INFO',
                message="Writing file ID {} to remote database...".format(str(contributor_file_id)),
                context='Run Session'
            )
                                              
            while(True):
                if utilities.userInputPrompt(
                        message="Would you like to enter run signature and partition key? [Y/N] ".format(
                            str(contributor_file_id)
                        ),
                        valid_options=('Y', 'N')
                ) == 'Y':             
                            
                    RUN_SIGNATURE = str(utilities.userInputPrompt(
                        message="Enter run signature for RFO uploading: "
                    ))
                    PARTITION_KEY = str(utilities.userInputPrompt(
                        message="Enter partition key for RFO uploading: "
                    ))
                else:
                    
                    RUN_SIGNATURE = None
                    PARTITION_KEY = None
                    
                try:
                    cf_inventory[contributor_file_id].writeToMoodysRFO(
                        p_reporting_date=PORTFOLIO_SNAPSHOT_DATE,
                        as_of_date=AS_OF_DATE,
                        p_run_id=RUN_VERSION,
                        debug=True,
                        moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
                        table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
                        contributor_file_id=contributor_file_id,
                        file_version=FILE_VERSION,                                                 
                        overwrite_vintage_asofdate=CONFIG['CONTRIBUTOR_FILE']["VINTAGE_ASOFDATE_VALUE"],
                        run_signature=RUN_SIGNATURE,
                        partition_key=PARTITION_KEY
                    )
                except Exception as e:
                    ccar_session.logger.add(
                        type='ERROR',
                        message="Could NOT write file ID {} to remote database.".format(str(contributor_file_id)),
                        context='Run Session'
                    )
                    ccar_session.logger.add(
                        type='ERROR',
                        message=str(e),
                        context='Run Session'
                    )
                    if utilities.userInputPrompt(
                            message="Could NOT write file ID {} to remote. Would you like to try again? [Y/N]".format(
                                str(contributor_file_id)
                            ),
                            valid_options=('Y', 'N')
                    ) == 'Y':
                        continue
                    else:
                        ccar_session.logger.add(
                            type='WARN',
                            message="Unable to write file ID {} to remote database.".format(
                                str(contributor_file_id)),
                            context='Run Session'
                        )
                        break
                else:
                    ccar_session.logger.add(
                        type='INFO',
                        message="Completed writing file ID {} to remote database.".format(str(contributor_file_id)),
                        context='Run Session'
                    )
                    break

if __name__ == "__main__":
    main()