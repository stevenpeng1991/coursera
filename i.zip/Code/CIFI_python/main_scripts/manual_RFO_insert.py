import os
import sys
global WD
WD = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if WD not in sys.path:
    sys.path.append(WD)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import getpass
import pandas as pd
from CIFI.controllers.contributorfile.contributorfile import ContributorFile
import numpy as np
from CIFI.config import CONFIG

global CONTRIBUTOR_DATA_HEADER_NAMES
CONTRIBUTOR_DATA_HEADER_NAMES = [
    "SCENARIO",
    "MODELSEGMENT",
    "PERIODDATE",
    "VINTAGE",
    "RATETYPE",
    "FEESANDEXPENSESLINEITEM",
    "ASSOCIATEDG_L_ITEM",
    "TRANSFORMATION",
    "PERIODLAG",
    "RATENAME",
    "MODELOUTPUTRATE",
    "UNCERTAINTYADJUSTMENTRATE",
    "MGMTADJUSTMENTRATE",
    "IDIOSYNCRATICRATE1",
    "IDIOSYNCRATICRATE2",
    "IDIOSYNCRATICRATE3",
    "IDIOSYNCRATICRATE4",
    "IDIOSYNCRATICRATE5",
    "ADJUSTMENT_OVERLAY_JUST"
]

global CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS
CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS = [
    "SCENARIO",
    "PERIODDATE",
    "VINTAGE",
    "MODELSEGMENT",
    "RATENAME"
]

global CONTRIBUTOR_DATA_DATE_FIELDS
CONTRIBUTOR_DATA_DATE_FIELDS = [
    'PERIODDATE',
    'VINTAGE'
]

global EAD_LEQ_SEGMENT_KEYS
EAD_LEQ_SEGMENT_KEYS = {
    'EADAVAILABLELINE':0.0,
    'EADBALANCE':1.0,
    'EADLETTEROFCREDIT':1.0,
    'EADTOTALLINE':0.0
}

AS_OF_DATE = datetime.datetime(2016,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2016,11,30)
SCENARIO='DR_BASE' # DR_SA, DR_BASE
SCENARIO_SEVERITY_LEVEL="BASE" # BASE, ADVERSE, STRESS
STRESS_TESTING_CYCLE='DryRun2017'
FORECAST_PERIODS=27
PROMPT_FOR_BLOCK_RUN_OPTION = True
FILE_VERSION = 12
USER_N_NUMBER = getpass.getuser()
SESSION_ID_NAME = STRESS_TESTING_CYCLE + " - " + SCENARIO + " [" + SCENARIO_SEVERITY_LEVEL + "]"

def readCSV(path_to_cf, sep_char=','):
    try:
        data = pd.read_csv(
            filepath_or_buffer=path_to_cf,
            sep=sep_char,
            keep_default_na = False,
            na_values = ['nan', 'NaN', 'NULL', 'null', 'NA', 'N\A', '#N\A', 'None', 'none',''],
            encoding='utf-8'    ,
            date_parser=lambda x : np.nan if x == '.' else datetime.datetime.strptime(x, '%Y-%m-%d'),
            parse_dates=CONTRIBUTOR_DATA_DATE_FIELDS
        )
    except IOError:
        raise Exception("File '" + path_to_cf + "' does not exist")

    # Clean BOM characters
    data.columns = [s.replace('\ufeff','').upper() for s in data.columns]
    data.replace('.', np.nan, inplace=True)

    # Return results
    return data

d101 = readCSV(path_to_cf="C:/Users/n813863/Documents/SHUSA/CIFI/DR_BASE_101.csv")
d102 = readCSV(path_to_cf="C:/Users/n813863/Documents/SHUSA/CIFI/DR_BASE_102.csv")
d103 = readCSV(path_to_cf="C:/Users/n813863/Documents/SHUSA/CIFI/DR_BASE_103.csv")
d104 = readCSV(path_to_cf="C:/Users/n813863/Documents/SHUSA/CIFI/DR_BASE_104.csv")

d = pd.concat([d101, d102, d103, d104])

cf_d = ContributorFile(
    primary_key=CONTRIBUTOR_DATA_PRIMARY_KEY_FIELDS,
    date_fields=CONTRIBUTOR_DATA_DATE_FIELDS,
    header_list=CONTRIBUTOR_DATA_HEADER_NAMES,
    data=d
)

cf_d.enforceCFIntegrity()
cf_d.checkCFIntegrity().getResponse()

cf_d.writeToMoodysRFO(
    p_reporting_date = PORTFOLIO_SNAPSHOT_DATE,
    as_of_date= AS_OF_DATE,
    p_rerun = 'N',
    p_engine = 'ME_LOSS_ENGINE',
    p_cycle = 'CCAR',
    debug = True,
    moodys_rfo_env = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
    table_name = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
    overwrite_vintage_asofdate=CONFIG['CONTRIBUTOR_FILE']["VINTAGE_ASOFDATE_VALUE"],
    contributor_file_id = 1,
    file_version = 12
)


























