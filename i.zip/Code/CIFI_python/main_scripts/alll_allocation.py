import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import numpy as np
import pandas as pd
import copy
import json
import datetime
import CIFI.controllers.utilities.utilities as utilities
from CIFI.config import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.controllers.utilities.smoothing import smoothVectorRatio

asofdate = datetime.datetime(2016, 12, 31)
path_to_loan_level_reserves = "I:/CRMPO/CCAR/4Q16/1 - Data/ALLL_MDS_ALLOC/\
201612 Loan Level Reserves - Without Acceleration.xlsx"

path_to_GCB_rating_group = "I:/CRMPO/CCAR/4Q16/1 - Data/ALLL_MDS_ALLOC/CCAR_DEC_RFO_GCB_ALLL.xlsx"

RATING_LEVEL_PD_GROUPS = [
    'CRE_OTHER', 'CRE_MULTIFAMILY',
    'MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL',
    'GCB'
]
GCB_PD_GROUP = ['GCB']
GCB_RATING_GROUPS = ['GROUP {}'.format(i+1) for i in range(8)]
CI_RISK_RATING_PD_GROUP = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL']
CRE_RISK_RATING_PD_GROUP = ['CRE_OTHER', 'CRE_MULTIFAMILY']
RISK_RATING_LEVELS = np.linspace(start=1.0, stop=8.5, num=16).tolist()[::-1]

def getVectorForSmoothing(
    index_list,
    coverage_summary,
    balance_type
):
    result = []
    for index in index_list:
        try:
            current_value = coverage_summary.loc[index][balance_type]
        except KeyError:
            current_value = 0
        result.append(current_value)

    return(np.asarray(result))

def getAnchorTable(asofdate: datetime.datetime, debug: bool= True):
    # Helpers
    date2OracleSTR = lambda x: x.strftime("%d-%b-%y")

    if debug: print(">>> Getting anchor data from Moody's RFO for {}".format(date2OracleSTR(asofdate)))
    anchor_table = queryRFO(
        query="""
            SELECT
                UNIQUE_FACILITY_ID,
                SUM(UTILIZATIONBOOKBALANCE) AS FUNDED_BALANCE,
                SUM(CALCULATED_LINE) - SUM(UTILIZATIONBOOKBALANCE) AS UNFUNDED_BALANCE,
                ROUND(2*SRR,0)*0.5 AS CONSOLIDATED_SRR,
                SRR,
                RATING_GROUP,
                SEGMENTNAME,
                TO_CHAR({}) AS PD_GROUP,
                FAS114_STATUS
            FROM {}
            WHERE
                ASOFDATE = '{}'
                AND
                UPPER(SEGMENTNAME) NOT IN ('SMALL BUSINESS BANKING', 'SBB')
                AND
                UPPER(SEGMENTNAME) NOT LIKE '%CEVF%'
                AND
                (
					(
						FAS114_STATUS = 'A - NOT REQUIRED'
						AND
						LOCAL_NPL_FLAG = 'N'
					)
					OR
					TDR = 'Y'
				)
				AND
				UPPER(SOURCEID) NOT IN ('OFFLINE')
            GROUP BY
                UNIQUE_FACILITY_ID,
                SRR,
                RATING_GROUP,
                SEGMENTNAME,
                {},
                FAS114_STATUS
            HAVING
                SUM(CALCULATED_LINE) > 0
        """.format(
            CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT_PD_GROUP_FIELD_NAME'],
            CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['TABLE_NAMES']['SB_COMM_ANCHOR_DATA'],
            date2OracleSTR(asofdate),
            CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT_PD_GROUP_FIELD_NAME']
        ),
        moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT']
    )

    # CREATE ANCHOR GROUP 1
    if debug: print(">>> Creating anchor_group_1...")
    anchor_group_1 = anchor_table.groupby(
        by=[
            'CONSOLIDATED_SRR',
            'SEGMENTNAME'
        ]
    )[['FUNDED_BALANCE', 'UNFUNDED_BALANCE']].sum()

    # CHECK CONSISTENCY ANCHOR GROUP 1
    if round(anchor_table['FUNDED_BALANCE'].sum(),-1) != round(anchor_group_1['FUNDED_BALANCE'].sum(), -1):
        raise Exception("Group1 FUNDED_BALANCE does not match starting balance.")
    if round(anchor_table['UNFUNDED_BALANCE'].sum(),-1) != round(anchor_group_1['UNFUNDED_BALANCE'].sum(),-1):
        raise Exception("Group1 UNFUNDED_BALANCE does not match starting balance.")
    if debug: print(">>> anchor_group_1 create with all checks passed.")

    # CREATE ANCHOR GROUP 2
    if debug: print(">>> Creating anchor_group_2...")
    anchor_group_2 = anchor_table.groupby(
        by=[
            'SEGMENTNAME'
        ]
    )[['FUNDED_BALANCE', 'UNFUNDED_BALANCE']].sum()

    # CHECK CONSISTENCY ANCHOR GROUP 2
    if round(anchor_table['FUNDED_BALANCE'].sum(),-1) != round(anchor_group_2['FUNDED_BALANCE'].sum(), -1):
        raise Exception("Group1 FUNDED_BALANCE does not match starting balance.")
    if round(anchor_table['UNFUNDED_BALANCE'].sum(),-1) != round(anchor_group_2['UNFUNDED_BALANCE'].sum(),-1):
        raise Exception("Group1 UNFUNDED_BALANCE does not match starting balance.")
    if debug: print(">>> anchor_group_2 create with all checks passed.")


    # CREATE ANCHOR GROUP 3
    if debug: print(">>> Creating anchor_group_3...")
    anchor_group_3 = pd.DataFrame({
        'FUNDED_BALANCE':pd.Series([anchor_table['FUNDED_BALANCE'].sum()]),
        'UNFUNDED_BALANCE':pd.Series([anchor_table['UNFUNDED_BALANCE'].sum()])
    })

    # CHECK CONSISTENCY ANCHOR GROUP 3
    if round(anchor_table['FUNDED_BALANCE'].sum(),-1) != round(anchor_group_3['FUNDED_BALANCE'].sum(), -1):
        raise Exception("Group1 FUNDED_BALANCE does not match starting balance.")
    if round(anchor_table['UNFUNDED_BALANCE'].sum(),-1) != round(anchor_group_3['UNFUNDED_BALANCE'].sum(),-1):
        raise Exception("Group1 UNFUNDED_BALANCE does not match starting balance.")
    if debug: print(">>> anchor_group_3 create with all checks passed.")

    # CREATE RATIOS FOR EACH GROUP LEVEL
    if debug: print(">>> Creating ratios for all groups...")
    anchor_table['FUNDED_ALLOC_GROUP_1'] = np.NaN
    anchor_table['FUNDED_ALLOC_GROUP_2'] = np.NaN
    anchor_table['FUNDED_ALLOC_GROUP_3'] = np.NaN
    anchor_table['UNFUNDED_ALLOC_GROUP_1'] = np.NaN
    anchor_table['UNFUNDED_ALLOC_GROUP_2'] = np.NaN
    anchor_table['UNFUNDED_ALLOC_GROUP_3'] = np.NaN
    coalesce = lambda x: 0 if pd.isnull(x) else x
    for index, row in anchor_table.iterrows():
        try:
            if (row['CONSOLIDATED_SRR'] == 0.0) & (row['PD_GROUP'] in RATING_LEVEL_PD_GROUPS):
                anchor_table.loc[index, 'FUNDED_ALLOC_GROUP_1'] = 0.0
            else:
                anchor_table.loc[index, 'FUNDED_ALLOC_GROUP_1'] = coalesce(row['FUNDED_BALANCE']/ \
                    anchor_group_1.loc[row['CONSOLIDATED_SRR'], row['SEGMENTNAME']]['FUNDED_BALANCE'])
            if (row['CONSOLIDATED_SRR'] == 0.0) & (row['PD_GROUP'] in RATING_LEVEL_PD_GROUPS):
                anchor_table.loc[index, 'UNFUNDED_ALLOC_GROUP_1'] = 0.0
            else:
                anchor_table.loc[index, 'UNFUNDED_ALLOC_GROUP_1'] = coalesce(row['UNFUNDED_BALANCE'] / \
                    anchor_group_1.loc[row['CONSOLIDATED_SRR'], row['SEGMENTNAME']]['UNFUNDED_BALANCE'])
        except KeyError:
            pass

        try:
            anchor_table.loc[index, 'FUNDED_ALLOC_GROUP_2'] = coalesce(row['FUNDED_BALANCE'] / \
                anchor_group_2.loc[row['SEGMENTNAME']]['FUNDED_BALANCE'])
            anchor_table.loc[index, 'UNFUNDED_ALLOC_GROUP_2'] = coalesce(row['UNFUNDED_BALANCE'] / \
                anchor_group_2.loc[row['SEGMENTNAME']]['UNFUNDED_BALANCE'])
        except KeyError:
            pass

        try:
            anchor_table.loc[index, 'FUNDED_ALLOC_GROUP_3'] = coalesce(row['FUNDED_BALANCE'] / \
                anchor_group_3['FUNDED_BALANCE'][0])
            anchor_table.loc[index, 'UNFUNDED_ALLOC_GROUP_3'] = coalesce(row['UNFUNDED_BALANCE'] / \
                anchor_group_3['UNFUNDED_BALANCE'][0])
        except KeyError:
            pass

    if debug: print(">>> Process completed successfully. Returning data...")
    return(anchor_table)

def getReservesTables(path_to_loan_level_reserves: str, debug: bool= True):
    if debug: print(">>> Fetching the loan level reserves file...")
    loan_level_reserves = pd.read_excel(
        io=path_to_loan_level_reserves,
        sheetname='DATA'
    )

    if debug: print(">>> Subsetting loan level results...")
    loan_level_reserves = loan_level_reserves[
        (loan_level_reserves['Status'] == 'Portfolio')
        &
        (~loan_level_reserves['SegmentName'].isin(['Small Business Banking', 'CEVF-Strategic']))
        &
        (~loan_level_reserves['SourceId'].isin(['Offline']))
    ]
    loan_level_reserves['UNIQUE_FACILITY_ID'] = (
        loan_level_reserves['SourceId'] + \
        loan_level_reserves['OneObligorNumber'] + \
        loan_level_reserves['CustomerNumber'] + \
        loan_level_reserves['FacilityNumber']
    )
    loan_level_reserves['FUNDED_RESERVE'] = loan_level_reserves['Final Reserve Book Balance']
    loan_level_reserves['UNFUNDED_RESERVE'] = loan_level_reserves['Contingent']
    loan_level_reserves['CONSOLIDATED_SRR'] = loan_level_reserves['SRR'].apply(
        lambda x : round(2*x,0)*0.5
    )
    loan_level_reserves['SEGMENTNAME'] = loan_level_reserves['SegmentName']
    loan_level_reserves['SEGMENTNAME'].replace(
        to_replace='Large Corporate Commercial',
        value='Global Corporate Banking',
        inplace=True
    )
    loan_level_reserves['SEGMENTNAME'].replace(
        to_replace='MRG',
        value='Global Corporate Banking',
        inplace=True
    )
    loan_level_reserves = loan_level_reserves[[
        'UNIQUE_FACILITY_ID',
        'SEGMENTNAME',
        'CONSOLIDATED_SRR',
        'FUNDED_RESERVE',
        'UNFUNDED_RESERVE'
    ]]

    # CHECK SEGMENTNAME VALUES IN BOTH DATAFRAMES
    if len(set(anchor_table.SEGMENTNAME.unique()) - set(loan_level_reserves.SEGMENTNAME.unique()))>0:
        raise Exception("The ANCHOR table contains SegmentName values that don't exist in ALLL RESERVES.")

    # CREATE ANCHOR GROUP 1
    if debug: print(">>> Creating reserves_group_1...")
    reserves_group_1 = loan_level_reserves.groupby(
        by=[
            'CONSOLIDATED_SRR',
            'SEGMENTNAME'
        ]
    )[['FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum()

    # CHECK CONSISTENCY ANCHOR GROUP 1
    if round(loan_level_reserves['FUNDED_RESERVE'].sum(),-1) != round(reserves_group_1['FUNDED_RESERVE'].sum(), -1):
        raise Exception("Group1 FUNDED_RESERVE does not match starting balance.")
    if round(loan_level_reserves['UNFUNDED_RESERVE'].sum(),-1) != round(reserves_group_1['UNFUNDED_RESERVE'].sum(),-1):
        raise Exception("Group1 UNFUNDED_RESERVE does not match starting balance.")
    if debug: print(">>> reserves_group_1 create with all checks passed.")

    # CREATE ANCHOR GROUP 2
    if debug: print(">>> Creating reserves_group_2...")
    reserves_group_2 = loan_level_reserves.groupby(
        by=[
            'SEGMENTNAME'
        ]
    )[['FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum()

    # CHECK CONSISTENCY ANCHOR GROUP 2
    if round(loan_level_reserves['FUNDED_RESERVE'].sum(),-1) != round(reserves_group_2['FUNDED_RESERVE'].sum(), -1):
        raise Exception("Group1 FUNDED_RESERVE does not match starting balance.")
    if round(loan_level_reserves['UNFUNDED_RESERVE'].sum(),-1) != round(reserves_group_2['UNFUNDED_RESERVE'].sum(),-1):
        raise Exception("Group1 UNFUNDED_RESERVE does not match starting balance.")
    if debug: print(">>> reserves_group_2 create with all checks passed.")


    # CREATE ANCHOR GROUP 3
    if debug: print(">>> Creating reserves_group_3...")
    reserves_group_3 = pd.DataFrame({
        'FUNDED_RESERVE':pd.Series([loan_level_reserves['FUNDED_RESERVE'].sum()]),
        'UNFUNDED_RESERVE':pd.Series([loan_level_reserves['UNFUNDED_RESERVE'].sum()])
    })

    # CHECK CONSISTENCY ANCHOR GROUP 3
    if round(loan_level_reserves['FUNDED_RESERVE'].sum(),-1) != round(reserves_group_3['FUNDED_RESERVE'].sum(), -1):
        raise Exception("Group1 FUNDED_RESERVE does not match starting balance.")
    if round(loan_level_reserves['UNFUNDED_RESERVE'].sum(),-1) != round(reserves_group_3['UNFUNDED_RESERVE'].sum(),-1):
        raise Exception("Group1 UNFUNDED_RESERVE does not match starting balance.")
    if debug: print(">>> reserves_group_3 create with all checks passed.")

    if debug: print(">>> Process completed successfully. Returning data...")
    return reserves_group_1, reserves_group_2, reserves_group_3

anchor_table = getAnchorTable(
    asofdate=asofdate,
    debug=True
)

GCB_rating_group = pd.read_excel(
    io=path_to_GCB_rating_group,
    sheetname='DATA'
)[['UNIQUE_FACILITY_ID', 'RatingGroup']]
GCB_rating_group['RatingGroup'] = GCB_rating_group['RatingGroup'].apply(lambda x : "GROUP {}".format(x))

anchor_table = anchor_table.merge(
    right=GCB_rating_group,
    how='left',
    on=['UNIQUE_FACILITY_ID']
)

reserves_group_1, reserves_group_2, reserves_group_3 = getReservesTables(
    path_to_loan_level_reserves=path_to_loan_level_reserves,
    debug=True
)

# RUN 1
anchor_table['FUNDED_RESERVE'] = np.NaN
anchor_table['UNFUNDED_RESERVE'] = np.NaN
for index, row in anchor_table.iterrows():
    allocation = 0
    try:
        if row['FUNDED_BALANCE'] == 0.0:
            allocation = 0
        elif (row['CONSOLIDATED_SRR'] == 0.0) & (row['PD_GROUP'] in RATING_LEVEL_PD_GROUPS):
            allocation = 0
        else:
            allocation = row['FUNDED_ALLOC_GROUP_1'] * \
                reserves_group_1.loc[row['CONSOLIDATED_SRR'], row['SEGMENTNAME']]['FUNDED_RESERVE']
        anchor_table.loc[index, 'FUNDED_RESERVE'] = allocation
    except KeyError:
        pass
    try:
        if row['UNFUNDED_BALANCE'] == 0.0:
            allocation = 0
        elif (row['CONSOLIDATED_SRR'] == 0.0) & (row['PD_GROUP'] in RATING_LEVEL_PD_GROUPS):
            allocation = 0
        else:
            allocation = row['UNFUNDED_ALLOC_GROUP_1'] * \
                reserves_group_1.loc[row['CONSOLIDATED_SRR'], row['SEGMENTNAME']]['UNFUNDED_RESERVE']
        anchor_table.loc[index, 'UNFUNDED_RESERVE'] = allocation
    except KeyError:
        pass

# CALCUALTE REMAINING RESERVES
reserves_group_2_remaining = abs(round(reserves_group_2 - anchor_table.groupby(
    by=[
        'SEGMENTNAME'
    ]
)[['FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum(), 0))

# RUN 2
for index, row in anchor_table.iterrows():
    allocation = 0
    try:
        allocation = row['FUNDED_ALLOC_GROUP_2'] * \
            reserves_group_2_remaining.loc[row['SEGMENTNAME']]['FUNDED_RESERVE']
        if pd.isnull(row['FUNDED_RESERVE']):
            anchor_table.loc[index, 'FUNDED_RESERVE'] = allocation
        else:
            anchor_table.loc[index, 'FUNDED_RESERVE'] = row['FUNDED_RESERVE'] + allocation
    except KeyError:
        pass
    try:
        allocation = row['UNFUNDED_ALLOC_GROUP_2'] * \
                     reserves_group_2_remaining.loc[row['SEGMENTNAME']]['UNFUNDED_RESERVE']
        if pd.isnull(row['UNFUNDED_RESERVE']):
            anchor_table.loc[index, 'UNFUNDED_RESERVE'] = allocation
        else:
            anchor_table.loc[index, 'UNFUNDED_RESERVE'] = row['UNFUNDED_RESERVE'] + allocation
    except KeyError:
        pass

reserves_group_3_remaining = abs(round(reserves_group_2 - anchor_table.groupby(
    by=[
        'SEGMENTNAME'
    ]
)[['FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum(), 0))

print("REMAINING RESERVES TO ALLOCATE: ")
print(reserves_group_3_remaining.sum())

# reserves_group_3['FUNDED_RESERVE'].sum() - anchor_table['FUNDED_RESERVE'].sum()
# reserves_group_3['UNFUNDED_RESERVE'].sum() - anchor_table['UNFUNDED_RESERVE'].sum()
#
# anchor_table[pd.isnull(anchor_table['FUNDED_RESERVE'])]
# anchor_table[pd.isnull(anchor_table['UNFUNDED_RESERVE'])]


# GENERATE PIVOTS

## PORTFOLIO_LEVEL_PD_GROUPS
portfolio_level_coverage_summary = anchor_table[~anchor_table['PD_GROUP'].isin(RATING_LEVEL_PD_GROUPS)].groupby(
    by=[
        'PD_GROUP'
    ]
)[['FUNDED_BALANCE', 'UNFUNDED_BALANCE', 'FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum()
portfolio_level_coverage_summary['ALLLCOVERAGE'] = portfolio_level_coverage_summary['FUNDED_RESERVE']/\
                                                   portfolio_level_coverage_summary['FUNDED_BALANCE']
portfolio_level_coverage_summary['CONTINGENTRESERVE'] = portfolio_level_coverage_summary['UNFUNDED_RESERVE']/\
                                                        portfolio_level_coverage_summary['UNFUNDED_BALANCE']
portfolio_level_coverage_summary.fillna(value=0, inplace=True)

## GCB
GCB_coverage_summary = anchor_table[anchor_table['PD_GROUP'].isin(GCB_PD_GROUP)].groupby(
    by=[
        'RatingGroup'
    ]
)[['FUNDED_BALANCE', 'UNFUNDED_BALANCE', 'FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum()
GCB_ALLLCOVERAGE_SMOOTH, GCB_ALLLCOVERAGE_SMOOTH_TRACKER = smoothVectorRatio(
    numerator=getVectorForSmoothing(
        index_list=GCB_RATING_GROUPS,
        coverage_summary=GCB_coverage_summary,
        balance_type='FUNDED_RESERVE'
    ),
    denominator=getVectorForSmoothing(
        index_list=GCB_RATING_GROUPS,
        coverage_summary=GCB_coverage_summary,
        balance_type='FUNDED_BALANCE'
    ),
    plot=True,
    debug=True
)
GCB_CONTINGENTRESERVE_SMOOTH, GCB_CONTINGENTRESERVE_SMOOTH_TRACKER = smoothVectorRatio(
    numerator=getVectorForSmoothing(
        index_list=GCB_RATING_GROUPS,
        coverage_summary=GCB_coverage_summary,
        balance_type='UNFUNDED_RESERVE'
    ),
    denominator=getVectorForSmoothing(
        index_list=GCB_RATING_GROUPS,
        coverage_summary=GCB_coverage_summary,
        balance_type='UNFUNDED_BALANCE'
    ),
    plot=True,
    debug=True
)
GCB_coverage_summary = pd.DataFrame(
    np.vstack((
        GCB_RATING_GROUPS,
        GCB_ALLLCOVERAGE_SMOOTH,
        GCB_CONTINGENTRESERVE_SMOOTH
    )).T,
    columns=['RatingGroup', 'ALLLCOVERAGE', 'CONTINGENTRESERVE']
).set_index('RatingGroup').join(GCB_coverage_summary)


## C&I RISK RATING
CI_RISK_RATING_coverage_summary = anchor_table[anchor_table['PD_GROUP'].isin(CI_RISK_RATING_PD_GROUP)].groupby(
    by=[
        'CONSOLIDATED_SRR'
    ]
)[['FUNDED_BALANCE', 'UNFUNDED_BALANCE', 'FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum()
CI_ALLLCOVERAGE_SMOOTH, CI_ALLLCOVERAGE_SMOOTH_TRACKER = smoothVectorRatio(
    numerator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CI_RISK_RATING_coverage_summary,
        balance_type='FUNDED_RESERVE'
    ),
    denominator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CI_RISK_RATING_coverage_summary,
        balance_type='FUNDED_BALANCE'
    ),
    plot=True,
    debug=False
)
CI_CONTINGENTRESERVE_SMOOTH, CI_CONTINGENTRESERVE_SMOOTH_TRACKER = smoothVectorRatio(
    numerator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CI_RISK_RATING_coverage_summary,
        balance_type='UNFUNDED_RESERVE'
    ),
    denominator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CI_RISK_RATING_coverage_summary,
        balance_type='UNFUNDED_BALANCE'
    ),
    plot=True,
    debug=True
)
CI_RISK_RATING_coverage_summary = pd.DataFrame(
    np.vstack((
        RISK_RATING_LEVELS,
        CI_ALLLCOVERAGE_SMOOTH,
        CI_CONTINGENTRESERVE_SMOOTH
    )).T,
    columns=['MRS', 'ALLLCOVERAGE', 'CONTINGENTRESERVE']
).set_index('MRS').join(CI_RISK_RATING_coverage_summary)

## CRE RISK RATING
CRE_RISK_RATING_coverage_summary = anchor_table[anchor_table['PD_GROUP'].isin(CRE_RISK_RATING_PD_GROUP)].groupby(
    by=[
        'CONSOLIDATED_SRR'
    ]
)[['FUNDED_BALANCE', 'UNFUNDED_BALANCE', 'FUNDED_RESERVE', 'UNFUNDED_RESERVE']].sum()
CRE_ALLLCOVERAGE_SMOOTH, CRE_ALLLCOVERAGE_SMOOTH_TRACKER = smoothVectorRatio(
    numerator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CRE_RISK_RATING_coverage_summary,
        balance_type='FUNDED_RESERVE'
    ),
    denominator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CRE_RISK_RATING_coverage_summary,
        balance_type='FUNDED_BALANCE'
    ),
    plot=True,
    debug=False
)
CRE_CONTINGENTRESERVE_SMOOTH, CRE_CONTINGENTRESERVE_SMOOTH_TRACKER = smoothVectorRatio(
    numerator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CRE_RISK_RATING_coverage_summary,
        balance_type='UNFUNDED_RESERVE'
    ),
    denominator=getVectorForSmoothing(
        index_list=RISK_RATING_LEVELS,
        coverage_summary=CRE_RISK_RATING_coverage_summary,
        balance_type='UNFUNDED_BALANCE'
    ),
    plot=True,
    debug=False
)
CRE_RISK_RATING_coverage_summary = pd.DataFrame(
    np.vstack((
        RISK_RATING_LEVELS,
        CRE_ALLLCOVERAGE_SMOOTH,
        CRE_CONTINGENTRESERVE_SMOOTH
    )).T,
    columns=['MRS', 'ALLLCOVERAGE', 'CONTINGENTRESERVE']
).set_index('MRS').join(CRE_RISK_RATING_coverage_summary)



# FINAL COPY TO CLIPBOARD
portfolio_level_coverage_summary.to_clipboard()
GCB_coverage_summary.to_clipboard()
CI_RISK_RATING_coverage_summary.to_clipboard()
CRE_RISK_RATING_coverage_summary.to_clipboard()









































