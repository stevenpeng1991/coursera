import sys
wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import pandas as pd
import numpy as np
import time
import copy
import os
import cx_Oracle
from CIFI.config import CONFIG

##
## IMPORT MODELS
##
from CIFI.controllers.models.creconstruction17 import CREConstruction
from CIFI.controllers.models.logitmodel import TwoFLogitModel
from CIFI.controllers.ejm.ejmmaster import EJMGenerator, ejmDictionaryGenerator
from CIFI.controllers.models.riskratingmodel import RiskRatingModel
from CIFI.controllers.models.gcbindustry import GCBModel
from CIFI.controllers.models.cniriskrating import CNIModel

##
## GLOBAL PARAMS
##
AS_OF_DATE = datetime.datetime(2016,6,30)
SCENARIO='ICP_Adverse'
STRESS_TESTING_CYCLE='ICAAP2016'
FORECAST_PERIODS=27
USER_N_NUMBER = 'n813863'
SESSION_ID_NAME = 'Mid Cycle Parallel Test'


##
## CREATE SESSION AND SHOPPING CART
##
ccar_session = CCARSession(
    session_id=SESSION_ID_NAME,
    session_date=AS_OF_DATE,
    user=USER_N_NUMBER
)
cart = ModelShoppingCart(ccar_session=ccar_session)

##
## CREATE MODEL INSTANCES
##
CRE_risk_rating_instance = RiskRatingModel(
    uncertainty_rate=0.00,
    as_of_date=AS_OF_DATE,
    model_id='721 - Commercial Rating Model - CRE Multifamily PD - SBNA',
    scenario=SCENARIO,
    scenario_context=STRESS_TESTING_CYCLE,
    forecast_periods=FORECAST_PERIODS,
    debug=True,
    bau=None,
    origination=True,
    book_balance_filter=None,
    gl_filter=True,
    read_input=False
)
cart.addModel(CRE_risk_rating_instance)


GCB = GCBModel(
    as_of_date=AS_OF_DATE,
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario=SCENARIO,
    scenario_context=STRESS_TESTING_CYCLE,
    forecast_periods=FORECAST_PERIODS,
    lgd_scale={
        'Consumer and Industrial-US/Canada':
        {'lgd_secured_scaling': 0.969960,
        'lgd_unsecured_scaling': 0.977930},
        'Financials-US/Canada':
        {'lgd_secured_scaling': 0.94694,
        'lgd_unsecured_scaling': 0.95973},
        'Oil and Gas-Global':
        {'lgd_secured_scaling': 0.85657,
        'lgd_unsecured_scaling': 0.88846},
        'Consumer and Industrial-Rest of the World':
        {'lgd_secured_scaling': 0.96232,
        'lgd_unsecured_scaling': 0.97229},
        'Financials-Rest of the World':
        {'lgd_secured_scaling': 0.86936,
        'lgd_unsecured_scaling': 0.89885}
        }
)
cart.addModel(GCB)


CI_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,
    scenario=SCENARIO,
    scenario_context=STRESS_TESTING_CYCLE,
    scenario_severity_level="ADVERSE",
    forecast_periods=FORECAST_PERIODS,
    pass_srr=4.0,
    model_id="2016-SBNA-Loss-Commecial-CI",
    forecast_periods_frequency='monthly',
    debug=True,
    include_originations=True,
    auto_fetch_macros=True
)
cart.addModel(CI_model_instance)


CREConstruction_instance = CREConstruction(
    uncertainty_rate=0.,
    as_of_date=AS_OF_DATE,
    model_id="2016-SBNA-Loss-Commercial-CREConstruction",
    scenario=SCENARIO,
    scenario_context=STRESS_TESTING_CYCLE,
    forecast_periods=FORECAST_PERIODS
)
cart.addModel(CREConstruction_instance)


TwoFLogitModel_SBB_instance = TwoFLogitModel(
    uncertainty_rate=0.,
    as_of_date=AS_OF_DATE,
    model_id='37 - Scenario Analysis Model - SBB PD - SBNA',
    scenario=SCENARIO,
    scenario_context=STRESS_TESTING_CYCLE,
    forecast_periods=FORECAST_PERIODS
)
cart.addModel(TwoFLogitModel_SBB_instance)

TwoFLogitModel_CEVF_instance = TwoFLogitModel(
    uncertainty_rate=0.,
    as_of_date=AS_OF_DATE,
    model_id='53 - Scenario Analysis Model - CEVF PD - SBNA',
    scenario=SCENARIO,
    scenario_context=STRESS_TESTING_CYCLE,
    forecast_periods=FORECAST_PERIODS
)
cart.addModel(TwoFLogitModel_CEVF_instance)


##
## CART CHECKOUT
##
cart.checkout()

##
## PROCESS EJM's
##
# Retail EJM's
retail_ejm_generator = EJMGenerator(
    as_of_date = AS_OF_DATE,
    path_to_json="I:/CRMPO/CCAR/4Q16/3-Contributor Files/json/ICP_Adverse_Retail_Loss_EJMs.json",
    forecast_periods=FORECAST_PERIODS,
    debug=True
)
retail_ejm_generator.execute(session=ccar_session)

# Commercial EJM's
commercial_ejm_dictionary = ejmDictionaryGenerator(
    asofdate = AS_OF_DATE,
    scenario_pairs = {
        "ADVERSE":"ICP_Adverse"
    },
    pd_group_field=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
    rfo_table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
    debug=True
)
commercial_ejm_generator = EJMGenerator(
    as_of_date = AS_OF_DATE,
    ejm_dictionary=commercial_ejm_dictionary,
    forecast_periods=FORECAST_PERIODS,
    debug=True
)
commercial_ejm_generator.execute(session=ccar_session)



cf = ccar_session.contributor_file_generator.contributor_file
cf.checkCFIntegrity().getResponse()

##
## Write CF to RFO
##
cf.writeToMoodysRFO(
    p_reporting_date = AS_OF_DATE,
    p_rerun = 'N',
    p_engine = 'ME_LOSS_ENGINE',
    p_cycle = 'CCAR',
    debug = True,
    moodys_rfo_env = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
    table_name = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
    contributor_file_id = 1,
    file_version = 5
)


# df = cf.getCFData().copy(deep=True)
# as_of_date = AS_OF_DATE
# debug = True
# moodys_rfo_env = "UAT_ENV"
# table_name = 'STG_CONTRIBUTOR_DATA'
# table_headers = [
#     "PARTITION_KEY",
#     "RUN_SIGNATURE",
#     "CONTRIBUTOR_FILE_ID",
#     "FILE_VERSION",
#     "SCENARIO",
#     "MODELSEGMENT",
#     "PERIODDATE",
#     "VINTAGE",
#     "RATETYPE",
#     "FEESANDEXPENSESLINEITEM",
#     "ASSOCIATEDG_L_ITEM",
#     "TRANSFORMATION",
#     "PERIODLAG",
#     "RATENAME",
#     "MODELOUTPUTRATE",
#     "UNCERTAINTYADJUSTMENTRATE",
#     "MGMTADJUSTMENTRATE",
#     "IDIOSYNCRATICRATE1",
#     "IDIOSYNCRATICRATE2",
#     "IDIOSYNCRATICRATE3",
#     "IDIOSYNCRATICRATE4",
#     "IDIOSYNCRATICRATE5",
#     "ADJUSTMENT_OVERLAY_JUST"
# ]
#
# """
# This function inserts contributor data into RFO.
#
# Parameters
# ----------
# data: (pandas.DataFrame) contributor data to insert
#
# Returns
# -------
# (bool) whether or not the data was inserted correctly
# """
# if debug:
#     print("Connecting to database...")
# connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][moodys_rfo_env]
# cx_Oracle_DSN = cx_Oracle.makedsn(
#     host=connection_strings["HOST_IP"],
#     port=connection_strings["ORACLE_PORT"],
#     sid=connection_strings["SID"]
# )
# connection = cx_Oracle.connect(
#     user=connection_strings["USER_NAME"],
#     password=connection_strings["PASSWORD"],
#     dsn=cx_Oracle_DSN
# )
# cursor = connection.cursor()
#
# # Create SQL insert statement
# def to_sql_array(A: list) -> str:
#     """
#     This function transforms an input array into a str representation
#     of the corresponding SQL array
#
#     Parameters
#     ----------
#     A: (list) some input array
#
#     Returns
#     -------
#     (str) str containing the SQL array
#     """
#     s = '('
#     for h in A:
#         wrap_char = ""
#         s += (wrap_char + str(h) + wrap_char + ',')
#     s = s.strip(',')
#     s += ')'
#     return(s)
# if debug:
#     print("Creating INSERT statement...")
# statement = 'INSERT INTO ' + \
#     connection_strings["SCHEMA_NAME"]+"."+table_name + \
#     to_sql_array(table_headers) + \
#     ' VALUES ' + \
#     to_sql_array([':' + str(i) for i in table_headers])
# if debug:
#     print("STATEMENT:\n"+statement)
#
# # Get run parameters
# if debug:
#     print("Getting run parameters...")
# v_run_sig = cursor.var(cx_Oracle.STRING)
# v_part_key = cursor.var(cx_Oracle.STRING)
# cursor.callproc(connection_strings["SCHEMA_NAME"]+"."+'publish_run_signature', [
#     as_of_date.strftime("%Y%m%d"),
#     'N',
#     'ME_LOSS_ENGINE',
#     'CCAR',
#     v_run_sig,
#     v_part_key
# ])
# df["PARTITION_KEY"] = 'S00000000022'
# df["RUN_SIGNATURE"] = '063016_12223'
# df["CONTRIBUTOR_FILE_ID"] = 1
# df["FILE_VERSION"] = 1
# df = df[table_headers]
#
# # Prepare data and replace NAs by None
# # data_2 = data[pd.notnull(data["VINTAGE"])]
# # data_3 = data_2.where((pd.notnull(data_2)), None)
# # data_2["VINTAGE"] = data_2.VINTAGE.apply(lambda x: None if pd.isnull(x) else x)
# if debug:
#     print("Transforming data to array of dicts...")
# records_to_insert = list(df.to_dict(orient='records'))
# records_to_insert = list(df.T.to_dict().values())
# if len(records_to_insert) != len(df):
#     raise Exception("Not all records were converted to array of dictionaries.")
#
# if debug:
#     print("Replacing nulls by None...")
# for item in records_to_insert:
#     for key in item.keys():
#         if pd.isnull(item[key]):
#             print(item)
#             item[key] = None
#
# # Begin insert process
# if debug:
#     print("Begin insert...")
# t0 = time.time()
# cursor.prepare(statement)
# print(cursor.bindnames())
# cursor.executemany(statement, records_to_insert)
# # try:
# # 	cursor.executemany(statement, records_to_insert)
# # except:
# # 	return(False)
#
# # Commit insert operation
# connection.commit()
#
# # Calculate runtime
# t1 = time.time()
# runtime = round((t1 - t0), 5)
# if debug:
#     print("Insert completed!")
#     print("Runtime : " + str(runtime) + "s.")
#
# # Finalize
# cursor.close()
# connection.close()
































