import sys
wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
import CIFI.models.macrovariables.macrovariables as mv
import datetime
import time
import pandas as pd
import numpy as np
import copy
import json
import os

ASOFDATE = datetime.datetime(2005, 12, 31)

def main():
	CONTEXT = 'MidCycle16'
	WD = "I:/CRMPO/CCAR/2Q16/2 - Scenarios/Scenario Plots/"

	list_of_indicators = {
        "FGDPxxx_US": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        "FLBR_US": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        "FYPEWSQ_US": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        "FHCHMPI_US": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        "FZFL075035503Q_US": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        "FLBU_US ": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        " FSP500Q_US ": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        " FRBAAC_US ": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        },
        " FRGT10Y_US ": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'none'
        }
        
        }

    list_of_indicators = {
        "FGDPxxx_US": {
        "geo_scope":'National&Regional',
        "period_frequency":'quarterly',
        "as_of_date":ASOFDATE,
        "forecast_periods":165,
        "lag":0,
        "transformation_type":'p1y'
        }
    }


	for indicator in list_of_indicators.keys():
		mv.plotIndicatorScenarios(
			indicator=indicator.strip(" "),
		    context=CONTEXT,
		    geo_scope=list_of_indicators[indicator]['geo_scope'],
		    period_frequency=list_of_indicators[indicator]['period_frequency'],
		    as_of_date =list_of_indicators[indicator]['as_of_date'],
		    forecast_periods = list_of_indicators[indicator]['forecast_periods'],
		    lag=list_of_indicators[indicator]['lag'],
		    transformation_type=list_of_indicators[indicator]['transformation_type'],
			save_to_file=WD+
                         indicator+"_"+
                         str(list_of_indicators[indicator]['lag'])+"_"+
                         list_of_indicators[indicator]['transformation_type']+"_"+
                         CONTEXT+".png"
		)

if __name__ == "__main__":
	main()

