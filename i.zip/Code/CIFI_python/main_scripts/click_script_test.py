import datetime
import sys
import pandas as pd
import numpy as np
import time
import copy
import os
import cx_Oracle
import getpass
import click
import click

@click.command()
@click.option(
    '-w',
    '--wd',
    type=str,
    prompt=True,
    help="Current working directory."
)
@click.option(
    '-y',
    '--year',
    type=int,
    prompt="Run year",
    help="Run year in yyyy format."
)
@click.option(
    '-m',
    '--month',
    type=int,
    prompt="Run month",
    help="Run month in mm format."
)
@click.option(
    '-d',
    '--day',
    type=int,
    prompt="Run day",
    help="Run day in dd format."
)
@click.option(
    '-s',
    '--scenario',
    type=str,
    prompt="Scenario",
    help="Scenario name."
)
@click.option(
    '--scenario_severity',
    type=str,
    prompt="Scenario severity level (BASE, ADVERSE, STRESS)",
    help="Scenario severity level (BASE, ADVERSE, or STRESS)."
)
@click.option(
    '-c',
    '--cycle',
    type=str,
    prompt="Stress testing cycle",
    help="Stress testing cycle name."
)
@click.option(
    '-p',
    '--periods',
    type=int,
    prompt="Forecast periods",
    help="Number of forecast periods."
)
def RUN(wd, year, month, day, scenario, scenario_severity, cycle, periods):

    ##
    ## GATHER CLI INPUTS
    ##
    click.echo("Current working directory: " + wd)
    as_of_date = datetime.datetime(year=year, month=month, day=day)
    click.echo("Run as-of-date: " + str(as_of_date))
    click.echo("Run scenario: " + scenario + "[" + scenario_severity + "]")
    click.echo("Run cycle: " + cycle)
    click.echo("Run forecast periods: " + str(periods))

    ##
    ## CREATE GLOBAL INPUT PARAMS
    ##
    AS_OF_DATE = as_of_date
    SCENARIO = scenario
    SCENARIO_SEVERITY_LEVEL = scenario_severity
    STRESS_TESTING_CYCLE = cycle
    FORECAST_PERIODS = periods
    USER_N_NUMBER = getpass.getuser()
    SESSION_ID_NAME = STRESS_TESTING_CYCLE + " - " + SCENARIO + " [" + SCENARIO_SEVERITY_LEVEL + "]"

    ##
    ## ADD CURRENT WD TO PYTHONPATH
    ##
    if wd not in sys.path:
        sys.path.append(wd)

    ##
    ## IMPORT ADDITIONAL MODULES
    ##
    from CIFI.config import CONFIG
    import CIFI.controllers.utilities.utilities as utilities
    from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
    from CIFI.controllers.utilities.session import CCARSession

    ##
    ## CREATE SESSION AND SHOPPING CART
    ##
    ccar_session = CCARSession(
        session_id=SESSION_ID_NAME,
        session_date=AS_OF_DATE,
        user=USER_N_NUMBER
    )
    cart = ModelShoppingCart(ccar_session=ccar_session)

    ##
    ## IMPORT MODELS
    ##
    from CIFI.controllers.models.creconstruction17 import CREConstruction
    from CIFI.controllers.models.logitmodel import TwoFLogitModel
    from CIFI.controllers.ejm.ejmmaster import EJMGenerator, ejmDictionaryGenerator
    from CIFI.controllers.models.riskratingmodel import RiskRatingModel
    from CIFI.controllers.models.gcbindustry import GCBModel
    from CIFI.controllers.models.cniriskrating import CNIModel

    TwoFLogitModel_CEVF_instance = TwoFLogitModel(
        uncertainty_rate=0.,
        as_of_date=AS_OF_DATE,
        model_id='53 - Scenario Analysis Model - CEVF PD - SBNA',
        scenario=SCENARIO,
        scenario_context=STRESS_TESTING_CYCLE,
        forecast_periods=FORECAST_PERIODS
    )
    cart.addModel(TwoFLogitModel_CEVF_instance)
    cart.checkout()

if __name__ == '__main__':
    RUN()
