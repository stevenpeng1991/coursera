CCAR Implementation Framework
=============================

Getting Started
---------------

#### Setup

Install the following packages:

-   TinyDB

-   dateutil

-   cx_Oracle (Oracle Client required)

-   pandasql

 

##### Project Structure

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
CIFI
├───controllers
│   ├───contributorfile
│   ├───ejm
│   ├───models
│   ├───timingcurves
│   └───utilities
├───database
├───log
├───main_scripts
├───models
│   ├───macrovariables
│   ├───masterdataset
│   └───modelproperties
├───testing
│   └───test_log
├───views
│   ├───static
│   │   ├───css
│   │   ├───fonts
│   │   ├───img
│   │   └───js
│   └───templates
└───visualdiagnostics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

##### List of Functions

-   **aggregateCF** This function aggregates all contributor files that have the
    specified `file_ending` in a given `working_directory`. Files are expected
    to be in csv format. If an optional `output_filename` is provided, the
    aggregated dataframe will be saved as a csv file in the specified
    `working_directory`.

-   **loadRequirements** This function loads the checker requirements from the
    json specs. It returns a list with of requirements for the specified
    requirement group.

-   **generateMonthSequence** This function generates a sequence of dates in
    `m_interval` monthly intervals given a starting date and a number of
    periods.

-   **readCSV** This function returns a pandas DataFrame object from a csv file.

-   **testCFHeaders** This function checks the completeness and order of headers
    in a contributor file given the specifications in a `requirements`
    dictionary object.

-   **testCFDuplicates** This function checks a contributor file for duplicates
    given a primary key in a `requirements` dictionary object.

-   **checkCFField** This function checks distribution properties of a
    particular field in a contributor file.

-   **checkCFFieldDistributionClass** This function checks the class of a pandas
    DataFrame vector.

-   **checkCFFieldDistributionMean** This function checks the mean of a pandas
    DataFrame vector.

-   **checkCFFieldDistributionSTDev** This function checks the standard
    deviation of a pandas DataFrame vector.

-   **checkCFFieldDistributionDistinctCount** This function checks the count of
    distinct values of a pandas series.

-   **checkCFFieldDistributionMeanDistinctCount** This function checks the mean
    count of distinct values of a pandas series.

-   **checkCFFieldDistributionSTDevDistinctCount** This function checks the
    standard deviation of count of distinct values of a pandas series.

##### Defining Requirements

##### Basic Usage

Contact
-------

| Organization | Team                         | Name          | Position                  | Email                       |
|--------------|------------------------------|---------------|---------------------------|-----------------------------|
| SBNA         | CCAR Wholesale Solvency Risk | David Hachuel | CCAR Quantitative Analyst | david.hachuel\@santander.us |
