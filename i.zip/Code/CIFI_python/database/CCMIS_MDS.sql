/*
    sqlplus MACCAR/hXrkdzz3%ND@180.24.87.25:1630/OTSUMODY
    @I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/CCMIS_MDS.sql
*/
SET SERVEROUTPUT ON
--DEFINE as_of_date = TO_DATE('06/30/2016', 'dd/mm/yyyy');

DECLARE
    STTMNT_1    VARCHAR2(200);
    STTMNT_2    VARCHAR2(200);
    F_PERIODS   INT := 27;
    AS_OF_DATE DATE := TO_DATE('06/30/2016', 'dd/mm/yyyy');

BEGIN
    FOR period_idx IN 1..F_PERIODS LOOP
        DBMS_OUTPUT.PUT_LINE(period_idx)
    END LOOP;
    COMMIT;
END;

-- BEGIN
--     FOR table IN (SELECT table_name FROM user_tables WHERE table_name IN ('MDS_EXTRACT')) LOOP
--         DBMS_OUTPUT.PUT_LINE('DROPING TABLE : '||table.table_name);
--         STTMNT_1 := 'TRUNCATE TABLE :tb_name';
--         EXECUTE IMMEDIATE STTMNT_1 USING table_name.table_name;
--         STTMNT_2 := 'DROP TABLE :tb_name';
--         EXECUTE IMMEDIATE STTMNT_2 USING table_name.table_name;
--     END LOOP;
--     COMMIT;
-- END;


-- ***************************
-- EMPTY AND DROP EXISTING GTT
-- ***************************
--TRUNCATE TABLE MDS_EXTRACT;
--DROP TABLE MDS_EXTRACT;

-- ****************************
-- INSERT CURRENT EXISTING BOOK
-- ****************************
BEGIN
--     CREATE GLOBAL TEMPORARY TABLE MDS_EXTRACT
--     ON COMMIT PRESERVE ROWS 
--     AS SELECT
--         ASOFDATE,
--         SOURCEID,
--         ONEOBLIGORNUMBER,
--         CUSTOMERNUMBER,
--         FACILITYNUMBER,
--         UNIQUE_FACILITY_ID,
--         SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCEAMOUNT,
--         SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
--         SUM(CALCULATED_LINE) AS EXPOSURE,
--         EXISTING_NEW
--     FROM MDS_DATA_TMP
--     WHERE
--         ASOFDATE = &AS_OF_DATE -- '30-JUN-16'
--         AND
--         PD_GROUP IN ('GBM_MRG', 'GBM LARGE CORPORATES')
--         AND
--         EXISTING_NEW = 'EXISTING'
--     GROUP BY
--         ASOFDATE,
--         SOURCEID,
--         ONEOBLIGORNUMBER,
--         CUSTOMERNUMBER,
--         FACILITYNUMBER,
--         UNIQUE_FACILITY_ID,
--         EXISTING_NEW;
-- /
    --SELECT UNIQUE_FACILITY_ID FROM MDS_EXTRACT WHERE ROWNUM<=10;

    FOR period_idx IN 1..F_PERIODS LOOP
        -- APPEND ORIGINATIONS TO MDS_EXTRACT
        DBMS_OUTPUT.PUT_LINE(period_idx)
        -- INSERT INTO MDS_EXTRACT (
        -- SELECT
        --     to_date('31-JUL-16','DD-MON-YY') AS ASOFDATE,
        --     SOURCEID,
        --     ONEOBLIGORNUMBER,
        --     CUSTOMERNUMBER,
        --     FACILITYNUMBER,
        --     UNIQUE_FACILITY_ID,
        --     SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCEAMOUNT,
        --     SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
        --     SUM(CALCULATED_LINE) AS EXPOSURE,
        --     EXISTING_NEW
        -- FROM MDS_DATA_TMP
        -- WHERE
        --     ASOFDATE = '30-JUN-16'
        --     AND
        --     PD_GROUP IN ('GBM_MRG', 'GBM LARGE CORPORATES')
        --     AND
        --     EXISTING_NEW = 'NEW'
        -- GROUP BY
        --     ASOFDATE,
        --     SOURCEID,
        --     ONEOBLIGORNUMBER,
        --     CUSTOMERNUMBER,
        --     FACILITYNUMBER,
        --     UNIQUE_FACILITY_ID,
        -- EXISTING_NEW);
    END LOOP;
    COMMIT;
END;


-- ***************************
-- EMPTY AND DROP EXISTING GTT
-- ***************************
-- TRUNCATE TABLE MDS_EXTRACT;
-- DROP TABLE MDS_EXTRACT;
-- COMMIT;