import sys
import os
wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
if wd not in sys.path:
    sys.path.append(wd)
import pandas as pd
from pandasql import sqldf
pysqldf = lambda q: sqldf(q, globals())
import datetime
import numpy as np
import cx_Oracle
from CIFI.config import CONFIG
import string

connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["DEFAULT_ENV"]

cx_Oracle_DSN = cx_Oracle.makedsn(
	host=connection_strings["HOST_IP"],
	port=connection_strings["ORACLE_PORT"],
	sid=connection_strings["SID"]
)
connection = cx_Oracle.connect(
	user=connection_strings["USER_NAME"],
	password=connection_strings["PASSWORD"],
	dsn=cx_Oracle_DSN
)
cursor = connection.cursor()



table_name = "MDS_DATA_TMP"

cursor.execute('Select * from {} where rownum <= 100'.format(table_name))
df = pd.DataFrame(cursor.fetchall(), columns=[item[0] for item in cursor.description])


float2str = lambda x : str('%8f' % x) if isinstance(x,(float, np.float, np.float16, np.float32, np.float64)) else None
mds = pd.read_excel(    
    io="I:\CRMPO\DEPT\Hachuel\CCAR\CIFI\database\AGG_MDS.xlsx"
)

if (df.columns == [s.upper() for s in mds.columns]).all():
    mds.columns = [s.upper() for s in mds.columns]
else:
    raise ValueError()
    
mds.DEFAULT_DATE = pd.to_datetime(mds.DEFAULT_DATE)
mds.UTILIZATIONRENEWALDATE = pd.to_datetime(mds.UTILIZATIONRENEWALDATE)
mds.CURRENTOCCUPANCY = mds.CURRENTOCCUPANCY.apply(lambda a : str(int(round(a*100))) if pd.notnull(a) else np.NaN )
mds.UTILIZATIONCOSTCENTER = mds.UTILIZATIONCOSTCENTER.apply(lambda a : str(int(a)) if pd.notnull(a) else np.NaN )
mds.RC_LINE_OF_BUSINESS_ROLLUP = mds.RC_LINE_OF_BUSINESS_ROLLUP.apply(lambda a : str(int(a)) if pd.notnull(a) else np.NaN )


sample_data = mds.head()
data_to_insert = list(mds.T.to_dict().values())

# Replace nulls by None
for ix, record in enumerate(data_to_insert):
    for key in record.keys():
        if pd.isnull(record[key]):
            record[key] = None
        if isinstance(record[key], str):
            record[key] = record[key].replace(u'\xa0', u'')
        #if not isinstance(record[key], (int, float, str, pd.tslib.Timestamp, pd.tslib.NaTType)):
            #print(str(ix) + " | " +str(key))

def to_sql_array(A):
	s = '('
	for h in A: s += str(h) + ','
	s = s.strip(',')
	s += ')'
	return s
 
statement = 'INSERT INTO '+\
    table_name+\
    to_sql_array(mds.columns)+\
    ' VALUES '+\
    to_sql_array([':'+str(v) for i,v in enumerate(mds.columns)])
    
cursor = connection.cursor()
cursor.executemany(statement, data_to_insert) 
connection.commit()



#for i in range(65000,70001):
#    try:
#        cursor.executemany(statement, [data_to_insert[i]])
#    except UnicodeEncodeError:
#        print("Error: " + str(i))


#for item in data_to_insert:
#    for key in item.keys():
#        print(" | "+" | "+str(type(item[key])))




























