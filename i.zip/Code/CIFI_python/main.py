# -*- coding: utf-8 -*-
"""
Created on Fri Apr 01 12:33:23 2016

@author: n813863
"""

import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.views.app import cifi_app

def init_message():
    print(" * ===================")
    print(" * STARTING UP CIFI...")
    print(" * ===================\n")


def main():
    init_message()

    # url = 'http://127.0.0.1:5000'
    # webbrowser.open_new(url)
    cifi_app.run()



if __name__ == "__main__":
    main()