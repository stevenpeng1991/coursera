import sys, os, datetime, time
try:
    from StringIO import StringIO, BytesIO
except ImportError:
    from io import StringIO, BytesIO
import numpy as np
from flask import Flask, flash, url_for, render_template, request, session, redirect, send_file
import hashlib
import copy
import pandas as pd
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import ModelShoppingCart
from CIFI.controllers.models.logitmodel import TwoFLogitModel
from CIFI.controllers.utilities.session import CCARSession

# GLOBAL PARAMETERS
cifi_app = Flask(__name__)
cifi_app.config['DEBUG'] = True
cifi_app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(seconds=3600)
cifi_app.config['USERNAME'] = 'e760580cc55e0c3a962b4dfd1473765d' # cifi
cifi_app.config['SECRET_KEY'] = 'e760580cc55e0c3a962b4dfd1473765d' # cifi


# <div class="form-group">
# <label class="" for="scenario_period_frequency">Scenario Period Frequency</label>
# <select class="form-control" id="scenario_period_frequency" name="scenario_period_frequency" required>
#     """+self.listToHTMLWrapperTag(utilities.PERIOD_FREQUENCY_MAP,'option')+"""
# </select>
# <span class="help-block">Select scenario period frequency</span>
# </div>
#
# <div class="form-group">
# <label class="" for="forecast_periods_frequency">Forecast Period Frequency</label>
# <select class="form-control" id="forecast_periods_frequency" name="forecast_periods_frequency" required>
#     """+self.listToHTMLWrapperTag(utilities.PERIOD_FREQUENCY_MAP,'option')+"""
# </select>
# <span class="help-block">Select forecast period frequency</span>
# </div>


class ModelView:
    # Properties
    _model_title = None
    _model_names = None
    _model_description = None
    _init_html_form = None
    _model_inventory_id = None
    _model_instance = None
    _request_form = None

    # Methods
    def __init__(
        self,
        model_title,
        model_names,
        model_description,
        init_html_form,
        model_inventory_id
    ):
        if isinstance(model_title,str):
            self._model_title = model_title
        else:
            raise TypeError('Input model_title not of str type.')

        if isinstance(model_names,list):
            self._model_names = model_names
        else:
            raise TypeError('Input model_names not of str type.')

        if isinstance(model_description,str):
            self._model_description = model_description
        else:
            raise TypeError('Input model_description not of str type.')

        if isinstance(init_html_form, str):
            self._init_html_form = init_html_form
        else:
            raise TypeError('Input init_html_form not of str type.')

        if isinstance(model_inventory_id, str):
            self._model_inventory_id = model_inventory_id
        else:
            raise TypeError('Input model_inventory_id not of str type.')

    @property
    def model_title(self):
        return(self._model_title)

    @property
    def model_names(self):
        return (self._model_names)

    @property
    def model_description(self):
        return (self._model_description)

    @property
    def init_html_form(self):
        return (self._init_html_form)

    @property
    def model_inventory_id(self):
        return (self._model_inventory_id)

    # @property
    # def model_instance(self):
    #     return (self._model_instance)
    #
    # @property
    # def request_form(self):
    #     return (self._request_form)

    def listToHTMLWrapperTag(self,l,wrapper):
        return(''.join(['<'+str(wrapper)+'>' + item + '</'+str(wrapper)+'>' for item in l]))


class TwoFLogitModelView(ModelView):
    def __init__(self):
        ModelView.__init__(
            self,
            model_title='2-Factor Logit Model',
            model_names=['CRE_CONSTRUCTION', 'SBB', 'CEVF'],
            model_description="""
            CCAR 2-factor Logit Models for the following portfolios/PD_GROUPs:</br>
                <ul>
                    <li>SBB</li>
                    <li>CEVF</li>
                    <li>CRE_CONSTRUCTION</li>
                </ul>
            """,
            init_html_form="""

            <div class="form-group">
              <div class="form-group">
                <label class="" for="model_id">Model ID</label>
                <select class="form-control" id="model_id" name="model_id" required>
                    <option>37 - Scenario Analysis Model - SBB PD - SBNA</option>
                    <option>53 - Scenario Analysis Model - CEVF PD - SBNA</option>
                    <option>34 - Scenario Analysis Model - CRE PD  - SBNA</option>
                </select>
                <span class="help-block">Select Model ID</span>
              </div>

              <div class="form-group">
                <label class="" for="as_of_date">Model as-of-date</label>
                <input type="date" id="as_of_date" name="as_of_date" class="form-control" placeholder="Model
                As-Of-Date" required>
                <span class="help-block">Select model run/as-of-date</span>
              </div>

            <div class="form-group">
                <label class="" for="uncertainty_rate">Model Uncertainty</label>
                <input id="uncertainty_rate" name="uncertainty_rate" type="number" class="form-control" aria-label="..."
                    value=0 required>
                <span class="help-block">Input model uncertainty rate and boolean checkbox</span>
            </div>

            <div class="form-group">
                <label class="" for="scenario_context">Stress Test Exercise Name</label>
                <select class="form-control" id="scenario_context" name="scenario_context" required>
                    <option>CCAR2016</option>
                    <option>EBA2016</option>
                    <option>SP19</option>
                    <option>MidCycle16</option>
                </select>
                <span class="help-block">Select stress test exercise</span>
              </div>

            <div class="form-group">
                <label class="" for="scenario">Scenario</label>
                <select class="form-control" id="scenario" name="scenario" required>
                    <option>Base</option>
                    <option>Adverse</option>
                    <option>FRB_Adverse</option>
                    <option>FRB_SA</option>
                    <option>BHC_Stress</option>
                    <option>MC_Base</option>
                    <option>MC_Adverse</option>
                    <option>MC_SA</option>
                </select>
                <span class="help-block">Select execution scenario</span>
              </div>

              <div class="form-group">
                <label class="" for="forecast_periods">Forecast Periods</label>
                <input id="forecast_periods" name="forecast_periods" type="number" class="form-control"
                aria-label="..." required>
                <span class="help-block">Select number of forecast periods</span>
              </div>
            """,
            model_inventory_id='2flogitmodel'
        )

    def generateModelInstance(self, request_form):
        return(TwoFLogitModel(
            uncertainty=bool(float(request_form['uncertainty_rate'])),
            uncertainty_rate=float(request_form['uncertainty_rate']),
            as_of_date=datetime.datetime.strptime(request_form['as_of_date'], '%Y-%m-%d'),
            model_id=request_form['model_id'],
            scenario=request_form['scenario'],
            scenario_context=request_form['scenario_context'],
            forecast_periods=int(request_form['forecast_periods'])
        ))


MODEL_INVENTORY = [
    TwoFLogitModelView()
]

SESSION_DATA = {}




def isValidAuthentication(username,password):
    return hashlib.md5(password.encode('utf-8')).hexdigest() == cifi_app.config['USERNAME']

@cifi_app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        # print(request.form['session_date'])
        # print(type(request.form['session_date']))
        # print(" * Entered username: "+request.form['username'])
        if isValidAuthentication(
            username=request.form['username'],
            password=request.form['password']
        ):
            # Add data elements to the session instance
            session['username'] = request.form['username']
            SESSION_DATA['ccar_session'] = CCARSession(
                session_id=request.form['session_id'],
                session_date=datetime.datetime.strptime(request.form['session_date'], '%Y-%m-%d'),
                user=request.form['username']
            )
            SESSION_DATA['model_shopping_cart'] = ModelShoppingCart(
                ccar_session=SESSION_DATA['ccar_session']
            )

            # Flash logged in message
            flash(u'Logged in!','success')

            # Redirect to index route
            return redirect(url_for('index'))
        else:
            error = 'Invalid passphrase.'
            flash(error,'danger')
            print('=> Invalid passphrase!')

    return render_template('login.html', title='CIFI - Login', error=error)

@cifi_app.route('/logout')
def logout():
    # Remove the username from the session if it's there
    session.pop('username', None)
    session.pop('model_shopping_cart', None)
    SESSION_DATA = {}

    # Redirect to login route
    return redirect(url_for('login'))

@cifi_app.route('/')
def index():
    return redirect(url_for('overview'))

@cifi_app.route('/overview')
def overview():
    if 'username' in session:
        return render_template(
            'overview.html',
            title='CIFI - Overview',
            cart_info=SESSION_DATA['model_shopping_cart'].getModelCartInfo()
        )
    return redirect(url_for('login'))

@cifi_app.route('/ccarmodels')
def ccarmodels():
    if 'username' in session:
        return render_template(
            'ccarmodels.html',
            title='CIFI - CCAR Models',
            model_inventory=MODEL_INVENTORY,
            cart_info=SESSION_DATA['model_shopping_cart'].getModelCartInfo()
        )
    return redirect(url_for('login'))

# @cifi_app.route('/get_model_shopping_cart')
# def get_model_shopping_cart():
#     if 'username' in session and 'model_shopping_cart' in session:

@cifi_app.route('/addModelToCart', methods=['POST'])
def addModelToCart():
    if request.method == "POST":
        request_form = copy.deepcopy(request.form)
        # print(request.form)

        # Generate model view instance
        model_view = [item for item in MODEL_INVENTORY if item.model_inventory_id==request.form[
            'model_inventory_id']][0]

        # Add model instance to cart
        SESSION_DATA['model_shopping_cart'].addModel(model_view.generateModelInstance(request_form=request_form))

        # Redirect
        flash(u'Model added to cart!', 'success')
        return redirect(url_for('ccarmodels'))


@cifi_app.route('/cartCheckout')
def cartCheckout():
    if 'username' in session:
        SESSION_DATA['model_shopping_cart'].checkout()
        flash(u'Checkout completed!', 'success')
        SESSION_DATA['model_shopping_cart'].resetCart()

        return redirect(url_for('ccarmodels'))

@cifi_app.route('/auditLog')
def auditLog():
    if 'username' in session:
        return render_template(
            'auditlog.html',
            title='CIFI - Audit Log',
            model_inventory=MODEL_INVENTORY,
            cart_info=SESSION_DATA['model_shopping_cart'].getModelCartInfo(),
            audit_log_data=SESSION_DATA['ccar_session'].logger.data.to_html(
                index=False,
                classes=['table', 'table-hover']
            )
        )

@cifi_app.route('/contributorData')
def contributorData():
    if 'username' in session:
        return render_template(
            'contributordata.html',
            title='CIFI - Contributor Data',
            model_inventory=MODEL_INVENTORY,
            cart_info=SESSION_DATA['model_shopping_cart'].getModelCartInfo(),
            audit_log_data=SESSION_DATA['ccar_session'].logger.data.to_html(
                index=False,
                classes=['table', 'table-hover']
            ),
            fmt_unique_model_segments = utilities.listToHTMLWrapperTag(
                ls=SESSION_DATA['ccar_session'].contributor_file_generator.contributor_file.getUniqueModelSegments(),
                wrapper_tag='option'
            ),
            fmt_unique_vintage_dates=utilities.listToHTMLWrapperTag(
                ls=SESSION_DATA['ccar_session'].contributor_file_generator.contributor_file.getUniqueVintageDates(),
                wrapper_tag='option'
            ),
            fmt_unique_scenarios=utilities.listToHTMLWrapperTag(
                ls=SESSION_DATA['ccar_session'].contributor_file_generator.contributor_file.getUniqueScenarios(),
                wrapper_tag='option'
            )
        )

@cifi_app.route('/downloadAuditLog')
def downloadAuditLog():
    buffer = BytesIO()
    buffer.write(str.encode(SESSION_DATA['ccar_session'].logger.data.to_csv(encoding='utf-8', index=False)))
    buffer.seek(0)

    filename = SESSION_DATA['ccar_session'].session_id+\
               '_'+\
               utilities.date2str(SESSION_DATA['ccar_session'].session_date)+\
               '_audit_log.csv'

    return send_file(
        buffer,
        attachment_filename=filename,
        mimetype='text/csv',
        as_attachment=True
    )

@cifi_app.route('/downloadContributorData')
def downloadContributorData():
    buffer = BytesIO()
    buffer.write(
        str.encode(
            SESSION_DATA['ccar_session'].contributor_file_generator.data.to_csv(
                encoding='utf-8',
                index=False
            )
        )
    )

    filename = SESSION_DATA['ccar_session'].session_id + \
               '_' + \
               utilities.date2str(SESSION_DATA['ccar_session'].session_date) + \
               '_contributor_data.csv'

    buffer.seek(0)
    return send_file(
        buffer,
        attachment_filename=filename,
        mimetype='text/csv',
        as_attachment=True
    )



@cifi_app.route('/plotContributorData', methods=['POST'])
def plotContributorData():
    # Fill model segment dict
    model_segment_dict = {}
    for sc in request.form.getlist('scenarios'):
        model_segment_dict[sc]={}
        for ms in request.form.getlist('model_segments'):
            model_segment_dict[sc][ms] = []
            for vint in request.form.getlist('vintage_dates'):
                model_segment_dict[sc][ms].append(vint)

    # Call plotting function
    img_buffer = BytesIO()
    SESSION_DATA['ccar_session'].contributor_file_generator.contributor_file.plotCFModelSegment(
        model_segment_dict=model_segment_dict,
        bytes_buffer=img_buffer
    )

    # Return image file
    img_buffer.seek(0)
    #import base64
    return(
        send_file(
            img_buffer,#base64.b64encode(img_buffer.getvalue()),
            mimetype='image/png'
        )
    )




