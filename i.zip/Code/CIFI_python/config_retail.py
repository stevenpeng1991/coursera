# Import necessary dependencies
import sys
import os
import datetime

# Declare global configuration variable
global CONFIG
CONFIG = {}

# Insert configuration key-value pairs
CONFIG['PARENT_DIRECTORY'] =  os.path.dirname(os.getcwd()).replace('\\','/')+'/'
CONFIG['WORKING_DIRECTORY'] =  os.getcwd().replace('\\','/')+'/'
CONFIG['PKG_NAME'] = 'CIFI'
CONFIG['SQLITE_DB'] = {
	'FILE_PATH':CONFIG['WORKING_DIRECTORY']+'database/ccar.db',
	'MACRO_VARIABLES_TABLE_NAME':'MacroVariables'
}
CONFIG['MODEL_PROPERTIES'] = {
	'FILE_PATH':CONFIG['WORKING_DIRECTORY']+'database/model_properties.json'
}
CONFIG['MODEL_PRECISION'] = 32
CONFIG['USER_AUTHENTICATION'] = [
    {
        "USERNAME": "admin",
        "MD5_PASSWORD":"e760580cc55e0c3a962b4dfd1473765d"
    },
    {
        "USERNAME": "n813863",
        "MD5_PASSWORD":"1b7161c4c1dfa2f11baa2a0ab71ad1fc"
    },
	{
        "USERNAME": "dhachuel",
        "MD5_PASSWORD":"1b7161c4c1dfa2f11baa2a0ab71ad1fc"
    }
]
CONFIG['MOODYS_RFO_ORACLE_CONNECTION'] = {
    "CURRENT" : "PROD_ENV",
	"DEFAULT_ENV": {
        "HOSTNAME":"dbmoodtvlsh01.shusadev.shusa.dev.corp",
        "HOST_IP": "180.24.87.25",
        "ORACLE_PORT": "1630",
        "SID": "OTSUMODY",
        "SCHEMA_NAME":"MACCAR",
        "USER_NAME":"MACCAR",
        "PASSWORD": "hXrkdzz3%ND",
        "URL":"sqlplus MACCAR/hXrkdzz3%ND@180.24.87.25:1630/OTSUMODY"
	},
    "DEV_ENV": {
        "HOSTNAME": "dbmoodtvlsh01.shusadev.shusa.dev.corp",
        "HOST_IP": "180.24.87.25",
        "ORACLE_PORT": "1630",
        "SID": "OTSUMODY",
        "SCHEMA_NAME": "MACCAR",
        "USER_NAME": "SASG_SA_USR",
        "PASSWORD": "Y8JZw_g5^kY"
    },
    "SIT_ENV": {
        "HOSTNAME": "dbmoodivlsh101.preshusa.santanderholdingsusa.pre.corp",
        "HOST_IP": "180.24.1.6",
        "ORACLE_PORT": "1630",
        "SID": "OTSUMODY",
        "SCHEMA_NAME": "MACCAR",
        "USER_NAME": "SASG_SA_USR",
        "PASSWORD": "DpkSa4V[T9N"
    },
    "UAT_ENV": {
        "HOSTNAME": "dbmoodqvlsh101.preshusa.santanderholdingsusa.pre.corp",
        "HOST_IP": "180.24.1.11",
        "ORACLE_PORT": "1640",
        "SID": "OTSUMOOD",
        "SCHEMA_NAME": "MACCAR",
        "USER_NAME": "SASG_SA_USR",
        "PASSWORD": "$Gh+YJbb7TN",
        "URL":"sqlplus 'SASG_SA_USR/$Gh+YJbb7TN@180.24.1.11:1640/OTSUMOOD'"
    },
    "PROD_ENV": {
        "WEB_INTERFACE":"http://wasmoodpvlsh101.shusapro.santanderholdingsusa.corp:9080/MAUIWeb/#",
        "HOSTNAME": "dbmoodpvlsh101.shusapro.santanderholdingsusa.corp",
        "HOST_IP": "dbmoodpvlsh101.shusapro.santanderholdingsusa.corp",
        "ORACLE_PORT": "1640",
        "SID": "oesumood",
        "SCHEMA_NAME": "MACCAR",
        "USER_NAME": "DQ_USR",
        "PASSWORD": "6-EE48ekmRP",
        "URL": "sqlplus 'DQ_USR/6-EE48ekmRP@dbmoodpvlsh101.shusapro.santanderholdingsusa.corp:1640/oesumood'"

    },
    "TABLE_NAMES":{
        "MACRO_SERIES":"MV_MEV_NORMALIZED",
        "SB_COMM_ANCHOR_DATA":"MACCAR.MV_LOSS_RETAIL",
        "SB_COMM_ORIG_DATA":"MACCAR.MV_LOSS_RETAIL_ORIG",
        "CONTRIBUTOR_DATA":"STG_CONTRIBUTOR_DATA"
    },
    "CURRENT_PD_GROUP_FIELD_NAME":"PD_GROUP_2017"
}

CONFIG['DOWNTURN_LGD_INTERCEPT'] = 0.08
CONFIG['DOWNTURN_LGD_FACTOR'] = 0.92

CONFIG['C&I_MRA_DATA'] = {
    datetime.datetime(2016,6,30):{
        "PATH_TO_MRA_DATA":"I:/CRMPO/DEPT/Hachuel/CCAR/MOODYS_MRA_DATA_MERGE/Python_Merge_Logic/uphiststmtMMAS_20160731.txt",
        "PATH_TO_SOURCESYSTEM_TO_MRA":"I:/CRMPO/DEPT/Hachuel/CCAR/MOODYS_MRA_DATA_MERGE/Python_Merge_Logic/201606_sourcesystem_to_mra.csv"
    },
    datetime.datetime(2016, 11, 30): {
        "PATH_TO_MRA_DATA": "I:/CRMPO/DEPT/Hachuel/CCAR/MOODYS_MRA_DATA_MERGE/Python_Merge_Logic/uphiststmtMMAS_20160930.txt",
        "PATH_TO_SOURCESYSTEM_TO_MRA": "I:/CRMPO/DEPT/Hachuel/CCAR/MOODYS_MRA_DATA_MERGE/Python_Merge_Logic/201609_sourcesystem_to_mra.csv"
    },
    datetime.datetime(2016, 12, 31): {
        "PATH_TO_MRA_DATA": "I:/CRMPO/DEPT/Hachuel/CCAR/MOODYS_MRA_DATA_MERGE/Python_Merge_Logic/uphiststmtMMAS_20160930.txt",
        "PATH_TO_SOURCESYSTEM_TO_MRA": "I:/CRMPO/DEPT/Hachuel/CCAR/MOODYS_MRA_DATA_MERGE/Python_Merge_Logic/201609_sourcesystem_to_mra.csv"
    }
}



CONFIG['CONTRIBUTOR_FILE'] = {
    "CHECKER_REQUIREMENTS_FILE_PATH":CONFIG['WORKING_DIRECTORY']+'database/CF_REQUIREMENTS.xlsm',
    "CHECKER_REQUIREMENTS_FILE_SHEETNAME":"CF_REQUIREMENTS",

    "VINTAGE_ASOFDATE_VALUE":datetime.datetime(1900,1,31)
}


CONFIG["EJM"] = {
    "COMMERCIAL_EJM_MASTER_PATH":"I:/CRMPO/CCAR/2Q17/5 - EJMs/Retail/RETAIL_EJM_MASTER_2Q17.xlsx",
    "COMMERCIAL_EJM_MASTER_SHEETNAME":"FORECAST_DATA"
}


CONFIG["VIRTUAL_MACHINE"] = {
    "VM_DEV" : {
        "HOST":"srvccart01.svrn.sovereignbank.com",
        "ID":"180.229.33.248",
        "MASK":"255.255.255.192",
        "DEFAULT_GATEWAY":"180.229.33.193"
    },
    "VM_PROD": {
        "HOST": "srvccart02.svrn.sovereignbank.com",
        "ID": "180.229.33.249",
        "MASK": "255.255.255.192",
        "DEFAULT_GATEWAY": "180.229.33.193"
    }
}


# Run configuration jobs
if CONFIG['PARENT_DIRECTORY'] not in sys.path:
    sys.path.append(CONFIG['PARENT_DIRECTORY'])

