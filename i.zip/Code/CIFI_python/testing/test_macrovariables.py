import sys
import os
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import datetime
import pytest
import pandas as pd
import numpy as np
import CIFI.models.macrovariables.macrovariables as mv






@pytest.mark.quicktest
class TestGenerateMnemonic:
    def test_generateMnemonic_ex1(self):
        assert mv.generateMnemonic(
            default_name = 'FLBR_US',
            lag=3,
            transformation_type = 'd1y',
            period_frequency = 'quarterly'
        ) == 'FLBR_US_d1y_l3q'

    def test_generateMnemonic_ex2(self):
        assert mv.generateMnemonic(
            default_name='FLBR_US',
            lag=0,
            transformation_type='d1y',
            period_frequency='quarterly'
        ) == 'FLBR_US_d1y'

    def test_generateMnemonic_ex3(self):
        assert mv.generateMnemonic(
            default_name='FLBR_US',
            lag=-2,
            period_frequency='monthly'
        ) == 'FLBR_US_f2m'

    def test_generateMnemonic_ValueError_ex1(self):
        with pytest.raises(ValueError):
            mv.generateMnemonic(
                default_name='FLBR_US',
                lag=2,
                transformation_type='log2',
                period_frequency='monthly'
            )

    def test_generateMnemonic_ValueError_ex2(self):
        with pytest.raises(ValueError):
            mv.generateMnemonic(
                default_name='FLBR_US',
                lag=2,
                period_frequency='annual'
            )

    def test_generateMnemonic_TypeError_ex1(self):
        with pytest.raises(TypeError):
            mv.generateMnemonic(
                default_name='FLBR_US',
                lag='2',
                period_frequency='monthly'
            )

    def test_generateMnemonic_TypeError_ex2(self):
        with pytest.raises(TypeError):
            mv.generateMnemonic(
                default_name='FLBR_US',
                lag=2,
                period_frequency=3
            )


@pytest.mark.quicktest
@pytest.mark.potatolong
class TestTransformDictionary:
    sample_series = pd.core.series.Series([1,2,3,4,5,6,7,8,9,10,11,12])
    to_np_array = lambda x : np.array(x)
    precision = 10

    def test_transform_none(self):
        a = round(mv.TRANSFORM_DICT['none'](self.sample_series,'monthly'),self.precision)
        b = np.round([1,2,3,4,5,6,7,8,9,10,11,12],self.precision)
        assert np.array_equal(np.nan_to_num(a),np.nan_to_num(b))

    def test_transform_log(self):
        a = round(mv.TRANSFORM_DICT['log'](self.sample_series, 'monthly'), self.precision)
        b = np.round(
            [
                0.0,
                0.69314718055994529,
                1.0986122886681098,
                1.3862943611198906,
                1.6094379124341003,
                1.791759469228055,
                1.9459101490553132,
                2.0794415416798357,
                2.1972245773362196,
                2.3025850929940459,
                2.3978952727983707,
                2.4849066497880004
            ],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_d1m(self):
        a = round(mv.TRANSFORM_DICT['d1m'](self.sample_series, 'monthly'), self.precision)
        b = np.round(
            [np.nan, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_p1m(self):
        a = round(mv.TRANSFORM_DICT['p1m'](self.sample_series, 'monthly'), self.precision)
        b = np.round(
            [
                np.nan,
                1.0,
                0.5,
                0.33333333333333326,
                0.25,
                0.19999999999999996,
                0.16666666666666674,
                0.14285714285714279,
                0.125,
                0.11111111111111116,
                0.10000000000000009,
                0.090909090909090828
            ],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_d1q(self):
        a = round(mv.TRANSFORM_DICT['d1q'](self.sample_series, 'quarterly'), self.precision)
        b = np.round(
            [np.nan, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_p1q(self):
        a = round(mv.TRANSFORM_DICT['p1q'](self.sample_series, 'quarterly'), self.precision)
        b = np.round(
            [
                np.nan,
                1.0,
                0.5,
                0.33333333333333326,
                0.25,
                0.19999999999999996,
                0.16666666666666674,
                0.14285714285714279,
                0.125,
                0.11111111111111116,
                0.10000000000000009,
                0.090909090909090828
            ],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_d1y(self):
        a = round(mv.TRANSFORM_DICT['d1y'](self.sample_series, 'quarterly'), self.precision)
        b = np.round(
            [np.nan, np.nan, np.nan, np.nan, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_p1y(self):
        a = round(mv.TRANSFORM_DICT['p1y'](self.sample_series, 'quarterly'), self.precision)
        b = np.round(
            [
                np.nan,
                np.nan,
                np.nan,
                np.nan,
                4.0,
                2.0,
                1.3333333333333335,
                1.0,
                0.80000000000000004,
                0.66666666666666674,
                0.5714285714285714,
                0.5
            ],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_mavely(self):
        a = round(mv.TRANSFORM_DICT['mavely'](self.sample_series, 'quarterly'), self.precision)
        b = np.round(
            [np.nan, np.nan, np.nan, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 10.5],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

    def test_transform_mavely_1qd(self):
        a = round(mv.TRANSFORM_DICT['mavely_1qd'](self.sample_series, 'quarterly'), self.precision)
        b = np.round(
            [
                np.nan,
                np.nan,
                -1093.75,
                -190.20061728395069,
                -71.908757716049308,
                -36.780625000000015,
                -22.097654320987601,
                -14.666760506167776,
                -10.414921110344608,
                -7.7648737866274047,
                -6.0057902758725561,
                -4.7803298954990154
            ],
            self.precision)
        assert np.array_equal(np.nan_to_num(a), np.nan_to_num(b))

