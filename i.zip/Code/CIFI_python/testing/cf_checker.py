# -*- coding: utf-8 -*-
"""
Created on Fri Apr 01 12:33:23 2016

@author: n813863
"""
import sys
import os
import datetime
import pandas as pd
import numpy as np
import re
wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.controllers.contributorfile.contributorfile import ContributorFile, CFCheckerResponse, CFChecker
import CIFI.controllers.utilities.utilities as utilities

# INPUTS
#group='SB_COMM_LOSS'
#cf_type='PRE_BW'
#run_name='SP19'
#as_of_date=datetime.datetime(2016,3,31)
#forecast_periods=45
#requirements_file_path = 'I:/CRMPO/DEPT/Hachuel/CCAR/CCAR_DESK/database/CF_REQUIREMENTS.xlsm'
#requirements_file_sheetname = 'CF_REQUIREMENTS'
#WD = 'I:/CRMPO/CCAR/1Q16/3 - Contributor Files/Wholesale/'


sbna_sp19_comm_loss_checker = CFChecker(
    group='SB_COMM_LOSS',
    cf_type='PRE_BW',
    run_name='SP19',
    as_of_date=datetime.datetime(2016,3,31),
    working_directory='I:/CRMPO/CCAR/1Q16/3 - Contributor Files/Wholesale/',
    scenario='Base',
    requirements_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CCAR_DESK/database/CF_REQUIREMENTS.xlsm',
    requirements_file_sheetname='CF_REQUIREMENTS',
    forecast_periods=45
)
sbna_sp19_comm_loss_checker.checkCFDirectory()

log_data = sbna_sp19_comm_loss_checker.getLogData()

sbna_sp19_comm_loss_checker.toCSV(
    output_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CCAR_DESK/database/SB_COMM_LOSS_SP19_checker_log.csv'
)



#cf = ContributorFile(
#    dir_path='I:/CRMPO/CCAR/1Q16/3 - Contributor Files/Wholesale/',
#    filename='EJM_Strat_Plan_SB_COMM_LOSS.csv',
#    as_of_date=datetime.datetime(2016,3,31),
#    forecast_periods=45
#)
#    
#cf.checkCFFieldItem(
#    field_name='ModelOutputRate',
#    subset="ALL",
#    check="^[-]{0,1}[0]{1}[.]{0,1}[0-9]*$|^[-]{0,1}[1]{1}[.]{0,1}[0]*$",
#    error_message='Individual REGEX pattern failed to match.',
#    check_name='regex_pattern'
#).getDict()
#
#cf.checkCFFieldItem(
#    field_name='PeriodDate',
#    subset="ALL",
#    check="datetime.datetime(2016,4,30)",
#    error_message='Lower bound.',
#    check_name='lower_bound'
#).getDict()
#
#cf.checkCFFieldItem(
#    field_name='PeriodDate',
#    subset="ALL",
#    check="datetime.datetime(2019,12,31)",
#    error_message='Upper bound.',
#    check_name='upper_bound'
#).getDict()
#
#cf.checkCFFieldItem(
#    field_name='Vintage',
#    subset="pd.notnull(data.Vintage)",
#    check="datetime.datetime(2019,12,31)",
#    error_message='Upper bound.',
#    check_name='upper_bound'
#).getDict()
#
#cf.checkCFFieldItem(
#    field_name='Vintage',
#    subset="pd.notnull(data.Vintage)",
#    check="datetime.datetime(2016,4,30)",
#    error_message='Lower bound.',
#    check_name='lower_bound'
#).getDict()

#
## Test Loading Requirements
#requirements = pd.read_excel(
#    io=requirements_file_path,
#    sheetname=requirements_file_sheetname
#)
#requirements_sub = requirements[
#    (requirements['group']==group) & 
#    (requirements['cf_type']==cf_type) &
#    (requirements['run_name']==run_name)
#]
#
## Initialize log
#log_data = pd.DataFrame(columns=CFCheckerResponse().getDict().keys())   
#
## Search check files
#file_regex=re.compile('('+group+'.csv)$', re.IGNORECASE)
#dir_ls = os.listdir(WD)
#files_to_check = [x for x in dir_ls if file_regex.search(x)]
#
#for file in files_to_check:
#    # Initialize ContributorFile instance
#    cf = ContributorFile(
#        dir_path=WD,#'I:/CRMPO/CCAR/1Q16/3 - Contributor Files/Wholesale/',
#        filename=file,#'NPLATTRITIONCURVE_Base_SB_COMM_LOSS.csv',
#        as_of_date=as_of_date,
#        forecast_periods=forecast_periods
#    )
#    
#    ## ------------ ##
#    ## CHECKS START ##
#    ## ------------ ##
#    main_message = 'Checking file ['+file+']'
#    print('='*len(main_message))
#    print(main_message)
#    print('='*len(main_message))
#    
#    # Check header completeness
#    header_completeness_response = cf.checkCFHeadersCompleteness()
#    log_data = log_data.append(
#        pd.DataFrame.from_dict(header_completeness_response.getDict())
#    )
#    if not header_completeness_response.getResponse():
#        print('Header Completeness check for file ' + file + ' failed.')
#        break
#    
#    # Check header order
#    log_data = log_data.append(
#        pd.DataFrame.from_dict(cf.checkCFHeadersOrder().getDict())
#    )
#    
#    # Check CF integrity (duplicates)
#    log_data = log_data.append(
#        pd.DataFrame.from_dict(cf.checkCFIntegrity().getDict())
#    )
#    
#    # Custom checks
#    for index,row in requirements_sub.iterrows():
#        print(
#            '>>> Checking [' + 
#            row['field_name'] + 
#            '] for ' + 
#            row['check_name'] + 
#            ':' +
#            str(row['check']) +
#            ' @ ' + 
#            row['subset'] + 
#            ' ...'
#        )
#        if row['check_name'] in ALLOWED_DISTRIBUTION_CHECK_NAMES:
#            log_data = log_data.append(
#                pd.DataFrame.from_dict(
#                    cf.checkCFFieldDistribution(
#                        field_name=row['field_name'],
#                        subset=row['subset'],
#                        check=row['check'],
#                        error_message=row['error_message'],
#                        check_name=row['check_name']
#                    ).getDict()
#                )
#            )    
#            
#        elif row['check_name'] in ALLOWED_INDIVIDUAL_CHECK_NAMES:
#            if row['check_name'] in ['value']:
#                check = str(row['check']).split(',')
#            else:
#                check = row['check']
#            log_data = log_data.append(
#                pd.DataFrame.from_dict(
#                    cf.checkCFFieldItem(
#                        field_name=row['field_name'],
#                        subset=row['subset'],
#                        check=check,
#                        error_message=row['error_message'],
#                        check_name=row['check_name']
#                    ).getDict()
#                )
#            )
#        else:
#            raise ValueError('Invalid check_name was provided.')

















