# -*- coding: utf-8 -*-
"""
Created on Sat Mar 18 17:02:29 2017
unit test for creconstruction

test content:
    
@author: n886528
"""

import CIFI.controllers.models.creconstruction17 as Cm
import pandas as pd
import numpy as np
import pytest
import datetime
import copy
#usage
CREConst_instance = Cm.CREConstruction(
    uncertainty_rate=0.,
    as_of_date=datetime.datetime(2016,12,31),
    model_id="2016-SBNA-Loss-Commercial-CREConstruction",
    scenario='FRB_ADVERSE',
    scenario_context='CCAR2017',
    forecast_periods=27
)

# output sample
# see python -m pytest py_test.py -s

CREConst_instance.calculateLoss()
CREConst_instance.calculate()
temp = CREConst_instance.transformed_macro_series
CREConst_instance.loss_results
precision = CREConst_instance.precision

# random input generator

np.random.seed(10086)

test_dat = [np.random.uniform(low = min(temp[i]), high=max(temp[i]), size = len(temp[i]) ) for i in temp.columns.tolist()]
test_dat = np.asarray(test_dat).T
test_dat_pd = pd.core.frame.DataFrame(test_dat,
                                      index = temp.index.tolist(),
                                      columns = temp.columns.tolist())

# coefficient details

res_coefs = {'coefficients_pairs': {'FHSTQ_US_p1y': -2.09, 'FRGT5Y_US_d1y': -0.7488},
             'intercept': -4.4464,
             'regression_variable': 'EL_resi'}
other_coefs = {'coefficients_pairs': {'FHSTQ_US_p1y': -2.7609,'FZFL075035503Q_US_p1y': -3.5105},
               'intercept': -5.5596,
               'regression_variable': 'EL_other'}

class Test_CREConst(object):
    
    # global variable 
    global res_coefs
    global other_coefs
    global test_dat_pd
    global precision
    CRE_test_obj = Cm.CREConstruction(
                    uncertainty_rate=0.,
                    as_of_date=datetime.datetime(2016,12,31),
                    model_id="2016-SBNA-Loss-Commercial-CREConstruction",
                    scenario='FRB_ADVERSE',
                    scenario_context='CCAR2017',
                    forecast_periods=27,
                    auto_fetch_macros = False)

    # test query result
    def test_coef(self):
        get_res_coefs = self.CRE_test_obj.residential_regression_coefficients
        get_other_coefs = self.CRE_test_obj.other_regression_coefficients
        assert get_res_coefs==res_coefs
        assert get_other_coefs==other_coefs
    
    # test exceptions handle    
    def test_uncertainty_exception(self):
        with pytest.raises(TypeError):
            Cm.CREConstruction(
                uncertainty_rate='a',
                as_of_date=datetime.datetime(2016,12,31),
                model_id="2016-SBNA-Loss-Commercial-CREConstruction",  
                scenario='FRB_ADVERSE',
                scenario_context='CCAR2017',
                forecast_periods=27)
    
    def test_macro_none_exception(self):
        with pytest.raises(AttributeError):
            self.CRE_test_obj._transformed_macro_series = None
            self.CRE_test_obj.calculateLoss()
    
    
    # test the calculation result
    def test_calculateLoss(self):
        self.CRE_test_obj._transformed_macro_series = test_dat_pd

        loss_result = self.CRE_test_obj.calculateLoss()
        el_resi, el_other = loss_result['EL_Yr_resi'], loss_result['EL_Yr_other']
        resi_log = lambda x: 1/ (1 + np.exp(-(-4.4464 + sum([i*j for i,j in zip([x['FHSTQ_US_p1y'],x['FRGT5Y_US_d1y']],[-2.09,-0.7488])]))))
        other_log = lambda x: 1/(1 + np.exp(-(-5.5596 + sum([i*j for i,j in zip([x['FHSTQ_US_p1y'],x['FZFL075035503Q_US_p1y']],[-2.7609,-3.5105])]))))
        test_dat_pd_resi = test_dat_pd[list(res_coefs['coefficients_pairs'].keys())]
        test_dat_pd_other = test_dat_pd[list(other_coefs['coefficients_pairs'].keys())]
        expected_resi = np.round(test_dat_pd_resi.apply(resi_log,axis = 1),precision)
        expected_other = np.round(test_dat_pd_other.apply(other_log, axis = 1),precision)
        global expected_resi
        global expected_other
        
        resi_comp = np.all(np.abs(el_resi - expected_resi)<0.00001) * 1 
        other_comp = np.all(np.abs(el_other - expected_other)<0.00001) * 1
#        py.test py_test.py -s to show the printed result
#        print('__test_dat_pd_resi\n', test_dat_pd_resi)
#        print('__test_dat_pd_other\n',test_dat_pd_other)
#        print('_test_dat_pd\n',test_dat_pd)
#        print('_transformed_macro_series\n',self.CRE_test_obj._transformed_macro_series)
#        print("__el_resi___\n",el_resi)
#        print("_expected_resi__\n",expected_resi)
#        print("__el_other\n",el_other)
#        print("__expected_other\n",expected_other)
        assert resi_comp==1 
        assert other_comp==1
    
    # test for the transformation
    def test_transformation(self):
        
        self.CRE_test_obj._transformed_macro_series = test_dat_pd
        trans_pd = pd.DataFrame.drop_duplicates(self.CRE_test_obj.calculate())
        trans_pd = trans_pd.set_index(test_dat_pd.index,drop=True)
        trans_pd_resi = trans_pd['PD_Mon_resi'].apply(lambda x: x.metric_value)
        trans_pd_other = trans_pd['PD_Mon_other'].apply(lambda x: x.metric_value)
        expected_pd_resi = expected_resi.apply(lambda x : round(1-((1-x)**(float(3/12))),10)/0.4).apply(lambda x : round(1-((1-x)**(float(1/3))),10))
        expected_pd_other = expected_other.apply(lambda x : round(1-((1-x)**(float(3/12))),10)/0.4).apply(lambda x : round(1-((1-x)**(float(1/3))),10))

        resi_pd_comp = np.all(np.abs(expected_pd_resi - trans_pd_resi) <0.00001) * 1
        other_pd_comp = np.all(np.abs(expected_pd_other - trans_pd_other) < 0.00001) * 1
#        py.test py_test.py -s to show the printed result
#        print('__trans_pd_resi\n', trans_pd_resi)
#        print('__trans_pd_pther\n', trans_pd_other)
#        print('__expected_pd_resi\n',expected_pd_resi)
#        print('__expected_pd_other\n',expected_pd_other)
#        print('___test___1\n',expected_pd_resi == trans_pd_resi)
#        print('___test___2\n',expected_pd_other == trans_pd_other)        
#        print('test_transformation: ___resi_____',resi_pd_comp)
#        print('test_transformation: ___other_____',other_pd_comp)
        assert resi_pd_comp==1
        assert other_pd_comp==1
        
    
        
        