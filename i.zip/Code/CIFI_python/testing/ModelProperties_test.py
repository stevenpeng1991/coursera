'''
Name: Test on modelproperties module 
Author: n886528
Date: 03/23/2017

external parameter used:
CONFIG['MODEL_PROPERTIES'] = {
	'FILE_PATH':CONFIG['WORKING_DIRECTORY']+'database/model_properties.json'
}

For fetching properties of model via querying JSON database
Structure decomposition:

    1. Initialize instance by model_id,version_date, and logger
     -> not test logger at current module
     -> version_date to be datetime.datetime type or raise TypeError
     -> isValidModelID to test model_id, return ValueError if not valid.
     -> isValidVersionDate tp test version_date, ValueError if not valid.
     1.1 DB connection:
     	-> JSONDecodeError if JSON file not valid.
     	-> NotConnectError if JSON path is not valid. 
     1.2 DB query:
     	1.2.1 getAllModelProperties():
     		-> get done in isValidVersionDate
     		-> no way to utilize without initializing
     	1.2.2 getParameters():
     		-> ValueError with duplicates or no existing
    2. Duplicate all properties with different date
     -> TypeError for invalid input value
     -> Do not need to touch

'''

import pytest
from CIFI.models.modelproperties.modelproperties import *
import datetime
import os
import sys

# test on initialization
test_paras = [
             pytest.mark.xfail(raises = TypeError)(
             	('37 - Scenario Analysis Model - SBB PD - SBNA','2016/12/31')),
             pytest.mark.xfail(raises = ValueError)(
             	("2016-SBNA-Loss-Commercial-EEE",datetime.datetime(2016,6,30))),
             pytest.mark.xfail(raises = ValueError)(
             	("2016-SBNA-Loss-Commercial-CRE",datetime.datetime(2013,3,20))),
             ('37 - Scenario Analysis Model - SBB PD - SBNA',datetime.datetime(2016,12,31))]

@pytest.mark.skipif(sys.version_info < (3,5), reason="Version might not be compatible!")     
@pytest.mark.parametrize(('model_id','version_date'),test_paras)
def test_exception_handling(model_id,version_date):
	ModelProperties(model_id = model_id,version_date = version_date)


# test on query result
test_query = [
	("743 - Commercial Rating Model - C&I PD - SBNA",[datetime.datetime(2016,12,31)],5),
	("2016-SBNA-Loss-Commercial-GCB",[datetime.datetime(2016,12,31),datetime.datetime(2016,6,30)],69)]

@pytest.mark.parametrize(('model_id','version_date','expected'),test_query)
def test_query_result(model_id,version_date,expected):
	query_length = 0
	for i in version_date:
		query_length += len(ModelProperties(model_id,i).getAllModelProperties())

	assert query_length == expected

# test on getParameters
test_filter = [pytest.mark.xfail(raises = ValueError)(
	("2016-SBNA-Loss-Commercial-CRE",datetime.datetime(2016,12,31),"operation","regression_coefficients"))]
@pytest.mark.parametrize(('model_id','version_date','type','name'),test_filter)
def test_filter_result(model_id,version_date,type,name):
	ModelProperties(model_id,version_date).getParameters(type,name)


test_specific_filter = [("2016-SBNA-Loss-Commercial-CRE",datetime.datetime(2016,12,31),"operation","regression_coefficients",'lgd_all',
		{
        "coefficients_pairs": {
          "MF": -0.0299,
          "UER_YoYDiff_L0": 0.0306,
          "dy1": 0.05414,
          "dy2": 0.08787,
          "dy3": 0.0734,
          "dy4": 0.04933,
          "isRetail": 0.02072,
          "ltv1": -0.09442,
          "ltv2": -0.10507,
          "ltv3": -0.07741,
          "ltv4": -0.05712,
          "ltv5": -0.03839,
          "mat_flag": -0.19017,
          "occ1": 0.09267,
          "occ2": 0.03723
        },
        "intercept": 0.30092,
        "regression_variable": "lgd"
      })]

@pytest.mark.parametrize(('model_id','version_date','type','name','seg','expected'),test_specific_filter)
def test_specific_filter(model_id,version_date,type,name,seg,expected):
	if seg is None:
		assert ModelProperties(model_id,version_date).getParameters(type,name) == expected
	else:
		assert ModelProperties(model_id,version_date).getParameters(type,name,segment = seg) == expected


