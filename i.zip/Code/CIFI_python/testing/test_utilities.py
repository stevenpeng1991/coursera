#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import datetime
import pytest
import CIFI.controllers.utilities.utilities as utilities

@pytest.mark.quicktest
class TestLambdaFunction:
    def test_date2str(self):
        assert utilities.date2str(datetime.datetime(2015,12,31)) == '12/31/2015'

    def test_str2date(self):
        assert utilities.str2date('12/31/2015') == datetime.datetime(2015,12,31)
        
    def test_str2date_ValueError(self):
        with pytest.raises(ValueError):
             utilities.str2date('2015-12-31')

    def test_float2str(self):
        assert utilities.float2str(1.20002) == '1.2000200000'

    def test_addMonths2Date(self):
        assert utilities.addMonths2date(datetime.datetime(2015,12,31),3) == datetime.datetime(2016, 3, 31, 0, 0)
             
    def test_addMonths2Date_TypeError(self):
        with pytest.raises(TypeError):
            utilities.addMonths2date('12/31/2015', 3)

    def test_PDPeriodConverter(self):
        assert round(utilities.PDPeriodConverter(0.05,3,1),5)==0.01695

    def test_checkDataType(self):
        assert utilities.checkDataType(9,int)

    def test_checkDataType_TypeError(self):
        with pytest.raises(TypeError):
            utilities.checkDataType(9, float)

@pytest.mark.quicktest
class TestStr2NumericFunction:
    def test_str2numeric(self):
        assert utilities.str2numeric('99.9')+0.1 == 100

    def test_str2numeric_ValueError(self):
        with pytest.raises(ValueError):
            utilities.str2numeric('hello')

@pytest.mark.quicktest
class TestYYYYQ2DateFunction:
    def test_YYYYQ2Date(self):
        assert utilities.YYYYQ2Date('2015Q2')==datetime.datetime(2015,6,30)

    def test_YYYYQ2Date_ValueError_regex(self):
        with pytest.raises(ValueError):
            utilities.YYYYQ2Date('20152')

    def test_YYYYQ2Date_ValueError_year_range(self):
        with pytest.raises(ValueError):
            utilities.YYYYQ2Date('1789Q1')

    def test_YYYYQ2Date_ValueError_month_value(self):
        with pytest.raises(ValueError):
            utilities.YYYYQ2Date('2015Q5')

@pytest.mark.quicktest
class TestDateSequencer:
    def test_3_period_sequence(self):
        response = utilities.generateDateSequence(
            as_of_date='12/31/2015', 
            forecast_periods=9,
            m_interval=3
        ) == [
            datetime.datetime(2016, 3, 31, 0, 0),
            datetime.datetime(2016, 6, 30, 0, 0),
            datetime.datetime(2016, 9, 30, 0, 0),
            datetime.datetime(2016, 12, 31, 0, 0),
            datetime.datetime(2017, 3, 31, 0, 0),
            datetime.datetime(2017, 6, 30, 0, 0),
            datetime.datetime(2017, 9, 30, 0, 0),
            datetime.datetime(2017, 12, 31, 0, 0),
            datetime.datetime(2018, 3, 31, 0, 0)
        ]
        assert response.all()
        
    def test_0_period_sequence_eom(self):
        response = utilities.generateDateSequence(
            as_of_date='12/23/2015', 
            forecast_periods=0, 
            include_init=True
        ) == [datetime.datetime(2015, 12, 31, 0, 0)]
        assert response.all()
        
    def test_sequence_as_of_date_ValueError(self):
        with pytest.raises(TypeError):
            utilities.generateDateSequence(as_of_date=1, forecast_periods=1)
            
    def test_sequence_m_interval_ValueError(self):
        with pytest.raises(TypeError):
            utilities.generateDateSequence('12/31/2015', 9, m_interval='2')
            
            
            