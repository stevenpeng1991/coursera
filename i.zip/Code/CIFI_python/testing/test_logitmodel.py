# -*- coding: utf-8 -*-
"""
Created on Fri Jan 20 09:27:13 2017

@author: n838126
"""
import sys
import os
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import datetime
import pytest
import pandas as pd
import numpy as np
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.logitmodel import TwoFLogitModel

@pytest.mark.quicktest
@pytest.mark.ccarmodel
class TestcalculatePD:
    precision=10
#    logistic_mapping = lambda ts : round(1/(1+np.exp(-ts)),precision)    
    regression_coefficients= {'coefficients_pairs': {
                                                      'FLBR_US_d1y': 0.442884456,
                                                      'bond_spread_lag_diff': 0.207889698},
                              'intercept': -5.992024291,
                              'regression_variable': 'PD'}
                              
    intercept = regression_coefficients['intercept']                          
    coeff_pairs=regression_coefficients['coefficients_pairs']
    data = pd.DataFrame({
      'FLBR_US_d1y':       [-0.10646695969999875,
                            -0.02237275440000097,
                            -0.16028786509999904,
                            -0.06492273789999992,
                            -0.26015221160000035,
                            -0.2953652334999992,
                            -0.2804906545000003,
                            -0.2395827989999999,
                            -0.18121819450000043],
     'bond_spread_lag_diff':[0.32925598649999976,
                             0.04850443599999954,
                             0.06631238740000045,
                             0.06420341190000034,
                             0.0036724893999999786,
                             0.042362847700000206,
                            -0.11831351279999991,
                            -0.08439285529999996,
                            -0.04184290330000051]
                      })
    def test_logistic_mapping(self):
      logistic_mapping = lambda ts : round(1/(1+np.exp(-ts)),self.precision) 
      assert logistic_mapping(0)==0.5
      
    def test_pd_qtr(self):
      logistic_mapping = lambda ts : round(1/(1+np.exp(-ts)),self.precision) 
      pd_qtr=logistic_mapping(
            (sum([self.data[item]*self.coeff_pairs[item] for item in self.coeff_pairs.keys()])+self.intercept)
        )
      result=np.round(
             [0.0025458847,
              0.0024928088,
              0.0023541288,
              0.0024543638,
              0.0022234303,
              0.0022067392,
              0.0021484767,
              0.0022031178,
              0.0022807178],self.precision)
              
      assert np.array_equal(np.array(pd_qtr),result)
   