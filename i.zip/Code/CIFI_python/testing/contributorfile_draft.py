# -*- coding: utf-8 -*-
"""
Created on Fri Apr 01 12:33:23 2016

@author: n813863
"""
import sys
import os
import datetime
wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.controllers.contributorfile.contributorfile import ContributorFile


# Set working directory
# WD = "I:/CRMPO/CCAR/4Q15/6 - Results/CONTRIBUTOR_FILE_CHECKER/"
WD = "I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/"
os.curdir = WD

# Test Loading Requirements
#requirements = cf.loadRequirements(
#        requirements_file_path=WD+"requirements.json",\
#        requirements_group='SB_COMM_LOSS')
#pprint.pprint(requirements)

# Create ContributorFile object instance
cf1 = ContributorFile(
    dir_path='I:/CRMPO/DEPT/Hachuel/CCAR/CCAR_API/test_files',
    filename='GBM_MRG_Base_SB_Comm_Loss.csv',
    forecast_periods=27,
    primary_key=["Scenario", "PeriodDate", "Vintage", "ModelSegment"],
    header_list=[
        "Scenario",
        "ModelSegment",
        "PeriodDate",
        "Vintage",
        "RateType",
        "FeesAndExpensesLineItem",
        "AssociatedG_L_Item",
        "Transformation",
        "PeriodLag",
        "RateName",
        "ModelOutputRate",
        "UncertaintyAdjustmentRate",
        "MgmtAdjustmentRate",
        "IdiosyncraticRate1",
        "IdiosyncraticRate2",
        "IdiosyncraticRate3",
        "IdiosyncraticRate4",
        "IdiosyncraticRate5",
        "Adjustment_Overlay_Justification"
    ],
    sep_char=','
)
cf1_data = cf1.getCFData()    

# INTEGRITY CHECKS
r = cf1.checkCFIntegrity()
r.getDict()
cf1.enforceCFIntegrity() # removing duplicates
r2 = cf1.checkCFIntegrity()
r2.getDict()

# HEADERS CHECKS
r = cf1.checkCFHeadersOrder()
r.getDict()
cf1.enforceCFHeaderOrder() # reordering headers
r2 = cf1.checkCFHeadersOrder()
r2.getDict()

# DISTRIBUTION CHECKS
cf1.checkCFFieldDistribution(
    field_name='Scenario',
    subset='ALL',
    check='character',
    error_message='Field class check failed.',
    check_name='class').getDict()
cf1.checkCFFieldDistribution(
    field_name='Scenario',
    subset='ALL',
    check='int',
    error_message='Distribution class check failed.',
    check_name='class').getDict()
cf1.checkCFFieldDistribution(
    field_name='ModelOutputRate',
    subset="data.ModelSegment=='ALLLCOVERAGE_9'",
    check='<1',
    error_message='Distribution mean check failed.',
    check_name='mean').getDict()
cf1.checkCFFieldDistribution(
    field_name='ModelOutputRate',
    subset="data.ModelSegment=='ALLLCOVERAGE_9'",
    check='<0.1',
    error_message='Distribution mean check failed.',
    check_name='mean').getDict()
cf1.checkCFFieldDistribution(
    field_name='ModelOutputRate',
    subset="ALL",
    check='<0.3',
    error_message='Distribution stdev check failed.',
    check_name='stdev').getDict()
cf1.checkCFFieldDistribution(
    field_name='ModelSegment',
    subset="data.ModelSegment=='ALLLCOVERAGE_9'",
    check='==1',
    error_message='Count of distinct values in distribution failed.',
    check_name='distinct_count').getDict()


# SINGLE ITEM CHECKS
cf1.checkCFFieldItem(
    field_name='ModelSegment',
    subset="data.ModelSegment=='ALLLCOVERAGE_9'",
    check='^[A-Z]*[_][0-9]*$|^SB[0-9]*$|^SB',
    error_message='Individual REGEX pattern failed to match.',
    check_name='regex_pattern').getDict()
cf1.checkCFFieldItem(
    field_name='ModelOutputRate',
    subset="data.ModelSegment=='ALLLCOVERAGE_9'",
    check="^[-]{0,1}[0]{1}[.]{0,1}[0-9]*$|^[-]{0,1}[1]{1}[.]{0,1}[0]*$",
    error_message='Individual REGEX pattern failed to match.',
    check_name='regex_pattern').getDict()
cf1.checkCFFieldItem(
    field_name='ModelSegment',
    subset="ALL",
    check='>4',
    error_message='Individual value length failed to check.',
    check_name='value_length').getDict()
cf1.checkCFFieldItem( # type error
    field_name='ModelOutputRate',
    subset="ALL",
    check='>4',
    error_message='Individual value length failed to check.',
    check_name='value_length').getDict()
cf1.checkCFFieldItem(
    field_name='ModelOutputRate',
    subset="ALL",
    check=0.00003,
    error_message='Individual value lower bound failed to match.',
    check_name='lower_bound').getDict()
cf1.checkCFFieldItem(
    field_name='ModelOutputRate',
    subset="ALL",
    check=1,
    error_message='Individual value upper bound failed to match.',
    check_name='upper_bound').getDict()
cf1.checkCFFieldItem(
    field_name='ModelOutputRate',
    subset="ALL",
    check=True,
    error_message='Field contains NA values.',
    check_name='check_na').getDict()



# as_of_date = datetime.datetime.strptime(requirements['as_of_date'],'%m/%d/%Y')

# List files in working directory
# os.listdir(os.curdir)
