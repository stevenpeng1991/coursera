#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 25 17:16:31 2016

@author: n813863
"""
import sys
import os
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
    
import CIFI.controllers.timingcurves.ncocurve as ncocurve
import collections
import datetime
import odbc
import pytest



    
# @pytest.mark.quicktest
class TestSegmentationMapping:
    def test_FAS114_STATUS_A(self):
        'A - NOT REQUIRED' in list(ncocurve.getSegmentationDictionary()['FAS114_STATUS'])
    
    def test_FAS115_STATUS_A_frequency(self):
        d = collections.Counter(list(ncocurve.getSegmentationDictionary()['FAS114_STATUS']))
        assert d['A - NOT REQUIRED'] == 5
        
    def test_FAS114_STATUS_B(self):
        'B - REQUIRED - NOT SUBMITTED' in list(ncocurve.getSegmentationDictionary()['FAS114_STATUS'])
    
    def test_FAS115_STATUS_B_frequency(self):
        d = collections.Counter(list(ncocurve.getSegmentationDictionary()['FAS114_STATUS']))
        assert d['B - REQUIRED - NOT SUBMITTED'] == 5
        
    def test_FAS114_STATUS_C(self):
        'C - REQUIRED - SUBMITTED' in list(ncocurve.getSegmentationDictionary()['FAS114_STATUS'])
    
    def test_FAS115_STATUS_C_frequency(self):
        d = collections.Counter(list(ncocurve.getSegmentationDictionary()['FAS114_STATUS']))
        assert d['C - REQUIRED - SUBMITTED'] == 5
        
    def test_CCRC_segment(self):
        l = list(ncocurve.getSegmentationDictionary()['SEGMENT'].unique())
        assert 'CCRC' not in l
    
class TestNCOTimingCurves:
    # @pytest.mark.quicktest
    def test_NCO_timing_curves_wrong_input_type(self):
        with pytest.raises(TypeError):
            ncocurve.getNCOTimingCurves('12/31/2015')
            
    # @pytest.mark.quicktest
    def test_NCO_timing_curves_wrong_ODBC_source(self):
        with pytest.raises(odbc.opError):
            ncocurve.getNCOTimingCurves(
                as_of_date = datetime.datetime(2015, 12, 31), 
                ODBC_source = 'Some ODBC Source'            
            )
    
    def test_NCO_timing_curves_2012_12_31():
        nco_rates_test = ncocurve.getNCOTimingCurves(as_of_date=datetime.datetime(2012,12,31))
        l1 = [float("%.4f" % item) 
            for item in list(nco_rates_test[nco_rates_test['SEGMENT']=='C&I']['NCO_PERCENT'])]                                      
        l2 = [float("%.4f" % float(item)) 
            for item in ['0.0057','0.0167','0.0551','0.0989','0.0283','0.0288','0.0095','0.0382',
            '0.0357', '0.0763','0.0131','0.0092','0.0401','0.0367','0.0292','0.0861','0.0184',
            '0.0026', '0','0.033','0.0042','0.1806','0.053','0.0316','0.063','0','0.0042']]
        assert l1 == l2