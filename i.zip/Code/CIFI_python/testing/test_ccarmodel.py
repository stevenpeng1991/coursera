#@pytest.mark.quicktest

'''
Name: Test on ccarmodel module 
Author: n886528
Date: 03/23/2017

The ccarmodel class acts as the super class for all risk models:
    methods in the class:
        1. get model parameters by querying internal database 
             * this method is built on methods of ModelProperties
        2. fetch macro series by querying external database
             * this method is built on methods of ScenarioMacroSeries
        3. check the data type and validate inputs for future use
    inputs:
        as_of_date: test on it for validation -> isValidAsOfDate
        model_id : primary key for querying internal database
        scenario : for querying external database
        forecast_periods: test on it for validation -> isValidForecastPeriods
        use_RFO_macro_series: bool to indicate whether to do query
        use_most_recent_model_properties: bool. 
        
'''

# loading related packages

from CIFI.controllers.models.ccarmodel import CCARModel
import pandas as pd
import numpy as np
import pytest
import sys
import datetime


    
# isValidAsOfDate : range should be located in the interval [last year + current m & d, next year + current m & d]
# usVakudFirecastPeriods : monthly, quarterly, anually
test_paras = [
             pytest.mark.xfail(raises = ValueError)((datetime.datetime(2013,12,31),
                                   '37 - Scenario Analysis Model - SBB PD - SBNA',
                                   'FRB_SA','CCAR2016','monthly',27)),
             pytest.mark.xfail(raises = TypeError)((datetime.datetime(2016,6,30),
                                   "2016-SBNA-Loss-Commercial-CRE",
                                   'FRB_SA','CCAR2016','monthly','27')),
             pytest.mark.xfail(raises = TypeError)((datetime.datetime(2016,6,30),
                                   "2016-SBNA-Loss-Commercial-CRE",
                                   'FRB_SA','CCAR2016','monthly','27')),
             pytest.mark.xfail(raises = ValueError)((datetime.datetime(2016,6,30),
                                   "2016-SBNA-Loss-Commercial-CRE",
                                   'FRB_SA','CCAR2016', 'monthly', 70)),
             pytest.mark.xfail(raises = ValueError)((datetime.datetime(2016,6,30),
                                   "2016-SBNA-Loss-Commercial-CRE",
                                   'FRB_SA','CCAR2016', 'quarterly', 21)),
             pytest.mark.xfail(raises = ValueError)((datetime.datetime(2016,6,30),
                                   "2016-SBNA-Loss-Commercial-CRE",
                                   'FRB_SA','CCAR2016', 'annually', 10)),
             (datetime.datetime(2016,6,30),"2016-SBNA-Loss-Commercial-CRE",'FRB_SA','CCAR2016', 'annually', 4),
             (datetime.datetime(2016,12,31),"2016-SBNA-Loss-Commercial-GCB",'DR_SA','CCAR2016', 'monthly', 27),
             (datetime.datetime(2016,12,31),"2016-SBNA-Loss-Commercial-GCB",'FRB_SA','CCAR2016', 'quarterly', 9)]
   
# input exception handling 

@pytest.mark.skipif(sys.version_info < (3,5), reason="Version might not be compatible!")     
@pytest.mark.parametrize(('as_of_date','model_id', 'scenario','scenario_context','forecast_periods_frequency','forecast_periods'),test_paras)
def test_exception_handling(as_of_date,model_id, scenario,scenario_context,forecast_periods_frequency,forecast_periods):
    ccarmodel.CCARModel(as_of_date=as_of_date,
                        model_id=model_id,
                        scenario= scenario,
                        scenario_context= scenario_context,
                        forecast_periods_frequency = forecast_periods_frequency,
                        forecast_periods=forecast_periods,
                        precision=None,
                        use_RFO_macro_series=False,
                        use_most_recent_model_properties = False )
   
# the following two parts should be used to test ModelProperties and ScenarioMacroSeries    
#    def test_query_result(self,*args):
#        pass
#
#    def test_macro(self,**kargs):
#        pass
        

