# Getting Started

1. Understand how CIFI.models.macrovariables.ScenarioMacroSeries works
2. Understand how CIFI.models.modelproperties.ModelProperties works (TinyDB, http://tinydb.readthedocs.io/en/latest/#)
3. Combine both to generate all transformations for all macrovariables pero model_id
4. Use Pandas charting methods to produce scenario comparisons per macrovariables per model_id 
    - If possible, add Santander theme (red color)