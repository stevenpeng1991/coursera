
"""
Sample Use

################ SPECIFICATION ############
########### Commercial
RETAIL_PLOT = False
PERIOD_FREQUENCY = 'quarterly'
model_id = ['743 - Commercial Rating Model - C&I PD - SBNA']
model_id = ['2018-SBNA-Loss-Business Banking-Streamlined']
model_id = ['2016-SBNA-Loss-Commercial-CRE']
model_id = ['37 - Scenario Analysis Model - SBB PD - SBNA']
model_id = ['2016-SBNA-Loss-Commercial-CRE']
model_id = [
            '743 - Commercial Rating Model - C&I PD - SBNA',
            '2016-SBNA-Loss-Commercial-CRE',  
            '2016-SBNA-Loss-Commercial-GCB',    
            '53 - Scenario Analysis Model - CEVF PD - SBNA',
            '2016-SBNA-Loss-Commercial-CREConstruction',
            '37 - Scenario Analysis Model - SBB PD - SBNA'
            ]

########### Retail            
RETAIL_PLOT = True
PERIOD_FREQUENCY = 'quarterly'
model_id = ['2016-SBNA-Loss-Retail-MORTGAGE']
model_id = ['2016-SBNA-Loss-Retail-HELOC']
model_id = ['2016-SBNA-Loss-Retail-MORTGAGE', '2016-SBNA-Loss-Retail-HELOC']

########### Auto Lease
RETAIL_PLOT = True
PERIOD_FREQUENCY = 'monthly'            
model_id = ['2016-SBNA-Loss-Retail-AUTOLEASE'] 


         
##########################################################################################
#################### 1. CCAR2017: 9Q forecast with historical ############################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2017': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_SA']
                         }
PLOT_START_DATE = datetime.datetime(2006, 3, 31)
VERSION_DATE = datetime.datetime(2016, 12, 31)
ADD_HISTORICAL = True
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/4Q16/9 - Scenarios/Scenario_Plots/CCAR2017_Historical&Forecast/test/"

##########################################################################################
#################### 2. CCAR2017: only plot 9Q forecast ##################################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2017': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_SA']
                         }
PLOT_START_DATE = datetime.datetime(2016, 12, 31)
VERSION_DATE = datetime.datetime(2016, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/4Q16/9 - Scenarios/Scenario_Plots/CCAR2017_9QForecast/test/"

##########################################################################################
#################### 3. Compare CCAR2017 & Mid-cycle2017 with historical #################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2017': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA'],
                'MidCycle2017': ['BASE', 'ADVERSE', 'STRESS']
                         }
PLOT_START_DATE = datetime.datetime(2006, 3, 31)
VERSION_DATE = datetime.datetime(2017, 6, 30)
ADD_HISTORICAL = True
FORECAST_PERIOD = 42
SAVEPATH = "I:/CRMPO/CCAR/2Q17/9 - Scenarios/Commercial/Scenario_Plots/Comparison_CCAR2017&MidCycle2017_Run1/test/"

##########################################################################################
#################### 4. Mid-cycle2017: 9Q forecast #######################################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'MidCycle2017': ['BASE', 'ADVERSE', 'STRESS']
                         }
PLOT_START_DATE = datetime.datetime(2017, 6, 30)
VERSION_DATE = datetime.datetime(2017, 6, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/2Q17/9 - Scenarios/Commercial/Scenario_Plots/MidCycle2017_Run1_9Qforecast/test/"

##########################################################################################
#################### 4.1 Mid-cycle2017: 14Q forecast (Seperate line in 9Q) #######################################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'MidCycle2017': ['BASE', 'ADVERSE', 'STRESS']
                         }
PLOT_START_DATE = datetime.datetime(2017, 6, 30)
VERSION_DATE = datetime.datetime(2017, 6, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 42
CUTOFF_PERIOD = datetime.datetime(2019, 9, 30)
SAVEPATH = "I:/CRMPO/CCAR/2Q17/9 - Scenarios/Commercial/Scenario_Plots/MidCycle2017_Run1_14Qforecast_updated/test/"

##########################################################################################
#################### 4.2 Mid-cycle2017: RETAIL Scenario 14Q forecast (Seperate line in 9Q) #######################################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'MidCycle2017': ['BASE', 'ADVERSE', 'STRESS']
                         }
PLOT_START_DATE = datetime.datetime(2017, 6, 30)
VERSION_DATE = datetime.datetime(2017, 6, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 42
CUTOFF_PERIOD = datetime.datetime(2019, 9, 30)
SAVEPATH = "I:/CRMPO/CCAR/2Q17/9 - Scenarios/Commercial/Scenario_Plots/retail_test_mc/"


##########################################################################################
#################### 5. Compare CCAR2017 & Mid-cycle2017: 9Q forecast ####################
## Start from the same point: Q0-Q1-Q2-........Q9 ########################################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2017': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA'],
                'MidCycle2017': ['BASE', 'ADVERSE', 'STRESS']
                         }
LEGEND_LIST = ['CCAR_BASE', 'CCAR_ADVERSE', 'CCAR_SA', 'MC_BASE', 'MC_ADVERSE', 'MC_STRESS']
CYCLE1 = 'CCAR2017'
CYCLE2 = 'MidCycle2017'
PLOT_START_DATE1 = datetime.datetime(2016, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2017, 6, 30)
VERSION_DATE1 = datetime.datetime(2016, 12, 31)
VERSION_DATE2 = datetime.datetime(2017, 6, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/2Q17/9 - Scenarios/Commercial/Scenario_Plots/Comparison_CCAR2017&MidCycle2017_Run1_9Q_updated/"

##########################################################################################
#################### 6. Compare Mid-cycle2017 & ICAAP2017: 13Q forecast ####################
## Start from the same point: Q0-Q1-Q2-........Q13 ########################################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'MidCycle2017': ['BASE', 'ADVERSE', 'STRESS'],
                'ICAAP2018': ['GLOBAL_STRESS']
                         }

LEGEND_LIST = ['MC_BASE', 'MC_ADVERSE', 'MC_STRESS', 'ICAAP_GLOBAL_STRESS']
CYCLE1 = 'MidCycle2017'
CYCLE2 = 'ICAAP2018'
PLOT_START_DATE1 = datetime.datetime(2017, 6, 30)
PLOT_START_DATE2 = datetime.datetime(2017, 9, 30)
VERSION_DATE1 = datetime.datetime(2017, 6, 30)
VERSION_DATE2 = datetime.datetime(2017, 9, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 39
SAVEPATH = "I:/CRMPO/CCAR/3Q17/9 - Scenarios/Commercial/Scenario_Plots/Comparison_MidCycle2017&ICAAP2018_13Q/"
#SAVEPATH = "I:/CRMPO/CCAR/3Q17/9 - Scenarios/Retail/Scenario_Plots/Comparison_MidCycle2017&ICAAP2018_13Q/"

##########################################################################################
#################### 7. Compare Mid-cycle2017 & IFRS9_2017_M9: 13Q forecast ####################
## Start from the same point: Q0-Q1-Q2-........Q13 ########################################
##########################################################################################
CONTEXT_SCENARIO_DICT = {
                'MidCycle2017': ['BASE', 'ADVERSE', 'STRESS'],
                'IFRS9_2017_M9': ['IFRS9_BASE', 'IFRS9_POSITIVE', 'IFRS9_NEGATIVE']
                         }

LEGEND_LIST = ['MC_BASE', 'MC_ADVERSE', 'MC_STRESS', 'IFRS9_BASE', 'IFRS9_POSITIVE', 'IFRS9_NEGATIVE']
CYCLE1 = 'MidCycle2017'
CYCLE2 = 'IFRS9_2017_M9'
PLOT_START_DATE1 = datetime.datetime(2017, 6, 30)
PLOT_START_DATE2 = datetime.datetime(2017, 9, 30)
VERSION_DATE1 = datetime.datetime(2017, 6, 30)
VERSION_DATE2 = datetime.datetime(2017, 9, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 39
SAVEPATH = "I:/CRMPO/CCAR/3Q17/9 - Scenarios/Commercial/Scenario_Plots/Comparison_MidCycle2017&IFRS9_M9_13Q/"
#SAVEPATH = "I:/CRMPO/CCAR/3Q17/9 - Scenarios/Retail/Scenario_Plots/Comparison_MidCycle2017&ICAAP2018_13Q/"

#############################################################################################################################################
#################### 8.1 CCAR2018: 9Q forecast; for both commercial and retail#######################################
#############################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_STRESS']
                         }
PLOT_START_DATE = datetime.datetime(2017, 12, 31)
VERSION_DATE = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
CUTOFF_PERIOD = None
SAVEPATH = "I:/CRMPO/CCAR/4Q17/9 - Scenarios/CCAR 2018/CCAR2018_9Q/"

#############################################################################################################################################
#################### 8.2 CCAR2018: 16Q forecast (Seperate line in 9Q); for both commercial and retail#######################################
#############################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_STRESS']
                         }
PLOT_START_DATE = datetime.datetime(2017, 12, 31)
VERSION_DATE = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 48
CUTOFF_PERIOD = datetime.datetime(2020, 3, 31)
SAVEPATH = "I:/CRMPO/CCAR/4Q17/9 - Scenarios/CCAR 2018/CCAR2018_16Q/test/"

############################################################################################################################################
#################### 8.3. Compare CCAR2017 & CCAR2018: 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2017': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_SA'],
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2017_BASE', 'CCAR2017_AD', 'CCAR2017_SA', 'CCAR2017_BHC_SA', 'CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_SA', 'CCAR2018_BHC_SA']
CYCLE1 = 'CCAR2017'
CYCLE2 = 'CCAR2018'
PLOT_START_DATE1 = datetime.datetime(2016, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2017, 12, 31)
VERSION_DATE1 = datetime.datetime(2016, 12, 31)
VERSION_DATE2 = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/4Q17/9 - Scenarios/CCAR 2018/Comparison_CCAR2018&CCAR2017_9Q/test/"
SHIFTING_TO_SAME_START_POINT = False

####################################################################################################################################################################################
#################### 8.4. Compare CCAR2017 & CCAR2018: 9Q forecast; SHIFTING old macro to new macro starting point; for both commercial and retail #################################
## Start from the same point: Q0-Q1-Q2-........Q9 ##################################################################################################################################
####################################################################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2017': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_SA'],
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2017_BASE', 'CCAR2017_SA', 'CCAR2018_BASE', 'CCAR2018_SA']
LEGEND_LIST = ['CCAR2017_BASE', 'CCAR2017_AD', 'CCAR2017_SA', 'CCAR2017_BHC_SA', 'CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_SA', 'CCAR2018_BHC_SA']
CYCLE1 = 'CCAR2017'
CYCLE2 = 'CCAR2018'
PLOT_START_DATE1 = datetime.datetime(2016, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2017, 12, 31)
VERSION_DATE1 = datetime.datetime(2016, 12, 31)
VERSION_DATE2 = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/4Q17/9 - Scenarios/CCAR 2018/Comparison_CCAR2018&CCAR2017_9Q_Shift2017Macro_allscenario/"
SHIFTING_TO_SAME_START_POINT = True

############################################################################################################################################
#################### 9.1. Compare CCAR2018 & EBA: 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_STRESS'],
                'EBA2018': ['EBA_BASE','EBA_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_SA', 'CCAR2018_BHC_SA', 'EBA_BASE', 'EBA_STRESS']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'EBA2018'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2017, 12, 31)
VERSION_DATE1 = datetime.datetime(2017, 12, 31)
VERSION_DATE2 = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/4Q17/9 - Scenarios/EBA 2018/Comparison_CCAR2018&EBA_9Q/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 10.1. Compare CCAR2018 & P21: 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE'],
                'P21': ['BASE']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'P21_BASE']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'P21'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2018, 3, 31)
VERSION_DATE1 = datetime.datetime(2017, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 3, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/CRMPO/CCAR/1Q18/8 - Scenarios/P21/Comparison_CCAR2018&P21_9Q/"
SHIFTING_TO_SAME_START_POINT = False

#############################################################################################################################################
#################### 11.0 IFRS9_2017_M12: 44Q forecast; for both commercial and retail#######################################
#############################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'IFRS9_2017_M12': ['IFRS9_BASE', 'IFRS9_POSITIVE', 'IFRS9_NEGATIVE']
                         }
PLOT_START_DATE = datetime.datetime(2017, 12, 31)
VERSION_DATE = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 132
CUTOFF_PERIOD = None
SAVEPATH = "I:/CRMPO/CCAR/1Q18/8 - Scenarios/IFRS9_2017_M12/"

############################################################################################################################################
#################### 12.1. Compare CCAR2018 & EBA_R2: 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_STRESS'],
                'EBA2018_R2': ['EBA_BASE','EBA_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_SA', 'CCAR2018_BHC_SA', 'EBA_BASE', 'EBA_STRESS']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'EBA2018_R2'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2017, 12, 31)
VERSION_DATE1 = datetime.datetime(2017, 12, 31)
VERSION_DATE2 = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/4Q17/9 - Scenarios/EBA2018_R2/Comparison_CCAR2018&EBA_R2_9Q/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 13.1. Compare M9 & M2: 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'IFRS9_2017_M9': ['IFRS9_BASE','IFRS9_POSITIVE','IFRS9_NEGATIVE'],
                'IFRS9_2018_M2': ['IFRS9_BASE','IFRS9_POSITIVE','IFRS9_NEGATIVE']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['M9_BASE', 'M9_POSITIVE', 'M9_NEGATIVE', 'M2_BASE', 'M2_POSITIVE', 'M2_NEGATIVE']
CYCLE1 = 'IFRS9_2017_M9'
CYCLE2 = 'IFRS9_2018_M2'
PLOT_START_DATE1 = datetime.datetime(2017, 9, 30)
PLOT_START_DATE2 = datetime.datetime(2018, 3, 31)
VERSION_DATE1 = datetime.datetime(2017, 12, 31)
VERSION_DATE2 = datetime.datetime(2017, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 129
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/1Q18/8 - Scenarios/Comparison_IFRS9_2017_M9&IFRS9_2018_M2_15Q/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 14.1. Compare CCAR2018 & MidCycle 2018: 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'BHC_STRESS'],
                'MidCycle2018': ['MC_BASE', 'MC_ADVERSE','MC_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_STRESS', 'MidCycle2018_BASE', 'MidCycle2018_ADVERSE', 'MidCycle2018_STRESS']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'MidCycle2018'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2018, 6, 30)
VERSION_DATE1 = datetime.datetime(2017, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 6, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/2Q18/9 - Scenarios/MidCycle2018/Comparison_CCAR2018&MidCycle2018/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 14.2. Compare MidCycle 2018 and ICAAP: 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'MidCycle2018': ['MC_BASE', 'MC_ADVERSE','MC_STRESS'],
                'ICAAP2019': ['BASE','GLOBAL_STRESS'],
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['MidCycle2018_BASE', 'MidCycle2018_ADVERSE', 'MidCycle2018_STRESS','ICAAP2019_BASE','ICAAP2019_GLOBAL_STRESS']
CYCLE1 = 'MidCycle2018'
CYCLE2 = 'ICAAP2019'
PLOT_START_DATE1 = datetime.datetime(2018, 6, 30)
PLOT_START_DATE2 = datetime.datetime(2018, 9, 30)
VERSION_DATE1 = datetime.datetime(2018, 6, 30)
VERSION_DATE2 = datetime.datetime(2018, 9, 30)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/3Q18/9 - Scenarios/Comparison_MidCycle2018&ICAAP2019/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 15.1. Compare CCAR2018 & MidCycle 2018 (Using CCAR 2019 macro!): 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'BHC_STRESS'],
                'MidCycle2018': ['MC_BASE', 'MC_ADVERSE','MC_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_STRESS', 'MidCycle2018_BASE', 'MidCycle2018_ADVERSE', 'MidCycle2018_STRESS']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'MidCycle2018'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2018, 6, 30)
VERSION_DATE1 = datetime.datetime(2018, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/3Q18/9 - Scenarios/CCAR2019 MODEL UAT/Comparison_CCAR2018&MidCycle2018/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 16.1. Compare CCAR2018 & ICAAP2019 (Using CCAR 2019 macro!): 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA','BHC_STRESS'],
                'ICAAP2019': ['BASE', 'DOWNSIDE','GLOBAL_STRESS','BHC_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_SA','CCAR2018_BHC', 'ICAAP_BASE', 'ICAAP_DOWNSIDE', 'ICAAP_GLOBAL_STRESS', 'ICAAP_BHC_STRESS']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'ICAAP2019'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2018, 12, 31)
VERSION_DATE1 = datetime.datetime(2018, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/4Q18/9 - Scenarios/test_ICAAP/Comparison_CCAR2018&ICAAP2019/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 17.1. Compare Dry Run & ICAAP2019 (Using CCAR 2019 macro!): 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'MidCycle2018': ['MC_BASE', 'MC_ADVERSE','MC_STRESS'],
                'ICAAP2019': ['BASE', 'DOWNSIDE','GLOBAL_STRESS','BHC_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['MidCycle2018_BASE', 'MidCycle2018_ADVERSE', 'MidCycle2018_STRESS','ICAAP_BASE', 'ICAAP_DOWNSIDE', 'ICAAP_GLOBAL_STRESS', 'ICAAP_BHC_STRESS']
CYCLE1 = 'MidCycle2018'
CYCLE2 = 'ICAAP2019'
PLOT_START_DATE1 = datetime.datetime(2018, 6, 30)
PLOT_START_DATE2 = datetime.datetime(2018, 12, 31)
VERSION_DATE1 = datetime.datetime(2018, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/4Q18/9 - Scenarios/test_ICAAP/Comparison_MidCycle2018&ICAAP2019/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 18.1. Compare CCAR2018 & CCAR2019 (Using CCAR 2019 macro!): 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA','BHC_STRESS'],
                'CCAR2019': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA','HCR_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_SA','CCAR2018_BHC', 'CCAR2019_BASE', 'CCAR2019_AD', 'CCAR2019_SA','CCAR2019_HCR']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'CCAR2019'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2018, 12, 31)
VERSION_DATE1 = datetime.datetime(2018, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 72
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/4Q18/9 - Scenarios/test_ICAAP/Comparison_CCAR2018&CCAR2019_24Q/"
SHIFTING_TO_SAME_START_POINT = False

############################################################################################################################################
#################### 18.2. Compare ICAAP2019 & CCAR2019 (Using CCAR 2019 macro!): 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'ICAAP2019': ['BASE', 'DOWNSIDE','GLOBAL_STRESS','BHC_STRESS'],
                'CCAR2019': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA','HCR_STRESS']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['ICAAP_BASE', 'ICAAP_DOWNSIDE', 'ICAAP_GLOBAL_STRESS', 'ICAAP_BHC_STRESS', 'CCAR2019_BASE', 'CCAR2019_AD', 'CCAR2019_SA','CCAR2019_HCR']
CYCLE1 = 'ICAAP2019'
CYCLE2 = 'CCAR2019'
PLOT_START_DATE1 = datetime.datetime(2018, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2018, 12, 31)
VERSION_DATE1 = datetime.datetime(2018, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 27
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/4Q18/9 - Scenarios/test_ICAAP/Comparison_ICAAP2019&CCAR2019/"
SHIFTING_TO_SAME_START_POINT = False

###############  GENERATION OF PLOTS  ##################
# to plot macro scenario for one cycle
plotMacroScenario(
    context_scenario_dict = CONTEXT_SCENARIO_DICT,
    geo_scope = 'National&Regional',
#    geo_scope = 'CNER',
    period_frequency = PERIOD_FREQUENCY,
    plot_start_date = PLOT_START_DATE,
    forecast_period = FORECAST_PERIOD,
    plotSavePath = SAVEPATH,
    model_id = model_id,
    rfo_environment = None,
    version_date = VERSION_DATE,
    cutoff_period = CUTOFF_PERIOD,
    save_to_file = True,
    add_historical = ADD_HISTORICAL,
    add_description = False,
    retail_plot = RETAIL_PLOT
    )

# to plot comparison of two cycles' macro scenario (start from the as-of-date)
plotMacroScenarioComparison(
    context_scenario_dict = CONTEXT_SCENARIO_DICT,
    geo_scope = 'National&Regional',
    period_frequency = PERIOD_FREQUENCY,
    cycle1 = CYCLE1,
    cycle2 = CYCLE2,
    plot_start_date1 = PLOT_START_DATE1,
    plot_start_date2 = PLOT_START_DATE2,
    version_date1 = VERSION_DATE1,
    version_date2 = VERSION_DATE2,
    forecast_period = FORECAST_PERIOD,
    plotSavePath = SAVEPATH,
    model_id = model_id,
    rfo_environment = 'PROD_ENV',
    save_to_file = True,
    add_historical = ADD_HISTORICAL,
    add_description = False,
    retail_plot = RETAIL_PLOT,
    shift_to_same_start_point = SHIFTING_TO_SAME_START_POINT
    )

###############  Store plots in different folder by model #############
segment_list = ['C&I', 'CRE', 'GCB', 'CEVF', 'CREConstruction', 'SBB']
segment_list = ['MORTGAGE', 'HELOC']
segment_list = ['C&I', 'CRE']
model_len = len(model_id)
for i in range(model_len):
    model = [model_id[i]]
    plotMacroScenario(
        context_scenario_dict = CONTEXT_SCENARIO_DICT,
        geo_scope = 'National&Regional',
        period_frequency = PERIOD_FREQUENCY,
        plot_start_date = PLOT_START_DATE,
        forecast_period = FORECAST_PERIOD,
        plotSavePath = SAVEPATH + segment_list[i] + "/",
        model_id = model,
        rfo_environment = 'PROD_ENV',
        version_date = VERSION_DATE,
        cutoff_period = CUTOFF_PERIOD,
        save_to_file = True,
        add_historical = ADD_HISTORICAL,
        add_description = False,
        retail_plot = RETAIL_PLOT
        )
    
for i in range(model_len):
    model = [model_id[i]]
    plotMacroScenarioComparison(
        context_scenario_dict = CONTEXT_SCENARIO_DICT,
        geo_scope = 'National&Regional',
        period_frequency = PERIOD_FREQUENCY,
        cycle1 = CYCLE1,
        cycle2 = CYCLE2,
        plot_start_date1 = PLOT_START_DATE1,
        plot_start_date2 = PLOT_START_DATE2,
        version_date1 = VERSION_DATE1,
        version_date2 = VERSION_DATE2,
        forecast_period = FORECAST_PERIOD,
        plotSavePath = SAVEPATH + segment_list[i] + "/",
        model_id = model,
        rfo_environment = 'PROD_ENV',
        save_to_file = True,
        add_historical = ADD_HISTORICAL,
        add_description = False,
        retail_plot = RETAIL_PLOT,
        shift_to_same_start_point = SHIFTING_TO_SAME_START_POINT
        )

###############  Plot given a macro dict ############## 
all_macro_vars = ScenarioMacroSeries(
    mv_dict_list=[
        {
            "macro_variable_name": "CREPINE_CNER",
            "lag": 0,
            "transformation_type": "none",
            "macro_variables_group": "CREPINE_CNER"
        },
    ],
    mv_group_dict_list=[
        {
            "combination" : "CREPINE_CNER",
            "operand_1" : "CREPINE_CNER",
            "operand_2" : None,
            "operator" : None
        }
    ],
    mv_as_of_date=datetime.datetime(2017,12,31),
    mv_forecast_periods=15,
    mv_context='CCAR2018',
    mv_scenario='FRB_SA',
    mv_geo_scope='CNER',
    mv_period_frequency='quarterly'
)



######################################################################
#################### Update Retail JSON file  ########################
######################################################################

from tinydb import TinyDB, Query
from CIFI.models.modelproperties.modelproperties import ModelProperties

################## Copy all model properties from last run  ###########
mp = ModelProperties(
	model_id = '2016-SBNA-Loss-Retail-MORTGAGE',
	version_date=datetime.datetime(2017, 6, 30),
	path_to_model_properties = CONFIG['WORKING_DIRECTORY'] + 'database/retail_macro_information.json'
     )

all = mp.getAll()
all_with_date = mp.getAllPropertiesWithVersionDate(version_date = datetime.datetime(2017,9,30))

mp.dupAllPropertiesWithDiffVersionDate(new_version_date=datetime.datetime(2017,12,31), old_version_date=datetime.datetime(2017,9,30), only_current_model_id = False)

all_new = mp.getAll()

"""
import sys
import CIFI.controllers.utilities.utilities as utilities
import CIFI.models.macrovariables.macrovariables as mv
import CIFI.models.modelproperties.modelproperties as mp
from CIFI.config import CONFIG
from tinydb import TinyDB, Query
import matplotlib.pyplot as plt
import pandas as pd
import datetime
import time
import pandas as pd
import numpy as np
import copy
import json
import os
import matplotlib as mpl
from matplotlib.dates import DateFormatter, YearLocator, MonthLocator
from datetime import timedelta
mpl.rcParams.update(mpl.rcParamsDefault)
import matplotlib.dates as mdates

# config for plot (color, shape)
PLOT_CONFIG = {
        "FRB_BASE": ('green', '--'),
        "FRB_ADVERSE": ('orange', '--'),
        "FRB_SA": ('red', '--'),
        "BHC_SA": ('black', '--'),
        "BHC_STRESS": ('black', '--'),
        "Historical": ('grey', '-'),
        "DR_BASE": ('lime', '-'),
        "DR_SA": ('red', '-'),
        "MC_BASE": ('lime', '--'),
        "MC_ADVERSE": ('darkorange', '--'),
        "MC_SA": ('red', '--'),
        "MC_STRESS": ('red', '--'),
        "BASE": ('green', '--'),
        "ADVERSE": ('orange', '--'),
        "STRESS": ('red', '--'),
        "GLOBAL_STRESS": ('orange', '-'),
        "IFRS9_BASE": ('lime', '-'),
        "IFRS9_POSITIVE": ('darkorange', '-'),
        "IFRS9_NEGATIVE": ('red', '-'),
        "CCAR2018_BASE": ('green', '--'),
        "CCAR2018_AD": ('orange', '--'),
        "CCAR2018_SA": ('red', '--'),
        "CCAR2018_BHC": ('black', '--'), 
        "CCAR2018_STRESS": ('red', '--'),      
        "CCAR2019_BASE": ('green', '-'),
        "CCAR2019_AD": ('orange', '-'),
        "CCAR2019_SA": ('red', '-'),
        "CCAR2019_HCR": ('black', '-'),    
        "CCAR2017_BASE": ('green', '--'),
        "CCAR2017_AD": ('orange', '--'),
        "CCAR2017_SA": ('red', '--'),
        "CCAR2017_BHC_SA": ('black', '--'),
        "EBA_BASE": ('green', '--'),
        "EBA_STRESS": ('red', '--'),
        "P21_BASE": ('green', '-'),
        "M9_BASE": ('lime', '--'),
        "M9_POSITIVE": ('darkorange', '--'),
        "M9_NEGATIVE": ('red', '--'),
        "M2_BASE": ('lime', '-'),
        "M2_POSITIVE": ('darkorange', '-'),
        "M2_NEGATIVE": ('red', '-'),
        "MidCycle2018_BASE": ('green', '--'),
        "MidCycle2018_ADVERSE": ('darkorange', '--'),
        "MidCycle2018_STRESS": ('red', '--'),
        "ICAAP_BASE": ('green', '--'),
        "ICAAP_DOWNSIDE": ('lime', '--'),
        "ICAAP_GLOBAL_STRESS": ('orange', '--'),
        "ICAAP_BHC_STRESS": ('black', '--')
        }         

# function to plot macro scenario for one cycle
def plotMacroScenario(
    context_scenario_dict: dict,
    model_id: (str, list),
    plot_start_date: datetime.datetime,
    version_date: datetime.datetime,
    forecast_period: int,
    plotSavePath: str,
    geo_scope: str = 'National&Regional',
    period_frequency: str = 'quarterly',
    rfo_environment = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
    cutoff_period =  None,
    save_to_file = False,
    add_historical = True,
    add_description = False,
    retail_plot = False
):
    
    # validate inputs
    if cutoff_period is not None:
        utilities.checkDataType(cutoff_period, datetime.datetime)
        
    if not os.path.isdir(plotSavePath):
        raise ValueError("Invalid plotSavePath!") 

    #  Path to model_properties JSON file for TinyDB usage
    if not retail_plot:
        path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
    else:
        path_to_model_properties = CONFIG['WORKING_DIRECTORY'] + 'database/retail_macro_information.json'
    
    db = TinyDB(path_to_model_properties)
#    all_model_property = db.all()
    """ ### test db search
    a = db.search((Query().model_id == '53 - Scenario Analysis Model - CEVF PD - SBNA') & (Query().name == "macro_variables")  
                            & (Query().version_date.test(
                           lambda s: utilities.str2date(s) == datetime.datetime(2016, 12, 31))))
    """
    


    # If not specify model_id, get all unique model id for macro variables in model_property JSON file
    if model_id is None:
        unique_model_id = list(
            pd.core.series.Series(
                [item['model_id'] for item in db.search((Query().model_id.exists()) 
                    & (Query().version_date.test(
                           lambda s: utilities.str2date(s) == version_date)) 
                    & (Query().name == "macro_variables"))]
                ).unique()
        )
    else:
        unique_model_id = model_id[:]
 
    # calculate length of plot period
    if period_frequency == 'quarterly':
        if forecast_period % 3 == 0:
            plot_period = int(forecast_period / 3) + utilities.datetimeDiffInQuarter(plot_start_date, version_date) + 1
        else:
            raise ValueError("Invalid forecast period(month) for quarterly forecast") 
    elif period_frequency == 'monthly':
        plot_period = forecast_period + utilities.datetimeDiffInMonth(plot_start_date, version_date) + 1
            
    # container for macro and group macro variable dictionary                                                  
    mv_dict_list = []
    mv_group_dict_list = []

    # create ModelProperties instance given model_id and version_date and get properties into dictionary list
#    model = '2016-SBNA-Loss-Retail-MORTGAGE'
#    model = '743 - Commercial Rating Model - C&I PD - SBNA'
    for model in unique_model_id:
        model_properties = mp.ModelProperties(
            model_id = model,
            version_date = version_date,
            path_to_model_properties = path_to_model_properties
            )
        macro_variables = model_properties.getParameters(type = 'operation', name = 'macro_variables')
        macro_group_variables = model_properties.getParameters(type = 'operation', name = 'macro_variable_combinations')
        mv_dict_list.extend(macro_variables) 
        mv_group_dict_list.extend(macro_group_variables)     

    # temp fix: first one is invalid: macro_variable_name: FGDPxxx_US, should be FGDPXXX_US
    if mv_dict_list[0]['macro_variable_name'] == 'FGDPxxx_US':
        mv_dict_list[0]['macro_variable_name'] = 'FGDPXXX_US'
    
    # containers for macro variables/raw data/transformed data
    all_macro_vars = []
    raw_macro_data = []
    trans_macro_data = []
    count = 0
    # context/scenario container
    context_list = []
    scenario_list = []
    
    # create ScenarioMacroSeries instances and fetch/transform macro variables
    # context = 'CCAR2017'
#    i = 0
    for context in sorted(context_scenario_dict):
        context_list.append(context)
        for i in range(len(context_scenario_dict[context])):
            scenario_list.append(context_scenario_dict[context][i])
            
            # decide which RFO database should fetch from
            if context in ['CCAR2017', 'CCAR2018', 'DryRun2017', 'P20_MAY']:
                rfo_environment = 'PROD_ENV'
            elif context in ['ICAAP2016', 'MidCycle2016']:
                rfo_environment = 'UAT_ENV'
            else:
                rfo_environment = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"]

            # create ScenarioMacroSeries instances
            all_macro_vars.append(mv.ScenarioMacroSeries(
                mv_dict_list = mv_dict_list,
                mv_group_dict_list = mv_group_dict_list,
                mv_as_of_date = plot_start_date - timedelta(days=1),
                mv_forecast_periods = plot_period,
                mv_context = context,
                mv_scenario = context_scenario_dict[context][i],
                mv_geo_scope = geo_scope,
                mv_period_frequency = period_frequency,
                rfo_environment = rfo_environment,
                dataViz = True
                )
            )
            # fetch macro data from RFO
            print('The scenario combo is:' + context + context_scenario_dict[context][i])
            print('>>> Fetching raw macro series...')
            raw_macro_data.append(all_macro_vars[count].fetchSQLiteMacroSeries())
            print('>>> Transforming macro series...')
            #  generate transformed data and remove the duplicate variables
            trans_macro_data.append(all_macro_vars[count].generateTransformedData().T.drop_duplicates().T)
            count += 1
            
    # change index into QQYYYY format
#    for item in trans_macro_data:
#        item['xtick'] = pd.Series(item.index).apply(utilities.date2XQYY).tolist()
#        
#    my_xticks = trans_macro_data[0]['xtick'].tolist()

#    for item in trans_macro_data:
#        item['xtick'] = item.index.to_period("Q").tolist()
#        item.set_index(item.index.to_period("Q"), inplace = True)
#    my_xticks = trans_macro_data[0].index.tolist()    
    
    scenario_list_length = len(scenario_list)
    
    if scenario_list_length > 8:
            raise ValueError('Number of input scenarios is not within allowable range(1 to 8)')
    
    # add additional legend for historical data
    print('>>> Adding historical...')
    if add_historical:
        scenario_list.append("Historical")
    
    # add macro variable description
    print('>>> Adding description for macro variables...')
    if add_description:
        macro_inventory = pd.read_excel(
            io = "I:/CRMPO/CCAR/4Q16/9 - Scenarios/BHC Stress macro selection_20170111.xlsm",
            sheetname = "Macrovariable Inventory"
            )
        macro_inventory = macro_inventory.set_index('Concept')
        macro_inventory = macro_inventory.groupby(macro_inventory.index).first()

    # config for plot (color, shape)
    plot_config = PLOT_CONFIG
    
    # create plots for transformed macro data and save the figures
    for column in trans_macro_data[0].columns:
        # set plot title
        if add_description:
            plot_title = macro_inventory.loc[column.split('_US')[0], 'Description']
        else:
            plot_title = 'Scenario Trends for %s' % column 
        line_width = 1.5
        
        if period_frequency == 'quarterly':
            if forecast_period > 27:
                legend_loc = -0.05
            else:
                legend_loc = -0.075
#            datemin = datetime.date(trans_macro_data[0].index.min().year, 1, 1)
#            datemax = datetime.date(trans_macro_data[0].index.max().year + 1, 1, 1)
#            ax.set_xlim(datemin, datemax)
        elif period_frequency == 'monthly':
            legend_loc = -0.07
#            datemin = datetime.date(trans_macro_data[0].index.min().year, 3, 1)
#            datemax = datetime.date(trans_macro_data[0].index.max().year + 1, 3, 1)
#            ax.set_xlim(datemin, datemax)

        # ax = trans_macro_data[0].plot(y = column, color = plot_config[scenario_list[0]][0], linewidth = line_width, linestyle = plot_config[scenario_list[0]][1])
        ax = trans_macro_data[0].plot(y = column, title = plot_title, color = plot_config[scenario_list[0]][0], linewidth = line_width, linestyle = plot_config[scenario_list[0]][1])
        for i in range(1,scenario_list_length):
                trans_macro_data[i].plot (y = column, ax = ax, color = plot_config[scenario_list[i]][0], linewidth = line_width, linestyle = plot_config[scenario_list[i]][1])
        # if need to plot historicals, add a grey line for historical data
        if add_historical:
            historical = trans_macro_data[-1][trans_macro_data[-1].index >= plot_start_date].ix[0:plot_period - forecast_period]
            historical.plot (y = column, ax = ax, color = plot_config[scenario_list[-1]][0], linewidth = line_width, linestyle = plot_config[scenario_list[-1]][1])

        ax.legend(scenario_list, loc = 'upper center', fontsize = 'xx-small', fancybox=True, shadow=False, bbox_to_anchor=(0.5, legend_loc), ncol = 7, handlelength = 2.8)
        # remove x lable
        ax.xaxis.label.set_visible(False)
        # add cutoff line
        if cutoff_period != None:
            plt.axvline(x = cutoff_period, color='grey', linestyle='--', linewidth = 1.4)

#        plt.xticks(list(range(len(my_xticks))), my_xticks)
        ax.tick_params(
            axis='both',
            which='both',
            bottom='on',
            top='off',
            left='on',
            right='off',
            labelbottom='on',
            labelleft='on')
        
        ax.yaxis.grid(True)
        
#        # format the ticks
#        years = mdates.YearLocator(1, month = 12, day = 31)   # every year
#        months = mdates.MonthLocator(interval=6)  # every month
#        yearsFmt = mdates.DateFormatter('%Y-%M')
#        monthsFmt = mdates.DateFormatter('%M')
#     
#        ax.xaxis.set_major_locator(years)
#        ax.xaxis.set_major_formatter(yearsFmt)
#        ax.xaxis.set_minor_locator(months)
#        ax.xaxis.set_minor_formatter(monthsFmt)

        
        fig = ax.get_figure()
        # if comparing between different context, file name will be different
        completeContext = '&'.join(context_list)
        if save_to_file:
            print('>>> Creating macro variables plots for ' + column)
            plot_file = plotSavePath + column + "_" + completeContext + ".png"
            fig.savefig(
                plot_file,
                dpi=300,
                transparent=False
                )  

# function to plot comparison of two cycles' macro scenario (start from the as-of-date)
def plotMacroScenarioComparison(
    context_scenario_dict: dict,
    model_id: (str, list),
    cycle1: str,
    cycle2: str,
    plot_start_date1: datetime.datetime,
    plot_start_date2: datetime.datetime,
    version_date1: datetime.datetime,
    version_date2: datetime.datetime,
    forecast_period: int,
    plotSavePath: str,
    geo_scope: str = 'National&Regional',
    period_frequency: str = 'quarterly',
    rfo_environment = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
    save_to_file = False,
    add_historical = True,
    add_description = False,
    retail_plot = False,
    shift_to_same_start_point = False
):

    # validate inputs
    if not os.path.isdir(plotSavePath):
        raise ValueError("Invalid plotSavePath!") 
        
    #  Path to model_properties JSON file for TinyDB usage
    if not retail_plot:
        path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
    else:
        path_to_model_properties = CONFIG['WORKING_DIRECTORY'] + 'database/retail_macro_information.json'
    
    db = TinyDB(path_to_model_properties)
#    all_model_property = db.all()
    """ ### test db search
    a = db.search((Query().model_id == '53 - Scenario Analysis Model - CEVF PD - SBNA') & (Query().name == "macro_variables")  
                            & (Query().version_date.test(
                           lambda s: utilities.str2date(s) == datetime.datetime(2016, 12, 31))))
    """
    
    # If not specify model_id, get all unique model id for macro variables in model_property JSON file
    if model_id is None:
        unique_model_id = list(
            pd.core.series.Series(
                [item['model_id'] for item in db.search((Query().model_id.exists()) 
                    & (Query().version_date1.test(
                           lambda s: utilities.str2date(s) == version_date1)) 
                    & (Query().name == "macro_variables"))]
                ).unique()
        )
    else:
        unique_model_id = model_id[:]
 
    # calculate length of plot period
    if period_frequency == 'quarterly':
        if forecast_period % 3 == 0:
#            plot_period = int(forecast_period / 3) + utilities.datetimeDiffInQuarter(plot_start_date1, version_date1) + 1
            plot_period = int(forecast_period / 3) + 1
        else:
            raise ValueError("Invalid forecast period(month) for quarterly forecast") 
    elif period_frequency == 'monthly':
#        plot_period = forecast_period + utilities.datetimeDiffInMonth(plot_start_date1, version_date1) + 1
        plot_period = forecast_period + 1
            
    # container for macro and group macro variable dictionary                                                  
    mv_dict_list = []
    mv_group_dict_list = []

    # create ModelProperties instance given model_id and version_date and get properties into dictionary list
#    model = '2016-SBNA-Loss-Retail-AUTOLEASE'
    for model in unique_model_id:
        model_properties = mp.ModelProperties(
            model_id = model,
            version_date = version_date1,
            path_to_model_properties = path_to_model_properties
            )
        macro_variables = model_properties.getParameters(type = 'operation', name = 'macro_variables')
        macro_group_variables = model_properties.getParameters(type = 'operation', name = 'macro_variable_combinations')
        mv_dict_list.extend(macro_variables) 
        mv_group_dict_list.extend(macro_group_variables)     
    
    # containers for macro variables/raw data/transformed data
    all_macro_vars = []
    raw_macro_data = []
    trans_macro_data = []
    count = 0
    # scenario container
    scenario_list = []
    
    
    # create ScenarioMacroSeries instances and fetch/transform macro variables
    for cycle, plot_start_date in zip([cycle1, cycle2], [plot_start_date1, plot_start_date2]):
        for item in context_scenario_dict[cycle]:
            print (item)
            scenario_list.append(item)
            
            # decide which RFO database should fetch from
            if cycle in ['CCAR2017', 'DryRun2017', 'P20_MAY']:
                rfo_environment = 'PROD_ENV'
            elif cycle in ['ICAAP2016', 'MidCycle2016']:
                rfo_environment = 'UAT_ENV'
            else:
                rfo_environment = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"]

            # create ScenarioMacroSeries instances
            all_macro_vars.append(mv.ScenarioMacroSeries(
                mv_dict_list = mv_dict_list,
                mv_group_dict_list = mv_group_dict_list,
                mv_as_of_date = plot_start_date - timedelta(days=1),
                mv_forecast_periods = plot_period,
                mv_context = cycle,
                mv_scenario = item,
                mv_geo_scope = geo_scope,
                mv_period_frequency = period_frequency,
                rfo_environment = rfo_environment,
                dataViz = True
                )
            )
            # fetch macro data from RFO
            print('The scenario combo is:' + cycle + '+' + item)
            print('>>> Fetching raw macro series...')
            raw_macro_data.append(all_macro_vars[count].fetchSQLiteMacroSeries())
            print('>>> Transforming macro series...')
            #  generate transformed data and remove the duplicate variables
            trans_macro_data.append(all_macro_vars[count].generateTransformedData().T.drop_duplicates().T)
            trans_macro_data[count]['Period'] = [('Q' + str(x)) for x in range(plot_period)] if period_frequency == 'quarterly' \
                                else [('M' + str(x)) for x in range(plot_period)]
            trans_macro_data[count].set_index('Period', inplace = True)
            count += 1
    
    scenario_list_length = len(scenario_list)        
    
    # added 02192018: shift to the same starting point
    if shift_to_same_start_point:
        if (scenario_list_length % 2 == 0):
            for i in range(int(scenario_list_length/2)):
                trans_temp = trans_macro_data[i].copy(deep=True)
                for column in trans_macro_data[i].columns:
                    diff = trans_macro_data[i+int(scenario_list_length/2)][column][0] - trans_macro_data[i][column][0]
                    trans_temp[column] = trans_temp[column] + diff
                trans_macro_data[i] = trans_temp
        else:
            raise ValueError('Number of scenario must be even for shifting macro)')    
    
    # save raw data
    pd.concat(trans_macro_data).to_excel(plotSavePath + "rawdata.xlsx")
    
    if scenario_list_length > 8:
            raise ValueError('Number of input scenarios is not within allowable range(1 to 8)')    
    
    # add macro variable description
    print('>>> Adding description for macro variables...')
    if add_description:
        macro_inventory = pd.read_excel(
            io = "I:/CRMPO/CCAR/4Q16/9 - Scenarios/BHC Stress macro selection_20170111.xlsm",
            sheetname = "Macrovariable Inventory"
            )
        macro_inventory = macro_inventory.set_index('Concept')
        macro_inventory = macro_inventory.groupby(macro_inventory.index).first()

    # config for plot (color, shape)
    plot_config = PLOT_CONFIG
    legend_list = LEGEND_LIST
    
    # create plots for transformed macro data and save the figures
    for column in trans_macro_data[0].columns:
        # set plot title
        if add_description:
            plot_title = macro_inventory.loc[column.split('_US')[0], 'Description']
        else:
            plot_title = 'Scenario Trends for %s' % column 
        line_width = 1.5
        
        if period_frequency == 'quarterly':
            if scenario_list_length <= 4:
                legend_loc = -0.05
            else:
                legend_loc = -0.04
        elif period_frequency == 'monthly':
            legend_loc = -0.05

        
        # no title
        # ax = trans_macro_data[0].plot(y = column, color = plot_config[scenario_list[0]][0], linewidth = line_width, linestyle = plot_config[scenario_list[0]][1])
        ax = trans_macro_data[0].plot(y = column, title = plot_title, color = plot_config[legend_list[0]][0], linewidth = line_width, linestyle = plot_config[legend_list[0]][1])
        for i in range(1,scenario_list_length):
                trans_macro_data[i].plot (y = column, ax = ax, color = plot_config[legend_list[i]][0], linewidth = line_width, linestyle = plot_config[legend_list[i]][1])
        ax.legend(legend_list, loc = 'upper center', fontsize = 'xx-small', bbox_to_anchor=(0.5, legend_loc), ncol = 4 if scenario_list_length > 6 else 7, handlelength = 2.8)
        # remove x axis tick
        ax.xaxis.label.set_visible(False)
        
        ax.tick_params(
            axis='both',
            which='both',
            bottom='on',
            top='off',
            left='on',
            right='off',
            labelbottom='on',
            labelleft='on')
        
        ax.yaxis.grid(True)
        
        fig = ax.get_figure()
        # if comparing between different context, file name will be different
        completeContext = cycle1 + '&' + cycle2
        if save_to_file:
            print('>>> Creating macro variables plots for ' + column)
            plot_file = plotSavePath + column + "_" + completeContext + ".png"
            fig.savefig(
                plot_file,
                dpi=300,
                transparent=False
                )  
