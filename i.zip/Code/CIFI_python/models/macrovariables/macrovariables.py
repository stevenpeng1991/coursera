#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
SAMPLE USE

##
## Uploading raw macro data to SQLite
##
uploadMacroVariablesSQLite(
    sqlite_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CCAR_DESK/database/ccar.db',
    sqlite_table_name='MacroVariables',
    csv_file_path='I:/CRMPO/CCAR/4Q15/4 - Models/Wholesale/Macro Data/Strat_Plan_CCAR2016_quarterly_full.csv',
    input_scenario='Base',
    input_title='SP19',
    input_as_of_date=datetime.datetime(2016, 3, 31),
    input_geo_scope='National&Regional', 
    input_frequency='quarterly', 
    input_source='Moodys'
)
###############
ICCAP-Adverse
###############
uploadMacroVariablesSQLite(
    sqlite_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/ccar.db',
    sqlite_table_name='MacroVariables',
    csv_file_path='I:\\CRMPO\\CCAR\\3Q16\\2 - Scenarios\\ICP_Adverse_quarterly_full.csv',
    input_scenario='ICP_Adverse',
    input_title='ICP16',
    input_as_of_book_date=datetime.datetime(2016, 6, 30),
    input_geo_scope='National&Regional', 
    input_frequency='quarterly', 
    input_source='Moodys'
)
uploadMacroVariablesSQLite(
    sqlite_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/ccar.db',
    sqlite_table_name='MacroVariables',
    csv_file_path='I:\\CRMPO\\CCAR\\3Q16\\2 - Scenarios\\ICP_Adverse_FRBBBQ.csv',
    input_scenario='ICP_Adverse',
    input_title='ICP16',
    input_as_of_book_date=datetime.datetime(2016, 6, 30),
    input_geo_scope='National&Regional', 
    input_frequency='quarterly', 
    input_source='Moodys'
)
###############
GCB-SA    
###############
uploadMacroVariablesSQLite(
    sqlite_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/ccar.db',
    sqlite_table_name='MacroVariables',
    csv_file_path='I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI\\docs\\GCB - CCAR 2017\\SA_Scenarios_7_variables_New.csv',
    input_scenario='SA',
    input_title='GCB_SA',
    input_as_of_book_date=datetime.datetime(2016, 6, 30),
    input_geo_scope='National&Regional', 
    input_frequency='quarterly', 
    input_source='Moodys'
)

###############
CRE_TEST   
###############
uploadMacroVariablesSQLite(
    sqlite_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/ccar.db',
    sqlite_table_name='MacroVariables',
    csv_file_path='I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\CRE_Test_Scenario.csv',
    input_scenario='SA',
    input_title='CRE_UAT',
    input_as_of_book_date=datetime.datetime(2016, 6, 30),
    input_geo_scope='National&Regional', 
    input_frequency='quarterly', 
    input_source='Moodys'
)


uploadMacroVariablesSQLite(
    sqlite_file_path='I:/CRMPO/DEPT/Hachuel/CCAR/CIFI/database/ccar.db',
    sqlite_table_name='MacroVariables',
    csv_file_path='I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI\\docs\\GCB - CCAR 2017\\SA_Scenarios_7_variables.csv',
    input_scenario='SA',
    input_title='GCB',
    input_as_of_book_date=datetime.datetime(2016, 6, 30),
    input_geo_scope='National&Regional', 
    input_frequency='quarterly', 
    input_source='Moodys'
)

##
## Connecting to SQLite db file
##
conn = sqlite3.connect('I:/CRMPO/DEPT/Hachuel/CCAR/CCAR_DESK/database/ccar.db')
c = conn.cursor()
c.execute(
)
conn.close()


##
## ScenarioMacroSeries
##
CEVF_macro_vars = ScenarioMacroSeries(
    mv_dict_list=[
        {
            "macro_variable_name": "FLBR_US",
            "lag": 0,
            "transformation_type": "d1y",
            "macro_variables_group": "FLBR_US_d1y"
        },
        {
            "macro_variable_name": "FRBAAC_US",
            "lag": 0,
            "transformation_type": "d1q",
            "macro_variables_group": "bond_spread_lag_diff"
        },
        {
            "macro_variable_name": "FRGT10Y_US",
            "lag": 0,
            "transformation_type": "d1q",
            "macro_variables_group": "bond_spread_lag_diff"
        }
    ],
    mv_group_dict_list=[
        {
            "combination" : "FLBR_US_d1y",
            "operand_1" : "FLBR_US_d1y",
            "operand_2" : None,
            "operator" : None
        },
        {
            "combination" : "bond_spread_lag_diff",
            "operand_1" : "FRBAAC_US_d1q",
            "operand_2" : "FRGT10Y_US_d1q",
            "operator" : "-"
        }
    ],
    mv_as_of_date=datetime.datetime(2006,3,31),
    mv_forecast_periods=50,
    mv_context='DryRun2017',
    mv_scenario='DR_SA',
    mv_geo_scope='National&Regional',
    mv_period_frequency='quarterly',
    debug=False
)
unique_ind = CEVF_macro_vars.getUniqueMacroIndicators()
raw_macro_data = CEVF_macro_vars.fetchSQLiteMacroSeries()
trans_macro_data = CEVF_macro_vars.generateTransformedData()
trans_macro_data

##
## Plotting indicator scenarios
##
CCAR_GDP_p1y_plot_data = plotIndicatorScenarios(
    indicator='FGDPxxx_US',
    context='ICP16',
    geo_scope='National&Regional',
    period_frequency='quarterly',
    as_of_date = datetime.datetime(2015,12,31),
    forecast_periods = 45,
    lag=0,
    transformation_type='p1y'
)


##
## RFO Implementation
##

NORMALIZED VIEW QUERIES ( LOSS TEAM)

Select Data based on Cycle

Select * from MV_MEV_NORMALIZED where cycle='CCAR2016'
Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016'

Select Data based on Cycle and Frequency

Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='MONTHLY'
Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='QUARTERLY'

Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='MONTHLY'
Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='QUARTERLY'

Select Data based on Cycle and Frequency and Scenario

-- Midcycle
Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='MONTHLY' and SCENARIO='MC_BASE'
Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='QUARTERLY' and SCENARIO='MC_BASE'

Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='MONTHLY' and SCENARIO='MC_ADVERSE'
Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='QUARTERLY' and SCENARIO='MC_ADVERSE'

Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='MONTHLY' and SCENARIO='MC_SA'
Select * from MV_MEV_NORMALIZED where cycle='MidCycle2016' and frequency='QUARTERLY' and SCENARIO='MC_SA'

--CCAR 2016
Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='MONTHLY' and SCENARIO='BASE'
Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='QUARTERLY' and SCENARIO='BASE'

Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='MONTHLY' and SCENARIO='FRB_ADVERSE'
Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='QUARTERLY' and SCENARIO='FRB_ADVERSE'

Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='MONTHLY' and SCENARIO='BHC_STRESS'
Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='QUARTERLY' and SCENARIO='BHC_STRESS'

Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='MONTHLY' and SCENARIO='FRB_ADVERSE'
Select * from MV_MEV_NORMALIZED where cycle='CCAR2016' and frequency='QUARTERLY' and SCENARIO='FRB_ADVERSE'

{
   "type":"operation",
   "value":[
      {
         "transformation_type":"mavely_1yd",
         "macro_variable_name":"FGDPxxx_US",
         "lag":0,
         "macro_variables_group":"FGDPxxx_US_mavely_1yd"
      },
      {
         "transformation_type":"p1y",
         "macro_variable_name":"FZFL075035503Q_US",
         "lag":1,
         "macro_variables_group":"FZFL075035503Q_US_p1y_l1q"
      }
   ],
   "model_id":"34 - Scenario Analysis Model - CRE PD - SBNA",
   "name":"macro_variables",
   "version_date":"12/31/2015"
}{
   "type":"operation",
   "value":[
      {
         "combination":"FGDPxxx_US_mavely_1yd",
         "operator":null,
         "operand_2":null,
         "operand_1":"FGDPxxx_US_mavely_1yd"
      },
      {
         "combination":"FZFL075035503Q_US_p1y_l1q",
         "operator":null,
         "operand_2":null,
         "operand_1":"FZFL075035503Q_US_p1y_l1q"
      }
   ],
   "model_id":"34 - Scenario Analysis Model - CRE PD - SBNA",
   "name":"macro_variable_combinations",
   "version_date":"12/31/2015"
}

{
   "type":"operation",
   "value":[
      {
         "transformation_type":"none",
         "macro_variable_name":"FLBR_US",
         "lag":0,
         "macro_variables_group":"FLBR_US"
      },
      {
         "transformation_type":"p1y",
         "macro_variable_name":"FYPEWSQ_US",
         "lag":1,
         "macro_variables_group":"FYPEWSQ_US_p1y_l1q"
      }
   ],
   "model_id":"37 - Scenario Analysis Model - SBB PD - SBNA",
   "name":"macro_variables",
   "version_date":"12/31/2015"
}{
   "type":"operation",
   "value":[
      {
         "combination":"FLBR_US",
         "operator":null,
         "operand_2":null,
         "operand_1":"FLBR_US"
      },
      {
         "combination":"FYPEWSQ_US_p1y_l1q",
         "operator":null,
         "operand_2":null,
         "operand_1":"FYPEWSQ_US_p1y_l1q"
      }
   ],
   "model_id":"37 - Scenario Analysis Model - SBB PD - SBNA",
   "name":"macro_variable_combinations",
   "version_date":"12/31/2015"
}

{
   "value":[
      {
         "transformation_type":"p1y",
         "macro_variable_name":"FLBU_US",
         "lag":4,
         "macro_variables_group":"FLBU_US_p1y_l4q"
      },
      {
         "transformation_type":"d1y",
         "macro_variable_name":"FSP500Q_US",
         "lag":1,
         "macro_variables_group":"FSP500Q_US_d1y_l1q"
      }
   ],
   "name":"macro_variables",
   "type":"operation",
   "industry":"all",
   "model_id":"35 - Scenario Analysis Model - GBM PD - SBNA",
   "version_date":"12/31/2015"
}

#### PLOTTING Scenarios
all_macro_vars = ScenarioMacroSeries(
    mv_dict_list=[
        {
            "macro_variable_name": "FLBR_US",
            "lag": 0,
            "transformation_type": "d1y",
            "macro_variables_group": "FLBR_US_d1y"
        },
        {
            "macro_variable_name": "FRBAAC_US",
            "lag": 0,
            "transformation_type": "d1q",
            "macro_variables_group": "bond_spread_lag_diff"
        },
        {
            "macro_variable_name": "FRGT10Y_US",
            "lag": 0,
            "transformation_type": "d1q",
            "macro_variables_group": "bond_spread_lag_diff"
        },


        {
         "transformation_type":"mavely_1yd",
         "macro_variable_name":"FGDPxxx_US",
         "lag":0,
         "macro_variables_group":"FGDPxxx_US_mavely_1yd"
      },
      {
         "transformation_type":"p1y",
         "macro_variable_name":"FZFL075035503Q_US",
         "lag":1,
         "macro_variables_group":"FZFL075035503Q_US_p1y_l1q"
      },


      {
         "transformation_type":"none",
         "macro_variable_name":"FLBR_US",
         "lag":0,
         "macro_variables_group":"FLBR_US"
      },
      {
         "transformation_type":"p1y",
         "macro_variable_name":"FYPEWSQ_US",
         "lag":1,
         "macro_variables_group":"FYPEWSQ_US_p1y_l1q"
      },


      {
         "transformation_type":"p1y",
         "macro_variable_name":"FLBU_US",
         "lag":4,
         "macro_variables_group":"FLBU_US_p1y_l4q"
      },
      {
         "transformation_type":"d1y",
         "macro_variable_name":"FSP500Q_US",
         "lag":1,
         "macro_variables_group":"FSP500Q_US_d1y_l1q"
      },








        {
            "macro_variable_name": "FGDPxxx_US",
            "lag": 0,
            "transformation_type": "p1y",
            "macro_variables_group": "FGDPxxx_US_p1y"
        },
        {
            "macro_variable_name": "FGDPxxx_US",
            "lag": 3,
            "transformation_type": "p1y",
            "macro_variables_group": "FGDPxxx_US_p1y_l3q"
        },
        {
            "macro_variable_name": "FLBR_US",
            "lag": 2,
            "transformation_type": "d1q",
            "macro_variables_group": "FLBR_US_d1q_l2q"
        }

    ],
    mv_group_dict_list=[
        {
            "combination" : "FLBR_US_d1y",
            "operand_1" : "FLBR_US_d1y",
            "operand_2" : None,
            "operator" : None
        },
        {
            "combination" : "bond_spread_lag_diff",
            "operand_1" : "FRBAAC_US_d1q",
            "operand_2" : "FRGT10Y_US_d1q",
            "operator" : "-"
        },


        {
         "combination":"FGDPxxx_US_mavely_1yd",
         "operator":None,
         "operand_2":None,
         "operand_1":"FGDPxxx_US_mavely_1yd"
      },
      {
         "combination":"FZFL075035503Q_US_p1y_l1q",
         "operator":None,
         "operand_2":None,
         "operand_1":"FZFL075035503Q_US_p1y_l1q"
      },



      {
         "combination":"FLBU_US_p1y_l4q",
         "operator":None,
         "operand_2":None,
         "operand_1":"FLBU_US_p1y_l4q"
      },
      {
         "combination":"FSP500Q_US_d1y_l1q",
         "operator":None,
         "operand_2":None,
         "operand_1":"FSP500Q_US_d1y_l1q"
      },



      {
         "combination":"FLBR_US",
         "operator":None,
         "operand_2":None,
         "operand_1":"FLBR_US"
      },
      {
         "combination":"FYPEWSQ_US_p1y_l1q",
         "operator":None,
         "operand_2":None,
         "operand_1":"FYPEWSQ_US_p1y_l1q"
      },



      {
         "combination":"FGDPxxx_US_p1y",
         "operator":None,
         "operand_2":None,
         "operand_1":"FGDPxxx_US_p1y"
      },
      {
         "combination":"FGDPxxx_US_p1y_l3q",
         "operator":None,
         "operand_2":None,
         "operand_1":"FGDPxxx_US_p1y_l3q"
      },
      {
         "combination":"FLBR_US_d1q_l2q",
         "operator":None,
         "operand_2":None,
         "operand_1":"FLBR_US_d1q_l2q"
      }
    ],
    mv_as_of_date=datetime.datetime(2016,3,31),
    mv_forecast_periods=15,
    mv_context='ICP16',
    mv_scenario='ICP_Adverse',
    mv_geo_scope='National&Regional',
    mv_period_frequency='quarterly'
)
raw_macro_data = all_macro_vars.fetchSQLiteMacroSeries()
trans_macro_data = all_macro_vars.generateTransformedData()
trans_macro_data

"""
import sys
import os
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import datetime
import pandas as pd
import numpy as np
import sqlite3
import cx_Oracle
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem

global TRANSFORM_DICT
TRANSFORM_DICT = {
    'none': lambda x, pf: x,
    'log': lambda x, pf: np.log(x),
    'log1y':lambda x, pf: np.log(x/x.shift(4)),
    'd1m': lambda x, pf: x.diff(1) if pf == 'monthly' else None,
    'p1m': lambda x, pf: x.pct_change(1) if pf == 'monthly' else None,
    'd1q': lambda x, pf: x.diff(1) if pf == 'quarterly' else x.diff(3) if pf == 'monthly' else None,
    'p1q': lambda x, pf: x.pct_change(1) if pf == 'quarterly' else x.pct_change(3) if pf == 'monthly' else None,
    'd2q': lambda x, pf: x.diff(2) if pf == 'quarterly' else x.diff(6) if pf == 'monthly' else None,
    'p2q': lambda x, pf: x.pct_change(2) if pf == 'quarterly' else x.pct_change(6) if pf == 'monthly' else None,
    'd1y': lambda x, pf: x.diff(4) if pf == 'quarterly' else x.diff(12) if pf == 'monthly' else None,
    'p1y': lambda x, pf: x.pct_change(4) if pf == 'quarterly' else x.pct_change(12) if pf == 'monthly' else None,
    'mavely': lambda x, pf: x.rolling(4).mean() if pf == 'quarterly' else x.rolling(
        12).mean() if pf == 'monthly' else None,
    'mavely_1qd': lambda x, pf: (((x / x.shift(1)) ** 4 - 1) * 100).diff(1) if pf == 'quarterly' else None,
    'mavely_1yd': lambda x, pf: (((x / x.shift(1)) ** 4 - 1) * 100).diff(4) if pf == 'quarterly' else None
}

global BINARY_OPERATORS
BINARY_OPERATORS = {
    '+': lambda a, b: a + b,
    '-': lambda a, b: a - b,
    '*': lambda a, b: a * b,
    '/': lambda a, b: a / b
}


class ScenarioMacroSeries:
    """
    ???

    """
    # Properties
    __macro_vars_dict = None
    __group_dict_list = None
    __forecast_periods = None
    __as_of_date = None
    __context = None
    __scenario = None
    __geo_scope = None
    __period_frequency = None
    __SQLite_connection = None
    __raw_macro_data = None
    __transformed_macro_data = None
    __transformed_macro_data_include_t0 = None
    __transformed_macro_data_include_all = None
    __logger = None
    __connection_strings = None
    __connection = None
    __use_RFO = None
    __rfo_environment = None

    def __init__(
        self,
        mv_dict_list,
        mv_group_dict_list,
        mv_as_of_date,
        mv_context,
        mv_scenario,
        mv_geo_scope,
        mv_period_frequency,
        mv_forecast_periods,
        rfo_environment=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
        use_RFO=True,
        logger=None,
        debug=False,
        dataViz=False
    ):
        ##
        ## Validating input variables
        ##
        if logger is not None:
            if isinstance(logger, Logger):
                self.__logger = logger
            else:
                raise TypeError("Input logger is not an instance of Logger.")
        else:
            self.__logger = Logger()

        if isinstance(mv_scenario, str):
            self.__scenario = mv_scenario.strip()
        else:
            raise TypeError('Invalid input mv_scenario type. Expects a str.')

        if isinstance(mv_context, str):
            self.__context = mv_context.strip()
        else:
            raise TypeError('Invalid input mv_context type. Expects a str.')

        utilities.checkDataType(use_RFO, bool)
        utilities.checkDataType(rfo_environment, str)
        utilities.checkDataType(debug, bool)
        self.__rfo_environment = rfo_environment
        self.__use_RFO = use_RFO
        self.debug = debug
        utilities.checkDataType(dataViz, bool)
        self.dataViz = dataViz

        self.__logger.add(
            type='INFO',
            message='Validating input variables...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        # Validating sqlite_file_path
        if self.__use_RFO:
            utilities.checkDataType(self.__rfo_environment, str)
            self.__connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][self.__rfo_environment]
            cx_Oracle_DSN = cx_Oracle.makedsn(
                host=self.__connection_strings["HOST_IP"],
                port=self.__connection_strings["ORACLE_PORT"],
                sid=self.__connection_strings["SID"]
            )
            self.__connection = cx_Oracle.connect(
                user=self.__connection_strings["USER_NAME"],
                password=self.__connection_strings["PASSWORD"],
                dsn=cx_Oracle_DSN
            )
        else:
            if os.path.exists(CONFIG['SQLITE_DB']['FILE_PATH']) & os.path.isfile(CONFIG['SQLITE_DB']['FILE_PATH']):
                self.__SQLite_connection = sqlite3.connect(CONFIG['SQLITE_DB']['FILE_PATH'])
            else:
                raise ValueError('Input <sqlite_file_path> is not reachable or is not a file.')

        # Validating period frequency
        if mv_period_frequency.strip() in ['quarterly', 'monthly']:
            self.__period_frequency = mv_period_frequency.strip()
        else:
            raise ValueError('Input <mv_period_frequency> is not recognized.')

        # Validating input as_of_date
        if self.isValidDate(mv_as_of_date):
            self.__as_of_date = mv_as_of_date

        # Validating macro variables dict list
        if self.isValidDict(
            mv_dict_list,
            template={
                "macro_variable_name": str,
                "lag": int,
                "transformation_type": str,
                "macro_variables_group": str
            },
            customCheckerFunc=self.isValidMacroVariableDict
        ):
            self.__macro_vars_dict = mv_dict_list

        # Validating macro variables combination dict list
        if self.isValidDict(
            mv_group_dict_list,
            template={
                "combination": str,
                "operand_1": str,
                "operand_2": (str, type(None)),
                "operator": (str, type(None))
            },
            customCheckerFunc=self.isValidMacroVariableCombinationDict
        ):
            self.__group_dict_list = mv_group_dict_list

        if self.isValidForecastPeriods(mv_forecast_periods):
            self.__forecast_periods = mv_forecast_periods

        self.__geo_scope = mv_geo_scope.strip()

        self.__list_of_indicators = [item['macro_variable_name'] for item in self.__macro_vars_dict]

        ##
        ## Validating input macro indicators
        ##
        self.__logger.add(
            type='INFO',
            message='Validating input macro variable names...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )
        check_valid_indicators = self.isValidListOfIndicators()
        if check_valid_indicators != True:
            raise ValueError('Invalid input indicators: ' + str(check_valid_indicators))
        else:
            self.__logger.add(
                type='INFO',
                message='Input macro variables have been checked.',
                context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
            )

    def getAsOfDate(self):
        return (self.__as_of_date)

    def getRawMacroData(self):
        return (self.__raw_macro_data)

    def getTransformedMacroData(self):
        return (self.__transformed_macro_data)
        
    def getTransformedMacroDataIncludeT0(self):
        return (self.__transformed_macro_data_include_t0)
    
    def getTransformedMacroDataIncludeAll(self):
        return (self.__transformed_macro_data_include_all)

    def __del__(self):
        """
        Class destroyer. Ensures...
        """
        class_name = self.__class__.__name__
        if self.__use_RFO:
            self.__connection.close()
        else:
            self.__SQLite_connection.close()
        # print(class_name+" destroyed.")

    def isValidMacroTuples(self, some_mv_tuples):
        """
        This function performs...
        -------------------------------------------------------------------------------------------

        Args:
            some_mv_tuples (list<tuples>) : list of macro variables tuples and transformations

        Returns:
            True if all tests pass
        """
        self.__logger.add(
            type='INFO',
            message='Validating input macro tuples...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        if not isinstance(some_mv_tuples, list):
            raise TypeError('Invalid input list macro tuples type. Expects a list of tuples.')
        if len(some_mv_tuples) == 0:
            raise Exception('Input list macro tuples is empty.')
        if sum([isinstance(item, tuple) for item in some_mv_tuples]) != len(some_mv_tuples):
            raise TypeError('Invalid input list macro tuples type. Expects a list of tuples.')
        if sum([len(item) == 4 for item in some_mv_tuples]) != len(some_mv_tuples):
            raise ValueError('Invalid length of input tuples. Expects 3-element tuples.')
        if sum([isinstance(item[0], str) for item in some_mv_tuples]) != len(some_mv_tuples):
            raise TypeError('Invalid tuple[0]. Expects a str.')
        if sum([isinstance(item[1], int) for item in some_mv_tuples]) != len(some_mv_tuples):
            raise TypeError('Invalid tuple[1]. Expects a int.')
        if sum([isinstance(item[2], str) for item in some_mv_tuples]) != len(some_mv_tuples):
            raise TypeError('Invalid tuple[2]. Expects a str.')
        if sum([isinstance(item[3], str) for item in some_mv_tuples]) != len(some_mv_tuples):
            raise TypeError('Invalid tuple[3]. Expects a str.')

        if self.__period_frequency == 'quarterly':
            if sum([((item[1] >= -8) and (item[1] <= 8)) for item in some_mv_tuples]) != len(some_mv_tuples):
                raise ValueError('Input lag is not within allowable range. -8 to 8 for quarterly frequencies.')
        elif self.__period_frequency == 'monthly':
            if sum([((item[1] >= -24) and (item[1] <= 24)) for item in some_mv_tuples]) != len(some_mv_tuples):
                raise ValueError('Input lag is not within allowable range. -24 to 24 for monthly frequencies.')

        if sum([item[2] in TRANSFORM_DICT.keys() for item in some_mv_tuples]) != len(some_mv_tuples):
            raise ValueError('Input transformation types is not recognized.')

        return (True)

    def isValidMacroVariableDict(self, some_mv_dict_list):
        self.__logger.add(
            type='INFO',
            message='Validating input macro variables dictionary...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        if self.__period_frequency == 'quarterly':
            if sum([((item['lag'] >= -8) and (item['lag'] <= 8)) for item in some_mv_dict_list]) != len(
                    some_mv_dict_list):
                raise ValueError('Input lag is not within allowable range. -8 to 8 for quarterly frequencies.')
        elif self.__period_frequency == 'monthly':
            if sum([((item['lag'] >= -24) and (item['lag'] <= 24)) for item in some_mv_dict_list]) != len(
                    some_mv_dict_list):
                raise ValueError('Input lag is not within allowable range. -24 to 24 for monthly frequencies.')

        if sum([item['transformation_type'] in TRANSFORM_DICT.keys() for item in some_mv_dict_list]) != len(
                some_mv_dict_list):
            raise ValueError('Input transformation_type types is not recognized.')

        return (True)

    def isValidMacroVariableCombinationDict(self, some_mv_dict_list):
        # Pending...
        return (True)

    def isValidDict(self, some_mv_dict_list, template, customCheckerFunc=None):
        self.__logger.add(
            type='INFO',
            message='Validating some input dictionary...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        # Check types and non-emptyness
        if not isinstance(some_mv_dict_list, list):
            raise TypeError('Invalid input list macro dictionaries type. Expects a list of dicts.')
        if len(some_mv_dict_list) == 0:
            raise Exception('Input list macro dictionaries is empty.')
        if sum([isinstance(item, dict) for item in some_mv_dict_list]) != len(some_mv_dict_list):
            raise TypeError('Invalid input list macro dictionaries type. Expects a list of dicts.')

        # Check dictionary keys
        key_set = set(template.keys())
        if sum([(set(item.keys()) == key_set) for item in some_mv_dict_list]) != len(some_mv_dict_list):
            raise KeyError('Missing keys in input dictionary list. Complete list of keys is : ' + str(key_set))

        # Check data types
        if sum([isinstance(item[typecheck], template[typecheck]) for item in some_mv_dict_list for typecheck in
                template]) != len(some_mv_dict_list) * len(template):
            raise TypeError('Types in list of dictionaries DO NOT match provided template.')

        if (customCheckerFunc is None):
            return (True)
        else:
            return (customCheckerFunc(some_mv_dict_list))

    def isValidForecastPeriods(self, some_forecast_periods):
        self.__logger.add(
            type='INFO',
            message='Validating input forecast periods ' + str(some_forecast_periods) + '...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        if isinstance(some_forecast_periods, int):
            # update for data visualization: change upper bound to 200 if doing data visualization
            if self.dataViz & (some_forecast_periods >= 0) & (some_forecast_periods <= 200):
                return (True)
            elif self.dataViz:
                raise ValueError('Input forecast periods is out of range for data visualization. Range is 0 to 200, inclusive.')
            elif (some_forecast_periods >= 0) & (some_forecast_periods <= 132):
                return (True)
            else:
                raise ValueError('Input forecast periods is out of range. Range is 0 to 132, inclusive.')
        else:
            raise TypeError('Input <mv_forecast_periods> is of the wrong data type. Expects type <int>.')

    def isValidDate(self, some_date):
        """
        This function validates corrext data type and range for as_of_date.
        Date ranges have been defined between the years 2000 and 2050.
        """
        self.__logger.add(
            type='INFO',
            message='Validating input date ' + str(some_date) + '...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        if isinstance(some_date, datetime.datetime):
            if (some_date >= datetime.datetime(2000, 1, 1)) & (some_date <= datetime.datetime(2050, 1, 1)):
                return (True)
            else:
                raise ValueError('Input date is out of range.')
        else:
            raise TypeError('Invalid input date type. Use datetime.datetime instance.')

    def getUniqueMacroIndicators(self):
        self.__logger.add(
            type='INFO',
            message='Getting unique macro indicators...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        if self.__use_RFO:
            cursor = self.__connection.cursor()
            query = """
                SELECT DISTINCT
                    MEV.INDICATOR
                FROM
                    @table_name MEV
                WHERE
                    UPPER(MEV.SCENARIO) = UPPER('@scenario')
                    AND
                    UPPER(MEV.CYCLE) = UPPER('@context')
                    AND
                    UPPER(MEV.GEOGRAPHYSCOPE) = UPPER('@geo_scope')
                    AND
                    UPPER(MEV.FREQUENCY) = UPPER('@period_frequency')
            """
            rfo_table_name = self.__connection_strings["SCHEMA_NAME"]+\
                             "."+\
                             CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['TABLE_NAMES']['MACRO_SERIES']
            query = query.replace('@table_name', rfo_table_name)
            if self.__geo_scope == "National&Regional":
                query = query.replace('@geo_scope', 'US')
            else:
                query = query.replace('@geo_scope', self.__geo_scope)
            query = query.replace('@scenario', self.__scenario)
            query = query.replace('@context', self.__context)
            query = query.replace('@period_frequency', self.__period_frequency)
            if self.debug:
                print(query)
            cursor.execute(query)
            response_data = pd.DataFrame(
                cursor.fetchall(),
                columns=[item[0] for item in cursor.description]
            )
        else:
            query = """
                SELECT DISTINCT
                    @table_name.Indicator
                FROM
                    @table_name
                WHERE
                    @table_name.Scenario = '@scenario'
                    AND
                    @table_name.Title='@context'
                    AND
                    @table_name.GeographicalScope = '@geo_scope'
                    AND
                    @table_name.Frequency = '@period_frequency'
                    AND
                    @table_name.Period >= @table_name.AsOfBookDate
            """
            query = query.replace('@table_name', CONFIG['SQLITE_DB']['MACRO_VARIABLES_TABLE_NAME'])
            query = query.replace('@scenario', self.__scenario)
            query = query.replace('@geo_scope', self.__geo_scope)
            query = query.replace('@context', self.__context)
            query = query.replace('@period_frequency', self.__period_frequency)
            if self.debug:
                print(query)
            response_data = pd.read_sql_query(query, self.__SQLite_connection)

        # Return results
        return (list(response_data[response_data.columns[0]]))

    def isValidIndicator(self, some_indicator):
        self.__logger.add(
            type='INFO',
            message='Validating indicator ' + str(some_indicator) + '...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )
        return (some_indicator in self.getUniqueMacroIndicators())

    def isValidListOfIndicators(self):
        self.__logger.add(
            type='INFO',
            message='Validating list of indicators...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        list_of_distinct_indicators = self.getUniqueMacroIndicators()

        bin_counter = True
        for indicator in self.__list_of_indicators:
            if indicator not in list_of_distinct_indicators:
                bin_counter = False

        if bin_counter == False:
            return ([indicator + ' -> ' + str(indicator in list_of_distinct_indicators) for indicator in
                     self.__list_of_indicators])
        else:
            return (True)

    def fetchSQLiteMacroSeries(self, return_data=True):
        self.__logger.add(
            type='INFO',
            message='Fetching macro series...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        if self.__use_RFO:
            cursor = self.__connection.cursor()
            query = """
                SELECT DISTINCT
                    MEV.PERIOD_END_DATE AS "Period",
                    MEV.INDICATOR AS "Indicator",
                    MEV.VALUE AS "Value"
                FROM
                    @table_name MEV
                WHERE
                    UPPER(MEV.SCENARIO) = UPPER('@scenario')
                    AND
                    UPPER(MEV.CYCLE) = UPPER('@context')
                    AND
                    UPPER(MEV.GEOGRAPHYSCOPE) = UPPER('@geo_scope')
                    AND
                    UPPER(MEV.FREQUENCY) = UPPER('@period_frequency')
                    AND
                    UPPER(MEV.INDICATOR) IN @macro_var_list
            """
            rfo_table_name = self.__connection_strings["SCHEMA_NAME"] + \
                             "." + \
                             CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['TABLE_NAMES']['MACRO_SERIES']
            query = query.replace('@table_name', rfo_table_name)
            if self.__geo_scope == "National&Regional":
                query = query.replace('@geo_scope', 'US')
            else:
                query = query.replace('@geo_scope', self.__geo_scope)
            query = query.replace('@scenario', self.__scenario)
            query = query.replace('@context', self.__context)
            query = query.replace('@period_frequency', self.__period_frequency)
            query = query.replace(
                '@macro_var_list',
                str(self.__list_of_indicators).replace('[', '(').replace(']', ')')
            )
            if self.debug:
                print(query)
            cursor.execute(query)
            response_data = pd.DataFrame(
                cursor.fetchall(),
                columns=[item[0] for item in cursor.description]
            )
            if self.debug:
                print(response_data.head(5))
        else:
            query = """
                SELECT
                    @table_name.Period,
                    @table_name.Indicator,
                    @table_name.Value
                FROM
                    @table_name
                WHERE
                    @table_name.Scenario = '@scenario'
                    AND
                    @table_name.Title='@context'
                    AND
                    @table_name.Indicator IN @macro_var_list
                    AND
                    @table_name.GeographicalScope = '@geo_scope'
                    AND
                    @table_name.Frequency = '@period_frequency'
                """
            query = query.replace('@scenario', self.__scenario)
            query = query.replace('@context', self.__context)
            query = query.replace('@geo_scope', self.__geo_scope)
            query = query.replace('@period_frequency', self.__period_frequency)
            query = query.replace('@table_name', CONFIG['SQLITE_DB']['MACRO_VARIABLES_TABLE_NAME'])
            query = query.replace(
                '@macro_var_list',
                str(self.__list_of_indicators).replace('[', '(').replace(']', ')')
            )

            response_data = pd.read_sql_query(query, self.__SQLite_connection)

        # Override Period data type
        response_data.Period = pd.to_datetime(response_data.Period)

        # Check if data is empty
        self.__logger.add(
            type='INFO',
            message='Checking for non-empty macro series data...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )
        if response_data.empty:
            raise Exception('Macro series data came back empty. Check input parameters.')

        # Check if there are enough forecast periods
        self.__logger.add(
            type='INFO',
            message='Checking sufficient forecast periods in macro series...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )
        periods_count = response_data[response_data.Period >= self.__as_of_date].groupby('Indicator')['Period'].count()
        bin_counter = True
        for indicator in self.__list_of_indicators:
            if periods_count[indicator] < self.__forecast_periods:
                bin_counter = False
                self.__logger.add(
                    type='WARN',
                    message=indicator + ' does NOT have enough forecast periods.',
                    context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
                )
        if not bin_counter:
            raise Exception('Insufficient number of forecast periods for some input macro variables.')

        # Return data
        self.__logger.add(
            type='INFO',
            message='Fetching macro series completed.',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )
        self.__raw_macro_data = response_data
        if return_data:
            return (response_data)
        return (True)

    def transformSeries(self, series, lag=0, transformation_type='none'):
        self.__logger.add(
            type='INFO',
            message='Transforming macro series ' + series.name + ' with lag [' + str(
                lag) + '] and tranformation type [' + transformation_type + ']...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        # Check data type for Pandas Series object
        utilities.checkDataType(series, pd.core.series.Series)

        # Process transform
        transformed_series = TRANSFORM_DICT[transformation_type](series, self.__period_frequency).shift(lag)

        # Update mnemonic
        transformed_series.name = generateMnemonic(
            default_name=series.name,
            lag=lag,
            transformation_type=transformation_type,
            period_frequency=self.__period_frequency
        )

        # Return results
        return (transformed_series)

    def generateTransformedData(self, return_data=True, truncate_result=True):
        self.__logger.add(
            type='INFO',
            message='Generating transformed data...',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )

        if self.__raw_macro_data is None:
            self.fetchSQLiteMacroSeries()

        data_wide = self.__raw_macro_data.pivot(
            index='Period',
            columns='Indicator',
            values='Value'
        )

        series_container = []
        for item in self.__macro_vars_dict:
            # Add transformed series
            series_container.append(self.transformSeries(
                series=data_wide[item['macro_variable_name']],
                lag=item['lag'],
                transformation_type=item['transformation_type']
            ))

            # Add raw/untransformed series
            if item['macro_variable_name'] not in [series.name for series in series_container]:
                series_container.append(data_wide[item['macro_variable_name']])

        # Return concatenated data
        result = pd.concat(series_container, axis=1)

        # Truncate results if specified
        if truncate_result:
            result1 = result[result.index > self.__as_of_date].ix[0:self.__forecast_periods]
            result2 = result[result.index >= self.__as_of_date].ix[0:self.__forecast_periods]
            result3 = result[result.index >= self.__as_of_date].ix[0:self.__forecast_periods + 1]
        self.__transformed_macro_data = result1
        self.__transformed_macro_data_include_t0 = result2
        self.__transformed_macro_data_include_all = result3

        # Process group combinations
        for group in self.__group_dict_list:
            if (group['operator'] is not None) & (group['operand_2'] is not None):
                self.__transformed_macro_data[group['combination']] = BINARY_OPERATORS[group['operator']](
                    self.__transformed_macro_data[group['operand_1']],
                    self.__transformed_macro_data[group['operand_2']]
                )
            if (group['operator'] is not None) & (group['operand_2'] is not None):
                self.__transformed_macro_data_include_t0[group['combination']] = BINARY_OPERATORS[group['operator']](
                    self.__transformed_macro_data_include_t0[group['operand_1']],
                    self.__transformed_macro_data_include_t0[group['operand_2']]
                )
            if (group['operator'] is not None) & (group['operand_2'] is not None):
                self.__transformed_macro_data_include_all[group['combination']] = BINARY_OPERATORS[group['operator']](
                    self.__transformed_macro_data_include_all[group['operand_1']],
                    self.__transformed_macro_data_include_all[group['operand_2']]
                )

        # Return resutls
        self.__logger.add(
            type='INFO',
            message='Data transformation completed.',
            context='Scenario Macro Series for ' + self.__context + ' ' + self.__scenario
        )
        if return_data:
            return (result1)
        return (True)


def generateMnemonic(default_name, lag, period_frequency, transformation_type='none'):
    """
    This function returns the mnemonic/name of a macro economic indicator

    Parameters
    ----------
    default_name (str) : macro variable/indicator raw name
    lag (int) : discrete number of lags, >0 for lag, <0 for lead
    transformation_type (str) : needs to be a valid transformation type
    period_frequency (str) : `monthly`, `quarterly` or `yearly`

    Returns
    -------
    (str) : the mnemonic/name of the transformed variable

    """
    if not isinstance(default_name, str):
        raise TypeError('Input [default_name] is not of type str.')
    if not isinstance(lag, int):
        raise TypeError('Input [lag] is not of type int.')
    if not isinstance(transformation_type, str):
        raise TypeError('Input [transformation_type] is not of type str.')
    if not isinstance(period_frequency, str):
        raise TypeError('Input [period_frequency] is not of type str.')

    if period_frequency[0] not in ['m', 'q', 'y']:
        raise ValueError("Input [period_frequency] seems to be invalid. Check again.")

    if transformation_type not in TRANSFORM_DICT .keys():
        raise ValueError("Input [transformation_type] seems to be invalid. Check again.")

    if lag<0:
        lag_name = '_f' + str(np.absolute(lag)) + period_frequency[0]
    elif lag>0:
        lag_name = '_l' + str(np.absolute(lag)) + period_frequency[0]
    else:
        lag_name = ''

    if transformation_type in ['','none','None']:
        transformation_name = ''
    else:
        transformation_name = '_' + transformation_type
        
    return(default_name + transformation_name + lag_name)

def plotIndicatorScenarios(
    indicator,
    context,
    geo_scope,
    period_frequency,
    as_of_date=None,
    forecast_periods=None,
    lag=0,
    transformation_type='none',
    return_data=True,
    save_to_file=None
):
    # Process sqlite query with input parameters
    query = """
        SELECT
            @table_name.Period,
            @table_name.Indicator,
            @table_name.Scenario,
            @table_name.Value
        FROM
            @table_name
        WHERE
            @table_name.Title='@context'
            AND
            @table_name.Indicator = '@indicator'
            AND
            @table_name.GeographicalScope = '@geo_scope'
            AND
            @table_name.Frequency = '@period_frequency'
        """
    query = query.replace('@indicator',indicator)
    query = query.replace('@context',context)
    query = query.replace('@geo_scope',geo_scope)
    query = query.replace('@period_frequency',period_frequency)
    query = query.replace('@table_name',CONFIG['SQLITE_DB']['MACRO_VARIABLES_TABLE_NAME'])

    # Initialize sqlite3 connection, run query and fetch results
    print('>>> Fetching raw macro series...')
    sqlite_conn = sqlite3.connect(CONFIG['SQLITE_DB']['FILE_PATH'])
    response_data = pd.read_sql_query(query, sqlite_conn)
    response_data.Period=pd.to_datetime(response_data.Period)
    response_data_pvt = round(response_data.pivot(index='Period',columns='Scenario',values='Value'),10)

    # Transform data given input specs
    series_container = []
    for scenario in response_data_pvt.columns:
        series_container.append(
            TRANSFORM_DICT[transformation_type](response_data_pvt[scenario], period_frequency).shift(lag)
        )
    response_data_pvt_transformed = pd.concat(series_container, axis=1)

    # Truncate data for as_of_date and forecast_periods if vars provided
    if (as_of_date is not None) & (forecast_periods is not None):
        response_data_final = response_data_pvt_transformed[
            response_data_pvt_transformed.index>=utilities.addMonths2date(as_of_date,-3)
        ].ix[0:forecast_periods+2]
    else:
        response_data_final = response_data_pvt_transformed

    # Plot final pivoted dataframe
    plot_title = 'Scenario Trends for '+indicator+', Lag ['+str(lag)+'], Transformation ['+transformation_type+']'
    ax = response_data_final.plot(grid=False, title=plot_title, style='-') # type <matplotlib.AxesSubplot>
    fig = ax.get_figure() # type <matplotlib.figure.Figure>
    if save_to_file is not None:
        fig.savefig(
            save_to_file,
            dpi=300,
            transparent=False
        )

    # Return data
    if return_data:
        return(response_data_final)

def preProcessMacroVariables(
    csv_file_path, 
    input_scenario, 
    input_title, 
    input_as_of_book_date,
    input_geo_scope, 
    input_frequency, 
    input_source
):
    """
    This function pre-processess and cleans scenario data:
    -> converts string periods into datetime.datetime instances
    -> transforms scenario from wide to long format
    -> adds important reference/description fields
    -----------------------------------------------------------------------

    Args
    ----
        csv_file_path (str) : full path to the raw scenario csv file
        input_scenario (str) : name of the scenario
        input_title (str) : scenario title, examples: EBA, SP19, CCAR2016
        input_as_of_date (datetime.datetime) : as-of-book date, i.e. 2015-12-31 for CCAR2016
        input_geo_scope (str) : geographic extent of macro variables, i.e. National&Regional, State
        input_frequency (str) : value frequency, quarterly, monthly, yearly
        input_source (str) : data source, example: Moodys, internal, etc...

    Returns
    -------
        (long_data) : returns a Pandas DataFrame with the scenario in long format
    """
    # Check input date type
    if not isinstance(input_as_of_book_date, datetime.datetime):
        raise TypeError('Wrong input as_of_date type. Use datetime.datetime instance.')                
    
    # Read csv file from input path
    wide_data = pd.read_csv(filepath_or_buffer=csv_file_path)
    
    # Convert period datetime.datetime
    wide_data['Period'] = wide_data['Period'].apply(utilities.YYYYQ2Date)    
    
    # Transform data from wide to long format
    long_data = pd.melt(
        frame=wide_data, 
        id_vars=['Period'],
        var_name='Indicator',
        value_name='Value'    
    )
    
    # Add important description fields
    long_data['Scenario'] = input_scenario
    long_data['Title'] = input_title
    long_data['AsOfBookDate'] = input_as_of_book_date
    long_data['GeographicalScope'] = input_geo_scope
    long_data['Frequency'] = input_frequency
    long_data['Source'] = input_source
    
    # Return data
    return(long_data)
    
def uploadMacroVariablesSQLite(
    sqlite_file_path,
    sqlite_table_name,
    csv_file_path, 
    input_scenario, 
    input_title, 
    input_as_of_book_date,
    input_geo_scope, 
    input_frequency, 
    input_source
):
    """
    This function pre-processess, cleans scenario data and insert data into SQLitedb:
    -> converts string periods into datetime.datetime instances
    -> transforms scenario from wide to long format
    -> adds important reference/description fields
    -> writes data to SQLite data store
    -----------------------------------------------------------------------

    Args
    ----
        sqlite_file_path (str) : full path to SQLite db file
        sqlite_table_name (str) : SQLite table name for macro variables
        csv_file_path (str) : full path to the raw scenario csv file
        input_scenario (str) : name of the scenario
        input_title (str) : scenario title, examples: EBA, SP19, CCAR2016
        input_as_of_date (datetime.datetime) : as-of-book date, i.e. 2015-12-31 for CCAR2016
        input_geo_scope (str) : geographic extent of macro variables, i.e. National&Regional, State
        input_frequency (str) : value frequency, quarterly, monthly, yearly
        input_source (str) : data source, example: Moodys, internal, etc...

    Returns
    -------
        (macro_variables) : returns a Pandas DataFrame with the scenario in long format
    """
    # Fetch pre-processed macro variables
    macro_variables = preProcessMacroVariables(
        csv_file_path=csv_file_path,
        input_scenario=input_scenario,
        input_title=input_title,
        input_as_of_book_date=input_as_of_book_date,
        input_geo_scope=input_geo_scope, 
        input_frequency=input_frequency, 
        input_source=input_source
    )

    # Insert macro variable data into SQLite data store
    macro_variables.to_sql(
        name=sqlite_table_name,
        con=sqlite3.connect(sqlite_file_path), 
        flavor='sqlite',
        if_exists='append',
        index=False
    )
    
    # Return macro variable data
    return(macro_variables)
    
    
    































