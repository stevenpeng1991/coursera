"""
mp = ModelProperties(
	model_id = '37 - Scenario Analysis Model - SBB PD - SBNA',
	version_date=datetime.datetime(2016,12,31)
)

mp.getParameters(type='property',name='model_segment')

all = mp.getAll()

all_with_date = mp.getAllPropertiesWithVersionDate(version_date = datetime.datetime(2016,12,31))

mp.dupAllPropertiesWithDiffVersionDate(new_version_date=datetime.datetime(2017,3,31), old_version_date=datetime.datetime(2016,12,31), only_current_model_id = False)

all_new = mp.getAll()


mp = ModelProperties(
	model_id = '35 - Scenario Analysis Model - GBM PD - SBNA',
	version_date=datetime.datetime(2015,12,31)
)
industry_name = 'oil'
mp.getParameters(type='property',name='historical_transition_matrix', industry=industry_name)


mp = ModelProperties(
	model_id = '743 - Commercial Rating Model - C&I PD - SBNA',
	version_date=datetime.datetime(2016,6,30)
)
lop = mp.listOfProperties()
mp.getParameters(type='property',name='model_segment')


# ------
# INSERT
# ------
# Validate path_to_model_properties for TinyDB usage
path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties)


for item in to_insert:
    db.insert(item)
    
    
unique_model_id = list(
	pd.core.series.Series(
		[item['model_id'] for item in db.search(Query().model_id.exists())]
	).unique()
)
for model in unique_model_id:
	db.insert(
		{
			'model_id': model,
			 'name': 'scenario_period_frequency',
			 'type': 'property',
			 'value': 'quarterly',
			 'version_date': '12/31/2015'
		}
	)

--------------
logit_model_id_dict = {
	'34 - Scenario Analysis Model - CRE PD  - SBNA':'PD_23',
	'37 - Scenario Analysis Model - SBB PD - SBNA':'PD_38',
	'53 - Scenario Analysis Model - CEVF PD - SBNA':'PD_13'
}
for model_id in logit_model_id_dict.keys():
	db.insert(
		{
			'model_id': model_id,
			 'name': 'model_segment',
			 'type': 'property',
			 'value': logit_model_id_dict[model_id],
			 'version_date': '12/31/2015'
		}
	)
 
 
MRMG_ID={
            '25 - Scenario Analysis Model - Mortgage Vintage LGD - SBNA'
            '26 - Scenario Analysis Model - Mortgage Vintage PD - SBNA'
            '34 - Scenario Analysis Model - CRE PD  - SBNA'
            '35 - Scenario Analysis Model - GBM PD - SBNA'
            '37 - Scenario Analysis Model - SBB PD - SBNA'
            '44 - Scenario Analysis Model - HELOC Vintage LGD - SBNA'
            '46 - Scenario Analysis Model - HELOC Vintage PD - SBNA'
            '53 - Scenario Analysis Model - CEVF PD - SBNA'
            '721 - Commercial Rating Model - CRE Multifamily PD - SBNA'
            '742 - Commercial Rating Model CRE General PD - SBNA'
            '743 - Commercial Rating Model - C&I PD - SBNA'
            '1042 - Mortgage PD Model - SBNA'
            '1043 - Mortgage LGD Model - SBNA'
            '1044 - HELOC PD - SBNA'
            '1045 - HELOC LGD Model - SBNA'
}
##################################
delete
##################################
#from tinydb.operations import delete
from tinydb import TinyDB, where
db.remove(where('segment')=='occ')

##################################
search
##################################
db.search((Query().model_id=='721 - Commercial Rating Model - CRE Multifamily PD - SBNA') & (Query().type=='operation') &(Query().name=='macro_variable_combinations'))
db.search(Query().model_id=='35 - Scenario Analysis Model - GBM PD - SBNA')
db.search((Query().model_id=='2016-SBNA-Loss-Commercial-CRE') &(Query().version_date=='12/31/2016'))

db.search((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='lgd_scale'))
.getParameters(
                            type='property',
                            name='alll_coverage',
                            industry=industryname
                        )[0]
db.search((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='alll_coverage'))                        
db.search((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='6/31/2016')&(Query().name=='lgd_scale'))
##################################
Update
##################################
db.update({
'value': [{'rating_group_1':0.0019472690806645,
'rating_group_2':0.0019472690806645,
'rating_group_3':0.00210943050545718,
'rating_group_4':0.0025009029609753,
'rating_group_5':0.0109639862172853,
'rating_group_6':0.0375469945716865,
'rating_group_7':0.128680645164604,
'rating_group_8':0.219814295757521,
'rating_group_9':0.45}]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='09/30/2017')&(Query().name=='alll_coverage')))

db.update({
'value': [{'rating_group_1':0.000925401568520687,
'rating_group_2':0.000925401568520687,
'rating_group_3':0.000908910343651423,
'rating_group_4':0.00124687136461149,
'rating_group_5':0.0115402084500396,
'rating_group_6':0.0282508840503342,
'rating_group_7':0.0447371605657248,
'rating_group_8':0.0612234370811154,
'rating_group_9':0.280108555866787}]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='09/30/2017')&(Query().name=='contingent_reserve')))
    

CCAR R1
db.update({
'value': [{'rating_group_1':0.00199819924687155,
'rating_group_2':0.00305601036380017,
'rating_group_3':0.0093360747008716,
'rating_group_4':0.0177332245491192,
'rating_group_5':0.0177332245491192,
'rating_group_6':0.104824039178035,
'rating_group_7':0.104824039178035,
'rating_group_8':0.104824039178035,
'rating_group_9':1}]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='alll_coverage')))

db.update({
'value': [{
    'rating_group_1': 0.00195505239820618,
    'rating_group_2': 0.00377532465762294,
    'rating_group_3': 0.00883419839378367,
    'rating_group_4': 0.0273960066099318,
    'rating_group_5': 0.0273960066099318,
    'rating_group_6': 0.0628261806209023,
    'rating_group_7': 0.0628261806209023,
    'rating_group_8': 0.0628261806209023,
    'rating_group_9': 1}]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='contingent_reserve')))

##################################
CCAR R1 Adjustment
##################################
db.update({
'value': [
          {
          'rating_group_1': 0.00176896805752849,
          'rating_group_2': 0.00176896805752849,
          'rating_group_3': 0.00176896805752849,
          'rating_group_4': 0.00265421198658557,
          'rating_group_5': 0.00653703336970459,
          'rating_group_6': 0.00653703336970459,
          'rating_group_7': 0.00653703336970459,
          'rating_group_8': 0.104824039178035,
          'rating_group_9': 1
          }
        ]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='alll_coverage')))

db.update({
'value': [{
    'rating_group_1': 0,
    'rating_group_2': 0.0016420031382933,
    'rating_group_3': 0.00199330525161995,
    'rating_group_4': 0.00255004492422892,
    'rating_group_5': 0.00921542130241626,
    'rating_group_6': 0.00921542130241626,
    'rating_group_7': 0.00921542130241626,
    'rating_group_8': 0.0628261806209023,
    'rating_group_9': 1
    }]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='contingent_reserve')))

db.update({
'value': [{'ConsumerAndIndustrial_RoW': {'lgd_secured_scaling': 0.9661599594226048,
  'lgd_unsecured_scaling': 0.97515653050652717},
 'ConsumerAndIndustrial_USCAN': {'lgd_secured_scaling': 0.96368894751979195,
  'lgd_unsecured_scaling': 0.97304276437446335},
 'Finance_RoW': {'lgd_secured_scaling': 0.84803816760526152,
  'lgd_unsecured_scaling': 0.88161557311571259},
 'Finance_USCAN': {'lgd_secured_scaling': 0.94757953325506206,
  'lgd_unsecured_scaling': 0.96022906993464263},
 'OilAndGas_Global': {'lgd_secured_scaling': 0.87576415064705915,
  'lgd_unsecured_scaling': 0.90423786478220414}}]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='lgd_scale')))

db.update({
'value': [{'ConsumerAndIndustrial_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'ConsumerAndIndustrial_USCAN':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_RoW':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'Finance_USCAN': 
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0},
           'OilAndGas_Global':
                  {'lgd_secured_scaling': 0,
                   'lgd_unsecured_scaling': 0}
         }]},((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') &(Query().version_date=='12/31/2016')&(Query().name=='lgd_scale')))


##################################
List of Macros
##################################

list_of_model=list(
                pd.core.series.Series(
                                [item['model_id'] for item in db.search((Query().model_id.exists())&(Query().version_date=='12/31/2016'))]
                ).unique()
)

list_of_version=list(
                pd.core.series.Series(
                                [item['version_date'] for item in db.search(Query().model_id.exists())]
                ).unique()
)

list_of_model=[
 '37 - Scenario Analysis Model - SBB PD - SBNA',
 '53 - Scenario Analysis Model - CEVF PD - SBNA',
 '2016-SBNA-Loss-Commercial-CRE',
 '2016-SBNA-Loss-Commercial-GCB',
 '2016-SBNA-Loss-Commercial-CREConstruction',
 '743 - Commercial Rating Model - C&I PD - SBNA']
 
macrovariables_list={}
for model in list_of_model:
  macrovariables_list[model]=list(
                pd.core.series.Series([item['macro_variable_name'] for item in segment['value']] for segment in   db.search((Query().version_date=='12/31/2016')&(Query().name=='macro_variables')&(Query().model_id==model))))

values=[]
for key in macrovariables_list:
  values.append(macrovariables_list[key][0])
unique=set([item for sublist in values for item in sublist])





"""

import sys
import os
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import datetime
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from tinydb import TinyDB, Query
import pandas as pd
from json import JSONDecodeError


# Exception handling
class NotConnectError(Exception):
    pass

class ModelProperties:
	"""
	Use TinyDB to get industry parameters including:
		- Industry Transition matrixes
		- Industry Alll Coverage
		- Industry Asset Correlation
	"""

	# Class properties
	__path_to_model_properties = None
	__db = None
	__model_id = None
	__version_date = None
	__logger = None
	__params = None

	# Class methods
	def __init__(self, model_id, version_date, logger=None, path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']):
		# Process logger
		if logger is not None:
			if isinstance(logger, Logger):
				self.__logger = logger
			else:
				raise TypeError("Input logger is not an instance of Logger.")
		else:
			self.__logger = Logger()

		self.__logger.add(
			type='INFO',
			message='Initializing model properties db connection...',
			context='Model Properties',
			model_id=model_id
		)
		# Validate path_to_model_properties for TinyDB usage
           # Trying to connect ot tinyDB
		self.__logger.add(
			type='INFO',
			message='Validating path to model properties...',
			context='Model Properties',
			model_id=model_id
		)
		if os.path.exists(path_to_model_properties) & os.path.isfile(path_to_model_properties):
			self.__path_to_model_properties = path_to_model_properties
			try:
				self.__db = TinyDB(self.__path_to_model_properties)
			except JSONDecodeError:
				raise JSONDecodeError('Input JSON file is not valid JSON file.')
		else:
                 wrong_msg = "make sure your JSON file in" + path_to_model_properties
                 raise NotConnectError('Input JSON file does not exist or is not reachable.'+wrong_msg)

		# Validate input model_id
		if self.isValidModelID(some_model_id=model_id):
			self.__model_id = model_id

		# Validate input version_date, get query result at same time
		if isinstance(version_date, datetime.datetime):
			if self.isValidVersionDate(
				version_date=version_date,
				model_id=model_id
			):
				self.__version_date = version_date
		else:
			raise TypeError("Input `version_date` is not datetime.")

		self.__logger.add(
			type='INFO',
			message='ModelProperties instance ready for use!',
			context='Model Properties',
			model_id=self.__model_id)

	def __del__(self):
		if self.__db is None:
			raise NotConnectError('TinyDB is not connected.')				
		print("NOTE: Closing TinyDB connection instance...")
		self.__db.close()
	
	@property
	def version_date(self):
		return (self.__version_date)

	@property
	def path_to_model_properties(self):
		return (self.__path_to_model_properties)

	@property
	def model_id(self):
		return (self.__model_id)

	@property
	def db(self):
		return (self.__db)

	@property
	def logger(self):
		return(self.__logger)

	def getAll(self):
		"""
        This method returns all properties for all models.
        :return: (list) of all properties
        """
		return (self.__db.all())

	def getAllPropertiesWithVersionDate(self, version_date: datetime.datetime):
		"""
		This method returns all properties for all models with a specific version date.
		:return: (list) of all properties
		"""
		# Initialize query item
		item = Query() 

		if not isinstance(version_date, datetime.datetime):
			raise TypeError("Wrong version_date type. Expect a datetime.datetime.")

		list_of_params = self.__db.search(
			item.version_date.test(
				lambda s: utilities.str2date(s) == version_date)
		)

		# Return and clean up
		if len(list_of_params) != 0:
			return list_of_params
		else:
			raise Exception('No parameters exist with this version Date.')

	def dupAllPropertiesWithDiffVersionDate(
		self,
		new_version_date: datetime.datetime,
		old_version_date: datetime.datetime,
		only_current_model_id: bool= False
	):
		"""
		:param new_version_date:
		:param only_current_model_id:
		:return:
		"""
		if not isinstance(new_version_date, datetime.datetime):
			raise TypeError("Input `new_version_date` is not a datetime instance.")

		self.__logger.add(
			type='INFO',
			message='Duplicating model properties with new version_date...',
			context='Model Properties'
		)
		if only_current_model_id:
			properties = self.getAllModelProperties()
		else:
			properties = self.getAllPropertiesWithVersionDate(version_date = old_version_date)

		# check whether new version date already exists
		list_of_existing_version=list(
				pd.core.series.Series(
				[item['version_date'] for item in self.__db.search(Query().model_id.exists())]
								).unique()
			)
		if utilities.date2str(new_version_date) in list_of_existing_version:
			raise ValueError("Input `new_version_date` already exists")          
		else:
			for property in properties:
				property['version_date'] = utilities.date2str(new_version_date)
				self.__db.insert(property)

		self.__logger.add(
			type='INFO',
			message='Duplicate completed.',
			context='Model Properties'
		)

	def isValidVersionDate(self, version_date, model_id):
		"""
		:param version_date:
		:return:
		"""
		self.__logger.add(
			type='INFO',
			message='Validating input version date...',
			context='Model Properties',
			model_id=model_id
		)

		item = Query()
		list_of_params = self.__db.search(
			(item.version_date.test(
				lambda s: utilities.str2date(s) == version_date)
			)
			&
			(item.model_id == self.__model_id)
		)
		if (len(list_of_params) >= 1):
			self.__params = list_of_params
			return (True)
		else:
			raise ValueError("There are no properties for {} with `version_date` {}.".format(
				model_id,
				str(version_date)
			))

	def isValidModelID(self,some_model_id):
		"""

		:param some_model_id:
		:return:
		"""
		self.__logger.add(
			type='INFO',
			message='Validating input model ID...',
			context='Model Properties',
			model_id=some_model_id
		)

		item = Query()
		if self.__db.search(item.model_id == some_model_id).__len__() >= 1:
			return(True)
		else:
			raise ValueError("Input `model_id` does not exist.")

	def getAllModelProperties(self):
		return self.__params
			

	def getParameters(self, type, name, **kwargs):
		"""

		:param type:
		:param name:
		:param kwargs:
		:return:
		"""
		self.__logger.add(
			type='INFO',
			message='Fetching parameter type : {} , parameter name : {}...'.format(type, name),
			context='Model Properties',
			model_id=self.__model_id
		)

		# Initialize query item
		item = Query()

		# Pre-process kwargs
		logical_container = []
		if kwargs is not None:
			for key in kwargs.keys():
				logical_container.append("(item." + key + " == '" + kwargs[key] + "')")

		# Query
		if len(logical_container)==0:
			value = self.__db.search(
				(item.type == type)
				&
				(item.version_date.test(
					lambda s: utilities.str2date(s) == self.__version_date)
				)
				&
				(item.model_id == self.__model_id)
				&
				(item.name == name)
			)
		else:
			value = self.__db.search(
				(item.type == type)
				&
				(item.version_date.test(
					lambda s: utilities.str2date(s) == self.__version_date)
				)
				&
				(item.model_id == self.__model_id)
				&
				(item.name == name)
			    &
				eval('&'.join(logical_container))
			)


		if len(value) == 1:
			return value[0]['value']
		elif len(value) == 0:
			raise ValueError('No parameters exist with these characteristics.')
		else:
			raise ValueError('Found duplicates in the parameter set.')