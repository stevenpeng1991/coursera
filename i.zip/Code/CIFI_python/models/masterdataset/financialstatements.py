"""
SAMPLE USE
----------

raw_mra = getRawMRA(source_data_set_date=datetime.datetime(2017,3,31))

"""
import sys
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
import datetime
import pandas as pd

date2str = lambda x : x.strftime("%Y%m%d")
date2OracleSTR = lambda x : x.strftime("%d-%b-%Y").upper()

def getRawMRA(source_data_set_date: datetime.datetime):
    """

    DATA SANITY CHECKS
    ------------------
    >>> SELECT SOURCE_DATA_SET, COUNT(SOURCE_DATA_SET)
        FROM STG_UPHISTSTMTMMAS
        GROUP BY SOURCE_DATA_SET
    """
    utilities.checkDataType(source_data_set_date, datetime.datetime)
    if source_data_set_date.year >= 2017: 
        raw_mra = queryRFO(
            query="""
            SELECT
                MASTERCUSTOMERID AS MasterCustomerID,
                TO_NUMBER(STATEMENTID) AS StatementID,
                TO_DATE(REPLACE(STATEMENTDATE,' 00:00:00',''), 'YYYY-MM-DD') AS StatementDate,
                TO_NUMBER(STATEMENTMONTHS) AS StatementMonths,
                AUDITMETHOD AS AuditMethod,
                TO_NUMBER(REPLACE(DEBTTOTNW, ',','')) AS DebtToTNW,
                TO_NUMBER(REPLACE(EBITDA, ',','')) AS EBITDA,
                TO_NUMBER(REPLACE(INTERESTEXPENSE, ',','')) AS InterestExpense,
                TO_NUMBER(REPLACE(CASHANDEQUIVS, ',','')) AS CashAndEquivs,
                TO_NUMBER(REPLACE(NETTRADEACCTSREC, ',','')) AS NetTradeAcctsRec,
                TO_NUMBER(REPLACE(TOTALCURLIABS, ',','')) AS TotalCurLiabs,
                TO_NUMBER(REPLACE(PROFITBEFORETAX, ',','')) AS ProfitBeforeTax,
                TO_NUMBER(REPLACE(NETSALES, ',','')) AS NetSales
            FROM MACCAR.STG_UPHISTSTMTMMAS
            WHERE
                SOURCE_DATA_SET = '{}'
            """.format(
                source_data_set_date.strftime("%Y%m%d")
            ),
            moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT']
        )
    else:
        raw_mra = queryRFO(
            query="""
            SELECT
                MASTERCUSTOMERID AS MasterCustomerID,
                TO_NUMBER(STATEMENTID) AS StatementID,
                TO_DATE(REPLACE(STATEMENTDATE,':00:00:00',''), 'DDMONYYYY') AS StatementDate,
                TO_NUMBER(STATEMENTMONTHS) AS StatementMonths,
                AUDITMETHOD AS AuditMethod,
                TO_NUMBER(REPLACE(DEBTTOTNW, ',','')) AS DebtToTNW,
                TO_NUMBER(REPLACE(EBITDA, ',','')) AS EBITDA,
                TO_NUMBER(REPLACE(INTERESTEXPENSE, ',','')) AS InterestExpense,
                TO_NUMBER(REPLACE(CASHANDEQUIVS, ',','')) AS CashAndEquivs,
                TO_NUMBER(REPLACE(NETTRADEACCTSREC, ',','')) AS NetTradeAcctsRec,
                TO_NUMBER(REPLACE(TOTALCURLIABS, ',','')) AS TotalCurLiabs,
                TO_NUMBER(REPLACE(PROFITBEFORETAX, ',','')) AS ProfitBeforeTax,
                TO_NUMBER(REPLACE(NETSALES, ',','')) AS NetSales
            FROM MACCAR.STG_UPHISTSTMTMMAS
            WHERE
                SOURCE_DATA_SET = '{}'
            """.format(
                source_data_set_date.strftime("%Y%m%d")
            ),
            moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT']
        )
            
    pd.set_option('mode.chained_assignment', None)  # Temp removal of warnings
    raw_mra.rename(
        index=str,
        columns={
            'MASTERCUSTOMERID' : 'MasterCustomerID',
            'STATEMENTID' : 'StatementID',
            'STATEMENTDATE' : 'StatementDate',
            'STATEMENTMONTHS' : 'StatementMonths',
            'AUDITMETHOD' : 'AuditMethod',
            'DEBTTOTNW' : 'DebtToTNW',
            'EBITDA' : 'EBITDA',
            'INTERESTEXPENSE' : 'InterestExpense',
            'CASHANDEQUIVS' : 'CashAndEquivs',
            'NETTRADEACCTSREC' : 'NetTradeAcctsRec',
            'TOTALCURLIABS' : 'TotalCurLiabs',
            'PROFITBEFORETAX' : 'ProfitBeforeTax',
            'NETSALES' : 'NetSales'
        },
        inplace=True
    )
    pd.set_option('mode.chained_assignment', 'warn')  # Reestablish warning message

    # FINAL CHECKS
    if len(raw_mra)==0:
        raise Exception("MRA dataset is empty. Review input parameters.")
    return(raw_mra)


def getSourceSystemToMRAMap(as_of_date: datetime.datetime):
    """

    
    DATA SANITY CHECKS
    ------------------
    >>> SELECT DISTINCT ASOFDATE, COUNT(ASOFDATE)
        FROM STG_MASTERCUST_TO_SOURCECUST
        GROUP BY ASOFDATE
        ORDER BY ASOFDATE DESC
    >>> SELECT DISTINCT ASOFDATE, COUNT(ASOFDATE)
        FROM STG_ONEOBLIGOR_TO_MASTCUST
        GROUP BY ASOFDATE
        ORDER BY ASOFDATE DESC


    """
    # FETCH RAW DATA
    sourcesystem_to_mra = queryRFO(
        query="""
        SELECT
            SOURCESYSTEMSOURCEID AS SOURCEID,
            SOURCESYSTEMCUSTOMERNUMBER AS CUSTOMERNUMBER,
            SOURCESYSTEMCUSTOMERNUMBER AS ONEOBLIGORNUMBER,
            MASTERCUSTOMERID AS MASTERCUSTOMERID,
            MASTERONEOBLIGORID AS MASTERONEOBLIGORID
        FROM (
            SELECT DISTINCT
                MCID_AGG.*,
                TO_CHAR(mooid.MASTERONEOBLIGORID) AS MASTERONEOBLIGORID
            FROM
                (
                    SELECT DISTINCT
                        LF.*,
                        RT.MASTERCUSTOMERID
                    FROM
                        (SELECT DISTINCT
                            MAX(MCID.ASOFDATE) AS MAX_ASOFDATE,
                            MCID.SOURCESYSTEMSOURCEID,
                            MCID.SOURCESYSTEMCUSTOMERNUMBER
                        FROM
                            (
                                SELECT DISTINCT
                                    mcid.ASOFDATE,
                                    UPPER(mcid.SOURCESYSTEMSOURCEID) AS SOURCESYSTEMSOURCEID,
                                    mcid.SOURCESYSTEMCUSTOMERNUMBER,
                                    TO_CHAR(mcid.MASTERCUSTOMERID) AS MASTERCUSTOMERID
                                FROM
                                    MACCAR.STG_MASTERCUST_TO_SOURCECUST mcid
                                WHERE
                                    SUBSTR(TO_CHAR(mcid.MASTERCUSTOMERID),1,4) = '3000'
                                    AND
                                    mcid.ASOFDATE <= '{}'
                                    AND
                                    mcid.SOURCESYSTEMSOURCEID <> 'KGR'
                            ) MCID
                        GROUP BY
                            MCID.SOURCESYSTEMSOURCEID,
                            MCID.SOURCESYSTEMCUSTOMERNUMBER) LF
                    LEFT JOIN
                        (
                            SELECT DISTINCT
                                mcid.ASOFDATE,
                                UPPER(mcid.SOURCESYSTEMSOURCEID) AS SOURCESYSTEMSOURCEID,
                                mcid.SOURCESYSTEMCUSTOMERNUMBER,
                                TO_CHAR(mcid.MASTERCUSTOMERID) AS MASTERCUSTOMERID
                            FROM
                                MACCAR.STG_MASTERCUST_TO_SOURCECUST mcid
                            WHERE
                                SUBSTR(TO_CHAR(mcid.MASTERCUSTOMERID),1,4) = '3000'
                                AND
                                mcid.ASOFDATE <= '{}'
                                AND
                                mcid.SOURCESYSTEMSOURCEID <> 'KGR'
                        ) RT
                    ON
                        RT.ASOFDATE = LF.MAX_ASOFDATE
                        AND
                        RT.SOURCESYSTEMSOURCEID = LF.SOURCESYSTEMSOURCEID
                        AND
                        RT.SOURCESYSTEMCUSTOMERNUMBER = LF.SOURCESYSTEMCUSTOMERNUMBER
                ) MCID_AGG
            LEFT JOIN
                MACCAR.STG_ONEOBLIGOR_TO_MASTCUST mooid
            ON
                MCID_AGG.MAX_ASOFDATE = mooid.ASOFDATE
                AND
                MCID_AGG.MASTERCUSTOMERID = TO_CHAR(mooid.MASTERCUSTOMERID)
            WHERE
                SUBSTR(TO_CHAR(mooid.MASTERONEOBLIGORID),1,4) = '2000' OR mooid.MASTERONEOBLIGORID IS NULL
            ORDER BY
                MAX_ASOFDATE DESC
        )
        """.format(
            date2OracleSTR(as_of_date),
            date2OracleSTR(as_of_date)
        ),
        moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT']
    )

    # CHECK FOR INTEGRITY
    if len(sourcesystem_to_mra[sourcesystem_to_mra.duplicated(subset=['SOURCEID','CUSTOMERNUMBER'], keep=False)])!=0:
        raise Exception("There are duplicates in the SOURCESYSTEM_TO_MRA mapping based on SOURCEID and CUSTOMERNUMBER")

    # RENAME FIELDS
    sourcesystem_to_mra.rename(
        index=str,
        columns={
            'SOURCEID': 'SourceId',
            'CUSTOMERNUMBER': 'CustomerNumber',
            'ONEOBLIGORNUMBER': 'OneObligorNumber',
            'MASTERCUSTOMERID': 'MasterCustomerId',
            'MASTERONEOBLIGORID': 'MasterOneObligorId'
        },
        inplace=True
    )

    return(sourcesystem_to_mra)



































