# How to query MV_MEV_NORMALIZED in Moody's RFO


First, you will need to declare all the input parameters that define a set of macro inputs for a specific scenario. In general, we assume that a "**_set of macro inputs_**" is some number of macro indicators for a specific scenario (FRB_BASE, FRB_SA,...), a stress testing cycle (DryRun2017, CCAR2017,...), a geographical scope (regional, US,...) and a frequency (monthly, quarterly).

For example,

**@scenario = 'FRB_BASE'**  -- the name of the scenario you are querying  
**@context = 'CCAR2017'** -- the stress testing cycle  
**@geo_scope = 'National&Regional'**  -- geographical scope  
**@period_frequency = 'quarterly'**  -- series frequency  
**@macro_var_list = ('FLBR_US', 'FRGT10Y_US', 'FGDPxxx_US')** -- the macro variable mnemonics

> **NOTE:** The '@' variables are just examples. You need to replace those with specific values.

```sql
SELECT DISTINCT
    PERIOD_END_DATE AS "Period",
    INDICATOR AS "Indicator",
    VALUE AS "Value"
FROM
    MV_MEV_NORMALIZED
WHERE
    UPPER(SCENARIO) = UPPER('@scenario')
    AND
    UPPER(CYCLE) = UPPER('@context')
    AND
    UPPER(GEOGRAPHYSCOPE) = UPPER('@geo_scope')
    AND
    UPPER(FREQUENCY) = UPPER('@period_frequency')
    AND
    UPPER(INDICATOR) IN @macro_var_list
```