"""


##
## UAT TESTING
##

query="
SELECT
     ANCHOR.*,
     CF_PD.MODELOUTPUTRATE,
     CF_PD.PERIODDATE
FROM (
SELECT
    UNIQUE_FACILITY_ID,
    PD,
    LGD,
    SRR,
    SUM(UTILIZATIONBOOKBALANCE),
    SUM(CALCULATED_LINE)
FROM MACCAR.MV_LOSS_COMMERCIAL
WHERE
    ASOFDATE = '30-NOV-2016'
    AND
    PD_GROUP_2017 = 'GCB'
    AND
   (
		(
			FAS114_STATUS = 'A - NOT REQUIRED'
			AND
			LOCAL_NPL_FLAG = 'N'
		)
		OR
		TDR = 'Y'
            )
  AND UPPER(SOURCEID) <> 'OFFLINE'
GROUP BY
UNIQUE_FACILITY_ID,
PD,
LGD,
SRR) ANCHOR
LEFT JOIN
     MACCAR.STG_CONTRIBUTOR_DATA CF_PD
ON
     ANCHOR.PD = CF_PD.MODELSEGMENT
     AND
     CF_PD.RATENAME = 'PD'
     AND
     CF_PD.CONTRIBUTOR_FILE_ID = 1
     AND
     CF_PD.FILE_VERSION=12
     AND
     CF_PD.VINTAGE = '31-JAN-1900'
"

df = queryRFO(
	query=query,
	moodys_rfo_env="PROD_ENV"
)







################################################################################

data = pd.read_csv(
	filepath_or_buffer="C:/Users/n813863/Documents/SHUSA/RFO_UAT/CONTRIBUTOR_FILES/MC_SA/EJM_MC_SA_SB_COMM_LOSS.csv",
	sep=',',
	keep_default_na = False,
	na_values = ['nan', 'NaN', 'NULL', 'null', 'NA', 'N\A', '#N\A', 'None', 'none',''],
	encoding='utf-8'    ,
	date_parser=utilities.str2date,
	parse_dates=["PERIODDATE", "VINTAGE"]
)

data.columns = [s.replace('\ufeff','') for s in data.columns]
data.replace('.', np.nan, inplace=True)



SAMPLE QUERIES
query = "
	SELECT
		 PD_GROUP,
		 COUNT(UNIQUE_FACILITY_ID)
	FROM (
		SELECT DISTINCT
			PD_GROUP,
			UNIQUE_FACILITY_ID
		FROM MDS_DATA_TMP
		WHERE
			ASOFDATE = '30-JUN-16'
	)
	GROUP BY
		 PD_GROUP
"
query="
	SELECT *
	FROM MDS_DATA_TMP
	WHERE
		 ASOFDATE = '30-JUN-16'
		 AND
		 UNIQUE_FACILITY_ID = 'AFS0051907348005191646300519164630000000042'
"
query="
SELECT * FROM MACCAR.MV_LOSS_COMMERCIAL WHERE REPORTING_DATE = '30-JUN-2016'
"
query="
SELECT * FROM all_source WHERE NAME LIKE '%GET_RUN%'
"
query="
DESC STG_CONTRIBUTOR_DATA
"
query="
SELECT
	SOURCEID,
	SUM(UTILIZATIONBOOKBALANCE),
	SUM(UTILIZATIONLCAMOUNT),
	SUM(CALCULATED_LINE),
	COUNT(UNIQUE_FACILITY_ID)
FROM MDS_DATA_TMP
WHERE
	ASOFDATE = '30-JUN-2016'
	AND
	EXISTING_NEW = 'EXISTING'
GROUP BY SOURCEID
"


##
## INSERT TEST
##
cf = ContributorFile(
	dir_path="C:/Users/n813863/Documents/SHUSA/RFO_UAT/CONTRIBUTOR_FILES/MC_SA/",
	filename="EJM_MC_SA_SB_COMM_LOSS.csv",
	primary_key=["SCENARIO", "PERIODDATE", "VINTAGE", "MODELSEGMENT", "RATENAME"],
	date_fields=["PERIODDATE", "VINTAGE"],
	header_list=(
	"SCENARIO",
	"MODELSEGMENT",
	"PERIODDATE",
	"VINTAGE",
	"RATETYPE",
	"FEESANDEXPENSESLINEITEM",
	"ASSOCIATEDG_L_ITEM",
	"TRANSFORMATION",
	"PERIODLAG",
	"RATENAME",
	"MODELOUTPUTRATE",
	"UNCERTAINTYADJUSTMENTRATE",
	"MGMTADJUSTMENTRATE",
	"IDIOSYNCRATICRATE1",
	"IDIOSYNCRATICRATE2",
	"IDIOSYNCRATICRATE3",
	"IDIOSYNCRATICRATE4",
	"IDIOSYNCRATICRATE5",
	"ADJUSTMENT_OVERLAY_JUST"
	)
)

data = cf.getCFData()
data.VINTAGE[~pd.isnull(data.VINTAGE)] = datetime.datetime(2016,6,30)
writeContributorData(
	data=data[~pd.isnull(data.VINTAGE)],
	as_of_date=datetime.datetime(2016, 6, 30),
	moodys_rfo_env="UAT_ENV",
	table_name='STG_CONTRIBUTOR_DATA'
)

cursor.execute("SELECT * FROM STG_CONTRIBUTOR_DATA WHERE CONTRIBUTOR_FILE_ID=1 AND ROWNUM<=100")
df = pd.DataFrame(cursor.fetchall())
df.columns = [item[0] for item in cursor.description]



###
### AGG CF + write to RFO
###

raw_data = utilities.aggregateCF(
	working_directory="C:/Users/n813863/Documents/SHUSA/RFO_UAT/CONTRIBUTOR_FILES/MC_SA"
)

raw_data["PERIODDATE"] = raw_data["PERIODDATE"].apply(lambda x: pd.NaT if (pd.isnull(x) or x=='.') else utilities.str2date(x))
raw_data["VINTAGE"] = raw_data["VINTAGE"].apply(lambda x: datetime.datetime(2016, 6, 30) if (pd.isnull(x) or x=='.') else utilities.str2date(x))

cf = ContributorFile(
	data=raw_data,
	primary_key=["SCENARIO", "PERIODDATE", "VINTAGE", "MODELSEGMENT", "RATENAME"],
	date_fields=["PERIODDATE", "VINTAGE"],
	header_list=(
	"SCENARIO",
	"MODELSEGMENT",
	"PERIODDATE",
	"VINTAGE",
	"RATETYPE",
	"FEESANDEXPENSESLINEITEM",
	"ASSOCIATEDG_L_ITEM",
	"TRANSFORMATION",
	"PERIODLAG",
	"RATENAME",
	"MODELOUTPUTRATE",
	"UNCERTAINTYADJUSTMENTRATE",
	"MGMTADJUSTMENTRATE",
	"IDIOSYNCRATICRATE1",
	"IDIOSYNCRATICRATE2",
	"IDIOSYNCRATICRATE3",
	"IDIOSYNCRATICRATE4",
	"IDIOSYNCRATICRATE5",
	"ADJUSTMENT_OVERLAY_JUST"
	)
)

data = cf.getCFData()
data.VINTAGE = data.VINTAGE

ans = writeContributorData(
	data=data,
	as_of_date=datetime.datetime(2016, 6, 30),
	moodys_rfo_env="UAT_ENV",
	table_name='STG_CONTRIBUTOR_DATA'
)

table_headers = (
	"PARTITION_KEY",
	"RUN_SIGNATURE",
	"CONTRIBUTOR_FILE_ID",
	"FILE_VERSION",
	"SCENARIO",
	"MODELSEGMENT",
	"PERIODDATE",
	"VINTAGE",
	"RATETYPE",
	"FEESANDEXPENSESLINEITEM",
	"ASSOCIATEDG_L_ITEM",
	"TRANSFORMATION",
	"PERIODLAG",
	"RATENAME",
	"MODELOUTPUTRATE",
	"UNCERTAINTYADJUSTMENTRATE",
	"MGMTADJUSTMENTRATE",
	"IDIOSYNCRATICRATE1",
	"IDIOSYNCRATICRATE2",
	"IDIOSYNCRATICRATE3",
	"IDIOSYNCRATICRATE4",
	"IDIOSYNCRATICRATE5",
	"ADJUSTMENT_OVERLAY_JUST"
)

data=data
as_of_date=datetime.datetime(2016, 6, 30)
moodys_rfo_env="UAT_ENV"
table_name='MACCAR.STG_CONTRIBUTOR_DATA'

connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][moodys_rfo_env]
cx_Oracle_DSN = cx_Oracle.makedsn(
	host=connection_strings["HOST_IP"],
	port=connection_strings["ORACLE_PORT"],
	sid=connection_strings["SID"]
)
connection = cx_Oracle.connect(
	user=connection_strings["USER_NAME"],
	password=connection_strings["PASSWORD"],
	dsn=cx_Oracle_DSN
)
cursor = connection.cursor()

# Create SQL insert statement
statement = 'INSERT INTO ' + \
	table_name + \
	to_sql_array(table_headers) + \
	' VALUES ' + \
	to_sql_array([':' + str(i) for i in table_headers])

# Get run parameters
v_run_sig = cursor.var(cx_Oracle.STRING)
v_part_key = cursor.var(cx_Oracle.STRING)
cursor.callproc('MACCAR.publish_run_signature', [
	as_of_date.strftime("%Y%m%d"),
	'N',
	'ME_LOSS_ENGINE',
	'CCAR',
	v_run_sig,
	v_part_key
])
data["PARTITION_KEY"] = v_part_key.getvalue()
data["RUN_SIGNATURE"] = v_run_sig.getvalue()
data["CONTRIBUTOR_FILE_ID"] = 1
data["FILE_VERSION"] = 1

# Prepare data and replace NAs by None
records_to_insert_2 = list(data.to_dict(orient='records'))
records_to_insert = list(data.T.to_dict().values())
if len(records_to_insert) != len(data):
	raise Exception("Not all records were converted to array of dictionaries.")
for item in records_to_insert:
	for key in item.keys():
		if pd.isnull(item[key]):
			item[key] = None

# Begin insert process
t0 = time.time()
cursor.executemany(statement, records_to_insert)
# try:
# 	cursor.executemany(statement, records_to_insert)
# except:
# 	return(False)

# Commit insert operation
connection.commit()

# Calculate runtime
t1 = time.time()
runtime = round((t1 - t0), 5)
if debug:
	print("Runtime : " + str(runtime) + "s.")

# Finalize
cursor.close()
connection.close()


"""
import sys
import os
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import datetime
import pandas as pd
import numpy as np
import cx_Oracle
import time
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.contributorfile.contributorfile import ContributorFile, ContributorFileGenerator



##
## Query RFO
##
def queryRFO(
	query: str,
	moodys_rfo_env: str = "DEFAULT_ENV",
	debug: bool= False
) -> pd.DataFrame:
	connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][moodys_rfo_env]

	cx_Oracle_DSN = cx_Oracle.makedsn(
		host=connection_strings["HOST_IP"],
		port=connection_strings["ORACLE_PORT"],
		sid=connection_strings["SID"]
	)
	connection = cx_Oracle.connect(
		user=connection_strings["USER_NAME"],
		password=connection_strings["PASSWORD"],
		dsn=cx_Oracle_DSN
	)
	cursor = connection.cursor()

	if debug: print(query)
	try:
		cursor.execute(query)
	except Exception as e:
		print(str(e))
		return(False)
	tmp_data = pd.DataFrame(
		cursor.fetchall(),
		columns=[item[0] for item in cursor.description]
	)

	cursor.close()
	connection.close()

	return(tmp_data)


##
## Generate random contributor file
##
def randomContributorData(
	number_of_records: int =10000,
	as_of_date: datetime.datetime = datetime.datetime(2016, 6, 30),
	random_model_segment_length: int = 50
) -> list:
	"""
	This functions generates a random list of contributor data records for testing purposes.

	Parameters
	----------
	number_of_records: (int) number of random records to produce
	as_of_date: (datetime.datetime) current as of date for the contributor data
	random_model_segment_length: (int) length in chars of the random model segments

	Returns
	-------
	list<dict>: list of random dictionary records

	"""
	# Import modules and declare helpers
	import random, string, uuid
	genRandId = lambda: str(uuid.uuid4())
	def random_char(y):
		return ''.join(random.choice(string.ascii_letters) for x in range(y))

	# Get run signature and partition key
	v_run_sig = cursor.var(cx_Oracle.STRING)
	v_part_key = cursor.var(cx_Oracle.STRING)
	cursor.callproc('publish_run_signature', [
		as_of_date.strftime("%Y%m%d"),
		'N',
		'ME_LOSS_ENGINE',
		'CCAR',
		v_run_sig,
		v_part_key
	])

	# Generate random records
	sample_data_to_insert = []
	rnd_strings = [random_char(random_model_segment_length) for item in range(number_of_records)]
	for i in range(number_of_records):
		sample_data_to_insert.append(
			{
				"PARTITION_KEY": v_part_key.getvalue(),
				"RUN_SIGNATURE": v_run_sig.getvalue(),
				"CONTRIBUTOR_FILE_ID": 1111,
				"FILE_VERSION": 1,
				"SCENARIO": 'MidCycle2016',
				"MODELSEGMENT": 'SB' + rnd_strings[i],
				"PERIODDATE": as_of_date,
				"VINTAGE": '.',
				"RATETYPE": '4',
				"FEESANDEXPENSESLINEITEM": None,
				"ASSOCIATEDG_L_ITEM": None,
				"TRANSFORMATION": 'No Transformation',
				"PERIODLAG": '0',
				"RATENAME": 'PD',
				"MODELOUTPUTRATE": 0.235466540,
				"UNCERTAINTYADJUSTMENTRATE": '0',
				"MGMTADJUSTMENTRATE": '0',
				"IDIOSYNCRATICRATE1": '0',
				"IDIOSYNCRATICRATE2": '0',
				"IDIOSYNCRATICRATE3": '0',
				"IDIOSYNCRATICRATE4": '0',
				"IDIOSYNCRATICRATE5": '0',
				"ADJUSTMENT_OVERLAY_JUST": None
			}
		)

	# Finalize
	return(sample_data_to_insert)

##
## CONNECT TO RFO INSTANCE
##
def writeContributorData(
	data: pd.DataFrame,
	as_of_date: datetime.datetime,
	debug: bool = True,
	moodys_rfo_env: str = "DEFAULT_ENV",
	table_name: str = 'STG_CONTRIBUTOR_DATA',
	table_headers: list = (
		"PARTITION_KEY",
		"RUN_SIGNATURE",
		"CONTRIBUTOR_FILE_ID",
		"FILE_VERSION",
		"SCENARIO",
		"MODELSEGMENT",
		"PERIODDATE",
		"VINTAGE",
		"RATETYPE",
		"FEESANDEXPENSESLINEITEM",
		"ASSOCIATEDG_L_ITEM",
		"TRANSFORMATION",
		"PERIODLAG",
		"RATENAME",
		"MODELOUTPUTRATE",
		"UNCERTAINTYADJUSTMENTRATE",
		"MGMTADJUSTMENTRATE",
		"IDIOSYNCRATICRATE1",
		"IDIOSYNCRATICRATE2",
		"IDIOSYNCRATICRATE3",
		"IDIOSYNCRATICRATE4",
		"IDIOSYNCRATICRATE5",
		"ADJUSTMENT_OVERLAY_JUST"
	)
) -> bool:
	"""
	This function inserts contributor data into RFO.

	Parameters
	----------
	data: (pandas.DataFrame) contributor data to insert

	Returns
	-------
	(bool) whether or not the data was inserted correctly
	"""
	if debug:
		print("Connecting to database...")
	connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][moodys_rfo_env]
	cx_Oracle_DSN = cx_Oracle.makedsn(
		host=connection_strings["HOST_IP"],
		port=connection_strings["ORACLE_PORT"],
		sid=connection_strings["SID"]
	)
	connection = cx_Oracle.connect(
		user=connection_strings["USER_NAME"],
		password=connection_strings["PASSWORD"],
		dsn=cx_Oracle_DSN
	)
	cursor = connection.cursor()

	# Create SQL insert statement
	if debug:
		print("Creating INSERT statement...")
	statement = 'INSERT INTO ' + \
		connection_strings["SCHEMA_NAME"]+"."+table_name + \
		utilities.to_sql_array(table_headers) + \
		' VALUES ' + \
		utilities.to_sql_array([':' + str(i) for i in table_headers])
	if debug:
		print("STATEMENT:\n"+statement)

	# Get run parameters
	if debug:
		print("Getting run parameters...")
	v_run_sig = cursor.var(cx_Oracle.STRING)
	v_part_key = cursor.var(cx_Oracle.STRING)
	cursor.callproc(connection_strings["SCHEMA_NAME"]+"."+'publish_run_signature', [
		as_of_date.strftime("%Y%m%d"),
		'N',
		'ME_LOSS_ENGINE',
		'CCAR',
		v_run_sig,
		v_part_key
	])
	data["PARTITION_KEY"] = 'S00000000022'
	data["RUN_SIGNATURE"] = '063016_12223'
	data["CONTRIBUTOR_FILE_ID"] = 1
	data["FILE_VERSION"] = 1

	# Prepare data and replace NAs by None
	# data_2 = data[pd.notnull(data["VINTAGE"])]
	# data_3 = data_2.where((pd.notnull(data_2)), None)
	# data_2["VINTAGE"] = data_2.VINTAGE.apply(lambda x: None if pd.isnull(x) else x)
	if debug:
		print("Transforming data to array of dicts...")
	records_to_insert = list(data.to_dict(orient='records'))
	if len(records_to_insert) != len(data):
		raise Exception("Not all records were converted to array of dictionaries.")

	if debug:
		print("Replacing nulls by None...")
	for item in records_to_insert:
		for key in item.keys():
			if pd.isnull(item[key]):
				item[key] = None

	# Begin insert process
	if debug:
		print("Begin insert...")
	t0 = time.time()
	cursor.executemany(statement, records_to_insert)
	# try:
	# 	cursor.executemany(statement, records_to_insert)
	# except:
	# 	return(False)

	# Commit insert operation
	connection.commit()

	# Calculate runtime
	t1 = time.time()
	runtime = round((t1 - t0), 5)
	if debug:
		print("Insert completed!")
		print("Runtime : " + str(runtime) + "s.")

	# Finalize
	cursor.close()
	connection.close()
	return(True)

##
## get partition key and run signatur of specific run
##
def getCurrentEnvRunSignature(
        p_reporting_date: datetime.datetime,
        p_rerun: str = 'N',
        p_engine: str = 'ME_LOSS_ENGINE',
        p_cycle: str = 'CCAR'
    ):
        connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][
            CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT']
        ]
        cx_Oracle_DSN = cx_Oracle.makedsn(
            host=connection_strings["HOST_IP"],
            port=connection_strings["ORACLE_PORT"],
            sid=connection_strings["SID"]
        )
        connection = cx_Oracle.connect(
            user=connection_strings["USER_NAME"],
            password=connection_strings["PASSWORD"],
            dsn=cx_Oracle_DSN
        )
        cursor = connection.cursor()

        v_run_sig = cursor.var(cx_Oracle.STRING)
        v_part_key = cursor.var(cx_Oracle.STRING)
        cursor.callproc(connection_strings["SCHEMA_NAME"] + "." + 'publish_run_signature', [
            p_reporting_date.strftime("%Y%m%d"),
            p_rerun,
            p_engine,
            p_cycle,
            v_run_sig,
            v_part_key
        ])

        return(
            {
                'partition_key':v_part_key.getvalue(),
                'run_signature':v_run_sig.getvalue()
            }
        )




