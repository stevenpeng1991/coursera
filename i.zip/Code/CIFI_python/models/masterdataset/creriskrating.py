import sys
import os
# wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
# if wd not in sys.path:
#     sys.path.append(wd)
import datetime
import pandas as pd
import numpy as np
import time
from CIFI.config import CONFIG


class CRERiskRatingDataModel:
    # Member properties

    # Member functions
    def __init__(self):
        pass

    def fetchContracts(self):
        some_data = {}

        return(some_data)
