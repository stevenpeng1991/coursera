"""
SAMPLE USE
----------

# Overwrite calculated_line for TermedOutLine
sample_mds = CCMISMasterDataset(
    asofdate=datetime.datetime(2017,12,31),
    include_originations=True,
    pd_groups=['GCB'],
    debug=True,
    limit_contracts=None,
    overwrite_calculated_line=True
)

sample_mds = CCMISMasterDataset(
    asofdate=datetime.datetime(2016,12,31),
    include_originations=True,
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'CRE_MULTIFAMILY', 'CRE_OTHER'],
    debug=True,
    limit_contracts=None
)

sample_mds = CCMISMasterDataset(
    asofdate=datetime.datetime(2017,2,28),
    include_originations=True,
    pd_groups=['GCB'],
    debug=True,
    limit_contracts=None
)

sample_mds = CCMISMasterDataset(
    asofdate=datetime.datetime(2016,6,30),
    pd_groups=['GCB'],
    debug=True
)

sample_mds = CCMISMasterDataset(
    asofdate=datetime.datetime(2016,12,31),
    include_originations=True,
    pd_groups=['CRE_CONSTRUCTION'],
    debug=True,
    limit_contracts=None
)

df = sample_mds.data

"""

import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import datetime
import pandas as pd
import numpy as np
import cx_Oracle
import time
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem


# Helpers
date2OracleSTR = lambda x: x.strftime("%d-%b-%Y").upper()


def to_sql_array(a, wrapper=('(', ')'), quote=False):
    s = wrapper[0]
    for h in a:
        if quote:
            s += "'"+str(h) + "',"
        else:
            s += str(h) + ','
    s = s.strip(',')
    s += wrapper[1]
    return s


class CCMISMasterDataset:
    # Properties
    __environment = None
    __connection_strings = None
    __asofdate = None
    __pd_groups = None
    __connection = None
    __granularity = None
    __anchor_table_name = None
    __orig_table_name = None
    __data = None
    __include_originations = None
    __debug = None
    __precision = None
    __limit_contracts = None
    __pd_group_field_name = None
    __fetchCNI = None
    __overwrite_calculated_line = None


    # Methods
    def __init__(
        self,
        asofdate,
        pd_groups,
        environment=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
        include_originations=True,
        granularity='facility',
        pd_group_field_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
        anchor_table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
        orig_table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
        auto_fetch=True,
        debug=False,
        limit_contracts=None,
        fetchCNI=False,
        overwrite_calculated_line=False,
        **kwargs
    ):
        # Create connection instance
        utilities.checkDataType(environment, str)
        self.__connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][environment]
        cx_Oracle_DSN = cx_Oracle.makedsn(
            host=self.__connection_strings["HOST_IP"],
            port=self.__connection_strings["ORACLE_PORT"],
            sid=self.__connection_strings["SID"]
        )
        self.__connection = cx_Oracle.connect(
            user=self.__connection_strings["USER_NAME"],
            password=self.__connection_strings["PASSWORD"],
            dsn=cx_Oracle_DSN
        )

        # Assign member properties
        utilities.checkDataType(asofdate, datetime.datetime)
        utilities.checkDataType(pd_groups, list)
        utilities.checkDataType(granularity, str)
        utilities.checkDataType(anchor_table_name, str)
        utilities.checkDataType(orig_table_name, str)
        utilities.checkDataType(include_originations, bool)
        utilities.checkDataType(debug, bool)
        utilities.checkDataType(pd_group_field_name, str)
        if limit_contracts is not None:
            utilities.checkDataType(limit_contracts, int)
        utilities.checkDataType(fetchCNI, bool)
        self.__asofdate = asofdate
        self.__pd_groups = pd_groups
        self.__granularity = granularity
        self.__anchor_table_name = anchor_table_name
        self.__orig_table_name = orig_table_name
        self.__include_originations = include_originations
        self.__debug = debug
        self.__precision = CONFIG['MODEL_PRECISION']
        self.__limit_contracts = limit_contracts
        self.__pd_group_field_name = pd_group_field_name
        self.__fetchCNI = fetchCNI
        self.__overwrite_calculated_line = overwrite_calculated_line
        self.utilization_switch = kwargs.get('utilization_switch')
        
        # Auto Fetch
        utilities.checkDataType(auto_fetch, bool)
        if auto_fetch and not fetchCNI:
            if self.utilization_switch == True:
                self.fetchUtilizationLevelData()
            else:
                self.fetchData()  
        elif auto_fetch and fetchCNI:
            self.fetchCNIData()
            
    def __del__(self):
        self.__connection.close()

    @property
    def data(self):
        return(self.__data)

    @property
    def environment(self):
        return (self.__environment)

    @property
    def asofdate(self):
        return (self.__asofdate)

    @property
    def pd_groups(self):
        return (self.__pd_groups)

    @property
    def include_originations(self):
        return (self.__include_originations)

    @property
    def granularity(self):
        return (self.__granularity)

    @property
    def table_name(self):
        return (self.__table_name)

    @property
    def debug(self):
        return (self.__debug)

    @property
    def precision(self):
        return (self.__precision)

    @property
    def limit_contracts(self):
        return(self.__limit_contracts)

    @property
    def pd_group_field_name(self):
        return (self.__pd_group_field_name)

    @property
    def fetchCNI(self):
        return (self.__fetchCNI)
        
    @property
    def overwrite_calculated_line(self):
        return (self.__overwrite_calculated_line)        

    def fetchData(self):
        cursor = self.__connection.cursor()
        if not self.__overwrite_calculated_line:
            query = """
                SELECT
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    MAX(MASTER_CUSTOMER_ID) AS MASTER_CUSTOMER_ID,
                    MAX(COSTCENTER) AS COSTCENTER,
                    SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                    LOCAL_NPL_FLAG,
                    MAX(PRI_COLLATVALUE) AS PRI_COLLATVALUE,
                    ROUND(MAX(SRR), 1) AS SRR,
                    UPPER(SOURCEID) AS SOURCEID,
                    FAS114_STATUS,
                    SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                    SUM(CALCULATED_LINE) AS EXPOSURE,
                    MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EAD,
                    LGD,
                    PD,
                    MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                    MAX(CURRENTOCCUPANCY) AS CURRENTOCCUPANCY,
                    MAX(PRI_COLLATNOI) AS PRI_COLLATNOI,
                    UNIQUE_FACILITY_ID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    MAX(PD_GROUP) AS PD_GROUP,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    IS_ORIG
                FROM (
                    (SELECT
                        ASOFDATE,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        MASTER_CUSTOMER_ID,
                        COSTCENTER,
                        UTILIZATIONLCAMOUNT,
                        LOCAL_NPL_FLAG,
                        PRI_COLLATVALUE,
                        SRR,
                        SOURCEID,
                        FAS114_STATUS,
                        UTILIZATIONBOOKBALANCE,
                        CALCULATED_LINE,
                        UTILIZATIONOPENDATE,
                        TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                        TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                        TO_CHAR(EAD) AS EAD,
                        TO_CHAR(LGD) AS LGD,
                        TO_CHAR(PD) AS PD,
                        MAXIMUMMATURITYDATE,
                        CURRENTOCCUPANCY,
                        CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                        UNIQUE_FACILITY_ID,
                        TDR,
                        PROPERTY_TYPE_MAP,
                        BINDINGINDICATOR,
                        TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                        FACILITYTYPE,
                        SICCODE,
                        RETYPE,
                        COLLATERALCODE,
                        COLLATERAL_DESCRIPTION,
                        CONSOLIDATED_COLLATERAL_CODE,
                        PRI_COLLATSTATE,
                        UNSECURED_INDICATOR,
                        'N' AS IS_ORIG
                    FROM {}
                    WHERE
                        ASOFDATE = '{}')
                    UNION ALL
                    (SELECT
                        ASOFDATE,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        MASTER_CUSTOMER_ID,
                        COSTCENTER,
                        UTILIZATIONLCAMOUNT,
                        LOCAL_NPL_FLAG,
                        PRI_COLLATVALUE,
                        SRR,
                        SOURCEID,
                        FAS114_STATUS,
                        UTILIZATIONBOOKBALANCE,
                        CALCULATED_LINE,
                        UTILIZATIONOPENDATE,
                        TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                        TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                        TO_CHAR(EAD) AS EAD,
                        TO_CHAR(LGD) AS LGD,
                        TO_CHAR(PD) AS PD,
                        MAXIMUMMATURITYDATE,
                        CURRENTOCCUPANCY,
                        CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                        UNIQUE_FACILITY_ID AS UNIQUE_FACILITY_ID,
                        TDR,
                        PROPERTY_TYPE_MAP,
                        BINDINGINDICATOR,
                        TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                        FACILITYTYPE,
                        SICCODE,
                        RETYPE,
                        COLLATERALCODE,
                        COLLATERAL_DESCRIPTION,
                        CONSOLIDATED_COLLATERAL_CODE,
                        PRI_COLLATSTATE,
                        UNSECURED_INDICATOR,
                        'Y' AS IS_ORIG
                    FROM {}
                    WHERE
                        ASOFDATE = '{}'
                        AND RUN_SIGNATURE = '123117_122757')
                )
                WHERE
                    (
                        (
                            FAS114_STATUS = 'A - NOT REQUIRED'
                            AND
                            LOCAL_NPL_FLAG = 'N'
                        )
                    )
                    AND
                    UPPER(SOURCEID) NOT IN ('OFFLINE')
                    {}
                    {}
                GROUP BY
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    LOCAL_NPL_FLAG,
                    SOURCEID,
                    FAS114_STATUS,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EAD,
                    LGD,
                    PD,
                    UNIQUE_FACILITY_ID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    IS_ORIG
                HAVING
                    (
                    SUM(CALCULATED_LINE) > 0
                    OR 
                    SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
                    )
    
            """.format(
                self.__anchor_table_name,
                date2OracleSTR(self.__asofdate),
                self.__orig_table_name,
                date2OracleSTR(self.__asofdate),
                " AND PD_GROUP IN "+to_sql_array(a=self.__pd_groups, quote=True) if len(self.__pd_groups)>0 else "",
                " AND ROWNUM <= " + str(int(self.limit_contracts)) if self.limit_contracts is not None else ""
            )            
        else:
            # Merge with FE views to overwrite calculated line
            query = """
                SELECT
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    MAX(MASTER_CUSTOMER_ID) AS MASTER_CUSTOMER_ID,
                    MAX(COSTCENTER) AS COSTCENTER,
                    SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                    LOCAL_NPL_FLAG,
                    MAX(PRI_COLLATVALUE) AS PRI_COLLATVALUE,
                    ROUND(MAX(SRR), 1) AS SRR,
                    UPPER(SOURCEID) AS SOURCEID,
                    FAS114_STATUS,
                    SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                    SUM(CALCULATED_LINE) AS EXPOSURE,
                    MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EAD,
                    LGD,
                    PD,
                    MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                    MAX(CURRENTOCCUPANCY) AS CURRENTOCCUPANCY,
                    MAX(PRI_COLLATNOI) AS PRI_COLLATNOI,
                    UNIQUE_FACILITY_ID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    MAX(PD_GROUP) AS PD_GROUP,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    IS_ORIG,
                    LINE_TERM
                FROM (
                    (SELECT 
                        ASOFDATE,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        MASTER_CUSTOMER_ID,
                        COSTCENTER,
                        UTILIZATIONLCAMOUNT,
                        LOCAL_NPL_FLAG,
                        PRI_COLLATVALUE,
                        SRR,
                        SOURCEID,
                        FAS114_STATUS,
                        UTILIZATIONBOOKBALANCE,
                        CALCULATED_LINE,
                        UTILIZATIONOPENDATE,
                        ALLLCOVERAGE,
                        CONTINGENTRESERVE,
                        EAD,
                        LGD,
                        PD,
                        MAXIMUMMATURITYDATE,
                        CURRENTOCCUPANCY,
                        PRI_COLLATNOI,
                        UNIQUE_FACILITY_ID,
                        UNIQUEID,
                        TDR,
                        PROPERTY_TYPE_MAP,
                        BINDINGINDICATOR,
                        PD_GROUP,
                        FACILITYTYPE,
                        SICCODE,
                        RETYPE,
                        COLLATERALCODE,
                        COLLATERAL_DESCRIPTION,
                        CONSOLIDATED_COLLATERAL_CODE,
                        PRI_COLLATSTATE,
                        UNSECURED_INDICATOR,
                        IS_ORIG,
                        LINE_TERM
                    FROM
                    (
                    SELECT *
                    FROM
                        (SELECT
                        ASOFDATE,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        MASTER_CUSTOMER_ID,
                        COSTCENTER,
                        UTILIZATIONLCAMOUNT,
                        LOCAL_NPL_FLAG,
                        PRI_COLLATVALUE,
                        SRR,
                        SOURCEID,
                        FAS114_STATUS,
                        UTILIZATIONBOOKBALANCE,
                        CALCULATED_LINE,
                        UTILIZATIONOPENDATE,
                        TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                        TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                        TO_CHAR(EAD) AS EAD,
                        TO_CHAR(LGD) AS LGD,
                        TO_CHAR(PD) AS PD,
                        MAXIMUMMATURITYDATE,
                        CURRENTOCCUPANCY,
                        CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                        UNIQUE_FACILITY_ID,
                        UNIQUEID,
                        TDR,
                        PROPERTY_TYPE_MAP,
                        BINDINGINDICATOR,
                        TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                        FACILITYTYPE,
                        SICCODE,
                        RETYPE,
                        COLLATERALCODE,
                        COLLATERAL_DESCRIPTION,
                        CONSOLIDATED_COLLATERAL_CODE,
                        PRI_COLLATSTATE,
                        UNSECURED_INDICATOR,
                        'N' AS IS_ORIG
                    FROM {}
                    WHERE
                    ASOFDATE = '{}'
                    AND (
                        FAS114_STATUS = 'A - NOT REQUIRED'
                        AND
                        LOCAL_NPL_FLAG = 'N'
                        )
                    AND
                    UPPER(SOURCEID) NOT IN ('OFFLINE')) anchor
                    LEFT JOIN
                    (SELECT *
                    FROM
                    ((SELECT 
                         UNIQUEIDENTIFIER, LINE_TERM
                     FROM MV_FE_CCMIS_REVOLVE
                     WHERE REPORTING_DATE = '{}')
                     UNION ALL
                     (SELECT 
                         UNIQUEIDENTIFIER, LINE_TERM
                     FROM MV_FE_CCMIS_TERM_LOAN
                     WHERE REPORTING_DATE = '{}')
                    ) 
                    ) fe
                     ON 
                     anchor.UNIQUEID = fe.UNIQUEIDENTIFIER
                    ))
                    UNION ALL
                    (SELECT
                        ASOFDATE,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        MASTER_CUSTOMER_ID,
                        COSTCENTER,
                        UTILIZATIONLCAMOUNT,
                        LOCAL_NPL_FLAG,
                        PRI_COLLATVALUE,
                        SRR,
                        SOURCEID,
                        FAS114_STATUS,
                        UTILIZATIONBOOKBALANCE,
                        CALCULATED_LINE,
                        UTILIZATIONOPENDATE,
                        TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                        TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                        TO_CHAR(EAD) AS EAD,
                        TO_CHAR(LGD) AS LGD,
                        TO_CHAR(PD) AS PD,
                        MAXIMUMMATURITYDATE,
                        CURRENTOCCUPANCY,
                        CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                        UNIQUE_FACILITY_ID AS UNIQUE_FACILITY_ID,
                        UNIQUEID,
                        TDR,
                        PROPERTY_TYPE_MAP,
                        BINDINGINDICATOR,
                        TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                        FACILITYTYPE,
                        SICCODE,
                        RETYPE,
                        COLLATERALCODE,
                        COLLATERAL_DESCRIPTION,
                        CONSOLIDATED_COLLATERAL_CODE,
                        PRI_COLLATSTATE,
                        UNSECURED_INDICATOR,
                        'Y' AS IS_ORIG,
                        NULL AS LINE_TERM
                    FROM {}
                    WHERE
                        ASOFDATE = '{}')
                )
                WHERE
                    (
                        (
                            FAS114_STATUS = 'A - NOT REQUIRED'
                            AND
                            LOCAL_NPL_FLAG = 'N'
                        )
                    )
                    AND
                    UPPER(SOURCEID) NOT IN ('OFFLINE')
                    {}
                    {}
                GROUP BY
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    LOCAL_NPL_FLAG,
                    SOURCEID,
                    FAS114_STATUS,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EAD,
                    LGD,
                    PD,
                    UNIQUE_FACILITY_ID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    IS_ORIG,
                    LINE_TERM
                HAVING
                    (
                    SUM(CALCULATED_LINE) > 0
                    OR 
                    SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
                    )
            """.format(
                self.__anchor_table_name,
                date2OracleSTR(self.__asofdate),
                date2OracleSTR(self.__asofdate),
                date2OracleSTR(self.__asofdate),
                self.__orig_table_name,
                date2OracleSTR(self.__asofdate),
                " AND PD_GROUP IN "+to_sql_array(a=self.__pd_groups, quote=True) if len(self.__pd_groups)>0 else "",
                " AND ROWNUM <= " + str(int(self.limit_contracts)) if self.limit_contracts is not None else ""
            )       
#        print(query)
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Executing query..."
            )
            # print(query)
        cursor.execute(query)
        tmp_data = pd.DataFrame(
            cursor.fetchall(),
            columns=[item[0] for item in cursor.description]
        )
        
        # added 02072018: If LINE_TERM=”TermedOutLine”, Overwrite CALCULATED_LINE as (UTILIZATIONBOOKBALANCE+UTILIZATIONLCAMOUNT)
        if self.__overwrite_calculated_line:
            def overwrite_exposure(line):
                if line['LINE_TERM'] == 'TermedOutLine':
                    return (line['BOOKBALANCE'] + line['LCAMOUNT'])
                else:
                    return (line['EXPOSURE'])
            tmp_data["EXPOSURE_NEW"] = tmp_data.apply(func=overwrite_exposure,axis=1)
            tmp_data["EXPOSURE"] = tmp_data["EXPOSURE_NEW"] 
            tmp_data.drop(['LINE_TERM', 'EXPOSURE_NEW'], axis=1, inplace = True)

        # Check for duplicates
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Checking for integrity..."
            )
        dups = tmp_data.duplicated([
            'ASOFDATE',
            'SOURCEID',
            'ONEOBLIGORNUMBER',
            'CUSTOMERNUMBER',
            'FACILITYNUMBER',
            'IS_ORIG'
        ])
        dups_index = list(dups[dups == True].index)
        if self.debug & (len(dups_index) != 0):
            print(
                self.__class__.__name__ + " : " +
                "Found duplicates..."
            )
            print(dups[dups == True])

        # Replace None with NaN
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Replace None with NaN..."
            )
        pd.set_option('mode.chained_assignment', None) # Temp removal of warnings
        tmp_data.fillna(value=np.nan, inplace=True)
        pd.set_option('mode.chained_assignment', 'warn') # Reestablish warning message

        # Remove originations
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Remove originations..."
            )
        if not self.include_originations:
            tmp_data = tmp_data[tmp_data['IS_ORIG'] == 'N']

        # TEMPORARY FIX
        if self.__asofdate == datetime.datetime(2017,2,28):
            tmp_data = tmp_data[tmp_data["ONEOBLIGORNUMBER"] != '0052690273']

        # Clean up and finalize
        if len(dups_index) != 0:
            # raise ValueError('Found duplicated records in index/indeces: {}'.format(dups_index))
            print('Found duplicated records in index/indeces: {}'.format(dups_index))
            self.__data = tmp_data
        else:
            self.__data = tmp_data
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Data fetch completed."
            )
    def fetchUtilizationLevelData(self):
        cursor = self.__connection.cursor()
        query = """
            SELECT
                ASOFDATE,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                MASTER_CUSTOMER_ID,
                COSTCENTER,
                UTILIZATIONNUMBER,
                UTILIZATIONLCAMOUNT AS LCAMOUNT,
                LOCAL_NPL_FLAG,
                PRI_COLLATVALUE AS PRI_COLLATVALUE,
                SRR,
                UPPER(SOURCEID) AS SOURCEID,
                FAS114_STATUS,
                UTILIZATIONBOOKBALANCE AS BOOKBALANCE,
                CALCULATED_LINE AS EXPOSURE,
                UTILIZATIONOPENDATE AS OPENDATE,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EAD,
                LGD,
                PD,
                MAXIMUMMATURITYDATE AS MAXIMUMMATURITYDATE,
                CURRENTOCCUPANCY AS CURRENTOCCUPANCY,
                PRI_COLLATNOI AS PRI_COLLATNOI,
                UNIQUE_FACILITY_ID,
                UNIQUEID,
                TDR,
                PROPERTY_TYPE_MAP,
                BINDINGINDICATOR,
                PD_GROUP,
                FACILITYTYPE,
                SICCODE,
                RETYPE,
                COLLATERALCODE,
                COLLATERAL_DESCRIPTION,
                CONSOLIDATED_COLLATERAL_CODE,
                PRI_COLLATSTATE,
                UNSECURED_INDICATOR,
                IS_ORIG
            FROM (
                (SELECT
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    MASTER_CUSTOMER_ID,
                    COSTCENTER,
                    UTILIZATIONNUMBER,
                    UTILIZATIONLCAMOUNT,
                    LOCAL_NPL_FLAG,
                    PRI_COLLATVALUE,
                    SRR,
                    SOURCEID,
                    FAS114_STATUS,
                    UTILIZATIONBOOKBALANCE,
                    CALCULATED_LINE,
                    UTILIZATIONOPENDATE,
                    TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                    TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                    TO_CHAR(EAD) AS EAD,
                    TO_CHAR(LGD) AS LGD,
                    TO_CHAR(PD) AS PD,
                    MAXIMUMMATURITYDATE,
                    CURRENTOCCUPANCY,
                    CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                    UNIQUE_FACILITY_ID,
                    UNIQUEID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    'N' AS IS_ORIG
                FROM {}
                WHERE
                    ASOFDATE = '{}')
                UNION ALL
                (SELECT
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    MASTER_CUSTOMER_ID,
                    COSTCENTER,
                    UTILIZATIONNUMBER,
                    UTILIZATIONLCAMOUNT,
                    LOCAL_NPL_FLAG,
                    PRI_COLLATVALUE,
                    SRR,
                    SOURCEID,
                    FAS114_STATUS,
                    UTILIZATIONBOOKBALANCE,
                    CALCULATED_LINE,
                    UTILIZATIONOPENDATE,
                    TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                    TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                    TO_CHAR(EAD) AS EAD,
                    TO_CHAR(LGD) AS LGD,
                    TO_CHAR(PD) AS PD,
                    MAXIMUMMATURITYDATE,
                    CURRENTOCCUPANCY,
                    CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                    UNIQUE_FACILITY_ID AS UNIQUE_FACILITY_ID,
                    UNIQUEID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    'Y' AS IS_ORIG
                FROM {}
                WHERE
                    ASOFDATE = '{}')
            )
            WHERE
                (
                    (
                        FAS114_STATUS = 'A - NOT REQUIRED'
                        AND
                        LOCAL_NPL_FLAG = 'N'
                    )
                )
                AND UPPER(SOURCEID) NOT IN ('OFFLINE')
                AND CALCULATED_LINE > 0
                {}
                {}

        """.format(
            self.__anchor_table_name,
            date2OracleSTR(self.__asofdate),
            self.__orig_table_name,
            date2OracleSTR(self.__asofdate),
            " AND PD_GROUP IN "+to_sql_array(a=self.__pd_groups, quote=True) if len(self.__pd_groups)>0 else "",
            " AND ROWNUM <= " + str(int(self.limit_contracts)) if self.limit_contracts is not None else ""
        )
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Executing query..."
            )
            # print(query)
        cursor.execute(query)
        tmp_data = pd.DataFrame(
            cursor.fetchall(),
            columns=[item[0] for item in cursor.description]
        )

        # Check for duplicates
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Checking for integrity..."
            )
        dups = tmp_data.duplicated([
            'ASOFDATE',
            'SOURCEID',
            'ONEOBLIGORNUMBER',
            'CUSTOMERNUMBER',
            'FACILITYNUMBER',
            'UTILIZATIONNUMBER',
            'IS_ORIG'
        ])
        dups_index = list(dups[dups == True].index)
        if self.debug & (len(dups_index) != 0):
            print(
                self.__class__.__name__ + " : " +
                "Found duplicates..."
            )
            print(dups[dups == True])

        # Replace None with NaN
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Replace None with NaN..."
            )
        pd.set_option('mode.chained_assignment', None) # Temp removal of warnings
        tmp_data.fillna(value=np.nan, inplace=True)
        pd.set_option('mode.chained_assignment', 'warn') # Reestablish warning message

        # Remove originations
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Remove originations..."
            )
        if not self.include_originations:
            tmp_data = tmp_data[tmp_data['IS_ORIG'] == 'N']

        # TEMPORARY FIX
        if self.__asofdate == datetime.datetime(2017,2,28):
            tmp_data = tmp_data[tmp_data["ONEOBLIGORNUMBER"] != '0052690273']

        # Clean up and finalize
        if len(dups_index) != 0:
            # raise ValueError('Found duplicated records in index/indeces: {}'.format(dups_index))
            print('Found duplicated records in index/indeces: {}'.format(dups_index))
            self.__data = tmp_data
        else:
            self.__data = tmp_data
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Data fetch completed."
            )
            
    def fetchCNIData(self):
        cursor = self.__connection.cursor()
        query = """
            SELECT
                ASOFDATE,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                MAX(MASTER_CUSTOMER_ID) AS MASTER_CUSTOMER_ID,
                MAX(COSTCENTER) AS COSTCENTER,
                SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                LOCAL_NPL_FLAG,
                MAX(PRI_COLLATVALUE) AS PRI_COLLATVALUE,
                ROUND(MAX(SRR), 1) AS SRR,
                UPPER(SOURCEID) AS SOURCEID,
                FAS114_STATUS,
                SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                SUM(CALCULATED_LINE) AS EXPOSURE,
                MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EAD,
                LGD,
                PD,
                MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                MAX(CURRENTOCCUPANCY) AS CURRENTOCCUPANCY,
                MAX(PRI_COLLATNOI) AS PRI_COLLATNOI,
                UNIQUE_FACILITY_ID,
                TDR,
                PROPERTY_TYPE_MAP,
                BINDINGINDICATOR,
                MAX(PD_GROUP) AS PD_GROUP,
                FACILITYTYPE,
                SICCODE,
                RETYPE,
                COLLATERALCODE,
                COLLATERAL_DESCRIPTION,
                CONSOLIDATED_COLLATERAL_CODE,
                PRI_COLLATSTATE,
                UNSECURED_INDICATOR,
                IS_ORIG,
                StatementDate,
                StatementMonths,
                AuditMethod,
                StatementID,
                EBITDA,
                InterestExpense,
                CashAndEquivs,
                NetTradeAcctsRec,
                TotalCurLiabs,
                ProfitBeforeTax,
                NetSales,
                DebtToTNW
            FROM (
                (SELECT
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    MASTER_CUSTOMER_ID,
                    COSTCENTER,
                    UTILIZATIONLCAMOUNT,
                    LOCAL_NPL_FLAG,
                    PRI_COLLATVALUE,
                    SRR,
                    SOURCEID,
                    FAS114_STATUS,
                    UTILIZATIONBOOKBALANCE,
                    CALCULATED_LINE,
                    UTILIZATIONOPENDATE,
                    TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                    TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                    TO_CHAR(EAD) AS EAD,
                    TO_CHAR(LGD) AS LGD,
                    TO_CHAR(PD) AS PD,
                    MAXIMUMMATURITYDATE,
                    CURRENTOCCUPANCY,
                    CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                    UNIQUE_FACILITY_ID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    'N' AS IS_ORIG,
                    STATEMENTDATE AS StatementDate,
                        TO_NUMBER(STATEMENTMONTHS) AS StatementMonths,
                        AUDITMETHOD AS AuditMethod,
                        TO_NUMBER(STATEMENTID) AS StatementID,
                        TO_NUMBER(REPLACE(EBITDA, ',','')) AS EBITDA,
                        TO_NUMBER(REPLACE(INTERESTEXPENSE, ',','')) AS InterestExpense,
                        TO_NUMBER(REPLACE(CASHANDEQUIVS, ',','')) AS CashAndEquivs,
                        TO_NUMBER(REPLACE(NETTRADEACCTSREC, ',','')) AS NetTradeAcctsRec,
                        TO_NUMBER(REPLACE(TOTALCURLIABS, ',','')) AS TotalCurLiabs,
                        TO_NUMBER(REPLACE(PROFITBEFORETAX, ',','')) AS ProfitBeforeTax,
                        TO_NUMBER(REPLACE(NETSALES, ',','')) AS NetSales,
                        TO_NUMBER(REPLACE(DEBTTOTNW, ',','')) AS DebtToTNW
                FROM {}
                WHERE
                    ASOFDATE = '{}')
                UNION ALL
                (SELECT
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    MASTER_CUSTOMER_ID,
                    COSTCENTER,
                    UTILIZATIONLCAMOUNT,
                    LOCAL_NPL_FLAG,
                    PRI_COLLATVALUE,
                    SRR,
                    SOURCEID,
                    FAS114_STATUS,
                    UTILIZATIONBOOKBALANCE,
                    CALCULATED_LINE,
                    UTILIZATIONOPENDATE,
                    TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                    TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                    TO_CHAR(EAD) AS EAD,
                    TO_CHAR(LGD) AS LGD,
                    TO_CHAR(PD) AS PD,
                    MAXIMUMMATURITYDATE,
                    CURRENTOCCUPANCY,
                    CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                    UNIQUE_FACILITY_ID AS UNIQUE_FACILITY_ID,
                    TDR,
                    PROPERTY_TYPE_MAP,
                    BINDINGINDICATOR,
                    TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                    FACILITYTYPE,
                    SICCODE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    'Y' AS IS_ORIG,
                    STATEMENTDATE AS StatementDate,
                        TO_NUMBER(STATEMENTMONTHS) AS StatementMonths,
                        AUDITMETHOD AS AuditMethod,
                        TO_NUMBER(STATEMENTID) AS StatementID,
                        TO_NUMBER(REPLACE(EBITDA, ',','')) AS EBITDA,
                        TO_NUMBER(REPLACE(INTERESTEXPENSE, ',','')) AS InterestExpense,
                        TO_NUMBER(REPLACE(CASHANDEQUIVS, ',','')) AS CashAndEquivs,
                        TO_NUMBER(REPLACE(NETTRADEACCTSREC, ',','')) AS NetTradeAcctsRec,
                        TO_NUMBER(REPLACE(TOTALCURLIABS, ',','')) AS TotalCurLiabs,
                        TO_NUMBER(REPLACE(PROFITBEFORETAX, ',','')) AS ProfitBeforeTax,
                        TO_NUMBER(REPLACE(NETSALES, ',','')) AS NetSales,
                        TO_NUMBER(REPLACE(DEBTTOTNW, ',','')) AS DebtToTNW
                FROM {}
                WHERE
                    ASOFDATE = '{}')
            )
            WHERE
                (
                    (
                        FAS114_STATUS = 'A - NOT REQUIRED'
                        AND
                        LOCAL_NPL_FLAG = 'N'
                    )
                )
                AND
                UPPER(SOURCEID) NOT IN ('OFFLINE')
                {}
                {}
            GROUP BY
                ASOFDATE,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                LOCAL_NPL_FLAG,
                SOURCEID,
                FAS114_STATUS,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EAD,
                LGD,
                PD,
                UNIQUE_FACILITY_ID,
                TDR,
                PROPERTY_TYPE_MAP,
                BINDINGINDICATOR,
                FACILITYTYPE,
                SICCODE,
                RETYPE,
                COLLATERALCODE,
                COLLATERAL_DESCRIPTION,
                CONSOLIDATED_COLLATERAL_CODE,
                PRI_COLLATSTATE,
                UNSECURED_INDICATOR,
                IS_ORIG,
                StatementDate,
                EBITDA,
                InterestExpense,
                CashAndEquivs,
                NetTradeAcctsRec,
                TotalCurLiabs,
                ProfitBeforeTax,
                NetSales,
                DebtToTNW,
                StatementMonths,
                AuditMethod,
                StatementID
            HAVING
                (
                SUM(CALCULATED_LINE) > 0
                OR 
                SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
                )
        """.format(
            self.__anchor_table_name,
            date2OracleSTR(self.__asofdate),
            self.__orig_table_name,
            date2OracleSTR(self.__asofdate),
            " AND PD_GROUP IN "+to_sql_array(a=self.__pd_groups, quote=True) if len(self.__pd_groups)>0 else "",
            " AND ROWNUM <= " + str(int(self.limit_contracts)) if self.limit_contracts is not None else ""
        )
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Executing query: fetch C&I master data and financials from RFO..."
            )
            # print(query)
        cursor.execute(query)
        tmp_data = pd.DataFrame(
            cursor.fetchall(),
            columns=[item[0] for item in cursor.description]
        )

        # Check for duplicates
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Checking for integrity..."
            )
        dups = tmp_data.duplicated([
            'ASOFDATE',
            'SOURCEID',
            'ONEOBLIGORNUMBER',
            'CUSTOMERNUMBER',
            'FACILITYNUMBER',
            'IS_ORIG'
        ])
        dups_index = list(dups[dups == True].index)
        if self.debug & (len(dups_index) != 0):
            print(
                self.__class__.__name__ + " : " +
                "Found duplicates..."
            )
            print(dups[dups == True])

        # Replace None with NaN
        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Replace None with NaN..."
            )
        pd.set_option('mode.chained_assignment', None) # Temp removal of warnings
        tmp_data.fillna(value=np.nan, inplace=True)
        pd.set_option('mode.chained_assignment', 'warn') # Reestablish warning message

        # Remove originations
        if self.debug & (not self.include_originations):
            print(
                self.__class__.__name__ + " : " +
                "Remove originations..."
            )
        if not self.include_originations:
            tmp_data = tmp_data[tmp_data['IS_ORIG'] == 'N']

        # TEMPORARY FIX
        if self.__asofdate == datetime.datetime(2017,2,28):
            tmp_data = tmp_data[tmp_data["ONEOBLIGORNUMBER"] != '0052690273']

        # Clean up and finalize
        if len(dups_index) != 0:
            # raise ValueError('Found duplicated records in index/indeces: {}'.format(dups_index))
            print('Found duplicated records in index/indeces: {}'.format(dups_index))
            self.__data = tmp_data
        else:
            self.__data = tmp_data
        self.__data.rename(
                     index=str,
                     columns={
                              'STATEMENTID' : 'StatementID',
                              'STATEMENTDATE' : 'StatementDate',
                              'STATEMENTMONTHS' : 'StatementMonths',
                              'AUDITMETHOD' : 'AuditMethod',
                              'EBITDA' : 'EBITDA',
                              'INTERESTEXPENSE' : 'InterestExpense',
                              'CASHANDEQUIVS' : 'CashAndEquivs',
                              'NETTRADEACCTSREC' : 'NetTradeAcctsRec',
                              'TOTALCURLIABS' : 'TotalCurLiabs',
                              'PROFITBEFORETAX' : 'ProfitBeforeTax',
                              'NETSALES' : 'NetSales',
                              'DEBTTOTNW' : 'DebtToTNW'
                     },
                     inplace = True
            )
#        # Parse date fields
#        parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S.%f')
#        self.__data["StatementDate"] = self.__data["StatementDate"].apply(parse_date)
#        self.__data["ASOFDATE"] = self.__data["ASOFDATE"].apply(parse_date)
#        self.__data["MAXIMUMMATURITYDATE"] = self.__data["MAXIMUMMATURITYDATE"].apply(parse_date)

        if self.debug:
            print(
                self.__class__.__name__ + " : " +
                "Data fetch completed."
            )
   



