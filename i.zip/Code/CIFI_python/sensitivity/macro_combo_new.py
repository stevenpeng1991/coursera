# -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 14:44:20 2018

@author: n838126


[(0.40870684093651494, 31487774.158666596),
 (0.25541892749023504, 19678098.576066226),
 (0.17237936022546474, 13280527.313801397),
 (0.16349487134778531, 12596044.571465774)]        
##############################
        test
##############################
variables = macrovariables_list['2016-SBNA-Loss-Commercial-CRE']
#SA
all_combos = generateCombo(variables,scenarios=[SCENARIO[0],SCENARIO[1]],driver=['FLBR_US','FZFL075035503Q_US','FHOFHOPIQ_US'])
#BASE
all_combos = generateCombo(variables,scenarios=[SCENARIO[0],SCENARIO[1]],driver=['FLBR_US','FZFL075035503Q_US','FRTB3M_US'])

cf_container = sensitivityOutput(all_combos,portfolio='CRE')

anchor_data = getAnchor(portfolio='CRE')  

# balance walk result    

balance_walk_sensitivity=balanceWalk(cf_container,anchor_data)
result = result(balance_walk_sensitivity,bw_mode=1,pd_group=['CRE_MULTIFAMILY'])

benchmark={'FRB_BASE': 26585072.37 ,'FRB_ADVERSE':103627516.99}
# get final result
final_result = getContribution(benchmark,result) 


##############################
        Example
##############################
# CRE
s = SensitivityProcessor(
        as_of_date = datetime.datetime(2017,12,31),
        portfolio_snapshot_date = datetime.datetime(2017,12,31),
        scenario_date = datetime.datetime(2017,12,31),
        forecast_periods = 27,
        stress_testing_cycle = 'CCAR2018',
        portfolio = 'CRE',
        scenarios=['FRB_ADVERSE','FRB_SA'],
        scenario_severity_level='STRESS',
        cre_mf_stress_switch = True,
        cre_risk_rating_dataset_input_path='I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cre_dec_2017.xlsx',
        driver = ['FLBR_US'],
        pd_group = 'CRE_MULTIFAMILY'
        )

# C&I 
s = SensitivityProcessor(
        as_of_date = datetime.datetime(2017,12,31),
        portfolio_snapshot_date = datetime.datetime(2017,12,31),
        scenario_date = datetime.datetime(2017,12,31),
        forecast_periods = 27,
        stress_testing_cycle = 'CCAR2018',
        portfolio = 'CNI',
        scenarios=['FRB_BASE','FRB_ADVERSE'],
        scenario_severity_level='ADVERSE',
        cni_risk_rating_dataset_input_path='I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cni_dec_2017.xlsx',
        statement_days_threshold = 546,
        driver = ['FHOFHOPIQ_US', 'FLBR_US'],
        pd_group = ['ABL'],
        bw_mode = 1
        )
# CRE_Construction
s = SensitivityProcessor(
        as_of_date = datetime.datetime(2017,12,31),
        portfolio_snapshot_date = datetime.datetime(2017,12,31),
        scenario_date = datetime.datetime(2017,12,31),
        forecast_periods = 27,
        stress_testing_cycle = 'CCAR2018',
        portfolio = 'CRE_CONSTRUCTION',
        scenarios=['FRB_ADVERSE','FRB_SA'],
        scenario_severity_level='STRESS',
        driver = None,
        bw_mode = 1
        )
# CEVF_RETAIL
s = SensitivityProcessor(
        as_of_date = datetime.datetime(2017,12,31),
        portfolio_snapshot_date = datetime.datetime(2017,12,31),
        scenario_date = datetime.datetime(2017,12,31),
        forecast_periods = 27,
        stress_testing_cycle = 'CCAR2018',
        portfolio = 'CEVF_RETAIL',
        scenarios=['FRB_ADVERSE','FRB_SA'],
        scenario_severity_level='STRESS',
        driver = ['bond_spread_lag_diff'],
        bw_mode = 1
        )

result= s.execute()

# C&I benchmark
result_filter = s.resultFilter(s.pivot_bw_result,s.bw_mode,pd_group=['BUSINESS_BANKING'])
benchmark={'FRB_ADVERSE': 36002255.6082265 ,'FRB_SA':93740804.3494171}  # UBB
benchmark={'FRB_ADVERSE': 12240309.1199598 ,'FRB_SA':25002958.3448536}  # ABL
benchmark={'FRB_ADVERSE': 73522607.5873539 ,'FRB_SA':204814255.775479}  # MM

benchmark={'FRB_BASE': 17788105.0693175 ,'FRB_ADVERSE':36002255.6082265}  # UBB
benchmark={'FRB_BASE': 6724942.05887322 ,'FRB_ADVERSE':12240309.1199598}  # ABL
benchmark={'FRB_BASE': 33540950.6970353 ,'FRB_ADVERSE':73522607.5873539}  # MM

# CRE_CONSTRUCTION benchmark
result_filter = s.resultFilter(s.pivot_bw_result,s.bw_mode,pd_group=['CRE_CONSTRUCTION'])
benchmark={'FRB_ADVERSE': 19863208.0598732 ,'FRB_SA':51697930.4529876}  # CRE_CONSTRUCTION
benchmark={'FRB_SA':51697930.4529876 ,'BHC_STRESS':41717375.1723799}  # CRE_CONSTRUCTION

# CEVF_RETAIL benchmark
result_filter = s.resultFilter(s.pivot_bw_result,s.bw_mode,pd_group=['CEVF_RETAIL'])
benchmark={'FRB_ADVERSE': 19365315.3290491 ,'FRB_SA':45780256.7895733}  # CEVF_RETAIL
benchmark={'FRB_SA':45780256.7895733 ,'BHC_STRESS':42404000.5508646}  # CEVF_RETAIL

# get final result
final_result = s.getContribution(benchmark,result_filter) 

cni_risk_rating_dataset_input_path='I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cni_dec_2017_current.xlsx'
statement_days_threshold = 546

industrytag_file = 'I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx'


"""
import copy
import os
import sys
global WD
WD = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if WD not in sys.path:
    sys.path.append(WD)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import time
import pandas as pd
from CIFI.config import CONFIG
from tinydb import TinyDB, Query

##
## IMPORT MODULES (MODELS AND EJMS)
##
from CIFI.controllers.models.creconstruction17 import CREConstruction
from CIFI.controllers.models.logitmodel import TwoFLogitModel
from CIFI.controllers.ejm.ejmmaster import EJMGenerator, ejmDictionaryGenerator
from CIFI.controllers.models.riskratingmodel import RiskRatingModel
from CIFI.controllers.models.gcbindustry import GCBModel
from CIFI.controllers.models.cniriskrating import CNIModel

## IMPORT Balance Walk module
from CIFI.sensitivity import balancewalk
from CIFI.sensitivity.triple_plot import triple_sensitivity_plot

def getPlot(base_adverse_result,adverse_sa_result):        
    variables_name = ['FRB BASE', 'HPI', 'Unemployment Rate','Others','FRB ADVERSE', 'HPI', 'Unemployment Rate','Others','FRB SA']
    values = [i[1] for i in base_adverse_result['result']] + [i[1] for i in adverse_sa_result['result'][1:]]
    pct_value = [i[0] for i in base_adverse_result['singleInput']] + [i[0] for i in adverse_sa_result['result'][1:]]
    sensitivity_plot = triple_sensitivity_plot(names = variables_name,value=values,pct_value= pct_value,title = 'Sensitivity',dollar_ind = True )
    sensitivity_plot.savefig('Sensitivity.png')

MODEL_NAME={
 'CEVF_RETAIL':'53 - Scenario Analysis Model - CEVF PD - SBNA',
 'CRE': '2016-SBNA-Loss-Commercial-CRE',
 'GCB': '2016-SBNA-Loss-Commercial-GCB',
 'CRE_CONSTRUCTION': '2016-SBNA-Loss-Commercial-CREConstruction',
 'CNI': '743 - Commercial Rating Model - C&I PD - SBNA'}
 


class SensitivityProcessor:
    def __init__(
            self,
            as_of_date,
            portfolio_snapshot_date,
            scenario_date,
            forecast_periods,
            stress_testing_cycle,
            scenarios,
            scenario_severity_level,
            portfolio,
            driver,
            bw_mode = 1,
            **kwargs
            ):

        self.as_of_date = as_of_date
        self.portfolio_snapshot_date = portfolio_snapshot_date
        self.scenario_date = scenario_date
        self.forecast_periods = forecast_periods
        self.stress_testing_cycle = stress_testing_cycle
        self.scenarios = scenarios
        self.scenario_severity_level = scenario_severity_level
        self.portfolio = portfolio
        self.driver = driver
        self.bw_mode = bw_mode
        self.cni_risk_rating_dataset_input_path = kwargs.get("cni_risk_rating_dataset_input_path")
        self.cre_risk_rating_dataset_input_path = kwargs.get("cre_risk_rating_dataset_input_path")
        self.cre_mf_stress_switch = kwargs.get("cre_mf_stress_switch")        
        self.statement_days_threshold = kwargs.get("statement_days_threshold")
        self.industrytag_file = kwargs.get("industrytag_file")
        self.pd_group = kwargs.get("pd_group")
        self.benchmark = kwargs.get("benchmark")
        
    @property
    def macro_variables(self):
        return(self.getMacroVariables(self.portfolio))
                
    @property
    def all_combos(self):
        if self.portfolio == 'CEVF_RETAIL':
            all_combos = self.generateCombo(variables=['FLBR_US', 'bond_spread_lag_diff'],scenarios=[self.scenarios[0],self.scenarios[1]],driver=self.driver)
        else:
            all_combos = self.generateCombo(variables=self.macro_variables,scenarios=[self.scenarios[0],self.scenarios[1]],driver=self.driver)
        return(all_combos)
        
    def getMacroVariables(self,portfolio):
        if portfolio not in ['CEVF_RETAIL','CRE','GCB','CRE_CONSTRUCTION','CNI']:
            raise ValueError('Portfolio is not CEVF_RETAIL,CRE,CRE_CONSTRUCTION,GCB or CNI.Please try again.')
            
        # Pull Macro list for portfolio from json file
        path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
        db = TinyDB(path_to_model_properties) 
        macrovariables_list={}
        for model in MODEL_NAME.values():
            macrovariables_list[model]=list(set([variable['macro_variable_name'] for variable in db.search((Query().version_date=='12/31/2017')&(Query().name=='macro_variables')&(Query().model_id== model))[0]['value']]))
        return(macrovariables_list[MODEL_NAME[portfolio]])        

   
    def generateCombo(self,variables,scenarios,driver=None,style='One'):
        if isinstance(scenarios, str) or len(scenarios) == 1:
            return {i: scenarios for i in variables} 
        elif isinstance(scenarios, list):
            # change one variable at a time
            if style == 'One': 
                if driver != None:
                    change_variables = driver                
                else:
                    change_variables = variables                
                all_combo = []
                for i in range(1,len(scenarios)):
                    raw_combo = {v: scenarios[i-1] for v in variables}                                         
                    for variable in change_variables:
                        raw_combo_new = copy.deepcopy(raw_combo)
                        raw_combo_new[variable] = scenarios[i]
                        all_combo.append(raw_combo_new) 
                    # if you specify some variables as driver, the rest changes as a group
                    if driver != None:
                        all_combo.append({v: scenarios[i-1] if v in (driver) else scenarios[i]for v in variables})   
                return(all_combo)
            else:            
                return(None)
        else:            
            return('Scenario type is not correct')        
            
    #####################
    ### Anchor Data ####
    #####################  
    def getAnchor(self,portfolio):
        # Get balance walk anchor dataset 
        if portfolio in ('CRE','CNI'):
            pd_groups = []
            only_risk_rating = True
            risk_rating_switch = True
            if self.portfolio == 'CRE':
                cni_dataset_path = None
                cre_dataset_path = self.cre_risk_rating_dataset_input_path
            else:
                cre_dataset_path = None  
                cni_dataset_path = self.cni_risk_rating_dataset_input_path
        else:
            pd_groups = [portfolio]
            only_risk_rating = False
            risk_rating_switch = False
            cni_dataset_path = None
            cre_dataset_path = None  
            
        anchor_data=balancewalk.getBWFormatAnchorData(
            as_of_date= self.portfolio_snapshot_date,
            pd_groups=pd_groups,
            risk_rating_switch = risk_rating_switch,
            cni_dataset_path = cni_dataset_path, 
            cre_dataset_path = cre_dataset_path,
            overwrite_calculated_line = True,
            only_risk_rating = only_risk_rating,
            debug=False
            ) 
        
        return(anchor_data)
               
    #####################
    ### Balance Walk ####
    #####################               
    def sensitivityOutput(self,all_combos,portfolio):        
        cf_container = []
        transformed_macro_series_list = []
        self.driver = []

        # Get LGD/EAD from EJM master for CEVF_RETAIL/CRE_Construction
        if portfolio in ['CRE_CONSTRUCTION', 'CEVF_RETAIL']:
            ejm_instance = EJMGenerator(
                as_of_date = self.as_of_date,
                ejm_dictionary=ejmDictionaryGenerator(
                    asofdate = self.portfolio_snapshot_date,
                    version_date=self.as_of_date,
                    scenario_pairs = {
                        self.scenario_severity_level:self.scenarios[1]
                    },
                    pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
                    rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
                    ejm_master_file_path = CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_PATH"],
                    only_run_cevf_creconstruction = True,
                    energy_finance_facility_rate = False,
                    forecast_periods = self.forecast_periods,
                    debug=False
                ),
                forecast_periods=self.forecast_periods,
                process_additional_ead=False,
                debug=False
            )   

        for idx, comb in enumerate(all_combos):
            current_driver = list(pd.Series(comb)[pd.Series(comb).values== self.scenarios[1]].index)
            if len(current_driver) > 1:
                self.driver.append('Other')
            else:
                self.driver.append(current_driver[0])
            print('>>>>Current driver is {}'.format(current_driver))
            
            if portfolio =='CRE':
                if self.stress_testing_cycle == 'CCAR2018':
                    if comb['FZFL075035503Q_US'] == 'BHC_STRESS':
                        CREPI_MULTIFAMILY_SCALAR=[
                                                        215.7,
                                                        220.7,
                                                        212.91060155,
                                                        188.50509395,
                                                        173.19332673,
                                                        151.04388494,
                                                        142.79066312,
                                                        127.63307239,
                                                        121.17749675,
                                                        109.06475059,
                                                        116.03725928,
                                                        117.6368452,
                                                        122.34079311,
                                                        126.53543839,
                                                        131.10649631,
                                                        134.44560066,
                                                        140.2107775,
                                                        144.56752945
                                                  ][:11]    
                    elif comb['FZFL075035503Q_US'] == 'FRB_ADVERSE':
                        CREPI_MULTIFAMILY_SCALAR=[
                                                        215.7,
                                                        220.7,
                                                        193.64108719,
                                                        185.32623251,
                                                        178.75353785,
                                                        173.76462504,
                                                        169.64679225,
                                                        167.1127413,
                                                        165.52895945,
                                                        165.52895945,
                                                        165.52895945,
                                                        166.16247219,
                                                        167.03355221,
                                                        168.1421995,
                                                        169.40922497,
                                                        170.72794611,
                                                        172.09927378,
                                                        173.52415999
                                                  ][:11]
                    elif comb['FZFL075035503Q_US'] == 'FRB_SA':
                        CREPI_MULTIFAMILY_SCALAR=[
                                                        215.7,
                                                        220.7,
                                                        185.32623251,
                                                        163.31166487,
                                                        145.65249731,
                                                        132.42791891,
                                                        121.341446,
                                                        114.76875135,
                                                        110.33416218,
                                                        110.33416218,
                                                        110.41335127,
                                                        112.1555113,
                                                        114.37280588,
                                                        117.3028023,
                                                        120.86631145,
                                                        123.89024991,
                                                        126.3256783,
                                                        128.12950444
                                                  ][:11]   
                    else:
                        CREPI_MULTIFAMILY_SCALAR = None    
                        
                model_instance = RiskRatingModel(
                                        uncertainty_rate=0.00,
                                        as_of_date=self.as_of_date,
                                        dataset_query_date=self.portfolio_snapshot_date,
                                        scenario_date=self.scenario_date,
                                        model_id=MODEL_NAME[portfolio],
                                        scenario=self.scenarios,
                                        scenario_severity_level=self.scenario_severity_level,
                                        scenario_context=self.stress_testing_cycle,
                                        forecast_periods=self.forecast_periods,
                                        ne_scalar=self.cre_mf_stress_switch,
                                        crepi_multifamily_scalar=CREPI_MULTIFAMILY_SCALAR,
                                        debug=True,
                                        bau=None,
                                        origination=False,
                                        book_balance_filter=None,
                                        gl_filter=True,
                                        path_dependent=True,
                                        read_input=True,
                                        dataset_path=self.cre_risk_rating_dataset_input_path,
                                        final_rating_switch = True,
                                        scenario_combinations = comb
                                    )             
            elif portfolio =='CNI':             
                model_instance = CNIModel(
                    as_of_date=self.as_of_date,
                    scenario=self.scenarios,
                    scenario_context=self.stress_testing_cycle,
                    scenario_date=self.scenario_date,
                    scenario_severity_level=self.scenario_severity_level,
                    forecast_periods=self.forecast_periods,
                    forecast_periods_frequency='monthly',
                    pass_srr=4.0,
                    model_id=MODEL_NAME[portfolio],
                    debug=False,
                    include_originations_switch=False,
                    auto_fetch_macros=True,
                    limit_contracts=None,
                    statement_days_threshold=self.statement_days_threshold,
                    portfolio_snapshot_date=self.portfolio_snapshot_date,
                    mature_non_pass_locs=True,
                    scenario_combinations = comb,
                    financial_in_rfo = True,
                    new_financial_logic = True,
                    risk_rating_dataset_input_path = self.cni_risk_rating_dataset_input_path
                )    
            elif portfolio =='GCB':                
                model_instance = GCBModel(
                    as_of_date=self.as_of_date,
                    dataset_query_date=self.portfolio_snapshot_date,
                    scenario_date=self.scenario_date,
                    model_id = MODEL_NAME[portfolio],
                    scenario=self.scenarios,
                    scenario_severity_level=self.scenario_severity_level,
                    scenario_context=self.stress_testing_cycle,
                    forecast_periods=self.forecast_periods,
                    industrytag_file=self.industrytag_file,
                    scenario_combinations = comb
                ) 
            elif portfolio == 'CRE_CONSTRUCTION':
                model_instance = CREConstruction(
                    uncertainty_rate=0.,
                    as_of_date=self.as_of_date,
                    model_id=MODEL_NAME[portfolio],
                    scenario=self.scenarios,
                    scenario_date=self.scenario_date,
                    scenario_context=self.stress_testing_cycle,
                    forecast_periods=self.forecast_periods,
                    scenario_combinations = comb
                )                
                
            elif portfolio == 'CEVF_RETAIL':              
                model_instance = TwoFLogitModel(
                    uncertainty_rate=0.,
                    as_of_date=self.as_of_date,
                    scenario_date=self.scenario_date,
                    model_id= MODEL_NAME[portfolio],
                    scenario=self.scenarios,
                    scenario_context=self.stress_testing_cycle,
                    forecast_periods=self.forecast_periods,
                    scenario_combinations = comb
                )      
            else:
                raise ValueError('Portfolio is not CEVF_RETAIL,CRE,CRE_CONSTRUCTION,GCB or CNI.Please try again.')

            # check macro and transformation
            transformed_macro_series_list.append(model_instance.transformed_macro_series_include_all)
            
            ## Create a session instance and a model shopping cart to run the CNIModel
            ccar_session = CCARSession(
                session_id='CCAR',
                session_date=self.as_of_date
            )
            cart = ModelShoppingCart(ccar_session=ccar_session)
            ## Add model to the shopping cart and execute
            cart.addModel(model_instance)
            if portfolio in ['CRE_CONSTRUCTION', 'CEVF_RETAIL']:
                cart.addModel(ejm_instance)
            cart.checkout() # execute() is called here
            
            ## Get contributor file and store in the cf container
            cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
            cf_container.append(cf.getCFData())
        
            ## reset CF generator and shopping cart
            ccar_session.contributor_file_generator.resetGenerator()
            cart.resetCart()     
            
        return(cf_container)
            

    #####################
    ### Balance Walk ####
    #####################    
    # generate balance walk outputs and combine them 
    def balanceWalk(self,cf_container,anchor_data):
        t0=time.time()
        bw_output_list = []
        pivot_bw_result=pd.DataFrame()
        i = 0
        for cf_data in cf_container:
            print('Running balance walk.......')
            bw_output = balancewalk.balanceWalkMacroSensitivity(
                cf_data = cf_data,
                anchor_data=anchor_data,
                segfield2_to_nco_timing_curve=None,
                process_ALLL_balances = False,
                debug = True
            )      
            bw_output_list.append(bw_output)
            # Pivot balance walk output
            pivot_bw=balancewalk.balanceWalkPivot(bw_output,self.forecast_periods,self.as_of_date,bw_output_from_csv = False)    
            pivot_bw['Driver'] = self.driver[i]
            pivot_bw_result = pivot_bw_result.append(pivot_bw)
            i += 1        
        print('Balance walk completed in ' + str(time.time()-t0) + ' s.')
        return(pivot_bw_result)
        
    def execute(self): 
        print('>>> Get Macro Variable')
        all_combos = self.all_combos
        print('>>> Get Anchor data')
        self.anchor_data = self.getAnchor(portfolio=self.portfolio)
        print('>>> Generate Contributor File')        
        self.cf_container = self.sensitivityOutput(all_combos,portfolio=self.portfolio)
        print('>>> Get Balance work result')         
        self.pivot_bw_result = self.balanceWalk(self.cf_container,self.anchor_data)
        print('>>> Filter result')   
        self.result_filter = self.resultFilter(self.pivot_bw_result,self.bw_mode,pd_group=self.pd_group)
        print('>>> Get Contribution')           
        result = self.getContribution(self.benchmark,self.result_filter)
        return(result)  
        
    def resultFilter(self,bw_result,bw_mode,pd_group=None):
        result = bw_result[(bw_result.index.get_level_values('BW_MODE')==bw_mode)]
        if pd_group != None:
            result = result[result.index.get_level_values('PD_GROUP').isin(pd_group)]
        result = result.sort_values(['LGD(%)'],ascending=False)
        return(result)   
        
    def getContribution(self,benchmark,result):
        benchamrk_dif = benchmark[self.scenarios[1]] - benchmark[self.scenarios[0]]
        result['Loss_dif'] = result['LGDAMOUNT'] - benchmark[self.scenarios[0]]
        result['Contribution(%)'] = result['Loss_dif']/result['Loss_dif'].sum()
        result['Contribution_Amount'] = result['Contribution(%)'] * benchamrk_dif
        return(list(zip(result["Contribution(%)"], result["Contribution_Amount"])))




        