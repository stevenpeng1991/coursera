# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 10:06:00 2017

@author: n838126
"""

'''
SAMPLE USE

AS_OF_DATE1 = datetime.datetime(2016,12,31)
AS_OF_DATE2 = datetime.datetime(2017,12,31)
NAME1 = 'CCAR 2017'
NAME2 = 'CCAR 2018'
PATH2= 'H:/risk_driver/CCAR2018/'
PATH = 'I:\\CRMPO\\CCAR\\4Q17\\10 - Process & Analysis\\Risk Driver\\Result\\'

################################# HELOC #####################################
HELOC_instance = SnapShotCheck(
        portfolio = 'HELOC',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH2+'HELOC',
        entire_pd_groups_switch = True,
        graph_switch = True
        )


HELOC_instance.executeGraph()



################################# MORTGAGE #####################################
MORTGAGE_instance = SnapShotCheck(
        portfolio = 'MORTGAGE',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH2+'MORTGAGE',
        entire_pd_groups_switch = True,
        graph_switch = True
        )

MORTGAGE_instance.executeGraph()
MORTGAGE_instance.average_result

################################# CRE #####################################
CRE_multifamily_instance = SnapShotCheck(
        portfolio = 'CRE',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = True,
        graph_switch = True,
        pd_groups = ['CRE_MULTIFAMILY'],
        graph_switch = True,
        orig = False
        )
CRE_multifamily_instance.executeGraph()

CRE_other_instance = SnapShotCheck(
        portfolio = 'CRE',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups=['CRE_OTHER'],
        graph_switch = True,
        orig = False
        )
CRE_other_instance.executeGraph()

CRE_other_instance.average_result
################################# C&I #####################################
######### Config for C&I ############
FINANCIAL_IN_RFO1 = False
FINANCIAL_IN_RFO2 = True
STATEMENT_DAYS_THRESHOLD1 = 366
STATEMENT_DAYS_THRESHOLD2 = 366

CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = True,
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        )
CNI_instance.executeGraph()

CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups=['ABL'],
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        )

CNI_instance.average_result
################################# Get dataset #################################
## Getting raw dataset
raw_dataset1 = CNI_instance.raw_dataset1
raw_dataset2 = CNI_instance.raw_dataset2

## Getting processed dataset
processed_dataset1 = CNI_instance.processed_dataset1
processed_dataset2 = CNI_instance.processed_dataset2

## Getting final dataset
dataset_with_bin1 = CNI_instance.dataset_with_bin1
dataset_with_bin2 = CNI_instance.dataset_with_bin2


'''

import os
import sys
#wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI'

from CIFI.models.masterdataset.masterdataset_retail import CCMISMasterDataset
from CIFI.controllers.models.cniriskrating import CNIModel, CNIMasterDataset
from CIFI.controllers.models.riskratingmodel import Mapping
import matplotlib.pyplot as plt
from CIFI.config import CONFIG
import datetime
import dateutil.relativedelta as relativedelta
import pandas as pd
import numpy as np
import copy
import _pickle 
#import matplotlib as mpl
#mpl.rcParams.update(mpl.rcParamsDefault) 


##
## GLOBAL VARIABLES
##
global VALID_PORTFOLIO_NAME
VALID_PORTFOLIO_NAME = ['HELOC', 'MORTGAGE']

class SnapShotCheck():
    # Member properties
    raw_dataset1 = None
    raw_dataset2 = None
    processed_dataset1 = None
    processed_dataset2 = None
    dataset_with_bin1 = None
    dataset_with_bin2 = None
    
    # Member methods
    def __init__(
        self,
        portfolio: str,
        asofdate1: datetime.datetime,
        asofdate2: datetime.datetime,
        name1: str,
        name2: str,
        path: str,
        entire_pd_groups_switch=False,
        graph_switch=True,
        orig: bool = False,
        financial_in_rfo1: bool = True,
        financial_in_rfo2: bool = True,
        statement_days_threshold1: int = 366,
        statement_days_threshold2: int = 366,
        **kwargs
    ):
        self.asofdate1 = asofdate1
        self.asofdate2 = asofdate2
        self.name1 = name1
        self.name2 = name2
        self.path = path
        self.orig = orig
        
        self.financial_in_rfo1 = financial_in_rfo1        
        self.financial_in_rfo2 = financial_in_rfo2
        
        self.statement_days_threshold1 = statement_days_threshold1        
        self.statement_days_threshold2 = statement_days_threshold2
        
        self.industrytag_file1 = kwargs.get('industrytag_file1')
        self.industrytag_file2 = kwargs.get('industrytag_file2')
     
        # Validate inputs
        if portfolio not in VALID_PORTFOLIO_NAME:
            raise ValueError("Invalid input of portfolio name. Valid names should be in: {}".format(VALID_PORTFOLIO_NAME))
        
        self.portfolio = portfolio
        self.graph_switch = graph_switch
        self.entire_pd_groups_switch = entire_pd_groups_switch
        # Assign pd groups
        # Aggregate default pd_groups if entire_pd_group_switch is True
#==============================================================================
#         if self.entire_pd_groups_switch == True:
#             self.portfolio_name = self.portfolio
#             if self.portfolio == 'CRE':
#                 self.pd_groups = ['CRE_MULTIFAMILY', 'CRE_OTHER']
#             elif self.portfolio == 'GCB':
#                 self.pd_groups = ['GCB']
#             elif self.portfolio == 'C&I':
#                 self.pd_groups = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL']        
#         else:
#             self.pd_groups = kwargs.get('pd_groups')
#         
#                
#             if len(self.pd_groups)!=1:
#                 raise ValueError ('Invalid pd groups length')
#             # Get portfolio name      
#             split_pd_groups = self.pd_groups[0].split('_')
#             
#             if len(split_pd_groups) > 1:
#                 self.portfolio_name = split_pd_groups[0]+' '+split_pd_groups[1].title()
#             else:
#==============================================================================
                
    def getRawData(self, portfolio, as_of_date, financial_in_rfo):
        print('>>> Fetch {} portfolio : {}'.format(self.portfolio, as_of_date))
        # pull raw data from RFO
        # define data columns
        columns = {'HELOC':[     
                         'SERVICING_ACCT_NUMBER',
                         'LOAN_FK_PK',
                         'CREDIT_SCORE',
                         'CREDIT_ORIG_CLTV',
                         'LOAN_LIEN_POSITION',
                         'LOAN_ORIG_NOTE_DATE',
                         'EFFECTIVE_DATE_PK',
                         'COLLATERAL_STATE',
                         'PD_GROUP',
                         'LOAN_CURR_UPB_AMT'
                         ],
                             
                'MORTGAGE':[    
                         'SERVICING_ACCT_NUMBER',
                         'LOAN_FK_PK',
                         'LOAN_ARM_IND',
                         'CREDIT_ORIG_CLTV',
                         'CREDIT_SCORE',
                         'LOAN_ORIG_NOTE_DATE',
                         'EFFECTIVE_DATE_PK',
                         'SEG_BREAK',
                         'COLLATERAL_STATE',
                         'PD_GROUP',
                         'LOAN_CURR_UPB_AMT'
                        ]} 
        

            
        # Fetch data
        dataset = CCMISMasterDataset(
                            	asofdate = as_of_date,
                            	pd_groups = [self.portfolio],
                            	debug = False
                              ).data[columns[portfolio]]
        return(dataset)
                                     
        

    def processData(self, industrytag_file, portfolio, raw_data, as_of_date): 

        # Get raw dataset
        dataset = raw_data.copy(deep=True) 
        # format data
        
        def getMaturity(maturitydate, as_of_date):
            maxmaturity=maturitydate
            # get month end date for maximum maturity date
            if pd.isnull(maxmaturity) or maxmaturity=='.':
                monthend_maxmaturity=maturitydate
            else:            
                if maxmaturity.month == 12:
                    monthend_maxmaturity=maxmaturity.replace(year=maxmaturity.year+1,month=1, day=1)-datetime.timedelta(days=1)
                else:
                    monthend_maxmaturity=maxmaturity.replace(month=maxmaturity.month+1, day=1)-datetime.timedelta(days=1)
        
            if (
                 pd.isnull(maturitydate)
               ) or (
                       maturitydate == '.' 
                     ) or (
                             maturitydate == '01/01/9999'):
                return(np.nan)
            else:
                m2mat=relativedelta.relativedelta(monthend_maxmaturity,as_of_date)                
                    
                return(m2mat.years*12+m2mat.months)   
        
        
        def processHELOCDate(dataset):
#==============================================================================
#             if dataset['CREDIT_ORIG_CLTV']>=0 and dataset['CREDIT_ORIG_CLTV']<0.5:
#                 dataset['cltv_heloc']=1
#             elif dataset['CREDIT_ORIG_CLTV']<0.8:
#                 dataset['cltv_heloc']=2
#             else:
#                 dataset['cltv_heloc']=3
#==============================================================================

            dataset['cltv_heloc']=dataset['CREDIT_ORIG_CLTV'].apply(lambda x: 1 if x>=0 and x<0.5 
                                                                              else (2 if x<0.8
                                                                                    else 3
                                                                                    )
                                                                        )
                                                                              
#==============================================================================
#             dataset['mob_heloc']=dataset.apply(lambda x: getMaturity(dataset['LOAN_ORIG_NOTE_DATE'],dataset['EFFECTIVE_DATE_PK']),axis=1)
#             
#==============================================================================
            
            dataset['mob_heloc']=dataset['LOAN_ORIG_NOTE_DATE'].apply(lambda x: getMaturity(as_of_date,x))
            
#==============================================================================
#             if dataset['CREDIT_SCORE']<=699:
#                 dataset['heloc_fico']=1
#             elif dataset['CREDIT_SCORE']<=739:
#                 dataset['heloc_fico']=2
#             elif dataset['CREDIT_SCORE']<=799:
#                 dataset['heloc_fico']=3
#             elif dataset['CREDIT_SCORE']>=800:
#                 dataset['heloc_fico']=4
#             else:
#                 dataset['heloc_fico']=1
#==============================================================================
 
            dataset['heloc_fico']=dataset['CREDIT_SCORE'].apply(lambda x: 1 if x<=699
                                                                              else (2 if x<=739
                                                                                    else (3 if x<=799
                                                                                          else (4 if x>=800
                                                                                                else 1
                                                                                                )
                                                                                          )
                                                                                    )
                                                                        )


           
#==============================================================================
#             if dataset['mob_heloc']<=18:
#                 dataset['heloc_age']=1
#             elif dataset['mob_heloc']<=48:
#                 dataset['heloc_age']=2
#             elif dataset['mob_heloc']<=72:
#                 dataset['heloc_age']=3
#             elif dataset['mob_heloc']>=73:
#                 dataset['heloc_age']=4
#             else:
#                 dataset['heloc_age']=1
#==============================================================================

            dataset['heloc_age']=dataset['mob_heloc'].apply(lambda x: 1 if x<=18
                                                                              else (2 if x<=48
                                                                                    else (3 if x<=72 
                                                                                          else (4 if x>=73
                                                                                                else 1
                                                                                                )
                                                                                          )
                                                                                    )
                                                                        )    

#==============================================================================
#             if dataset['COLLATERAL_STATE'] in ['MA','NH']:
#                 dataset['location']=1
#             elif dataset['COLLATERAL_STATE'] in ['RI','CT','NY','NJ']:
#                 dataset['location']=2
#             elif dataset['COLLATERAL_STATE'] in ['PA']:
#                 dataset['location']=3
#             else:
#                 dataset['location']=4
#==============================================================================
            dataset['location']=dataset['COLLATERAL_STATE'].apply(lambda x: 1 if x in ['MA','NH']
                                                                              else (2 if x in ['RI','CT','NY','NJ']
                                                                                    else (3 if x in ['PA']
                                                                                          else 4
                                                                                          )
                                                                                    )
                                                                        )
            return(dataset)
        
            
            
        def processMORTGAGEDate(dataset):
#==============================================================================
#             if dataset['CREDIT_ORIG_CLTV']>=0 and dataset['CREDIT_ORIG_CLTV']<0.5:
#                 dataset['cltv_mortgage']=1
#             elif  dataset['CREDIT_ORIG_CLTV']<0.7:
#                 dataset['cltv_mortgage']=2
#             elif dataset['CREDIT_ORIG_CLTV']<0.8:
#                 dataset['cltv_mortgage']=3
#             else:
#                 dataset['cltv_mortgage']=4
#==============================================================================

            dataset['cltv_mortgage']=dataset['CREDIT_ORIG_CLTV'].apply(lambda x: 1 if x>=0 and x<0.5 
                                                                              else (2 if x<0.7
                                                                                    else (3 if x< 0.8
                                                                                          else 4
                                                                                          )
                                                                                    )
                                                                        )

            dataset['mob_mortgage']=dataset['LOAN_ORIG_NOTE_DATE'].apply(lambda x: getMaturity(as_of_date,x))
            
#==============================================================================
#             if dataset['CREDIT_SCORE']<=659:
#                 dataset['mortgage_fico']=1
#             elif dataset['CREDIT_SCORE']<=699:
#                 dataset['mortgage_fico']=2
#             elif dataset['CREDIT_SCORE']<=739:
#                 dataset['mortgage_fico']=3
#             elif dataset['CREDIT_SCORE']>=740:
#                 dataset['mortgage_fico']=4
#             else:
#                 dataset['mortgage_fico']=1                        
#==============================================================================
 
            dataset['mortgage_fico']=dataset['CREDIT_SCORE'].apply(lambda x: 1 if x<=659
                                                                              else (2 if x<=699
                                                                                    else (3 if x<=739 
                                                                                          else (4 if x>=740
                                                                                                else 1
                                                                                                )
                                                                                          )
                                                                                    )
                                                                        )

           
#==============================================================================
#             if dataset['mob_mortgage']<=12:
#                 dataset['mortgage_age']=1
#             elif dataset['mob_mortgage']<=48:
#                 dataset['mortgage_age']=2
#             elif dataset['mob_mortgage']<=96:
#                 dataset['mortgage_age']=3
#             elif dataset['mob_mortgage']>=97:
#                 dataset['mortgage_age']=4
#             else:
#                 dataset['mortgage_age']=1
#==============================================================================

            dataset['mortgage_age']=dataset['mob_mortgage'].apply(lambda x: 1 if x<=12
                                                                              else (2 if x<=48
                                                                                    else (3 if x<=96 
                                                                                          else (4 if x>=97
                                                                                                else 1
                                                                                                )
                                                                                          )
                                                                                    )
                                                                        )            
            
#==============================================================================
#             if dataset['COLLATERAL_STATE'] in ['MA','NH']:
#                 dataset['location']=1
#             elif dataset['COLLATERAL_STATE'] in ['RI','CT','NY','NJ']:
#                 dataset['location']=2
#             elif dataset['COLLATERAL_STATE'] in ['PA']:
#                 dataset['location']=3
#             else:
#                 dataset['location']=4
#==============================================================================

            dataset['location']=dataset['COLLATERAL_STATE'].apply(lambda x: 1 if x in ['MA','NH']
                                                                              else (2 if x in ['RI','CT','NY','NJ']
                                                                                    else (3 if x in ['PA']
                                                                                          else 4
                                                                                          )
                                                                                    )
                                                                        )


#==============================================================================
#             if dataset['SEG_BREAK'].upper()=='JUMBO':
#                 dataset['jumbo']=1
#             else:
#                 dataset['jumbo']=0
#==============================================================================

            dataset['jumbo']=dataset['SEG_BREAK'].apply(lambda x: 1 if x.upper()=='JUMBO'
                                                                    else 0
                                                                        )
            return(dataset)
        
        if portfolio == 'HELOC':
            processed_data = processHELOCDate(dataset)
            print('>>> Format {} portfolio : {}'.format(self.portfolio,as_of_date))    
        elif portfolio == 'MORTGAGE':    
            processed_data = processMORTGAGEDate(dataset)
            print('>>> Tag {} portfolio : {}'.format(self.portfolio,as_of_date)) 
            
        return(processed_data)
       

                                     
        # get 'Multifamily_Status', 'Property', 'Property_Type', 'division', 'm2mat'
    def getVariable(self, portfolio, processed_dataset, as_of_date, statement_days_threshold = 366): 
        # Get raw dataset
        dataset = processed_dataset.copy(deep=True) 
        
        # Map dataset with different variable bins
        print('>>> Map {} portfolio : {}'.format(self.portfolio, as_of_date))    
        # mapping function
        list_of_mappings=[   
                            {
                                'IN_VAR':'cltv_heloc',
                                'OUT_VAR':'cltv_heloc_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (1,
                                              2,
                                              3
                                             ),
                                'MAPPED_VALUES': ('0%-50%',
                                                  '50%-80%',
                                                  '>=80%, Missing'
                                                 ),
                                 'MISSING': '>=80%, Missing'
                            },
                            {
                                'IN_VAR':'heloc_fico',
                                'OUT_VAR':'heloc_fico_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (1,
                                              2,
                                              3,
                                              4
                                             ),
                                'MAPPED_VALUES': ('<= 699, Missing',
                                                  '700-739',
                                                  '740-799',
                                                  '>=800'
                                                 ),
                                 'MISSING': '<= 699, Missing'
                            },        
                            {
                                'IN_VAR':'heloc_age',
                                'OUT_VAR':'heloc_age_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (1,
                                              2,
                                              3,
                                              4
                                             ),
                                'MAPPED_VALUES': ('<=18 MOB',
                                                  '19-48 MOB',
                                                  '49-72 MOB',
                                                  '>=73 MOB'
                                                 ),
                                 'MISSING': '>=73 MOB'
                            },                               
                            {
                                    
                                'IN_VAR':'location',
                                'OUT_VAR':'location_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (1,
                                              2,
                                              3,
                                              4
                                             ),
                                'MAPPED_VALUES': ('MA,NH',
                                                  'RI, CT, NY, NJ',
                                                  'PA',
                                                  'Others'
                                                 ),
                                 'MISSING': 'Others'
                            },
                            {
                                'IN_VAR': 'LOAN_LIEN_POSITION',
                                'OUT_VAR': 'heloc_lien_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (
                                    1,
                                    2
                                ),
                                'MAPPED_VALUES': (
                                    'First Lien',
                                    'Second Lien'
                                ),
                                'MISSING': 'Missing'
                            },
                            {
                                'IN_VAR': 'cltv_mortgage',
                                'OUT_VAR': 'cltv_mortgage_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (
                                    1, 
                                    2, 
                                    3, 
                                    4
                                ),
                                'MAPPED_VALUES': (
                                    '0%-50%', 
                                    '50%-70%',
                                    '70%-80%',
                                    '>=80%, Missing'
                                ),
                                 'MISSING': '>=80%, Missing'
                            },
                            {
                                'IN_VAR': 'mortgage_fico',
                                'OUT_VAR': 'mortgage_fico_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (
                                    1, 
                                    2, 
                                    3,
                                    4
                                ),
                                'MAPPED_VALUES': (
                                    '<= 659, Missing',
                                    '660-699',
                                    '700-739',
                                    '>=740'
                                ),
                                 'MISSING': '<= 659, Missing'
                            },  
                            {
                                'IN_VAR': 'mortgage_age',
                                'OUT_VAR': 'mortgage_age_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (1,
                                              2,
                                              3,
                                              4
                                             ),
                                'MAPPED_VALUES': ('<=12 MOB',
                                                  '13-48 MOB',
                                                  '49-96 MOB',
                                                  '>=97 MOB'
                                                 ),
                                 'MISSING': '>=97 MOB'                                              
                            },
                            {
                                'IN_VAR': 'LOAN_ARM_IND',
                                'OUT_VAR': 'mortgage_product_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (
                                   0,
                                   1
                                ),
                                'MAPPED_VALUES': (
                                    'Fixed Rate',
                                    'Adjusted Rate'
                                ),
                                'MISSING': 'Missing'
                            },
                            {
                                'IN_VAR': 'jumbo',
                                'OUT_VAR': 'mortgage_jumbo_bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (
                                   0,
                                   1
                                ),
                                'MAPPED_VALUES': (
                                    'Not Jumbo',
                                    'Jumbo'
                                ),
                                'MISSING': 'Missing'
                            }

                    ] 
      

               
        def processMappings(list_of_mappings):
            """ This function associates some mappings 
        
            Args:
                list_of_mapping: a mapping list, which will be the keys of the mapping dictionaries
            Return:
                mapping_dict: a mapping dictionary, key-> 'IN_VAR' of the mapping, value->mapping object corresponding
                                 to the key
            """
            mapping_dict = {}
            for mapping in list_of_mappings:
                mapping_dict[mapping['IN_VAR']] = Mapping(
                    in_map=mapping
                )
            return mapping_dict
        
        def asofdate2stmtdate_mapping(x):
            if pd.isnull(x) or (x == -1):            
                return ('Missing')
            elif x <= statement_days_threshold:
                return ('Current Statement')
            else:
                return ('Non-Current Statement')    
            
        if portfolio == 'HELOC':
            mappings=processMappings(list_of_mappings=list_of_mappings)
            dataset['cltv_heloc_bins']=dataset['cltv_heloc'].apply(lambda x: mappings['cltv_heloc'].apply(to_map=x))  
            dataset['heloc_fico_bins']=dataset['heloc_fico'].apply(lambda x: mappings['heloc_fico'].apply(to_map=x))  
            dataset['heloc_age_bins']=dataset['heloc_age'].apply(lambda x: mappings['heloc_age'].apply(to_map=x))  
            dataset['location_bins']=dataset['location'].apply(lambda x: mappings['location'].apply(to_map=x))  
            dataset['heloc_lien_bins']=dataset['LOAN_LIEN_POSITION'].apply(lambda x: mappings['LOAN_LIEN_POSITION'].apply(to_map=x))  
        elif portfolio == 'MORTGAGE':        
            mappings=processMappings(list_of_mappings=list_of_mappings)
            dataset['cltv_mortgage_bins']=dataset['cltv_mortgage'].apply(lambda x: mappings['cltv_mortgage'].apply(to_map=x))  
            dataset['mortgage_fico_bins']=dataset['mortgage_fico'].apply(lambda x: mappings['mortgage_fico'].apply(to_map=x))  
            dataset['mortgage_age_bins']=dataset['mortgage_age'].apply(lambda x: mappings['mortgage_age'].apply(to_map=x))  
            dataset['mortgage_product_bins']=dataset['LOAN_ARM_IND'].apply(lambda x: mappings['LOAN_ARM_IND'].apply(to_map=x))  
            dataset['mortgage_jumbo_bins']=dataset['jumbo'].apply(lambda x: mappings['jumbo'].apply(to_map=x))  
            dataset['location_bins']=dataset['location'].apply(lambda x: mappings['location'].apply(to_map=x))  
            
        # get weight
        dataset['Balance_Weight'] = dataset['LOAN_CURR_UPB_AMT'] / dataset['LOAN_CURR_UPB_AMT'].sum()
        dataset['Facility_Weight'] = 1 / len(dataset['LOAN_FK_PK'])       
        return(dataset)        
    
    def getGraph(self, portfolio, variablename, dataset1, dataset2, asofdate1, asofdate2, name1, name2, variable, weight_switch):
        print('>>> Plot {} : {} '.format(self.portfolio,variablename))                                
    #    plt.style.use('ggplot')
    #    data1=dataset1.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})
    #    data2=dataset2.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})      
    
        # Set Weight measure
        if weight_switch == 'Exposure': 
            data1=dataset1.groupby(variable)['Exposure_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Exposure_Weight'].sum().to_frame()  
        elif weight_switch == 'Balance': 
            data1=dataset1.groupby(variable)['Balance_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Balance_Weight'].sum().to_frame()
        elif weight_switch == 'Facility': 
            data1=dataset1.groupby(variable)['Facility_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Facility_Weight'].sum().to_frame()
        else:
            raise ValueError("Input weight switch should be <Exposure>,<Balance> or <facility>.")        
        
        # rename
        data1.columns=[name1]
        data2.columns=[name2]
        
        # merge
        data=pd.merge(data1,data2,how='outer',left_index=True,right_index=True)
            
        position={
                   'cltv_heloc_bins':
                        {
                          '0%-50%':0, 
                          '50%-80%':1,
                          '>=80%, Missing':2        
                        },    
                   'heloc_age_bins':
                        {
                          '<=18 MOB':0,
                          '19-48 MOB':1,
                          '49-72 MOB':2,
                          '>=73 MOB':3
                        },
                   'heloc_fico_bins':
                        {
                          '<= 699, Missing':0,
                          '700-739':1,
                          '740-799':2,
                          '>=800':3
                        },
                   'location_bins':
                        {
                          'MA,NH':0,
                          'RI, CT, NY, NJ':1,
                          'PA':2,
                          'Others':3
                        },
                   'heloc_lien_bins':
                        {
                          'Missing':0,
                          'First Lien':1,
                          'Second Lien':2
                        },
                   'cltv_mortgage_bins':
                        {
                          '0%-50%':0,
                          '50%-70%':1,
                          '70%-80%':2,
                          '>=80%, Missing':3
                        },
                   'mortgage_fico_bins':
                        {
                            '<= 659, Missing': 0,
                            '660-699': 1,
                            '700-739': 2,
                            '>=740': 3
                        },
                   'mortgage_age_bins':
                        {
                            '<=12 MOB': 0,
                            '13-48 MOB': 1, 
                            '49-96 MOB': 2,
                            '>=97 MOB': 3
                        },                         
                   'mortgage_product_bins':
                        {
                            'Missing': 0,
                            'Fixed Rate': 1,
                            'Adjusted Rate': 2
                        }, 
                   'mortgage_jumbo_bins':
                        {
                            'Missing': 0,
                            'Not Jumbo': 1,
                            'Jumbo': 2
                        }               
                  }
                  
                  
        # get graph position
        data_position = pd.DataFrame.from_dict(position[variable], orient='index')  
        data_position.columns = ['position']     
        data = pd.merge(data_position, data, left_index=True, right_index=True, how='left')
        # check whether two datasets have equal length               
        data.fillna(0, inplace = True)
        data.sort_values('position', inplace=True)
                  
        if (portfolio=='GCB') & (variable=='RatingGroup'): 
            #drop default rating
            data.drop([9],inplace=True)              

        bar_width = 0.45
        opacity = 0.95
        x_label_size = 9 
        x_label_rotation = 8
        factor = 20 
#        space = 0.3
        
        fig, ax = plt.subplots()
        plt.gca().yaxis.grid(color='lightgray', linestyle='dashed', zorder=0)
        ax.patch.set_facecolor('white')
        index = np.array(data.position)
        plt.ylim(0,max(max(data[name1]), max(data[name2]))*1.2)
        #plt.xlim(0,len(index) * 2 * bar_width + (len(index) - 1) * space + space)
        #index = index + space

        rects1 = plt.bar(index, data[name1], bar_width,
                         alpha = opacity,
                         color = '#000080',
                         label = name1,zorder = 5)
        
        rects2 = plt.bar(index + bar_width, data[name2], bar_width,
                         alpha = opacity,
                         color = '#6495ed',
                         label = name2,zorder = 5)
        
    #    plt.xlabel(variable[0]+(variable[1:].lower()))
        plt.ylabel('{} Weighted % of Portfolio'.format(weight_switch),fontsize=8)

        if (portfolio=='GCB') & (variable=='RatingGroup'): 
            plt.title('Distribution of %s portfolio across %s bins*' % (self.portfolio,variablename),fontsize=10)
        else:
            plt.title('Distribution of %s portfolio across %s bins' % (self.portfolio,variablename),fontsize=10)
            
        if (portfolio=='GCB') & (variable=='industry'):
            x_label_size = 8            
            data.index = [
                      'Consumer&Industrial:USCAN',
                      'Consumer&Industrial:Rest of World',
                      'Oil&Gas:Global',
                      'Finance:RoW',
                      'Finance:USCAN'                  
                      ]
            x_label_rotation = 10

                      
        plt.xticks(index + 0.5 * bar_width, data.index, fontsize = x_label_size, rotation = x_label_rotation)
        plt.legend()
        
             
        def autolabel(data,rects):
            # Now make some labels
            labels = ['{:3.1f}%'.format(i*100)  for i in data.values]
        
            for rect, label in zip(rects, labels):
                height = rect.get_height()
                ax.text(rect.get_x() + rect.get_width()/2, height+0.005, label, ha='center', va='bottom',fontsize=rect.get_width()*factor)
                
        autolabel(data[name1], rects1)
        autolabel(data[name2], rects2) 
        ax.set_yticklabels(['{:3.0f}%'.format(x*100) for x in ax.get_yticks()])
        # Shrink current axis's height by 10% on the bottom
        box = ax.get_position()
        ax.set_position([box.x0, box.y0 + box.height * 0.1,
                         box.width, box.height * 0.9])
        # Put a legend below current axis
        ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.12),
          fancybox=True, shadow=False, ncol=5,fontsize=8)
        
        ax.tick_params(
            axis='both',
            which='both',
            bottom='off',
            top='off',
            left='off',
            right='off',
            labelbottom='on',
            labelleft='on')
            
        plt.savefig("{}/{}_{}_{}_{}.png" .format(self.path,self.portfolio,variablename,name1,name2),dpi=300)    
        plt.show()  

    def executeGraph(self):   
        # Execution function
        
        # Fetch and format data
        self.raw_dataset1 = self.getRawData(self.portfolio, self.asofdate1, self.financial_in_rfo1) 
        self.raw_dataset2 = self.getRawData(self.portfolio, self.asofdate2, self.financial_in_rfo2) 

#         # if raw data already available
#        self.raw_dataset1 = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/dec_cni_additional_fields.p", 'rb'))
#        self.raw_dataset2 = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/jun_old_finanical_cni_additional_fields.p", 'rb'))

        # Format data
        self.processed_dataset1 = self.processData(self.industrytag_file1, self.portfolio, self.raw_dataset1, self.asofdate1)
        self.processed_dataset2 = self.processData(self.industrytag_file2, self.portfolio, self.raw_dataset2, self.asofdate2)   

        # Get variable bins
        self.dataset_with_bin1 = self.getVariable(self.portfolio, self.processed_dataset1, self.asofdate1, self.statement_days_threshold1)
        self.dataset_with_bin2 = self.getVariable(self.portfolio, self.processed_dataset2, self.asofdate2, self.statement_days_threshold2)
        # Get mean and median
        variable_mean_dictionary={
                              'HELOC':{'variable':
                                      [('CREDIT_ORIG_CLTV','CLTV'),
                                       ('mob_heloc','Loan Age'),
                                       ('CREDIT_SCORE','FICO')]                                    
                                    },
                              'MORTGAGE':{'variable':
                                      [('CREDIT_ORIG_CLTV','CLTV'),
                                       ('mob_mortgage','Loan Age'),
                                       ('CREDIT_SCORE','FICO')],                                                                           
                                     }    
                                  }
        
        
        if self.portfolio != 'GCB':
            result=[]
            for variable in variable_mean_dictionary[self.portfolio]['variable']: 
                current_result1=[]
                current_result2=[]            
                # append variable name            
                variable_mean_1=self.dataset_with_bin1[variable[0]].mean()
                variable_median_1=self.dataset_with_bin1[variable[0]].median()
                
                variable_mean_2=self.dataset_with_bin2[variable[0]].mean()
                variable_median_2=self.dataset_with_bin2[variable[0]].median() 
                
                current_result1.extend([self.portfolio,variable[1],self.name1,variable_mean_1,variable_median_1])
                current_result2.extend([self.portfolio,variable[1],self.name2,variable_mean_2,variable_median_2])            
                
                result.extend([current_result1,current_result2])
                
            self.average_result=pd.DataFrame(result,columns=['Portfolio','Variable','Cycle','Mean','Median'])
            self.average_result.to_excel(("{}/{}_{}_{}.xlsx".format(self.path,self.portfolio,self.name1,self.name2)),index=False)
 
        # define risk drivers in each portfolio
        variable_dictionary={'HELOC':{
                                    0: {
                                        'variablename':'CLTV',
                                        'variable':'cltv_heloc_bins',
                                        'weight_switch':'Balance'
                                        },
                                    1: {
                                        'variablename':'Loan Age',
                                        'variable':'heloc_age_bins',
                                        'weight_switch':'Balance'
                                        },
                                    2: {
                                        'variablename':'Lien Position',
                                        'variable':'heloc_lien_bins',
                                        'weight_switch':'Balance'
                                        },
                                    3: {
                                        'variablename':'FICO',
                                        'variable':'heloc_fico_bins',
                                        'weight_switch':'Balance'
                                        },
                                    4: {
                                        'variablename':'Property Location',
                                        'variable':'location_bins',
                                        'weight_switch':'Balance'
                                        }
                                    },
                                    
                              'MORTGAGE':{   
                                    0: {
                                        'variablename':'CLTV',
                                        'variable':'cltv_mortgage_bins',
                                        'weight_switch':'Balance'
                                        },
                                    1: {
                                        'variablename':'Loan Age',
                                        'variable':'mortgage_age_bins',
                                        'weight_switch':'Balance'
                                        },
                                    2: {
                                        'variablename':'Product Type',
                                        'variable':'mortgage_product_bins',
                                        'weight_switch':'Balance'
                                        },
                                    3: {
                                        'variablename':'FICO',
                                        'variable':'mortgage_fico_bins',
                                        'weight_switch':'Balance'
                                        },
                                    4: {
                                        'variablename':'Property Location',
                                        'variable':'location_bins',
                                        'weight_switch':'Balance'
                                        },
                                    5: {
                                        'variablename':'Jumbo',
                                        'variable':'mortgage_jumbo_bins',
                                        'weight_switch':'Balance'
                                        }
                                    }
                             } 
           
        # start plotting
        if self.graph_switch == True:
            for item in variable_dictionary[self.portfolio]:                        
                self.getGraph(
                         portfolio = self.portfolio,
                         variablename = variable_dictionary[self.portfolio][item]['variablename'],
                         dataset1 = self.dataset_with_bin1,
                         dataset2 = self.dataset_with_bin2,
                         asofdate1 = self.asofdate1,
                         asofdate2 = self.asofdate2,
                         name1 = self.name1,
                         name2 = self.name2,
                         variable = variable_dictionary[self.portfolio][item]['variable'],
                         weight_switch = variable_dictionary[self.portfolio][item]['weight_switch']
                         )
