# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 10:06:00 2017

@author: n838126
"""

'''
SAMPLE USE

AS_OF_DATE1 = datetime.datetime(2016,12,31)
AS_OF_DATE2 = datetime.datetime(2017,12,31)
NAME1 = 'CCAR 2017'
NAME2 = 'CCAR 2018'
PATH = 'I:\\CRMPO\\CCAR\\4Q17\\10 - Process & Analysis\\Risk Driver\\Wholesale\\02212018'

PATH = 'C:\\Users\\n838126\\CCAR2018\\CIFI\\test'

################################# GCB #####################################
GCB_instance = SnapShotCheck(
        portfolio = 'GCB',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = True,
        graph_switch = True,        
        industrytag_file1 = 'I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\GCB\\CCAR\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx',
        industrytag_file2 = 'I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx',
        orig = False
        )

GCB_instance.executeGraph()

################################# CRE #####################################
RISK_RATING_DATASET_INPUT_PATH_1 = None
RISK_RATING_DATASET_INPUT_PATH_2 = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cre_dec_2017.xlsx"

CRE_instance = SnapShotCheck(
        portfolio = 'CRE',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups = ['CRE_MULTIFAMILY','CRE_OTHER'],
        graph_switch = True,
        orig = False,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2        
        )
CRE_instance.executeGraph()


CRE_multifamily_instance = SnapShotCheck(
        portfolio = 'CRE',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups = ['CRE_MULTIFAMILY'],
        graph_switch = True,
        orig = False,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2        
        )
CRE_multifamily_instance.executeGraph()

CRE_other_instance = SnapShotCheck(
        portfolio = 'CRE',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups=['CRE_OTHER'],
        graph_switch = True,
        orig = False,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2        
        )
CRE_other_instance.executeGraph()

#CRE_other_instance.average_result

################################# C&I #####################################
######### Config for C&I ############
FINANCIAL_IN_RFO1 = False
FINANCIAL_IN_RFO2 = True
STATEMENT_DAYS_THRESHOLD1 = 366
STATEMENT_DAYS_THRESHOLD2 = 546
RISK_RATING_DATASET_INPUT_PATH_1 = None
#RISK_RATING_DATASET_INPUT_PATH_2 = None
RISK_RATING_DATASET_INPUT_PATH_2 = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"

#Plot for all seperate pd groups inside C&I
CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = True,
        pd_groups=['ABL','BUSINESS_BANKING','MIDDLE_MARKET'],
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2
        )
CNI_instance.executeGraph()

## Plot for entire C&I ##
CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = True,
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2
        )
CNI_instance.executeGraph()

## Plot seperated PD_GROUP for C&I ##
CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups=['MIDDLE_MARKET'],    # ABL/BUSINESS_BANKING/MIDDLE_MARKET
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2
        )
CNI_instance.executeGraph()

CNI_instance.average_result

CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups=['ABL'],    # ABL/BUSINESS_BANKING/MIDDLE_MARKET
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2
        )
CNI_instance.executeGraph()

CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups=['BUSINESS_BANKING'],    # ABL/BUSINESS_BANKING/MIDDLE_MARKET
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        risk_rating_dataset_input_path_1 = RISK_RATING_DATASET_INPUT_PATH_1,
        risk_rating_dataset_input_path_2 = RISK_RATING_DATASET_INPUT_PATH_2
        )
CNI_instance.executeGraph()
################################# Get dataset #################################
## Getting raw dataset
raw_dataset1 = CNI_instance.raw_dataset1
raw_dataset2 = CNI_instance.raw_dataset2

## Getting processed dataset
processed_dataset1 = CNI_instance.processed_dataset1
processed_dataset2 = CNI_instance.processed_dataset2

## Getting final dataset
dataset_with_bin1 = CNI_instance.dataset_with_bin1
dataset_with_bin2 = CNI_instance.dataset_with_bin2


'''

import os
import sys
#wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI'
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)   
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.cniriskrating import CNIModel, CNIMasterDataset
from CIFI.controllers.models.riskratingmodel import Mapping
import matplotlib.pyplot as plt
from CIFI.config import CONFIG
import datetime
import dateutil.relativedelta as relativedelta
import pandas as pd
import numpy as np
import copy
import _pickle 
import time
#import matplotlib as mpl
#mpl.rcParams.update(mpl.rcParamsDefault) 


##
## GLOBAL VARIABLES
##
global VALID_PORTFOLIO_NAME
VALID_PORTFOLIO_NAME = ['GCB', 'CRE', 'C&I']

# define risk drivers in each portfolio    
VARIABLE_DICTIONARY = {'GCB':{
                            0: {
                                'variablename':'Industry',
                                'variable':'industry',
                                'weight_switch':'Exposure'
                                },
                            1: {
                                'variablename':'Rating Group',
                                'variable':'RatingGroup',
                                'weight_switch':'Exposure'
                                }
                            },
                            
                      'CRE':{   
                            0: {
                                'variablename':'LTV',
                                'variable':'LTV_Bins',
                                'weight_switch':'Balance'
                                },
                            1: {
                                'variablename':'Occupancy',
                                'variable':'OCCUPANCY_Bins',
                                'weight_switch':'Balance'
                                },      
                            2: {
                                'variablename':'Months to Maturity',
                                'variable':'Months to Maturity_Bins',
                                'weight_switch':'Balance'
                                }   
                            },
                      'C&I':{   
                            0: {
                                'variablename':'Debt to Tangible Net Worth Ratio',
                                'variable':'r_DebtToTNW1_Bins',
                                'weight_switch':'Balance'
                                },
                            1: {
                                'variablename':'EBITDA to Interest Coverage Ratio',
                                'variable':'r_EBITDAoIntrst_Bins',
                                'weight_switch':'Balance'
                                },      
                            2: {
                                'variablename':'Quick Ratio',
                                'variable':'r_quickRatio_Bins',
                                'weight_switch':'Balance'
                                },   
                            3: {
                                'variablename':'Profit Margin',
                                'variable':'r_proftmargin_Bins',
                                'weight_switch':'Balance'
                                },
                            4: {
                                'variablename':'Collateral Type',
                                'variable':'COLLATERAL_TYPE_Bins',
                                'weight_switch':'Balance'
                                },      
                            5: {
                                'variablename':'Days to Financial Statement',
                                'variable':'asofdate2stmtdate_Bins',
                                'weight_switch':'Balance'
                                },   
                            6: {
                                'variablename':'SRR',
                                'variable':'SRR_Bins',
                                'weight_switch':'Balance'
                                },      
                            7: {
                                'variablename':'Facility Type',
                                'variable':'FACILITYTYPE_Bins',
                                'weight_switch':'Balance'
                                } 
                            }
                     }         

class SnapShotCheck():
    # Member properties
    raw_dataset1 = None
    raw_dataset2 = None
    processed_dataset1 = None
    processed_dataset2 = None
    dataset_with_bin1 = None
    dataset_with_bin2 = None
    
    # Member methods
    def __init__(
        self,
        portfolio: str,
        asofdate1: datetime.datetime,
        asofdate2: datetime.datetime,
        name1: str,
        name2: str,
        path: str,
        entire_pd_groups_switch=False,
        graph_switch=True,
        orig: bool = False,
        financial_in_rfo1: bool = True,
        financial_in_rfo2: bool = True,
        statement_days_threshold1: int = 366,   # For C&I
        statement_days_threshold2: int = 366,   # For C&I
        risk_rating_dataset_input_path_1: str = None,   # For C&I/CRE
        risk_rating_dataset_input_path_2: str = None,   # For C&I/CRE
        **kwargs
    ):
        self.asofdate1 = asofdate1
        self.asofdate2 = asofdate2
        self.name1 = name1
        self.name2 = name2
        self.path = path
        self.orig = orig
        
        self.financial_in_rfo1 = financial_in_rfo1        
        self.financial_in_rfo2 = financial_in_rfo2
        
        self.statement_days_threshold1 = statement_days_threshold1        
        self.statement_days_threshold2 = statement_days_threshold2
        
        self.risk_rating_dataset_input_path_1 = risk_rating_dataset_input_path_1
        self.risk_rating_dataset_input_path_2 = risk_rating_dataset_input_path_2
        
        self.industrytag_file1 = kwargs.get('industrytag_file1')
        self.industrytag_file2 = kwargs.get('industrytag_file2')
     
        # Validate inputs
        if portfolio not in VALID_PORTFOLIO_NAME:
            raise ValueError("Invalid input of portfolio name. Valid names should be in: {}".format(VALID_PORTFOLIO_NAME))
        
        self.portfolio = portfolio
        self.graph_switch = graph_switch
        self.entire_pd_groups_switch = entire_pd_groups_switch
        # Assign pd groups
        # Aggregate default pd_groups if entire_pd_group_switch is True
        if self.entire_pd_groups_switch == True:
            self.portfolio_name = self.portfolio
            if self.portfolio == 'CRE':
                self.pd_groups = ['CRE_MULTIFAMILY', 'CRE_OTHER']
            elif self.portfolio == 'GCB':
                self.pd_groups = ['GCB']
            elif self.portfolio == 'C&I':
                self.pd_groups = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL']        
        else:
            self.pd_groups = kwargs.get('pd_groups')

                      
#            # Get portfolio name
#            self.portfolio_name = []
#            for group in self.pd_groups:
#                split_pd_groups = group.split('_')
#            
#                if len(split_pd_groups) = 1:
#                    self.portfolio_name.append(split_pd_groups[0])
#                elif len(split_pd_groups) < 4:    
#                    self.portfolio_name.append(split_pd_groups[0] +' '+split_pd_groups[1].title())
#                else:
#                    self.portfolio_name.append(split_pd_groups[0].title() +' '+split_pd_groups[1].title())     
                    
                
    def getRawData(self, portfolio, as_of_date, financial_in_rfo, risk_rating_dataset_input_path):
        print('>>> Fetch {} portfolio : {}'.format(portfolio, as_of_date))
        # pull raw data from RFO
        # define data columns
        columns = {'CRE':[     
                         'ASOFDATE',                         
                         'SOURCEID',
                         'ONEOBLIGORNUMBER',
                         'CUSTOMERNUMBER',
                         'FACILITYNUMBER',
                         'FAS114_STATUS',
                         'LOCAL_NPL_FLAG',
                         'TDR',
                         'COLLATERALCODE',
                         'UNIQUE_FACILITY_ID',
                         'CURRENTOCCUPANCY',
                         'MAXIMUMMATURITYDATE',
                         'PD_GROUP',
                         'PRI_COLLATNOI',
                         'PRI_COLLATVALUE',
                         'PRI_COLLATSTATE',
                         'PROPERTY_TYPE_MAP',
                         'SRR',
                         'BOOKBALANCE',
                         'OPENDATE',
                         'IS_ORIG'],
                             
                'GCB':[    
                         'ASOFDATE',                         
                         'COLLATERALCODE',                        
                         'SOURCEID',
                         'ONEOBLIGORNUMBER',
                         'CUSTOMERNUMBER',
                         'FACILITYNUMBER',
                         'LCAMOUNT',
                         'EXPOSURE',
                         'UNSECURED_INDICATOR',
                         'UNIQUE_FACILITY_ID',
                         'PD_GROUP',
                         'SRR',
                         'BOOKBALANCE',
                         'IS_ORIG'
                        ]} 
        

            
        # Fetch data
        if portfolio == 'GCB':
            dataset = CCMISMasterDataset(
                                	asofdate = as_of_date,
                                	pd_groups = self.pd_groups,
                                	debug = False
                                  ).data[columns[portfolio]]

        elif portfolio == 'CRE':

            if risk_rating_dataset_input_path == None:
                dataset = CCMISMasterDataset(
                                    	asofdate = as_of_date,
                                    	pd_groups = self.pd_groups,
                                    	debug = False
                                      ).data[columns[portfolio]]    
            else:
               # read from excel dataset
                if os.path.exists(risk_rating_dataset_input_path) & os.path.isfile(risk_rating_dataset_input_path):       
                    raw_dataset = pd.read_excel(risk_rating_dataset_input_path,converters={
                            'SOURCEID':str,'ONEOBLIGORNUMBER':str,
                            'ONEOBLIGORNUMBER':str,'CUSTOMERNUMBER':str,
                            'FACILITYNUMBER':str,'MASTER_CUSTOMER_ID':str
                            })
                    # Rename column names
                    raw_dataset.drop('PD_GROUP', inplace=True, axis=1)
                    raw_dataset.rename(columns = {'UTILIZATIONBOOKBALANCE':'BOOKBALANCE',
                                                  'UTILIZATIONLCAMOUNT': 'UTILIZATIONLCAMOUNT',
                                                  'UTILIZATIONOPENDATE':'OPENDATE',
                                                  'CALCULATED_LINE': 'EXPOSURE',
                                                  'pd_group_tool': 'PD_GROUP'},inplace = True)
    
                else:
                    raise Exception("Input path does not exist")
                # origination tag        
                # Apply filter     
                raw_dataset = raw_dataset[
                                (
                                        (raw_dataset['FAS114_STATUS']== 'A - NOT REQUIRED') &
                                        (raw_dataset['LOCAL_NPL_FLAG']=='N')
                                ) &
                                (raw_dataset['SOURCEID']!= 'OFFLINE') 
                                         ]
                
                raw_dataset = raw_dataset[(raw_dataset['EXPOSURE'] > 0) |((raw_dataset['BOOKBALANCE']+raw_dataset['UTILIZATIONLCAMOUNT']) > 0)]
                
                # origination tag 
                raw_dataset['IS_ORIG'] = np.where(raw_dataset['UNIQUE_FACILITY_ID'].str.contains('_O'),'Y','N')  
                # Check whether there is duplicated facility level loans         
                check_dup = raw_dataset.groupby('UNIQUE_FACILITY_ID').agg({                                                
                                 'SOURCEID': 'nunique',  
                                 'ONEOBLIGORNUMBER': 'nunique',
                                 'CUSTOMERNUMBER': 'nunique',   
                                 'FACILITYNUMBER': 'nunique',
                                 'MASTER_CUSTOMER_ID':'nunique',
                                 'DEBTYIEL':'nunique',
                                 'LOANTOVA':'nunique',
                                 'FAS114_STATUS': 'nunique',   
                                 'LOCAL_NPL_FLAG': 'nunique',   
                                 'TDR': 'nunique',   
                                 'COLLATERALCODE' : 'nunique',    
                                 'CURRENTOCCUPANCY' : 'nunique',    
                                 'PD_GROUP' : 'nunique',   
                                 'PRI_COLLATNOI' : 'nunique',   
                                 'PRI_COLLATVALUE' : 'nunique',   
                                 'PRI_COLLATSTATE' : 'nunique',   
                                 'PROPERTY_TYPE_MAP': 'nunique',   
                                 'SRR' : 'nunique'
                                 })
                    
                if check_dup.max().max() != 1:
                    raise ValueError('The field is not unique at facility level')
                else:       
                    dataset = raw_dataset.groupby('UNIQUE_FACILITY_ID', as_index=False).agg({                         
                                             'ASOFDATE' : 'min',                         
                                             'SOURCEID': 'min',  
                                             'ONEOBLIGORNUMBER': 'min',
                                             'CUSTOMERNUMBER': 'min',   
                                             'FACILITYNUMBER': 'min',
                                             'MASTER_CUSTOMER_ID':'min',                           
                                             'FAS114_STATUS': 'min',   
                                             'LOCAL_NPL_FLAG': 'min',   
                                             'TDR': 'min',   
                                             'COLLATERALCODE' : 'min',    
                                             'CURRENTOCCUPANCY' : 'min',   
                                             'MAXIMUMMATURITYDATE' : 'max', 
                                             'OPENDATE': 'min',                         
                                             'PD_GROUP' : 'min',   
                                             'PRI_COLLATNOI' : 'min',   
                                             'PRI_COLLATVALUE' : 'min',   
                                             'PRI_COLLATSTATE' : 'min',   
                                             'PROPERTY_TYPE_MAP': 'min',   
                                             'SRR' : 'min',  
                                             'EXPOSURE':'sum', 
                                             'UTILIZATIONLCAMOUNT':'sum',
                                             'BOOKBALANCE': 'sum',      
                                             'IS_ORIG': 'min'
                                             })  
  
            # filter one facility (outlier ltv)
            dataset=dataset[dataset['UNIQUE_FACILITY_ID']!='AFS0051954589005253674000525367400000000018']

            
        elif portfolio == 'C&I':
            dataset = CNIMasterDataset(
                asofdate = as_of_date,
                pd_groups = self.pd_groups,
                debug = False,
                financial_in_rfo = financial_in_rfo,
                risk_rating_dataset_input_path = risk_rating_dataset_input_path
            ).mds_mra_additional_fields
                    
     

        # Filter for existing book loans
        if self.orig == False:
            dataset = dataset[~dataset['IS_ORIG'].str.contains('Y')]     
        return(dataset)
    
    def processData(self, industrytag_file, portfolio, raw_data, as_of_date): 
        
        # Get raw dataset
        dataset = raw_data.copy(deep=True) 
        # format data
        def processCREData(dataset):    
            # replace special character
            dataset=dataset.replace({'uav': np.nan,None:np.nan,'NA':np.nan,'na':np.nan,'Unknown':np.nan,' ':np.nan}, regex=True)   
            # check numeric data type
            
            for field in ['COLLATERALCODE','CURRENTOCCUPANCY','PRI_COLLATNOI','PRI_COLLATVALUE','PROPERTY_TYPE_MAP','SRR','BOOKBALANCE']:
                dataset[field]=dataset[field].apply(pd.to_numeric)
            # NOI 0 is missing
            dataset['PRI_COLLATNOI']=dataset['PRI_COLLATNOI'].replace({0: np.nan}, regex=True)  
            return(dataset) 
        # tag data with rating and industry
        def processGCBData(dataset, industrytag_file):          
            # get rating and segment for each facility        
            # read in excel file to get industry segments         
            if os.path.exists(industrytag_file) & os.path.isfile(industrytag_file):
                industrytag = pd.ExcelFile(industrytag_file)
                industrytag_data = industrytag.parse('GCB_List')
            else:
                raise Exception('Input master datset file does not exist or is not reachable.')    
                  
            srr_rating=pd.DataFrame({'GCB_SRR':[
                                                     1,1.1,1.2,1.5,
                                                     2,2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,
                                                     3,3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,
                                                     4,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,
                                                     5,5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9,
                                                     6,6.1,6.2,6.3,6.4,6.5,6.6,6.7,6.8,6.9,
                                                     7,7.1,7.2,7.3,7.4,7.5,7.6,7.7,7.8,7.9,
                                                     8,8.1,8.2,8.3,8.4,8.5,8.6,8.7,8.8,8.9,
                                                     9,9.1,9.2,9.3
                                                    ],
                                             'NonFin_Rating':[
                                                 9,9,9,
                                                 8,8,8,8,8,8,8,8,8,8,8,
                                                 7,7,7,7,
                                                 6,6,6,6,6,
                                                 5,5,5,5,5,5,5,5,5,5,5,5,5,
                                                 4,4,4,4,4,4,4,	4,4,
                                                 3,3,3,3,3,3,3,3,3,
                                                 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                                                 1,1,1,1,1,1
                                                   ],
                                             'Fin_Rating':[
                                                 9,9,9,
                                                 8,
                                                 7,7,7,7,7,
                                                 6,6,6,6,6,
                                                 5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
                                                 4,4,4,4,4,4,4,4,4,4,
                                                 3,3,3,3,3,3,3,3,3,3,
                                                 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                                                 1,1,1,1,1,1,1,1,1
                                             ]})
                              
            # get industry segment for each facility                                                
            # Creat New column for origination in order to merge with the file provided                        
                    
            data_segment=pd.merge(
                        left=dataset,right=industrytag_data,
                        how='left',left_on='UNIQUE_FACILITY_ID',right_on='Unique_Facility_ID')
    
            # Check origination get the same industry and srr                           
            untaged_industry_positive_exposure=(
                        data_segment[pd.isnull(data_segment['industry'])&(data_segment['EXPOSURE']>0)])
            if len(untaged_industry_positive_exposure)!=0:
              raise ValueError('There is untaged industry besides 0 exposure loans')
              
            # get RatingGroup from SRR  
            data_segment['SRR']=data_segment['SRR'].round(1)

            data_rating=pd.merge(left=data_segment,right=srr_rating,how='left',on='GCB_SRR')
    
            untaged_f_rating_positive_exposure=(
                        data_rating[pd.isnull(data_rating['Fin_Rating'])&(data_rating['EXPOSURE']>0)])
            if len(untaged_f_rating_positive_exposure)!=0:
              raise ValueError('There is untaged financial rating besides 0 exposure loans')                       
            untaged_nf_rating_positive_exposure=(
                        data_rating[pd.isnull(data_rating['NonFin_Rating'])&(data_rating['EXPOSURE']>0)])                    
            if len(untaged_nf_rating_positive_exposure)!=0:
              raise ValueError('There is untaged non-financial rating besides 0 exposure loans')               
            
            # get rating for each facility        
            data_rating['RatingGroup']=data_rating['Fin_Rating'].where(
                                          (
                                        (
                               data_rating['industry']== ['Finance_USCAN','Finance_RoW'][0]
                                        )|(
                               data_rating['industry']==['Finance_USCAN','Finance_RoW'][1])
                                          ),
                          other=data_rating['NonFin_Rating']
                                                    )  
            return(data_rating) 
       
        def processCNIData(dataset):    
            return(dataset)
        
        if portfolio == 'CRE':
            processed_data = processCREData(dataset)
            print('>>> Format {} portfolio : {}'.format(self.portfolio,as_of_date))    
        elif portfolio == 'GCB':    
            processed_data = processGCBData(dataset,industrytag_file)
            print('>>> Tag {} portfolio : {}'.format(self.portfolio,as_of_date)) 
        elif portfolio == 'C&I':
            processed_data = processCNIData(dataset)
            print('>>> Format {} portfolio : {}'.format(self.portfolio,as_of_date))
        else:
            raise ValueError('Cannot handle portfolio other than GCB or CRE or C&I')  
            
        return(processed_data)
                                            
        # get 'Multifamily_Status', 'Property', 'Property_Type', 'division', 'm2mat'
    def getVariable(self, portfolio, processed_dataset, as_of_date, statement_days_threshold = 366): 
        # Get raw dataset
        dataset = processed_dataset.copy(deep=True) 
        
        # Map dataset with different variable bins
        print('>>> Map {} portfolio : {}'.format(self.portfolio, as_of_date))    
        # mapping function
        list_of_mappings=[   
                            {
                                'IN_VAR':'Ltv_Non_Multifamily',
                                'OUT_VAR':'WOE_LTV_Non_Multifamily',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0.388257496,
                                              0.43967162769487,
                                              0.7884597706,
                                              0.8376397627,
                                              0.8937550834,
                                              0.9571615309,
                                              1.0354949941,
                                              1.1625173411
                                             ),
                                'MAPPED_VALUES': ('(~,0.39]',
                                                  '(0.39,0.45]',
                                                  '(0.45,0.79]',
                                                  '(0.79,0.84]',
                                                  '(0.84,0.89]',
                                                  '(0.89,0.96]',
                                                  '(0.96,1.04]',
                                                  '(1.04,1.16]',
                                                  '(1.16,~)'
                                                 ),
                                'MISSING': 'Missing'
                            },
                            {
                                'IN_VAR':'OCCUPANCY',
                                'OUT_VAR':'OCCUPANCY_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0.65,
                                              0.85,
                                              0.95
                                             ),
                                'MAPPED_VALUES': ('<= 65%',
                                                  '65%-85%',
                                                  '85%-95%',
                                                  '> 95%'
                                                 ),
                                'MISSING': 'Missing'
                            },        
                            {
                                'IN_VAR':'LTV',
                                'OUT_VAR':'LTV_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0.5,
                                              0.65,
                                              0.806,
                                              1
                                             ),
                                'MAPPED_VALUES': ('<= 50%',
                                                  '50%-65%',
                                                  '65%-80%',
                                                  '80%-100%',
                                                  '> 100%'
                                                 ),
                                'MISSING': 'Missing'
                            },                               
                            {
                                    
                                'IN_VAR':'Months to Maturity',
                                'OUT_VAR':'Months to Maturity_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0,
                                              12,
                                              24,
                                              36
                                             ),
                                'MAPPED_VALUES': ('<= 0',
                                                  '0-12',
                                                  '12-24',
                                                  '24-36',
                                                  '>36'
                                                 ),
                                'MISSING': 'Missing'
                            },
                            {
                                'IN_VAR': 'r_DebtToTNW1',
                                'OUT_VAR': 'r_DebtToTNW1_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (
                                    -1.009854, 
                                    0.752294, 
                                    2.113506, 
                                    3.357537
                                ),
                                'MAPPED_VALUES': (
                                    '<=-1.01',
                                    '-1.01 - 0.75',
                                    '0.75 - 2.11',
                                    '2.11 - 3.36',
                                    '>3.36'
                                ),
                                'MISSING': 'Missing'
                            },       
                            {
                                'IN_VAR': 'r_EBITDAoIntrst',
                                'OUT_VAR': 'r_EBITDAoIntrst_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (
                                    1.13793103448275, 
                                    3.46031746031746, 
                                    8.00684931506849, 
                                    20.8333333333333
                                ),
                                'MAPPED_VALUES': (
                                    '<=1.13', 
                                    '1.13 - 3.46',
                                    '3.46 - 8.01',
                                    '8.01 - 20.83',
                                    '>20.83'
                                ),                
                                'MISSING': 'Missing'               
                            },
                            {
                                'IN_VAR': 'r_quickRatio',
                                'OUT_VAR': 'r_quickRatio_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (
                                    0.46828143021914, 
                                    1.06599578750292, 
                                    1.61751152073732
                                ),
                                'MAPPED_VALUES': (
                                    '<=0.46',
                                    '0.46 - 1.06',
                                    '1.06 - 1.61',
                                    '>1.61'
                                ),
                                'MISSING': 'Missing'
                            },  
                            {
                                'IN_VAR': 'r_proftmargin',
                                'OUT_VAR': 'r_proftmargin_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (
                                    -0.01217656, 
                                    0.0040471885, 
                                    0.02028458976687, 
                                    0.29189044038668,
                                ),
                                'MAPPED_VALUES': (
                                    '<=-0.012',
                                    '-0.012 - 0.004',
                                    '0.004 -0.020',
                                    '0.020 - 0.292',
                                    '>0.292'
                                ),
                
                                'MISSING': 'Missing'
                            },
                            {
                                'IN_VAR': 'COLLATERAL_TYPE',
                                'OUT_VAR': 'COLLATERAL_TYPE_Bins',
                                'TYPE': 'categorical',
                                'IN_VALUES': (
                                    'COMMERCIAL PROPERTIES', 'UNSECURED', 'EQUIPMENT/VEHICLE',
                                    ('HOSPITAL/ MEDICAL CARE PROPERTIES','RESIDENTIAL PROPERTIES',
                                    'FINANCIAL ASSETS','ALL ASSETS/OTHER')
                                ),
                                'MAPPED_VALUES': (
                                    'COMM PROP',
                                    'UNSECURED',
                                    'EQUIP/VEH',
                                    'HOSP/RESI/FIN/OTHER'
                                ),
                                'MISSING': 'Missing'
                            }

                    ] 
      
        def getMaturity(maturitydate, as_of_date):
            maxmaturity=maturitydate
            # get month end date for maximum maturity date
            if pd.isnull(maxmaturity) or maxmaturity=='.':
                monthend_maxmaturity=maturitydate
            else:            
                if maxmaturity.month == 12:
                    monthend_maxmaturity=maxmaturity.replace(year=maxmaturity.year+1,month=1, day=1)-datetime.timedelta(days=1)
                else:
                    monthend_maxmaturity=maxmaturity.replace(month=maxmaturity.month+1, day=1)-datetime.timedelta(days=1)
        
            if (
                 pd.isnull(maturitydate)
               ) or (
                       maturitydate == '.' 
                     ) or (
                             maturitydate == '01/01/9999'):
                return(np.nan)
            else:
                m2mat=relativedelta.relativedelta(monthend_maxmaturity,as_of_date)                
                    
                return(m2mat.years*12+m2mat.months)   
               
        def processMappings(list_of_mappings):
            """ This function associates some mappings 
        
            Args:
                list_of_mapping: a mapping list, which will be the keys of the mapping dictionaries
            Return:
                mapping_dict: a mapping dictionary, key-> 'IN_VAR' of the mapping, value->mapping object corresponding
                                 to the key
            """
            mapping_dict = {}
            for mapping in list_of_mappings:
                mapping_dict[mapping['IN_VAR']] = Mapping(
                    in_map=mapping
                )
            return mapping_dict
        
        def asofdate2stmtdate_mapping(x):
            if pd.isnull(x) or (x == -1):            
                return ('Missing')
            elif x <= statement_days_threshold:
                return ('Current Statement')
            else:
                return ('Non-Current Statement')    
            
        if portfolio == 'CRE':
            mappings=processMappings(list_of_mappings=list_of_mappings)
            # Get month to maturity    
            dataset['M2MAT']=dataset['MAXIMUMMATURITYDATE'].apply(lambda x: getMaturity(x,as_of_date))    
            # get ltv,debtyield              
            dataset['LTV']=dataset['BOOKBALANCE']/dataset['PRI_COLLATVALUE']
            # replace inf 
            dataset['LTV']=dataset['LTV'].replace(np.inf,np.nan)
            
            dataset['debtyield']=dataset['PRI_COLLATNOI']/dataset['BOOKBALANCE']    
            dataset['debtyield']=dataset['debtyield'].replace(np.inf,np.nan)
            
            dataset['LTV_Bins']=dataset['LTV'].apply(lambda x: mappings['LTV'].apply(to_map=x))
            dataset['OCCUPANCY_Bins']=dataset['CURRENTOCCUPANCY'].apply(lambda x: mappings['OCCUPANCY'].apply(to_map=x))  
            dataset['Months to Maturity_Bins']=dataset['M2MAT'].apply(lambda x: mappings['Months to Maturity'].apply(to_map=x)) 
        elif portfolio == 'GCB':        
            dataset['Exposure_Weight']=dataset['EXPOSURE']/dataset['EXPOSURE'].sum() 
        elif portfolio == 'C&I':
            mappings=processMappings(list_of_mappings=list_of_mappings)
            dataset['r_DebtToTNW1_Bins']=dataset['r_DebtToTNW1'].apply(lambda x: mappings['r_DebtToTNW1'].apply(to_map=x))  
            dataset['r_EBITDAoIntrst_Bins']=dataset['r_EBITDAoIntrst'].apply(lambda x: mappings['r_EBITDAoIntrst'].apply(to_map=x))  
            dataset['r_quickRatio_Bins']=dataset['r_quickRatio'].apply(lambda x: mappings['r_quickRatio'].apply(to_map=x))  
            dataset['r_proftmargin_Bins']=dataset['r_proftmargin'].apply(lambda x: mappings['r_proftmargin'].apply(to_map=x))  
            dataset['COLLATERAL_TYPE_Bins']=dataset['COLLATERAL_TYPE'].apply(lambda x: mappings['COLLATERAL_TYPE'].apply(to_map=x))  
            dataset['asofdate2stmtdate_Bins']=dataset['asofdate2stmtdate'].apply(asofdate2stmtdate_mapping)
            dataset['SRR_Bins']=dataset['SRR'].apply(lambda x: 'Missing' if pd.isnull(x) else ('pass: SRR > 4' if x > 4 else 'non-pass: SRR <= 4'))    
            dataset['FACILITYTYPE_Bins']=dataset['FACILITYTYPE'].apply(lambda x: 'Missing' if pd.isnull(x) else ('Revolving Line of Credit' if x == 'Revolving Line of Credit' else 'Non-Revolving Line of Credit'))    
             
        return(dataset)        
    
    def getGraph(self, portfolio,portfolio_name,variablename, dataset1, dataset2, asofdate1, asofdate2, name1, name2, variable, weight_switch):
        print('>>> Plot {} : {} '.format(self.portfolio,variablename))                                
    #    plt.style.use('ggplot')
    #    data1=dataset1.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})
    #    data2=dataset2.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})      
    
        # Set Weight measure
        if weight_switch == 'Exposure': 
            data1=dataset1.groupby(variable)['Exposure_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Exposure_Weight'].sum().to_frame()  
        elif weight_switch == 'Balance': 
            data1=dataset1.groupby(variable)['Balance_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Balance_Weight'].sum().to_frame()
        elif weight_switch == 'Facility': 
            data1=dataset1.groupby(variable)['Facility_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Facility_Weight'].sum().to_frame()
        else:
            raise ValueError("Input weight switch should be <Exposure>,<Balance> or <facility>.")        
        
        # rename
        data1.columns=[name1]
        data2.columns=[name2]
        
        # merge
        data=pd.merge(data1,data2,how='outer',left_index=True,right_index=True)
            
        position={
                   'LTV_Bins':
                        {
                          '> 100%':0, 
                          '80%-100%':1,
                          '65%-80%':2,
                          '50%-65%':3,
                          'Missing':4,
                          '<= 50%':5           
                        },    
                   'OCCUPANCY_Bins':
                        {
                          '<= 65%':0,
                          '65%-85%':1,
                          '85%-95%':2,
                          'Missing':3,
                          '> 95%':4             
      
                        }, 
                   'Months to Maturity_Bins':
                        {
                          '<= 0':0,
                          'Missing':1,
                          '0-12':2,
                          '12-24':3,
                          '24-36':4,
                          '>36':5 
    
                        },
                   'industry':
                        {
                          'ConsumerAndIndustrial_USCAN':0,
                          'ConsumerAndIndustrial_RoW':1,
                          'OilAndGas_Global':2,
                          'Finance_RoW':3,
                          'Finance_USCAN':4
                        },
                   'RatingGroup':
                        {
                          1:0,
                          2:1,
                          3:2,
                          4:3,
                          5:4,
                          6:5,
                          7:6,
                          8:7,
                          9:8
                        },
                   'r_DebtToTNW1_Bins':
                        {
                            'Missing': 0,
                            '<=-1.01': 1,
                            '-1.01 - 0.75': 5,
                            '0.75 - 2.11': 4,
                            '2.11 - 3.36': 3,
                            '>3.36': 2
                        },
                   'r_EBITDAoIntrst_Bins':
                        {
                            'Missing': 3,
                            '<=1.13': 0, 
                            '1.13 - 3.46': 1,
                            '3.46 - 8.01': 2,
                            '8.01 - 20.83': 4,
                            '>20.83':5
                        },                         
                   'r_quickRatio_Bins':
                        {
                            'Missing': 2,
                            '<=0.46': 0,
                            '0.46 - 1.06': 1,
                            '1.06 - 1.61': 3,
                            '>1.61':4
                        }, 
                   'r_proftmargin_Bins':
                        {
                            'Missing': 5,
                            '<=-0.012': 0,
                            '-0.012 - 0.004': 1,
                            '0.004 -0.020': 2,
                            '0.020 - 0.292': 3,
                            '>0.292': 4
                        },
                   'COLLATERAL_TYPE_Bins':
                        {
                            'Missing': 0,
                            'COMM PROP': 1,
                            'UNSECURED': 2,
                            'EQUIP/VEH': 3,
                            'HOSP/RESI/FIN/OTHER': 4
                        },                         
                   'asofdate2stmtdate_Bins':
                        {
                          'Missing': 0,
                          'Current Statement': 2,
                          'Non-Current Statement': 1
                        },                      
                   'SRR_Bins':
                        {
                          'Missing':0,
                          'pass: SRR > 4': 2,
                          'non-pass: SRR <= 4': 1
                        },                         
                   'FACILITYTYPE_Bins':
                        {
                          'Missing':0,
                          'Revolving Line of Credit': 1,
                          'Non-Revolving Line of Credit': 2
                        }                                                      
                  }
                  
                  
        # get graph position
        data_position = pd.DataFrame.from_dict(position[variable], orient='index')  
        data_position.columns = ['position']     
        data = pd.merge(data_position, data, left_index=True, right_index=True, how='left')
        # check whether two datasets have equal length               
        data.fillna(0, inplace = True)
        data.sort_values('position', inplace=True)

        bar_width = 0.45
        opacity = 0.95
        x_label_size = 9 
        x_label_rotation = 8
        factor = 20 
#        space = 0.3
                  
        if (portfolio=='GCB') & (variable=='RatingGroup'): 
            #drop default rating
            data.drop([9],inplace=True)              
            bar_width = 0.43
            factor = 17
        
        fig, ax = plt.subplots(1,1,figsize=(8, 6))
        plt.gca().yaxis.grid(color='lightgray', linestyle='dashed', zorder=0)
        ax.patch.set_facecolor('white')
        index = np.array(data.position)
        plt.ylim(0,max(max(data[name1]), max(data[name2]))*1.2)
        #plt.xlim(0,len(index) * 2 * bar_width + (len(index) - 1) * space + space)
        #index = index + space

        rects1 = plt.bar(index, data[name1], bar_width,
                         alpha = opacity,
                         color = '#000080',
                         label = name1,zorder = 5)
        
        rects2 = plt.bar(index + bar_width, data[name2], bar_width,
                         alpha = opacity,
                         color = '#6495ed',
                         label = name2,zorder = 5)
        
    #    plt.xlabel(variable[0]+(variable[1:].lower()))
        plt.ylabel('{} Weighted % of Portfolio'.format(weight_switch),fontsize=9)

        if (portfolio=='GCB') & (variable=='RatingGroup'): 
            plt.title('Distribution of %s portfolio across %s bins' % (portfolio_name,variablename),fontsize=10)
        else:
            plt.title('Distribution of %s portfolio across %s bins' % (portfolio_name,variablename),fontsize=10)
            
        if (portfolio=='GCB') & (variable=='industry'):
            x_label_size = 8
            data.index = [
                      'Consumer&Industrial:USCAN',
                      'Consumer&Industrial:ROW',
                      'Oil&Gas:Global',
                      'Finance:ROW',
                      'Finance:USCAN'                  
                      ]   
            x_label_rotation = 10
            
             
        plt.xticks(index + 0.5 * bar_width, data.index, fontsize = x_label_size, rotation = x_label_rotation)
        plt.legend()
        # bar numeric number fontsize
    
        def autolabel(data,rects):
            # Now make some labels
            labels = ['{:3.1f}%'.format(i*100)  for i in data.values]
        
            for rect, label in zip(rects, labels):
                height = rect.get_height()
                ax.text(rect.get_x() + rect.get_width()/2, height+0.005, label, ha='center', va='bottom',fontsize=rect.get_width()*factor)
                
        autolabel(data[name1], rects1)
        autolabel(data[name2], rects2) 
        ax.set_yticklabels(['{:3.0f}%'.format(x*100) for x in ax.get_yticks()])
        # Shrink current axis's height by 10% on the bottom
        box = ax.get_position()
        ax.set_position([box.x0, box.y0 + box.height * 0.13,
                         box.width, box.height * 0.9])
        # Put a legend below current axis
        ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.09),
          fancybox=True, shadow=False, ncol=5,fontsize=10)
        
        ax.tick_params(
            axis='both',
            which='both',
            bottom='off',
            top='off',
            left='off',
            right='off',
            labelbottom='on',
            labelleft='on')
           
        plt.savefig("{}/{}_{}_{}_{}.png" .format(self.path,portfolio_name,variablename,name1,name2),dpi=400,bbox_inches="tight")    
        plt.show()  

    def getMeanMax(self,portfolio,portfolio_name,dataset_with_bin1,dataset_with_bin2):
        # Get mean and median
        variable_mean_dictionary={
                              'CRE':{'variable':
                                      [('LTV','LTV'),
                                       ('CURRENTOCCUPANCY','Occupancy Rate'),
                                       ('M2MAT','Months to Maturity')]                                    
                                    },
                              'C&I':{'variable':
                                      [('r_DebtToTNW1','Debt to Tangible Net Worth Ratio'),
                                       ('r_EBITDAoIntrst','EBITDA to Interest Coverage Ratio'),
                                       ('r_quickRatio','Quick Ratio'),
                                       ('r_proftmargin','Profit Margin'),
                                       ('asofdate2stmtdate','Days to Financial Statement'),
                                       ('SRR','SRR')],                                                                           
                                     }    
                                  }
        
        
        if portfolio != 'GCB':
            result=[]
            for variable in variable_mean_dictionary[portfolio]['variable']: 
                current_result1=[]
                current_result2=[]            
                # append variable name            
                variable_mean_1=dataset_with_bin1[variable[0]].mean()
                variable_median_1=dataset_with_bin1[variable[0]].median()
                variable_min_1=dataset_with_bin1[variable[0]].min()
                variable_max_1=dataset_with_bin1[variable[0]].max()
                
                variable_mean_2=dataset_with_bin2[variable[0]].mean()
                variable_median_2=dataset_with_bin2[variable[0]].median() 
                variable_min_2=dataset_with_bin2[variable[0]].min()
                variable_max_2=dataset_with_bin2[variable[0]].max() 
                
                variable_weighted_mean_1=(dataset_with_bin1[variable[0]]*dataset_with_bin1['Balance_Weight']).sum()
                variable_weighted_mean_2=(dataset_with_bin2[variable[0]]*dataset_with_bin2['Balance_Weight']).sum()
                current_result1.extend([portfolio_name,variable[1],self.name1,
                                        variable_mean_1,variable_weighted_mean_1,variable_median_1,
                                        variable_min_1,variable_max_1])
                current_result2.extend([portfolio_name,variable[1],self.name2,
                                        variable_mean_2,variable_weighted_mean_2,variable_median_2,
                                        variable_min_2,variable_max_2])   
                result.extend([current_result1,current_result2])
                self.average_result=pd.DataFrame(result,columns=['Portfolio','Variable','Cycle',
                                                                 'Mean','Balance Wighted Mean','Median',
                                                                 'Min','Max'])
            
            self.average_result.to_excel(("{}/{}_{}_{}.xlsx".format(self.path,portfolio_name,self.name1,self.name2)),index=False)

    def executeGraph(self):   
        # Execution function
        t0 = time.time()
        # Fetch and format data
        self.raw_dataset1 = self.getRawData(self.portfolio, self.asofdate1, self.financial_in_rfo1, self.risk_rating_dataset_input_path_1) 
        self.raw_dataset2 = self.getRawData(self.portfolio, self.asofdate2, self.financial_in_rfo2, self.risk_rating_dataset_input_path_2) 

#         # if raw data already available
#        self.raw_dataset1 = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/dec_cni_additional_fields.p", 'rb'))
#        self.raw_dataset2 = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/jun_old_finanical_cni_additional_fields.p", 'rb'))

        # Format data
        self.processed_dataset1 = self.processData(self.industrytag_file1, self.portfolio, self.raw_dataset1, self.asofdate1)
        self.processed_dataset2 = self.processData(self.industrytag_file2, self.portfolio, self.raw_dataset2, self.asofdate2)   

        # Get variable bins
        self.dataset_with_bin1 = self.getVariable(self.portfolio, self.processed_dataset1, self.asofdate1, self.statement_days_threshold1)
        self.dataset_with_bin2 = self.getVariable(self.portfolio, self.processed_dataset2, self.asofdate2, self.statement_days_threshold2)
        
        # get weight
        def filterDataGetWeight(dataset,pd_group,entire_pd_groups_switch):
            if entire_pd_groups_switch != True:
                dataset = dataset[dataset['PD_GROUP'] == pd_group]
            dataset['Balance_Weight'] = dataset['BOOKBALANCE'] / dataset['BOOKBALANCE'].sum()
            dataset['Facility_Weight'] = 1 / len(dataset['UNIQUE_FACILITY_ID'])           
            return(dataset)               
        
        if self.entire_pd_groups_switch == True:
            final_pd_groups = [self.portfolio]
        else:
            final_pd_groups = self.pd_groups
        
        for group in final_pd_groups:
            # Get portfolio name
            split_pd_groups = group.split('_')
            if len(split_pd_groups) == 1:
                portfolio_name = split_pd_groups[0]
            elif len(split_pd_groups[0]) < 4:    
                portfolio_name = split_pd_groups[0] +' '+split_pd_groups[1].title()
            else:
                portfolio_name = split_pd_groups[0].title() +' '+split_pd_groups[1].title()

            dataset_with_bin1 = filterDataGetWeight(self.dataset_with_bin1,group,self.entire_pd_groups_switch)
            dataset_with_bin2 = filterDataGetWeight(self.dataset_with_bin2,group,self.entire_pd_groups_switch)

                
            self.getMeanMax(self.portfolio,portfolio_name,dataset_with_bin1,dataset_with_bin2)
         

               
            # start plotting
            if self.graph_switch == True:
                for item in VARIABLE_DICTIONARY[self.portfolio]:                        
                    self.getGraph(
                             portfolio = self.portfolio,
                             portfolio_name = portfolio_name,
                             variablename = VARIABLE_DICTIONARY[self.portfolio][item]['variablename'],
                             dataset1 = dataset_with_bin1,
                             dataset2 = dataset_with_bin2,
                             asofdate1 = self.asofdate1,
                             asofdate2 = self.asofdate2,
                             name1 = self.name1,
                             name2 = self.name2,
                             variable = VARIABLE_DICTIONARY[self.portfolio][item]['variable'],
                             weight_switch = VARIABLE_DICTIONARY[self.portfolio][item]['weight_switch']
                             )
        print('Execution Complted in {} s.'.format(time.time()-t0))