# -*- coding: utf-8 -*-
"""
Created on Thu May 11 13:45:02 2017

@author: n886528
"""
#from CIFI.models.masterdataset.rfoplayground import queryRFO
import pandas as pd
import numpy as np
import cx_Oracle
import datetime
from CIFI.config import CONFIG
import matplotlib.pyplot as plt
import os

## pre-declaration
UTILIZATIONBOOKBALANCE='UTILIZATIONBOOKBALANCE'
UNIQUE_FACILITY_ID='UNIQUE_FACILITY_ID'
MAXIMUMMATURITYDATE='MAXIMUMMATURITYDATE'
UTILIZATIONOPENDATE='UTILIZATIONOPENDATE'
OCCUPANCYRATE='CURRENTOCCUPANCY'
COLLATERALCODE='COLLATERALCODE'
#EXISTING_NEW='IS_ORIG'
NEW='Y'

PD_GROUP='PD_GROUP_2017'
PRI_COLLATNOI='PRI_COLLATNOI'
PRI_COLLATVALUE='PRI_COLLATVALUE'
PRI_COLLATSTATE='PRI_COLLATSTATE'
SRR='SRR'
CRE_MULTIFAMILY='CRE_MULTIFAMILY'
CRE_OTHER='CRE_OTHER'
PROPERTY_TYPE='PROPERTY_TYPE_MAP'

M2MAT='m2mat'
MULTIFAMILY_STATUS='Multifamily_Status'

OFFLINE='OFFLINE'
# Match what used in mapping
MULTIFAMILY='Multifamily'
NON_MULTIFAMILY='Non-Multifamily'

## Index_list
index_list = {
    "ABL":[
         'COLLATERALCODE',
         'FACILITYTYPE',
         'COLLATERAL_DESCRIPTION',
         'UNIQUE_FACILITY_ID',
         'PD_GROUP',
         UTILIZATIONBOOKBALANCE,
         UTILIZATIONOPENDATE
         #,EXISTING_NEW
     ],## Steven
    "BUSINESS_BANKING":[
         'COLLATERALCODE',
         'FACILITYTYPE',
         'COLLATERAL_DESCRIPTION',
         'UNIQUE_FACILITY_ID',
         'PD_GROUP',
         UTILIZATIONBOOKBALANCE,
         UTILIZATIONOPENDATE
         #,EXISTING_NEW
     ],## Steven


    "CRE_MULTIFAMILY":[
            'ASOFDATE',                         
             'SOURCEID',
             'ONEOBLIGORNUMBER',
             'CUSTOMERNUMBER',
             'FACILITYNUMBER',
             'FAS114_STATUS',
             'LOCAL_NPL_FLAG',
             'TDR',
             COLLATERALCODE,
             UNIQUE_FACILITY_ID,
             OCCUPANCYRATE,
             MAXIMUMMATURITYDATE,
             PD_GROUP,
             PRI_COLLATNOI,
             PRI_COLLATVALUE,
             PRI_COLLATSTATE,
             PROPERTY_TYPE,
             SRR,
             UTILIZATIONBOOKBALANCE,
             UTILIZATIONOPENDATE
    ],
    "CRE_OTHER":[
            'ASOFDATE',                         
             'SOURCEID',
             'ONEOBLIGORNUMBER',
             'CUSTOMERNUMBER',
             'FACILITYNUMBER',
             'FAS114_STATUS',
             'LOCAL_NPL_FLAG',
             'TDR',
             COLLATERALCODE,
             UNIQUE_FACILITY_ID,
             OCCUPANCYRATE,
             MAXIMUMMATURITYDATE,
             PD_GROUP,
             PRI_COLLATNOI,
             PRI_COLLATVALUE,
             PRI_COLLATSTATE,
             PROPERTY_TYPE,
             SRR,
             UTILIZATIONBOOKBALANCE,
             UTILIZATIONOPENDATE
     ],

 
    "GCB":[
        'ASOFDATE',                         
         'SOURCEID',
         'ONEOBLIGORNUMBER',
         'CUSTOMERNUMBER',
         'FACILITYNUMBER',
         'FAS114_STATUS',
         'LOCAL_NPL_FLAG',
         'TDR',
         UNIQUE_FACILITY_ID,
         PD_GROUP,
         UTILIZATIONBOOKBALANCE,
         UTILIZATIONOPENDATE
         #,EXISTING_NEW
     ],
    "MIDDLE_MARKET":[
        'ASOFDATE',                         
         'SOURCEID',
         'ONEOBLIGORNUMBER',
         'CUSTOMERNUMBER',
         'FACILITYNUMBER',
         'FAS114_STATUS',
         'LOCAL_NPL_FLAG',
         'TDR',
         UNIQUE_FACILITY_ID,
         PD_GROUP,
         UTILIZATIONBOOKBALANCE,
         UTILIZATIONOPENDATE
         #,EXISTING_NEW
     ], 
     "MWH":[
        'ASOFDATE',                         
         'SOURCEID',
         'ONEOBLIGORNUMBER',
         'CUSTOMERNUMBER',
         'FACILITYNUMBER',
         'FAS114_STATUS',
         'LOCAL_NPL_FLAG',
         'TDR',
         UNIQUE_FACILITY_ID,
         PD_GROUP,
         UTILIZATIONBOOKBALANCE,
         UTILIZATIONOPENDATE
         #,EXISTING_NEW
     ],
     "RUNOFF_CCRC":[
        'ASOFDATE',                         
         'SOURCEID',
         'ONEOBLIGORNUMBER',
         'CUSTOMERNUMBER',
         'FACILITYNUMBER',
         'FAS114_STATUS',
         'LOCAL_NPL_FLAG',
         'TDR',
         UNIQUE_FACILITY_ID,
         PD_GROUP,
         UTILIZATIONBOOKBALANCE,
         UTILIZATIONOPENDATE
         #,EXISTING_NEW
     ],
     "SBB":[
        'ASOFDATE',                         
         'SOURCEID',
         'ONEOBLIGORNUMBER',
         'CUSTOMERNUMBER',
         'FACILITYNUMBER',
         'FAS114_STATUS',
         'LOCAL_NPL_FLAG',
         'TDR',
         UNIQUE_FACILITY_ID,
         PD_GROUP,
         UTILIZATIONBOOKBALANCE,
         UTILIZATIONOPENDATE
         #,EXISTING_NEW
     ]


}

'''
Usage:
main()
***
args:
    optional:
    
    -index_list: a list of portfolios & attributes
    -to_where: default is your current working directory
    -dat: dict : the data used to plot
    -save: boolean : whether to store the figures 
    dates: list e.g. [datetime.datetime(2017,3,31),datetime.datetime(2016,12,31)]
'''        
def main(index_list = index_list, to_where = os.getcwd(),dat = None,save = True,dates = [datetime.datetime(2017,3,31),datetime.datetime(2016,12,31)]):
    to_where = to_where.replace('\\','/') + '/' + 'QQQ'
    result = []
    if not os.path.exists(to_where):
        os.mkdir(to_where)
    if save:
        print("Charts will be stored into {}".format(to_where))
    if dat is None:
        dat = get_summary(dates) 
    for i in index_list.keys():
        path = to_where+ '/' + i + '_Quality_Checking.png'
        if save:
            create_quality_checking_plot(dat,i).savefig(path,bbox_inches='tight')
            print('{} Chart path: {}'.format(i,path))
        else:
            result.append(create_quality_checking_plot(dat,i))
    if len(result)>0:
        return result
    print("Done.")

    

# to generate sql query
def make_query(as_of_date: datetime.datetime,
	pd_groups: (str,list),
	attributes: (str,list) = '*',
	pd_group_seg: str = 'PD_GROUP_2017'
	):
	sql_query = '''
		SELECT {attributes}
		FROM MACCAR.MV_LOSS_COMMERCIAL
		WHERE {pd_group_seg} in ({pd_groups}) AND ASOFDATE = \'{as_of_date}\'
		'''.format(attributes = ','.join(attributes) if isinstance(attributes,list) else attributes,
				   pd_group_seg = pd_group_seg,
				   pd_groups = ','.join(['\'' + i + '\'' for i in pd_groups]) if isinstance(pd_groups,list) else '\'' + pd_groups + '\'',
				   as_of_date = as_of_date.strftime('%d %b %Y'))
	return sql_query

# fetch data
def queryRFO(
	query: str,
	moodys_rfo_env: str = 'PROD_ENV',
	debug: bool= False
) -> pd.DataFrame:
	connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['PROD_ENV']

	cx_Oracle_DSN = cx_Oracle.makedsn(
		host=connection_strings["HOST_IP"],
		port=connection_strings["ORACLE_PORT"],
		sid=connection_strings["SID"]
	)
	connection = cx_Oracle.connect(
		user=connection_strings["USER_NAME"],
		password=connection_strings["PASSWORD"],
		dsn=cx_Oracle_DSN
	)
	cursor = connection.cursor()

	if debug: print(query)
	try:
		cursor.execute(query)
	except Exception as e:
		print(str(e))
		return(False)
	tmp_data = pd.DataFrame(
		cursor.fetchall(),
		columns=[item[0] for item in cursor.description]
	)
	cursor.close()
	connection.close()

	return(tmp_data)

 
# get data we need
def get_summary(as_of_date,lists = index_list):
	def get_one_date(date,lists = lists):
		pd_groups = list(lists.keys())
		output = {}
		for pd_group in pd_groups:
			print('****TEST******'+pd_group)
			queryResult = queryRFO(make_query(date,pd_group,lists[pd_group]))
			# summary
			print('******TEST****** QUERY')
			print(queryResult.iloc[0:5])
			check_null = {i:{'Count':sum(pd.isnull(queryResult[i])),\
							 'Total Count':len(queryResult),\
							 'Weighted_Balance':sum(queryResult.dropna(axis= 0, how = 'any',subset = [i])['UTILIZATIONBOOKBALANCE'])/sum(queryResult['UTILIZATIONBOOKBALANCE'])\
							 }\
						  if sum(pd.isnull(queryResult[i]))/len(queryResult) > 0 else None\
			              for i in queryResult.keys()}
			print('**********TEST**********')
			print(check_null)
			output[pd_group] = check_null
		return output
	if isinstance(as_of_date,datetime.datetime):
		return get_one_date(date = as_of_date,lists = lists)
	elif isinstance(as_of_date,(list,tuple)):
		try:
			ultimate_output = {}
			for date in as_of_date:
				ultimate_output[date] = get_one_date(date =date, lists = lists)
			return ultimate_output
		except TypeError:
			raise TypeError('Input date not valid!')
	else:
		raise TypeError('Input date not valid!')


# plot func
def create_quality_checking_plot(dat,portfolio_name,rowcolors = ['darkgrey','mistyrose','dodgerblue'],colcolors = ['lemonchiffon','khaki'],figsize = (16,9)):
    abl = [dat[i][portfolio_name] for i in dat.keys()]
    a1 = pd.DataFrame.dropna(pd.DataFrame.from_dict(abl[1]),axis = 1)
    a2 = pd.DataFrame.dropna(pd.DataFrame.from_dict(abl[0]),axis = 1)
    ab = pd.merge(a1,a2,how = 'outer',left_index=True,right_index=True,suffixes=('_1','_2'))
    if len(ab.keys()) <= 10:
        dates = [i.strftime('%d %b %Y') for i in dat.keys()]
    else:
        dates = [i.strftime('%m/%d/%Y') for i in dat.keys()]
    fig,axs = plt.subplots(1,1,figsize =figsize)
    #rowcolors = plt.cm.YlGn([0.5,0.1,0.7])
    rowcolors = rowcolors
    colcolors = colcolors
    # set the margins of plots
    axs.set_xlim(0, 1)
    axs.set_ylim(0, 1)
    posi = np.arange(len(ab.keys()))
    each = 1/len(posi)
    each_start  = np.linspace(0,1,len(posi)+1)[0:-1]
    width = each*0.4
    space = each*0.1
    left = [i+space for i in each_start]
    bar1 = axs.bar(left=left,
    					   height=[1]*len(left),
            					   bottom=[0]*len(left),
            					   width=[width] * (len(left)),
            					   color=[rowcolors[1]]*len(left),
            					   alpha=0.75,
            					   edgecolor=[rowcolors[1]]*len(left),
            					   linewidth=0.01)
    bar2 = axs.bar(left=left,
            					   height=ab.apply(lambda x:x['Count']/x['Total Count'],axis=0).tolist(),
            					   bottom=[0]*len(left),
            					   width=[width] * len(left),
            					   color=[rowcolors[0]]*len(left),
            					   alpha=0.75,
            					   edgecolor=[rowcolors[0]]*len(left),
            					   linewidth=0.01)
    bar3 = axs.bar(left = [i+width for i in left],
                            height=[1]*len(left), 
                            bottom = [0]*len(left),
                            width = [width] * (len(left)),
                            color=[rowcolors[1]]*len(left),
                            alpha = 0.75,
                            edgecolor=[rowcolors[1]]*len(left),
                            linewidth=0.01 
            )
    bar4 = axs.bar(left = [i+width for i in left],
                            bottom = [0]*len(left), 
                            height = [i for i in ab.loc['Weighted_Balance',:]],
                            width = [width] * (len(left)),
                            color=[rowcolors[2]]*len(left),
                            alpha = 0.75,
                            edgecolor=[rowcolors[2]]*len(left),
                            linewidth=0.01 
            )
    #axs.set_xticks([])
    axs.set_yticks(np.linspace(0,1,len(posi))[0:])
    axs.set_yticklabels(['%.0f'%(i*100)+'%' for i in np.linspace(0,1,len(posi))][0:])
    #axs.set_title('ABL',fontsize = 20,color = 'red',loc = 'right')
    axs.set_ylabel('NULL / WeightedBalance Percentage',fontsize = 20)
    
    
    #axs.text(1, 0.95, 'CRE MULTIFAMILY',
    #        horizontalalignment='right',
    #        verticalalignment='center',
    #        rotation='horizontal',
    #        fontsize = 20,
    #        color = 'red',
    #        family = 'cursive')
    
    axs.set_xticks([i+width for i in left])
    axs.set_xticklabels([''.join(i.split('_')[0:-1]) for i in ab.keys()],minor = False,rotation = 10)
    
    #axs.invert_xaxis()
    axs.xaxis.tick_top()
    
    #axs.yaxis.tick_right()
    #axs.yaxis.set_label_position("right")
    rows = ['Missing Count','Total Count', 'Weighted Balance']
    columns = ab.keys()
    data_u = np.asarray(ab)
    celltext = []
    celltext.append(['%d'%(i) for i in data_u[0]])
    celltext.append(['%d'%(i) for i in data_u[1]])
    celltext.append(['%.1f'%(i*100)+'%' for i in data_u[2]])
    
    the_table = axs.table(cellText = celltext ,
                          rowLabels=rows,
                          rowColours=rowcolors,
                          colColours =np.repeat(colcolors,len(ab.keys())//2),
                          colLabels=np.repeat(dates,len(ab.keys())//2),
                          loc='bottom')
    the_table.auto_set_font_size(False)
    the_table.set_fontsize(12)
    the_table.scale(1,2)
    axs.tick_params(
            axis='both',
            which='both',
            bottom='off',
            top='off',
            left='off',
            right='off',
            labelbottom='off',
            labeltop = 'on',
            labelleft='on')
    fig.suptitle(' '.join(portfolio_name.split('_')), fontsize=18, fontweight='bold',color = 'red')
    return fig

#dat = get_summary([datetime.datetime(2017,3,31),datetime.datetime(2016,12,31)])    


