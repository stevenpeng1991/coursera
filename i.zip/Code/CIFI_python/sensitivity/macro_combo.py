# -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 14:44:20 2018

@author: n838126

list_of_model=[
 '37 - Scenario Analysis Model - SBB PD - SBNA',
 '53 - Scenario Analysis Model - CEVF PD - SBNA',
 '2016-SBNA-Loss-Commercial-CRE',
 '2016-SBNA-Loss-Commercial-GCB',
 '2016-SBNA-Loss-Commercial-CREConstruction',
 '743 - Commercial Rating Model - C&I PD - SBNA']
        
##############################
        Example
##############################
variables = macrovariables_list['743 - Commercial Rating Model - C&I PD - SBNA']
all_combos = generateCombo(variables,scenarios=[SCENARIO[0],SCENARIO[1]],driver=['FHOFHOPIQ_US','FLBR_US'])

cf_container = sensitivityOutput(all_combos, portfolio = 'CNI')

anchor_data = getAnchor(portfolio = 'CNI')  

# balance walk result    

balance_walk_sensitivity=balanceWalk(cf_container,anchor_data,)
result = result(balance_walk_sensitivity,bw_mode=1,pd_group=['CRE_MULTIFAMILY'])

"""
import copy
import os
import sys
global WD
WD = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if WD not in sys.path:
    sys.path.append(WD)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import getpass
import _pickle
import time
import pandas as pd
from CIFI.config import CONFIG
from tinydb import TinyDB, Query

##
## IMPORT MODULES (MODELS AND EJMS)
##
from CIFI.controllers.models.creconstruction17 import CREConstruction
from CIFI.controllers.models.logitmodel import TwoFLogitModel
from CIFI.controllers.ejm.ejmmaster import EJMGenerator, ejmDictionaryGenerator
from CIFI.controllers.models.riskratingmodel import RiskRatingModel
from CIFI.controllers.models.gcbindustry import GCBModel
from CIFI.controllers.models.cniriskrating import CNIModel

## IMPORT Balance Walk module
from CIFI.sensitivity import balancewalk

SCENARIO=["FRB_BASE","FRB_ADVERSE"]
SCENARIO_SEVERITY_LEVEL='ADVERSE'

AS_OF_DATE=datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE=datetime.datetime(2017,12,31)
SCENARIO_DATE=datetime.datetime(2017,12,31)

STRESS_TESTING_CYCLE='CCAR2018'
FORECAST_PERIODS=27
CRE_MF_STRESS_SWITCH=True
CREPI_MULTIFAMILY_SCALAR=None
CRE_RISK_RATING_DATASET_INPUT_PATH='I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cre_dec_2017_current.xlsx'
CNI_RISK_RATING_DATASET_INPUT_PATH='I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cni_dec_2017_no_orig.xlsx'
INDUSTRYTAG_FILE = 'I:\\CRMPO\\CCAR\\4Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Dec.xlsx'
STATEMENT_DAYS_THRESHOLD = 546
# Pull Macro list
path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties) 

MODEL_NAME={
 'SBB': '37 - Scenario Analysis Model - SBB PD - SBNA',
 'CEVF':'53 - Scenario Analysis Model - CEVF PD - SBNA',
 'CRE': '2016-SBNA-Loss-Commercial-CRE',
 'GCB': '2016-SBNA-Loss-Commercial-GCB',
 'CRE_C': '2016-SBNA-Loss-Commercial-CREConstruction',
 'CNI': '743 - Commercial Rating Model - C&I PD - SBNA'}
 
macrovariables_list={}
for model in MODEL_NAME.values():
    macrovariables_list[model]=list(set([variable['macro_variable_name'] for variable in db.search((Query().version_date=='12/31/2017')&(Query().name=='macro_variables')&(Query().model_id== model))[0]['value']]))


  
def generateCombo(variables,scenarios,driver=None,style='One'):
    if isinstance(scenarios, str) or len(scenarios) == 1:
        return {i: scenarios for i in variables} 
    elif isinstance(scenarios, list):
        if style == 'One': 
            if driver != None:
                change_variables = driver                
            else:
                change_variables = variables                
            all_combo = []
            for i in range(1,len(scenarios)):
                raw_combo = {v: scenarios[i-1] for v in variables}                                         
                for variable in change_variables:
                    raw_combo_new = copy.deepcopy(raw_combo)
                    raw_combo_new[variable] = scenarios[i]
                    all_combo.append(raw_combo_new) 
                if driver != None:
                    all_combo.append({v: scenarios[i-1] if v in (driver) else scenarios[i]for v in variables})   
            return(all_combo)
        else:            
            return(None)
    else:            
        return('Scenario type is not correct')        
        

     
##
## Balance Walk
##       
def sensitivityOutput(all_combos,portfolio='CRE'):
    cf_container = []
    transformed_macro_series_list = []
    driver = []
    for idx, comb in enumerate(all_combos):
        current_driver = list(pd.Series(comb)[pd.Series(comb).values==SCENARIO[1]])
        driver.append(current_driver)
        print('>>>>Current driver is {}'.format(current_driver))
        if portfolio =='CRE':
            if STRESS_TESTING_CYCLE == 'CCAR2018':
                if comb['FZFL075035503Q_US'] == 'BHC_STRESS':
                    CREPI_MULTIFAMILY_SCALAR=[
                                                    215.7,
                                                    220.7,
                                                    212.91060155,
                                                    188.50509395,
                                                    173.19332673,
                                                    151.04388494,
                                                    142.79066312,
                                                    127.63307239,
                                                    121.17749675,
                                                    109.06475059,
                                                    116.03725928,
                                                    117.6368452,
                                                    122.34079311,
                                                    126.53543839,
                                                    131.10649631,
                                                    134.44560066,
                                                    140.2107775,
                                                    144.56752945
                                              ][:11]    
                elif comb['FZFL075035503Q_US'] == 'FRB_ADVERSE':
                    CREPI_MULTIFAMILY_SCALAR=[
                                                    215.7,
                                                    220.7,
                                                    193.64108719,
                                                    185.32623251,
                                                    178.75353785,
                                                    173.76462504,
                                                    169.64679225,
                                                    167.1127413,
                                                    165.52895945,
                                                    165.52895945,
                                                    165.52895945,
                                                    166.16247219,
                                                    167.03355221,
                                                    168.1421995,
                                                    169.40922497,
                                                    170.72794611,
                                                    172.09927378,
                                                    173.52415999
                                              ][:11]
                elif comb['FZFL075035503Q_US'] == 'FRB_SA':
                    CREPI_MULTIFAMILY_SCALAR=[
                                                    215.7,
                                                    220.7,
                                                    185.32623251,
                                                    163.31166487,
                                                    145.65249731,
                                                    132.42791891,
                                                    121.341446,
                                                    114.76875135,
                                                    110.33416218,
                                                    110.33416218,
                                                    110.41335127,
                                                    112.1555113,
                                                    114.37280588,
                                                    117.3028023,
                                                    120.86631145,
                                                    123.89024991,
                                                    126.3256783,
                                                    128.12950444
                                              ][:11]   
                else:
                    CREPI_MULTIFAMILY_SCALAR = None    
                    
            model_instance = RiskRatingModel(
                                    uncertainty_rate=0.00,
                                    as_of_date=AS_OF_DATE,
                                    dataset_query_date=PORTFOLIO_SNAPSHOT_DATE,
                                    scenario_date=SCENARIO_DATE,
                                    model_id=MODEL_NAME[portfolio],
                                    scenario=SCENARIO,
                                    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                                    scenario_context=STRESS_TESTING_CYCLE,
                                    forecast_periods=FORECAST_PERIODS,
                                    ne_scalar=True,
                                    crepi_multifamily_scalar=CREPI_MULTIFAMILY_SCALAR,
                                    debug=True,
                                    bau=None,
                                    origination=True,
                                    book_balance_filter=None,
                                    gl_filter=True,
                                    path_dependent=True,
                                    read_input=True,
                                    dataset_path=CRE_RISK_RATING_DATASET_INPUT_PATH,
                                    final_rating_switch = True,
                                    scenario_combinations = comb
                                ) 
        elif portfolio =='CNI':             
            model_instance = CNIModel(
                as_of_date=AS_OF_DATE,
                scenario=SCENARIO,
                scenario_context=STRESS_TESTING_CYCLE,
                scenario_date=SCENARIO_DATE,
                scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                forecast_periods=FORECAST_PERIODS,
                forecast_periods_frequency='monthly',
                pass_srr=4.0,
                model_id=MODEL_NAME[portfolio],
                debug=False,
                include_originations_switch=False,
                auto_fetch_macros=True,
                limit_contracts=None,
                statement_days_threshold=STATEMENT_DAYS_THRESHOLD,
                portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,
                mature_non_pass_locs=True,
                scenario_combinations = comb,
                financial_in_rfo = True,
                new_financial_logic = True,
                risk_rating_dataset_input_path = CNI_RISK_RATING_DATASET_INPUT_PATH
            )    
        elif portfolio =='GCB':                
            model_instance = GCBModel(
                as_of_date=AS_OF_DATE,
                dataset_query_date=PORTFOLIO_SNAPSHOT_DATE,
                scenario_date=SCENARIO_DATE,
                model_id = MODEL_NAME[portfolio],
                scenario=SCENARIO,
                scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS,
                industrytag_file=INDUSTRYTAG_FILE
            ) 
        else:              
            model_instance = TwoFLogitModel(
                uncertainty_rate=0.,
                as_of_date=AS_OF_DATE,
                scenario_date=SCENARIO_DATE,
                model_id= MODEL_NAME[portfolio],
                scenario=SCENARIO,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS,
            )            
        # check macro and transformation
        transformed_macro_series_list.append(model_instance.transformed_macro_series_include_all)
        
        ## Create a session instance and a model shopping cart to run the CNIModel
        ccar_session = CCARSession(
            session_id='2018 CCAR',
            session_date=datetime.datetime(2017,12,31)
        )
        cart = ModelShoppingCart(ccar_session=ccar_session)
        ## Add model to the shopping cart and execute
        cart.addModel(model_instance)
        cart.checkout() # execute() is called here
        
        ## Get contributor file and store in the cf container
        cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
        cf_container.append(cf.getCFData())
    
        ## reset CF generator and shopping cart
        ccar_session.contributor_file_generator.resetGenerator()
        cart.resetCart()
        return(cf_container)
        
#####################
### Anchor Data ####
#####################  
def getAnchor(portfolio):
    
    cni_risk_rating_dataset_input_path = CNI_RISK_RATING_DATASET_INPUT_PATH
    cre_risk_rating_dataset_input_path = CRE_RISK_RATING_DATASET_INPUT_PATH
    
    if portfolio in ('CRE','CNI'):
        pd_groups = []
        only_risk_rating = True
        risk_rating_switch = True
        if portfolio == 'CRE':
            cni_risk_rating_dataset_input_path = None        
        else:
            cre_risk_rating_dataset_input_path = None  

    else:
        pd_groups = [portfolio]
        only_risk_rating = False
        risk_rating_switch = False
        cni_risk_rating_dataset_input_path = None
        cre_risk_rating_dataset_input_path = None  
        
    anchor_data=balancewalk.getBWFormatAnchorData(
        as_of_date= PORTFOLIO_SNAPSHOT_DATE,
        pd_groups=pd_groups,
        risk_rating_switch = risk_rating_switch,
        cni_dataset_path = cni_risk_rating_dataset_input_path, 
        cre_dataset_path = cre_risk_rating_dataset_input_path,
        overwrite_calculated_line = True,
        only_risk_rating = only_risk_rating,
        debug=False
        ) 
    return(anchor_data)       
#####################
### Balance Walk ####
#####################    
# generate balance walk outputs and combine them 
def balanceWalk(cf_container,anchor_data,driver):
    t0=time.time()
    bw_output_list = []
    pivot_bw_result=pd.DataFrame()
#    i = 0
    for cf_data in cf_container:
        print('Running balance walk.......')
        bw_output = balancewalk.balanceWalkMacroSensitivity(
            cf_data = cf_data,
            anchor_data=anchor_data,
            segfield2_to_nco_timing_curve=None,
            process_ALLL_balances = False,
            debug = True
        )      
        bw_output_list.append(bw_output)
    #    bw_output.to_csv(WD+'/CIFI/Execution/BalanceWalk/'+'BW_output_'+SCENARIO+"_version_"+str(i)+'.csv') 
        # Pivot balance walk output
        pivot_bw=balancewalk.balanceWalkPivot(bw_output,FORECAST_PERIODS,AS_OF_DATE,bw_output_from_csv = False)    
#        pivot_bw['Driver'] = driver[i]
        pivot_bw_result = pivot_bw_result.append(pivot_bw)
#        i += 1
    
    print('Balance walk completed in ' + str(time.time()-t0) + ' s.')
    return(pivot_bw_result)


def result(bw_result,bw_mode,pd_group=None):
    result = bw_result[(bw_result.index.get_level_values('BW_MODE')==bw_mode)]
    if pd_group != None:
        result = result[result.index.get_level_values('PD_GROUP').isin(pd_group)]
    result = result.sort_values(['LGD(%)'])
    return(result)
    
