"""
SAMPLE USE
----------

FRB_SA_BW = balanceWalk(
    as_of_date = datetime.datetime(2016, 12, 31),
    cf_id_list = [101, 102, 103, 104],
    scenario = 'FRB_SA',
    file_version = 5,
    limit_contracts = 1,
    debug = True
)
----------
SP20
----------

def getdata(id):
    data=pd.read_csv("C:/Users/n838126/CCAR/CIFI/run_log/" + id+ ".csv")
    return(data)

cf_data=pd.DataFrame()
for id in ['cf_id_101','cf_id_102','cf_id_103','cf_id_104']:
    cf_data=pd.concat([cf_data,getdata(id)])

cf_data_raw=copy.deepcopy(cf_data)

# Convert datetime
cf_data.PERIODDATE = pd.to_datetime(cf_data.PERIODDATE)
cf_data.VINTAGE = pd.to_datetime(cf_data.VINTAGE)

# select current vintage for balance walk
cf_data=cf_data[cf_data['VINTAGE']==datetime.datetime(2017,3,31)]
# if anchor data is loaded as csv --> convert datetime
anchor_data.MAXIMUMMATURITYDATE = pd.to_datetime(anchor_data.MAXIMUMMATURITYDATE)

#get anchor data set
anchor_data=getBWFormatAnchorData(
    as_of_date= datetime.datetime(2017,2,28),
    debug=True
    )

t0=time.time()

# SP20_BASE_BW = balanceWalk(
#     cf_data = cf_data,
#     anchor_data=anchor_data,
#     scenario_list=['BASE'],
#     process_ALLL_balances = True,
#     debug = True
# )
# CCAR17_BW = balanceWalk(
#     cf_data = cf_data,
#     anchor_data=anchor_data,
#     scenario_list=['FRB_BASE','FRB_ADVERSE','FRB_SA','BHC_SA'],
#     process_ALLL_balances = True,
#     debug = True
# )
SP20_ccarBASE_BW = balanceWalk(
    cf_data = cf_data,
    anchor_data=anchor_data,
    scenario_list=['FRB_BASE'],
    process_ALLL_balances = True,
    debug = True
)
print('End balance walk in ' + str(time.time()-t0) + ' s.')
CCAR17_BW.to_csv("C:/Users/n838126/CCAR/CIFI/run_log/ccar2017.csv")


FRB_SA_BW_pivot = FRB_SA_BW.run(return_results=True)


as_of_date = datetime.datetime(2016, 12, 31)
cf_id_list = [101, 102, 103, 104]
scenario_list = ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA', 'BHC_SA']
debug = True

# READ FROM CSV
cf_data = pd.read_csv("C:/Users/n813863/Documents/cf_data.csv")
cf_data.drop('Unnamed: 0', axis=1, inplace=True)
cf_data.PERIODDATE = pd.to_datetime(cf_data.PERIODDATE)

#TEST
anchor_data=getBWFormatAnchorData(
    as_of_date= datetime.datetime(2017,12,31),
    pd_groups=['GCB'],
    debug=True
    )
# test overwrite_calculated_line
anchor_data_new=getBWFormatAnchorData(
    as_of_date= datetime.datetime(2017,12,31),
    pd_groups=['GCB'],
    debug=True,
    overwrite_calculated_line = True
    )

################  Risk Rating Dataset  ################
cni_dataset_path = 'I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cni_nov_2017.xlsx'
cre_dataset_path = 'I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cre_nov_2017.xlsx'
    
anchor_data=getBWFormatAnchorData(
    as_of_date = datetime.datetime(2017,11,30),
    risk_rating_switch = True,
    cni_dataset_path = 'I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cni_nov_2017.xlsx', 
    cre_dataset_path = 'I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cre_nov_2017.xlsx',
    overwrite_calculated_line = True,
    debug=True
    )
bhc = balanceWalk(
    cf_data = cf_data,
    anchor_data=anchor_data,
    scenario_list=['BHC_STRESS'],
    process_ALLL_balances = False,
    debug = True
)
########################################################

#get NCO curve
segfield2_to_nco_timing_curve= balancewalk.getNCOCurve(        
    forecast_period=27,
    nco_data_path = CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_PATH"],
    timing_curve_switch = True   
    )
"""
import sys
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.models.masterdataset.masterdataset import to_sql_array
import datetime
import pandas as pd
from pandasql import sqldf
import numpy as np
from scipy.ndimage.interpolation import shift
import copy
import dateutil.relativedelta as relativedelta


# HELPERS
date2str = lambda x : x.strftime("%Y%m%d")
date2OracleSTR = lambda x : x.strftime("%d-%b-%Y").upper()

# SEGMENTATION MAPS
global PORTFOLIO_SEGMENTATION_MAP
PORTFOLIO_SEGMENTATION_MAP = {
    'CI_RR': 'CCB Portfolio',
    'GCB': 'GCB',
    'CEVF_RETAIL': 'CCB Portfolio',
    'GOVERNMENT_BANKING': 'CCB Portfolio',
    'DFP_CHRYSLER': 'Auto Portfolio',
    'MWH': 'CCB Portfolio',
    'CRE_CONSTRUCTION': 'CRE - Portfolio',
    'MIDDLE_MARKET': 'CCB Portfolio',
    'CEVF_RR': 'CCB Portfolio',
    'CRE_UNSECURED': 'CCB Portfolio',
    'ABL': 'CCB Portfolio',
    'EQUIPMENT_FINANCE_LEASING': 'CCB Portfolio',
    'RUNOFF_CCRC': 'CCB Portfolio',
    'BUSINESS_BANKING': 'CBB',
    'CRE_OTHER': 'CRE - Portfolio',
    'CI_OTHERS': 'CCB Portfolio',
    'CRE_MULTIFAMILY': 'CRE - Portfolio',
    'ENERGY_FINANCE': 'CCB Portfolio',
    'DFP_FOOTPRINT': 'Auto Portfolio',
    'CRE_REITS': 'CCB Portfolio'
}

global MODEL_SEGMENTATION_MAP
MODEL_SEGMENTATION_MAP = {
    'CI_RR': 'Other EJMs',
    'GCB': 'GCB',
    'CEVF_RETAIL': 'CEVF',
    'GOVERNMENT_BANKING': 'Other EJMs',
    'DFP_CHRYSLER': 'Chrysler',
    'MWH': 'Other EJMs',
    'CRE_CONSTRUCTION': 'CRE - Construction',
    'MIDDLE_MARKET': 'MM model',
    'CEVF_RR': 'Other EJMs',
    'CRE_UNSECURED': 'Other EJMs',
    'ABL': 'ABL',
    'EQUIPMENT_FINANCE_LEASING': 'Other EJMs',
    'RUNOFF_CCRC': 'Other EJMs',
    'BUSINESS_BANKING': 'UBB',
    'CRE_OTHER': 'CRE-Others',
    'CI_OTHERS': 'Other EJMs',
    'CRE_MULTIFAMILY': 'CRE - Multifamily',
    'ENERGY_FINANCE': 'Other EJMs',
    'DFP_FOOTPRINT': 'Core',
    'CRE_REITS': 'Other EJMs'
}


# global SEGFIELD2_TO_NCO_TIMING_CURVE
def getNCOCurve(        
        forecast_period : int,
        nco_data_path : str,
        timing_curve_switch = True     
        ):
    
    # example: nco_data_path= CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_PATH"]    
    generateFlatNCOTimingCurve = lambda forecast_periods : [1]+np.repeat(0,forecast_periods-1).tolist()
    
    # switch of whether using timing curve for NCO curve
    if timing_curve_switch:
        nco_data = pd.read_excel(
            io=nco_data_path,
            sheetname='NCO_BalanceWalk',
            na_values = [],
            keep_default_na = False
        )
        SEGFIELD2_TO_NCO_TIMING_CURVE = {}
        for segment in ('SBB', 'CRE', 'C&I', 'CEVF') :
            SEGFIELD2_TO_NCO_TIMING_CURVE[segment] = nco_data[segment][:forecast_period].tolist()
    else:
        SEGFIELD2_TO_NCO_TIMING_CURVE = {
            'SBB': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
            'CRE': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
            'C&I': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
            'CEVF': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
        }    
    
    return (SEGFIELD2_TO_NCO_TIMING_CURVE)

def processNCOTimingCurves(
    lgd_amount: (np.ndarray, list, tuple),
    nco_curve: (np.ndarray, list, tuple),
    apply_curve: bool
) -> np.ndarray:
    """

    """
    if len(lgd_amount) != len(nco_curve):
        raise ValueError("Input vector-like parameters have unequal lengths.")
    utilities.checkDataType(lgd_amount, (np.ndarray, list, tuple))
    utilities.checkDataType(nco_curve, (np.ndarray, list, tuple))
    utilities.checkDataType(apply_curve, bool)

    lgd_amount = np.array(lgd_amount)
    dim1_len = len(lgd_amount)
    if apply_curve:
        nco_curve = np.array(nco_curve)
    else:
        nco_curve = np.zeros(dim1_len)
        nco_curve[0] = 1

    result = lgd_amount.transpose() * np.matrix([
        shift(row, idx) for idx, row in enumerate(nco_curve * np.ones([dim1_len, dim1_len]))
    ])

    return np.array(result.tolist()[0])


def processBWFacility(
    forecast_periods: int,
    current_facility: dict,
    scenario_name: str,
    loc_default_reduction_switch: bool,
    loc_maturity_treatment_switch: bool,
    apply_curve: bool,    
    process_ALLL_balances: bool,
    remove_lc_from_balance: bool = False,
    **kwargs
):
    """

    Args:
        forecast_periods:
        current_facility:
        scenario_name:
        loc_default_reduction_switch:
        loc_maturity_treatment_switch:
        apply_curve:
        process_ALLL_balances:
        segfield2_to_nco_timing_curve: (optional)            

    Return:

    """
    segfield2_to_nco_timing_curve = kwargs.get('segfield2_to_nco_timing_curve')
    
    # INITIAL CHECKS
    for forecast_var in [
        'STARTINGBALANCE',
        'FINALBALANCE',
        'DEFAULTBALANCE',
        'BALANCE',
        'LCAMT',
        'CALCULATEDLINE',
        'LGDAMOUNT',
        'NCOAMOUNT',
        'EADAMOUNT',
        'ALLLRESERVEAMOUNT',
        'CONTINGENTRESERVEAMOUNT',
        'FACILITYTYPE',
        'PORTFOLIO',
        'MODEL',
        'SCENARIO',
        'LOC_DEFAULT_REDUCTION_FLAG',
        'LOC_MATURITY_TREATMENT_FLAG',
        'LOANTYPE',
        'BW_MODE'
    ]:
        if forecast_var not in list(current_facility.keys()):
            current_facility[forecast_var] = [np.NaN]*forecast_periods

    for idx in range(forecast_periods):
        # SET INITIAL PROPERTIES
        current_facility['SCENARIO'][idx] = scenario_name
        current_facility['PORTFOLIO'][idx] = PORTFOLIO_SEGMENTATION_MAP[current_facility['PD_GROUP'][idx]]
        current_facility['MODEL'][idx] = MODEL_SEGMENTATION_MAP[current_facility['PD_GROUP'][idx]]

        # SET INITIAL FLAGS
        if loc_default_reduction_switch:
            current_facility['LOC_DEFAULT_REDUCTION_FLAG'][idx] = 'Y'

            if loc_maturity_treatment_switch:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'Y'
                current_facility['BW_MODE'][idx] = 1
            else:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'N'
                current_facility['BW_MODE'][idx] = 2

        else:
            current_facility['LOC_DEFAULT_REDUCTION_FLAG'][idx] = 'N'

            if loc_maturity_treatment_switch:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'Y'
                current_facility['BW_MODE'][idx] = 3
            else:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'N'
                current_facility['BW_MODE'][idx] = 4


       # DEFINE BOP BALANCES
        if idx == 0:
            current_facility['STARTINGBALANCE'][idx] = current_facility['BOOKBALANCE'][idx]
            if not remove_lc_from_balance:
                current_facility['BALANCE'][idx] = current_facility['BOOKBALANCE'][idx] + \
                                                    current_facility['LCAMOUNT'][idx]
            else:
                current_facility['BALANCE'][idx] = current_facility['BOOKBALANCE'][idx] 
            current_facility['LCAMT'][idx] = current_facility['LCAMOUNT'][idx]

            current_facility['CALCULATEDLINE'][idx] = current_facility['EXPOSURE'][idx]
        else:
            current_facility['STARTINGBALANCE'][idx] = 0

            current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx-1]
            current_facility['LCAMT'][idx] = current_facility['LCAMT'][idx-1]
            current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx-1]

        # CALCULATE EAD BALANCES
        ead_balance = current_facility['BALANCE'][idx] * current_facility['EADBALANCE'][idx]
        ead_lcamount= current_facility['LCAMT'][idx] * current_facility['EADLETTEROFCREDIT'][idx]
        if not remove_lc_from_balance:
            ead_available_line = (
                current_facility['CALCULATEDLINE'][idx] - current_facility['BALANCE'][idx]
            ) * current_facility['EADAVAILABLELINE'][idx]
        else:                
            ead_available_line = (
                current_facility['CALCULATEDLINE'][idx] - current_facility['BALANCE'][idx]-current_facility['LCAMT'][idx]
            ) * current_facility['EADAVAILABLELINE'][idx]
        ead_total_line = current_facility['CALCULATEDLINE'][idx] * current_facility['EADTOTALLINE'][idx]

        # CURRENT EAD AMOUNT
        if 'LINE OF CREDIT' in current_facility['FACILITYTYPE'][idx].upper():
            current_facility['LOANTYPE'][idx] = 'LINE OF CREDIT'
            if not remove_lc_from_balance:
                current_facility['EADAMOUNT'][idx] = min(
                    current_facility['CALCULATEDLINE'][idx],
                    ead_balance + ead_available_line + ead_total_line
                )
            else:   
                current_facility['EADAMOUNT'][idx] = min(
                    current_facility['CALCULATEDLINE'][idx],
                    ead_balance + ead_lcamount+ ead_available_line + ead_total_line
                )
        else:
            current_facility['LOANTYPE'][idx] = 'TERM_CCC'
            if not remove_lc_from_balance:
                current_facility['EADAMOUNT'][idx] = current_facility['BALANCE'][idx]
            else:
                current_facility['EADAMOUNT'][idx] = current_facility['BALANCE'][idx]+current_facility['LCAMT'][idx]

        # CHECK MATURITY
        if current_facility['PD_GROUP'][idx] == 'MWH':
            # For MWH: DO NOT Reduce Balances & DO NOT Mature LOCs
            # CALCULATE DEFAULT BALANCE
            current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * current_facility['PD'][idx]

            # UPDATE BALANCES
            current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx]
            current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx]

        elif 'LINE OF CREDIT' in current_facility['FACILITYTYPE'][idx].upper():

            # VERSION 1 - Reduce Balances & Mature LOCs
            if loc_default_reduction_switch & loc_maturity_treatment_switch:
                if pd.isnull(current_facility['MAXIMUMMATURITYDATE'][idx]):
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                       current_facility['DEFAULTBALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                              current_facility['DEFAULTBALANCE'][idx]
                elif(
                    ((current_facility['MAXIMUMMATURITYDATE'][idx] - current_facility['PERIODDATE'][idx]).days < 0)
                ):
                    current_facility['EADAMOUNT'][idx] = 0

                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = 0

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = 0
                    current_facility['CALCULATEDLINE'][idx] = 0
                else:
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                       current_facility['DEFAULTBALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                              current_facility['DEFAULTBALANCE'][idx]

            # VERSION 2 - DO NOT Reduce Balances & Mature LOCs
            elif (not loc_default_reduction_switch) & loc_maturity_treatment_switch:

                if pd.isnull(current_facility['MAXIMUMMATURITYDATE'][idx]):
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx]
                elif (
                    ((current_facility['MAXIMUMMATURITYDATE'][idx] - current_facility['PERIODDATE'][idx]).days < 0)
                ):
                    current_facility['EADAMOUNT'][idx] = 0

                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = 0

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = 0
                    current_facility['CALCULATEDLINE'][idx] = 0
                else:
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx]

            # VERSION 3 - Reduce Balances & DO NOT Mature LOCs
            elif loc_default_reduction_switch & (not loc_maturity_treatment_switch):
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                          current_facility['PD'][idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                   current_facility['DEFAULTBALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                          current_facility['DEFAULTBALANCE'][idx]

            # VERSION 4 - DO NOT Reduce Balances & DO NOT Mature LOCs
            else:
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * current_facility['PD'][idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx]

        else:
            if pd.isnull(current_facility['MAXIMUMMATURITYDATE'][idx]):
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * current_facility['PD'][
                    idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                   current_facility['DEFAULTBALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                          current_facility['DEFAULTBALANCE'][idx]
            elif (
                ((current_facility['MAXIMUMMATURITYDATE'][idx] - current_facility['PERIODDATE'][idx]).days < 0)
            ):
                current_facility['EADAMOUNT'][idx] = 0

                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = 0

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = 0
                current_facility['CALCULATEDLINE'][idx] = 0
            else:
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * current_facility['PD'][
                    idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                   current_facility['DEFAULTBALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                          current_facility['DEFAULTBALANCE'][idx]
        # CALCULATE LGD AMOUNT
        current_facility['LGDAMOUNT'][idx] = current_facility['DEFAULTBALANCE'][idx] * current_facility['LGD'][idx]

        # FINAL BALANCE
        if idx == (forecast_periods - 1):
            current_facility['FINALBALANCE'][idx] = current_facility['BALANCE'][idx]
        else:
            current_facility['FINALBALANCE'][idx] = 0

        # ALLOWANCE CALCULATIONS
        if process_ALLL_balances:
            current_facility['ALLLRESERVEAMOUNT'][idx] = current_facility['BALANCE'][idx] * \
                                                         current_facility['ALLLCOVERAGE'][idx]
            current_facility['CONTINGENTRESERVEAMOUNT'][idx] = (
                current_facility['CALCULATEDLINE'][idx] - current_facility['BALANCE'][idx]
            ) * current_facility['ALLLCOVERAGE'][idx]

    # APPLY NCO TIMING CURVE
    if segfield2_to_nco_timing_curve != None:    
        current_facility['NCOAMOUNT'] = processNCOTimingCurves(
            lgd_amount=current_facility['LGDAMOUNT'],
            nco_curve=segfield2_to_nco_timing_curve[current_facility['SEGMENTATIONFIELD2'][0]],
            apply_curve=apply_curve
        )
    else:
        current_facility['NCOAMOUNT'] = current_facility['LGDAMOUNT']
        
    return current_facility


def getBWFormatAnchorData(
    as_of_date: datetime.datetime,
    debug: bool,
    pd_groups: list =[],
    maximum_maturity_date_imputation: bool = True,
    **kwargs
) -> (str, pd.DataFrame):
    """

    Args:
        as_of_date (datetime.datetime) :
        debug (bool) :
        pd_groups (list) :
        risk_rating_switch (bool) : optional switch to choose whether reading risk rating input data or not
        cni_dataset_path(str): optional cni risk rating input data path 
        e.g cni_dataset_path = 'I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cni_nov_2017.xlsx'        
        cre_dataset_path(str): optional cre risk rating input data pat
        e.g cre_dataset_path = 'I:\\CRMPO\\CCAR\\4Q17\\1 - Data\\Risk Rating\\rfo_cre_nov_2017.xlsx'
        overwrite_calculated_line (bool) : optional switch to choose whether overwrite calculated_line for termoutline
        maximum_maturity_date_imputation (bool): optional switch to choose whether do maturity imputation
            
    Return:

    Example:
        >>> anchor_query, anchor_data = getBWFormatAnchorData(
                as_of_date=datetime.datetime(2016, 12, 31),
                debug=True,
                pd_groups=["CRE_CONSTRUCTION"]
            )
    """
    risk_rating_switch = kwargs.get('risk_rating_switch')
    only_risk_rating = kwargs.get('only_risk_rating')
    cni_dataset_path = kwargs.get('cni_dataset_path')
    cre_dataset_path = kwargs.get('cre_dataset_path')    
    overwrite_calculated_line = kwargs.get('overwrite_calculated_line')    
    
    if (risk_rating_switch != True) | (only_risk_rating != True):
        if not overwrite_calculated_line:
            query="""
                SELECT
                    ANCHOR.SOURCEID,
                    ANCHOR.ONEOBLIGORNUMBER,
                    ANCHOR.CUSTOMERNUMBER,
                    ANCHOR.FACILITYNUMBER,
                    ANCHOR.UNIQUE_FACILITY_ID,
                    ANCHOR.BOOKBALANCE,
                    ANCHOR.LCAMOUNT,
                    ANCHOR.EXPOSURE,
                    ANCHOR.SEGMENTNAME,
                    ANCHOR.PD_GROUP,
                    ANCHOR.MAXIMUMMATURITYDATE,
                    ANCHOR.OPENDATE,
                    ANCHOR.FACILITYTYPE,
                    ANCHOR.SEGMENTATIONFIELD2,
                    ANCHOR.MODELSEGMENT,
                    ANCHOR.RATENAME
                FROM (
                    (
                    SELECT INTER.*
                     FROM (SELECT
                        UPPER(SOURCEID) AS SOURCEID,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        UNIQUE_FACILITY_ID,
                        SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                        SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                        SUM(CALCULATED_LINE) AS EXPOSURE,
                        MAX(SEGMENTNAME) AS SEGMENTNAME,
                        MAX({}) AS PD_GROUP,
                        MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                        MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                        FACILITYTYPE,
                        SEGMENTATIONFIELD2,
                        TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                        TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                        TO_CHAR(EADAVAILABLELINE) AS EADAVAILABLELINE,
                        TO_CHAR(EADBALANCE) AS EADBALANCE,
                        TO_CHAR(EADLETTEROFCREDIT) AS EADLETTEROFCREDIT,
                        TO_CHAR(EADTOTALLINE) AS EADTOTALLINE,
                        TO_CHAR(EAD) AS EAD,
                        TO_CHAR(LGD) AS LGD,
                        TO_CHAR(PD) AS PD
                    FROM {}
                    WHERE
                        ASOFDATE = '{}'
                        AND
                        UPPER({}) NOT IN ('SMALL BUSINESS BANKING', 'SBB')
                        {}
                        {}
                        AND
                         (
                             (
                                 FAS114_STATUS = 'A - NOT REQUIRED'
                                 AND
                                 LOCAL_NPL_FLAG = 'N'
                             )
                         )
                        AND
                        UPPER(SOURCEID) NOT IN ('OFFLINE')
                    GROUP BY
                        SOURCEID,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        UNIQUE_FACILITY_ID,
                        FACILITYTYPE,
                        SEGMENTATIONFIELD2,
                        TO_CHAR(ALLLCOVERAGE),
                        TO_CHAR(CONTINGENTRESERVE),
                        TO_CHAR(EADAVAILABLELINE),
                        TO_CHAR(EADBALANCE),
                        TO_CHAR(EADLETTEROFCREDIT),
                        TO_CHAR(EADTOTALLINE),
                        TO_CHAR(EAD),
                        TO_CHAR(LGD),
                        TO_CHAR(PD)
                    HAVING
                        (
                        SUM(CALCULATED_LINE) > 0
                        OR 
                        SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
                        ))  INTER         
                )
                UNPIVOT (
                    MODELSEGMENT FOR RATENAME IN (
                        PD,
                        LGD,
                        EAD,
                        EADAVAILABLELINE,
                        EADBALANCE,
                        EADLETTEROFCREDIT,
                        EADTOTALLINE,
                        ALLLCOVERAGE,
                        CONTINGENTRESERVE
                    )
                ) ) ANCHOR
                ORDER BY
                    ANCHOR.UNIQUE_FACILITY_ID,
                    ANCHOR.RATENAME
                """.format(
                    CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
                    date2OracleSTR(as_of_date),
                    CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    " AND {} IN ".format(CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"]) + to_sql_array(
                    a=pd_groups, quote=True) if len(pd_groups) > 0 else "",
                    " AND {} NOT IN ".format(CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"]) + to_sql_array(
                    a=['ABL','BUSINESS_BANKING','MIDDLE_MARKET','CRE_MULTIFAMILY','CRE_OTHER'], quote=True) if risk_rating_switch == True else ""            
                )
        else:
            query="""
                SELECT
                    ANCHOR.SOURCEID,
                    ANCHOR.ONEOBLIGORNUMBER,
                    ANCHOR.CUSTOMERNUMBER,
                    ANCHOR.FACILITYNUMBER,
                    ANCHOR.UNIQUE_FACILITY_ID,
                    ANCHOR.BOOKBALANCE,
                    ANCHOR.LCAMOUNT,
                    ANCHOR.EXPOSURE,
                    ANCHOR.SEGMENTNAME,
                    ANCHOR.PD_GROUP,
                    ANCHOR.MAXIMUMMATURITYDATE,
                    ANCHOR.OPENDATE,
                    ANCHOR.FACILITYTYPE,
                    ANCHOR.SEGMENTATIONFIELD2,
                    ANCHOR.MODELSEGMENT,
                    ANCHOR.RATENAME,
                    ANCHOR.LINE_TERM
                FROM (
                    (SELECT
                        SOURCEID,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        UNIQUE_FACILITY_ID,
                        SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                        SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                        SUM(CALCULATED_LINE) AS EXPOSURE,
                        MAX(SEGMENTNAME) AS SEGMENTNAME,
                        MAX({}) AS PD_GROUP,
                        MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                        MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                        FACILITYTYPE,
                        SEGMENTATIONFIELD2,
                        ALLLCOVERAGE,
                        CONTINGENTRESERVE,
                        EADAVAILABLELINE,
                        EADBALANCE,
                        EADLETTEROFCREDIT,
                        EADTOTALLINE,
                        EAD,
                        LGD,
                        PD,
                        LINE_TERM
                    FROM
                    ( SELECT master.*, fe.*
                      FROM
                     (SELECT
                        UPPER(SOURCEID) AS SOURCEID,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        UNIQUE_FACILITY_ID,
                        UNIQUEID,
                        UTILIZATIONBOOKBALANCE,
                        UTILIZATIONLCAMOUNT,
                        CALCULATED_LINE,
                        SEGMENTNAME,
                        {},
                        MAXIMUMMATURITYDATE,
                        UTILIZATIONOPENDATE,
                        FACILITYTYPE,
                        SEGMENTATIONFIELD2,
                        TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                        TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                        TO_CHAR(EADAVAILABLELINE) AS EADAVAILABLELINE,
                        TO_CHAR(EADBALANCE) AS EADBALANCE,
                        TO_CHAR(EADLETTEROFCREDIT) AS EADLETTEROFCREDIT,
                        TO_CHAR(EADTOTALLINE) AS EADTOTALLINE,
                        TO_CHAR(EAD) AS EAD,
                        TO_CHAR(LGD) AS LGD,
                        TO_CHAR(PD) AS PD
                     FROM {}
                     WHERE
                         ASOFDATE = '{}'
                         AND
                         UPPER({}) NOT IN ('SMALL BUSINESS BANKING', 'SBB')
                         {}
                         {}
                         AND
                         (
                             (
                                 FAS114_STATUS = 'A - NOT REQUIRED'
                                 AND
                                 LOCAL_NPL_FLAG = 'N'
                             )
                         )
                         AND
                         UPPER(SOURCEID) NOT IN ('OFFLINE')
                    ) master
                    LEFT JOIN
                    (
                     SELECT *
                     FROM
                     (
                      (SELECT UNIQUEIDENTIFIER, LINE_TERM
                      FROM MV_FE_CCMIS_REVOLVE
                      WHERE REPORTING_DATE = '{}')
                      UNION ALL
                      (SELECT 
                      UNIQUEIDENTIFIER, LINE_TERM
                      FROM MV_FE_CCMIS_TERM_LOAN
                      WHERE REPORTING_DATE = '{}')
                     ) 
                    ) fe
                     ON master.UNIQUEID = fe.UNIQUEIDENTIFIER
                     )
                    GROUP BY
                        SOURCEID,
                        ONEOBLIGORNUMBER,
                        CUSTOMERNUMBER,
                        FACILITYNUMBER,
                        UNIQUE_FACILITY_ID,
                        FACILITYTYPE,
                        SEGMENTATIONFIELD2,
                        ALLLCOVERAGE,
                        CONTINGENTRESERVE,
                        EADAVAILABLELINE,
                        EADBALANCE,
                        EADLETTEROFCREDIT,
                        EADTOTALLINE,
                        EAD,
                        LGD,
                        PD,
                        LINE_TERM
                    HAVING
                        (
                        SUM(CALCULATED_LINE) > 0
                        OR 
                        SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
                        )        
                    )
                UNPIVOT (
                    MODELSEGMENT FOR RATENAME IN (
                        PD,
                        LGD,
                        EAD,
                        EADAVAILABLELINE,
                        EADBALANCE,
                        EADLETTEROFCREDIT,
                        EADTOTALLINE,
                        ALLLCOVERAGE,
                        CONTINGENTRESERVE
                    )
                ) ) ANCHOR
                ORDER BY
                    ANCHOR.UNIQUE_FACILITY_ID,
                    ANCHOR.RATENAME
                """.format(
                    CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
                    date2OracleSTR(as_of_date),
                    CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
                    " AND {} IN ".format(CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"]) + to_sql_array(
                    a=pd_groups, quote=True) if len(pd_groups) > 0 else "",
                    " AND {} NOT IN ".format(CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"]) + to_sql_array(
                    a=['ABL','BUSINESS_BANKING','MIDDLE_MARKET','CRE_MULTIFAMILY','CRE_OTHER'], quote=True) if risk_rating_switch == True else "",
                    date2OracleSTR(as_of_date),
                    date2OracleSTR(as_of_date)         
                )
                
        anchor_data = queryRFO(
            query=query,
            moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT'],
            debug=debug
        )
        
        # added 02072018: If LINE_TERM=”TermedOutLine”, Overwrite CALCULATED_LINE as (UTILIZATIONBOOKBALANCE+UTILIZATIONLCAMOUNT)
        if overwrite_calculated_line:
            def overwrite_exposure(line):
                if line['LINE_TERM'] == 'TermedOutLine':
                    return (line['BOOKBALANCE'] + line['LCAMOUNT'])
                else:
                    return (line['EXPOSURE'])
            anchor_data["EXPOSURE_NEW"] = anchor_data.apply(func=overwrite_exposure,axis=1)
            anchor_data["EXPOSURE"] = anchor_data["EXPOSURE_NEW"] 
            anchor_data.drop(['LINE_TERM', 'EXPOSURE_NEW'], axis=1, inplace = True)
            
        # 02282017 RFO GCB C&I fix
        if as_of_date==datetime.datetime(2017,2,28):
            anchor_data = anchor_data[anchor_data["ONEOBLIGORNUMBER"] != '0052690273']
    
    def readRiskRatingData(path):
        if os.path.exists(path) & os.path.isfile(path): 
            data = pd.read_excel(path,converters={
                                    'SOURCEID':str,'ONEOBLIGORNUMBER':str,
                                    'ONEOBLIGORNUMBER':str,'CUSTOMERNUMBER':str,
                                    'FACILITYNUMBER':str,'MASTER_CUSTOMER_ID':str
                                                 }
                                 )          
            return(data)
                       
    if risk_rating_switch == True:
        if cni_dataset_path != None:
            cni_dataset = readRiskRatingData(cni_dataset_path)
            if cre_dataset_path == None:
                risk_rating_dataset = cni_dataset
        if cre_dataset_path != None:
            cre_dataset = readRiskRatingData(cre_dataset_path)
            if cni_dataset_path == None:
                risk_rating_dataset = cre_dataset                      
        if (cni_dataset_path != None) & (cre_dataset_path != None):          
            risk_rating_dataset = pd.concat([cni_dataset, cre_dataset], ignore_index=True)
        # Take out origination    
        risk_rating_dataset = risk_rating_dataset[~risk_rating_dataset['UNIQUE_FACILITY_ID'].str.contains('_O')]            

        # Filter and aggregate to Facility level
        query = sqldf("""
            SELECT
                SOURCEID,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                UNIQUE_FACILITY_ID,
                BOOKBALANCE,
                LCAMOUNT,
                EXPOSURE,
                SEGMENTNAME,
                PD_GROUP,
                MAXIMUMMATURITYDATE,
                OPENDATE,
                FACILITYTYPE,
                SEGMENTATIONFIELD2,
                ALLLCOVERAGE,
                CONTINGENTRESERVE,
                EADAVAILABLELINE,
                EADBALANCE,
                EADLETTEROFCREDIT,
                EADTOTALLINE,
                EAD,
                LGD,
                PD
            FROM (
                
                SELECT *
                 FROM (SELECT
                    UPPER(SOURCEID) AS SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                    SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                    SUM(CALCULATED_LINE) AS EXPOSURE,
                    MAX(SEGMENTNAME) AS SEGMENTNAME,
                    MAX(PD_GROUP_2017) AS PD_GROUP_2017,
                    MAX(pd_group_tool) AS PD_GROUP,
                    MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                    MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                    FACILITYTYPE,
                    SEGMENTATIONFIELD2,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EADAVAILABLELINE,
                    EADBALANCE,
                    EADLETTEROFCREDIT,
                    EADTOTALLINE,
                    EAD,
                    LGD,
                    PD
                FROM risk_rating_dataset
                WHERE

                     (
                         (
                             FAS114_STATUS = 'A - NOT REQUIRED'
                             AND
                             LOCAL_NPL_FLAG = 'N'
                         )
                     )
                    AND
                    UPPER(SOURCEID) NOT IN ('OFFLINE')
                GROUP BY
                    SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    FACILITYTYPE,
                    SEGMENTATIONFIELD2,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EADAVAILABLELINE,
                    EADBALANCE,
                    EADLETTEROFCREDIT,
                    EADTOTALLINE,
                    EAD,
                    LGD,
                    PD
                HAVING
                    (
                    SUM(CALCULATED_LINE) > 0
                    OR 
                    SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
                    ))      
            ) 
            ORDER BY
                UNIQUE_FACILITY_ID,
                PD,
                LGD,
                EAD,
                EADAVAILABLELINE,
                EADBALANCE,
                EADLETTEROFCREDIT,
                EADTOTALLINE,
                ALLLCOVERAGE,
                CONTINGENTRESERVE
            """       
            )
        # Date Format       
        query['MAXIMUMMATURITYDATE'] = pd.to_datetime(query['MAXIMUMMATURITYDATE'],format="%Y-%m-%d")   
        query['OPENDATE'] = pd.to_datetime(query['OPENDATE'],format="%Y-%m-%d") 
                      
        risk_rating_dataset = pd.melt(
                                       query,
                                       id_vars=[ 'SOURCEID',
                                                 'ONEOBLIGORNUMBER',
                                                 'CUSTOMERNUMBER',
                                                 'FACILITYNUMBER',
                                                 'UNIQUE_FACILITY_ID',
                                                 'BOOKBALANCE',
                                                 'LCAMOUNT',
                                                 'EXPOSURE',
                                                 'SEGMENTNAME',
                                                 'PD_GROUP',
                                                 'MAXIMUMMATURITYDATE',
                                                 'OPENDATE',
                                                 'FACILITYTYPE',
                                                 'SEGMENTATIONFIELD2'
                                                 ],
                                       var_name=['RATENAME'],
                                       value_name='MODELSEGMENT'
                                     )   
        if only_risk_rating != True:
            anchor_data = pd.concat([risk_rating_dataset, anchor_data], ignore_index=True)                          
        else:
            anchor_data = risk_rating_dataset
            
    # added 02082018: Maximum maturity date imputation for missing maturity date or maturity date is prior to reporting month
    def updateMaturityDate(line):
        mat_d = line["MAXIMUMMATURITYDATE"]
        orig_d = line["OPENDATE"]
        asofdate = as_of_date
        facility_type = line['FACILITYTYPE']
        dmdLife = 11*12  # 11 years
        rloc_month_add = 15
        non_rloc_month_add = 46
        def remaining_life(asofdate, maturityDate):
            try:
                r_delta = relativedelta.relativedelta(maturityDate, asofdate)
            except (TypeError, AssertionError):
                remainingLife = np.nan
            else:
                remainingLife = r_delta.years * 12 + r_delta.months
            return(remainingLife)
        
        if mat_d <= asofdate:
            # if maturity date is prior or equal to as_of_date, forecast 12 month
            mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, 12))
        elif pd.isnull(mat_d):
            if pd.isnull(orig_d):
                if (facility_type.upper() == 'REVOLVING LINE OF CREDIT'):
                    mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, rloc_month_add))
                else:
                    mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, non_rloc_month_add))
            else:
                mat_d = utilities.monthEndDate(utilities.addMonths2date(orig_d, dmdLife))
                remainingLife = remaining_life(asofdate, mat_d)
                if (facility_type.upper() == 'REVOLVING LINE OF CREDIT') and (remainingLife < 15):
                    mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, rloc_month_add)) 
                elif (facility_type.upper() != 'REVOLVING LINE OF CREDIT') and (remainingLife < 46):
                    mat_d = utilities.monthEndDate(utilities.addMonths2date(asofdate, non_rloc_month_add)) 
        else:
            return(mat_d)
        return(mat_d)
        
    if maximum_maturity_date_imputation:
        anchor_data["MAXIMUMMATURITYDATE"] = anchor_data.apply(
            func=updateMaturityDate,
            axis=1
        )
        
    return(anchor_data)

def getRFOBWFormatCFData(
    debug: bool,
    cf_id_list: list,
    scenario_list: list
) -> (str, pd.DataFrame):
    query = """
        SELECT DISTINCT
            MODELSEGMENT,
            PERIODDATE,
            MODELOUTPUTRATE,
            RATENAME,
            SCENARIO,
            MAX(FILE_VERSION) AS FILE_VERSION
        FROM {}
        WHERE
            CONTRIBUTOR_FILE_ID IN {}
            AND VINTAGE='{}'
            AND SCENARIO IN {}
            AND RATENAME in (
                'PD',
                'LGD',
                'EAD',
                'EADAVAILABLELINE',
                'EADBALANCE',
                'EADLETTEROFCREDIT',
                'EADTOTALLINE',
                'ALLLCOVERAGE',
                'CONTINGENTRESERVE'
            )
        GROUP BY
            MODELSEGMENT,
            PERIODDATE,
            MODELOUTPUTRATE,
            RATENAME,
            SCENARIO
        """.format(
        'MACCAR.STG_CONTRIBUTOR_DATA',  # CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
        to_sql_array(A=cf_id_list, quote=False),
        date2OracleSTR(CONFIG['CONTRIBUTOR_FILE']['VINTAGE_ASOFDATE_VALUE']),
        to_sql_array(A=scenario_list, quote=True)
    )
    cf_data = queryRFO(
        query=query,
        moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT'],
        debug=debug
    )


def balanceWalk(
    cf_data: pd.DataFrame,
    anchor_data: pd.DataFrame,
    scenario_list: list,
    process_ALLL_balances: bool,
    debug: bool =True,
    remove_lc_from_balance: bool = False,
    **kwargs   
) -> pd.DataFrame:
    """

    Args:
        cf_data (pd.DataFrame) :
        anchor_data (pd.DataFrame) :
        scenario_list (list) :
        debug (bool) :
        segfield2_to_nco_timing_curve (optional) :
        remove_lc_from_balance (optional): whether remove LCAmount from 'BALANCE'
    Return:
        bw_results_pivot (pd.DataFrame) : the aggregated balance walk results.

    """
    segfield2_to_nco_timing_curve = kwargs.get('segfield2_to_nco_timing_curve')
    
    raw_anchor_balance_check = anchor_data.BOOKBALANCE.sum() / (len(anchor_data.RATENAME.unique()))
    cf_data_tmp = cf_data.copy(deep=True)
    
    # sum values for three columns in case of overlay
    cf_data_tmp['MODELOUTPUTRATE'] =  cf_data_tmp['MODELOUTPUTRATE'] + cf_data_tmp['MGMTADJUSTMENTRATE'] + cf_data_tmp['UNCERTAINTYADJUSTMENTRATE']

    pre_bw_data = anchor_data[['UNIQUE_FACILITY_ID','RATENAME', 'MODELSEGMENT']].merge(
        cf_data_tmp[
            ['SCENARIO', 'MODELOUTPUTRATE', 'RATENAME', 'MODELSEGMENT', 'PERIODDATE']
        ],
        on=['RATENAME', 'MODELSEGMENT'],
        how='left'
    )

    period_date_index = pd.Series(pre_bw_data['PERIODDATE'].unique()).sort_values()
    period_date_index = period_date_index[~pd.isnull(period_date_index)]
    period_date_index.reset_index(drop=True, inplace=True)
    forecast_periods = len(period_date_index)

    if len(pre_bw_data)!=(len(anchor_data)*forecast_periods*len(scenario_list)):
        raise Exception("Length of anchor_data != pre_bw_data.")

    pre_bw_data.drop('MODELSEGMENT', axis=1, inplace=True)

    bw_data_wide = pd.pivot_table(
        pre_bw_data,
        values='MODELOUTPUTRATE',
        index=list(set(list(pre_bw_data.columns)) - set(['RATENAME', 'MODELOUTPUTRATE'])),
        columns=['RATENAME'],
        aggfunc=np.mean
    ).reset_index()

    dups_check = bw_data_wide.duplicated(['UNIQUE_FACILITY_ID', 'SCENARIO', 'PERIODDATE'])
    if len(bw_data_wide[dups_check]) != 0:
        raise Exception("Duplicate in pivot table.")

    bw_data_wide_additional_fields = anchor_data[anchor_data.RATENAME=='PD'].merge(
        bw_data_wide,
        on=['UNIQUE_FACILITY_ID'],
        how='left'
    )
    bw_data_wide_additional_fields.drop('RATENAME', axis=1, inplace=True)

    bw_data_wide_balance_check = bw_data_wide_additional_fields.BOOKBALANCE.sum()/(len(scenario_list) *
        forecast_periods
    )
    if round(raw_anchor_balance_check - bw_data_wide_balance_check, -1) != 0:
        raise Exception("Balance check 2 failed.")

    indexed_bw_data = bw_data_wide_additional_fields.set_index([
        'SCENARIO',
        'UNIQUE_FACILITY_ID'
    ])

    if debug:
        print("Computing list of unique facilities...")
    unique_facilities = indexed_bw_data.index.get_level_values('UNIQUE_FACILITY_ID').unique().tolist()

    if debug:
        print("Computing counter breakpoints...")
    breakpoints = [int((len(unique_facilities) / 100) * (m + 1)) for m in range(100)]

    if debug:
        print("Beginning balance walk process...")
    bw_results = []

    for scenario in scenario_list:
        print("****** Processing scenario {} ******".format(scenario))
        for unique_facility_idx, unique_facility_id in enumerate(unique_facilities):
            if unique_facility_idx in breakpoints:
                print("Process {}% completed".format(str(
                    (breakpoints.index(unique_facility_idx) + 1) * 1
                )))
            current_facility = indexed_bw_data.loc[scenario, unique_facility_id].to_dict(orient='list')

            # VERSION 1
            current_facility_v1 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve, 
                loc_default_reduction_switch=True,
                loc_maturity_treatment_switch=True,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances,
                remove_lc_from_balance=remove_lc_from_balance
            )

            # VERSION 2
            current_facility_v2 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,  
                loc_default_reduction_switch=False,
                loc_maturity_treatment_switch=True,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances,
                remove_lc_from_balance=remove_lc_from_balance
            )

            # VERSION 3
            current_facility_v3 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,  
                loc_default_reduction_switch=True,
                loc_maturity_treatment_switch=False,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances,
                remove_lc_from_balance=remove_lc_from_balance
            )

            # VERSION 4
            current_facility_v4 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,  
                loc_default_reduction_switch=False,
                loc_maturity_treatment_switch=False,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances,
                remove_lc_from_balance=remove_lc_from_balance
            )

            current_facility_v1['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
            current_facility_v2['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
            current_facility_v3['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
            current_facility_v4['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods

            try:
                bw_results.append(pd.DataFrame(current_facility_v1))
            except ValueError as e:
                print(current_facility_v1)

            try:
                bw_results.append(pd.DataFrame(current_facility_v2))
            except ValueError as e:
                print(current_facility_v2)

            try:
                bw_results.append(pd.DataFrame(current_facility_v3))
            except ValueError as e:
                print(current_facility_v3)

            try:
                bw_results.append(pd.DataFrame(current_facility_v4))
            except ValueError as e:
                print(current_facility_v4)

    bw_results_final = pd.concat(bw_results)
    bw_results_pivot = bw_results_final.groupby(
        by=[
            'PD_GROUP',
            'PERIODDATE',
            'LOANTYPE',
            'PORTFOLIO',
            'MODEL',
            'SCENARIO',
            'LOC_DEFAULT_REDUCTION_FLAG',
            'LOC_MATURITY_TREATMENT_FLAG',
            'BW_MODE'
        ]
    )[[
        'BALANCE',
        'CALCULATEDLINE',
        'STARTINGBALANCE',
        'FINALBALANCE',
        'DEFAULTBALANCE',
        'LGDAMOUNT',
        'NCOAMOUNT',
        'EADAMOUNT',
        'ALLLRESERVEAMOUNT',
        'CONTINGENTRESERVEAMOUNT'
    ]].sum()

    return(bw_results_pivot)

def balanceWalkPivot(bw_output, forecast_period, as_of_date, bw_output_from_csv = False):
    """
    Args:
        bw_output (pd.DataFrame) :
        forecast_period (int) : number of forecast months
        as_of_date (datetime.datetime) : starting date of the balance walk
        bw_output_from_csv (bool) : default False
            if bw_output from a csv file (bw_output = pd.read_csv(....csv')), bw_output_from_csv set to True 
            if bw_output from balancewalk() functions, bw_output_from_csv set to False 
    Return:
        pivot_bw (pd.DataFrame) : the aggregated balance walk results including loss rates.
    """
    # helper function to get end of forecast date using start date and forecast period
    end_forecast_date = lambda as_of_date, forecast_period: utilities.monthEndDate(
        utilities.addMonths2date(as_of_date, forecast_period))
    
    # filter for selected forecast periods
    if not bw_output_from_csv:        
#        bw_output.index.get_level_values('PERIODDATE') = pd.to_datetime(bw_output.index.get_level_values('PERIODDATE'))
        bw_output = bw_output[bw_output.index.get_level_values('PERIODDATE') <= end_forecast_date(as_of_date, forecast_period)]
    else:
        bw_output.PERIODDATE = pd.to_datetime(bw_output.PERIODDATE)
        bw_output = bw_output[bw_output['PERIODDATE'] <= end_forecast_date(as_of_date, forecast_period)]

    # pivot result
    pivot_bw = bw_output.reset_index().groupby(
            ['BW_MODE', 'PORTFOLIO', 'PD_GROUP']
            )['STARTINGBALANCE', 'LGDAMOUNT', 'NCOAMOUNT'].sum()

    pivot_bw['LGD(%)'] = pivot_bw['LGDAMOUNT'] / pivot_bw['STARTINGBALANCE']
    pivot_bw['NCO(%)'] = pivot_bw['NCOAMOUNT'] / pivot_bw['STARTINGBALANCE']

    pivot_bw['Annulized LGD(%)'] = utilities.PDPeriodConverter(pivot_bw['LGD(%)'], forecast_period, 12)
    pivot_bw['Annulized NCO(%)'] = utilities.PDPeriodConverter(pivot_bw['NCO(%)'], forecast_period, 12)
    return (pivot_bw)


def balanceWalkMacroSensitivity(
    cf_data: pd.DataFrame,
    anchor_data: pd.DataFrame,
    process_ALLL_balances: bool,
    debug: bool =True,
    remove_lc_from_balance: bool = False,
    **kwargs
) -> pd.DataFrame:
    """

    Args:
        cf_data (pd.DataFrame) :
        anchor_data (pd.DataFrame) :
        scenario_list (list) :
        debug (bool) :

    Return:
        bw_results_pivot (pd.DataFrame) : the aggregated balance walk results.

    """
    segfield2_to_nco_timing_curve = kwargs.get('segfield2_to_nco_timing_curve')
    scenario="macro_sensitivity"
    raw_anchor_balance_check = anchor_data.BOOKBALANCE.sum() / (len(anchor_data.RATENAME.unique()))
    cf_data_tmp = cf_data.copy(deep=True)
    
    # sum values for three columns in case of overlay
    cf_data_tmp['MODELOUTPUTRATE'] =  cf_data_tmp['MODELOUTPUTRATE'] + cf_data_tmp['MGMTADJUSTMENTRATE'] + cf_data_tmp['UNCERTAINTYADJUSTMENTRATE']

    pre_bw_data = anchor_data[['UNIQUE_FACILITY_ID','RATENAME', 'MODELSEGMENT']].merge(
        cf_data_tmp[
            ['MODELOUTPUTRATE', 'RATENAME', 'MODELSEGMENT', 'PERIODDATE']
        ],
        on=['RATENAME', 'MODELSEGMENT'],
        how='left'
    )

    period_date_index = pd.Series(pre_bw_data['PERIODDATE'].unique()).sort_values()
    period_date_index = period_date_index[~pd.isnull(period_date_index)]
    period_date_index.reset_index(drop=True, inplace=True)
    forecast_periods = len(period_date_index)

    pre_bw_data.drop('MODELSEGMENT', axis=1, inplace=True)

    bw_data_wide = pd.pivot_table(
        pre_bw_data,
        values='MODELOUTPUTRATE',
        index=list(set(list(pre_bw_data.columns)) - set(['RATENAME', 'MODELOUTPUTRATE'])),
        columns=['RATENAME'],
        aggfunc=np.mean
    ).reset_index()

    dups_check = bw_data_wide.duplicated(['UNIQUE_FACILITY_ID', 'PERIODDATE'])
    if len(bw_data_wide[dups_check]) != 0:
        raise Exception("Duplicate in pivot table.")

    bw_data_wide_additional_fields = anchor_data[anchor_data.RATENAME=='PD'].merge(
        bw_data_wide,
        on=['UNIQUE_FACILITY_ID'],
        how='left'
    )
    bw_data_wide_additional_fields.drop('RATENAME', axis=1, inplace=True)

    bw_data_wide_balance_check = bw_data_wide_additional_fields.BOOKBALANCE.sum()/(forecast_periods)
    if round(raw_anchor_balance_check - bw_data_wide_balance_check, -1) != 0:
        raise Exception("Balance check 2 failed.")

    indexed_bw_data = bw_data_wide_additional_fields.set_index([
        'UNIQUE_FACILITY_ID'
    ])

    if debug:
        print("Computing list of unique facilities...")
    unique_facilities = indexed_bw_data.index.get_level_values('UNIQUE_FACILITY_ID').unique().tolist()

    if debug:
        print("Computing counter breakpoints...")
    breakpoints = [int((len(unique_facilities) / 100) * (m + 1)) for m in range(100)]

    if debug:
        print("Beginning balance walk process...")
    bw_results = []

    for unique_facility_idx, unique_facility_id in enumerate(unique_facilities):
        if unique_facility_idx in breakpoints:
            print("Process {}% completed".format(str(
                (breakpoints.index(unique_facility_idx) + 1) * 1
            )))
        current_facility = indexed_bw_data.loc[unique_facility_id].to_dict(orient='list')

        # VERSION 1
        current_facility_v1 = processBWFacility(
            forecast_periods=forecast_periods,
            current_facility=copy.deepcopy(current_facility),
            scenario_name=scenario,
            segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve, 
            loc_default_reduction_switch=True,
            loc_maturity_treatment_switch=True,
            apply_curve=True,
            process_ALLL_balances=process_ALLL_balances,
            remove_lc_from_balance=remove_lc_from_balance
        )

        # VERSION 2
        current_facility_v2 = processBWFacility(
            forecast_periods=forecast_periods,
            current_facility=copy.deepcopy(current_facility),
            scenario_name=scenario,
            segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve, 
            loc_default_reduction_switch=False,
            loc_maturity_treatment_switch=True,
            apply_curve=True,
            process_ALLL_balances=process_ALLL_balances,
            remove_lc_from_balance=remove_lc_from_balance
        )

        # VERSION 3
        current_facility_v3 = processBWFacility(
            forecast_periods=forecast_periods,
            current_facility=copy.deepcopy(current_facility),
            scenario_name=scenario,
            segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,             
            loc_default_reduction_switch=True,
            loc_maturity_treatment_switch=False,
            apply_curve=True,
            process_ALLL_balances=process_ALLL_balances,
            remove_lc_from_balance=remove_lc_from_balance
        )

        # VERSION 4
        current_facility_v4 = processBWFacility(
            forecast_periods=forecast_periods,
            current_facility=copy.deepcopy(current_facility),
            scenario_name=scenario,
            segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,  
            loc_default_reduction_switch=False,
            loc_maturity_treatment_switch=False,
            apply_curve=True,
            process_ALLL_balances=process_ALLL_balances,
            remove_lc_from_balance=remove_lc_from_balance
        )

        current_facility_v1['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
        current_facility_v2['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
        current_facility_v3['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
        current_facility_v4['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods

        try:
            bw_results.append(pd.DataFrame(current_facility_v1))
        except ValueError as e:
            print(current_facility_v1)

        try:
            bw_results.append(pd.DataFrame(current_facility_v2))
        except ValueError as e:
            print(current_facility_v2)

        try:
            bw_results.append(pd.DataFrame(current_facility_v3))
        except ValueError as e:
            print(current_facility_v3)

        try:
            bw_results.append(pd.DataFrame(current_facility_v4))
        except ValueError as e:
            print(current_facility_v4)

    bw_results_final = pd.concat(bw_results)
    bw_results_pivot = bw_results_final.groupby(
        by=[
            'PD_GROUP',
            'PERIODDATE',
            'LOANTYPE',
            'PORTFOLIO',
            'MODEL',
            'SCENARIO',
            'LOC_DEFAULT_REDUCTION_FLAG',
            'LOC_MATURITY_TREATMENT_FLAG',
            'BW_MODE'
        ]
    )[[
        'BALANCE',
        'CALCULATEDLINE',
        'STARTINGBALANCE',
        'FINALBALANCE',
        'DEFAULTBALANCE',
        'LGDAMOUNT',
        'NCOAMOUNT',
        'EADAMOUNT',
        'ALLLRESERVEAMOUNT',
        'CONTINGENTRESERVEAMOUNT'
    ]].sum()

    return(bw_results_pivot)






























