'''
*********
**USAGE**
*********
    Function Name: triple_sensitivity_plot
    Built-in Function:
        add_bar
        set_text
        plot_bar
    Usage by 'import' : from triple_plot import *
    
    ********
    **ARGS**
    ********
        names: list, -> y ticks labels
        value: list, -> for plotting bins
        pct_value: list =None, -> percentage value tags
        title: str = '', -> title for the hist
        dollar_ind: bool = False, -> dollar value tags
        color_schema: str = 'distinct', -> color schema (colormap,extra_contrast,distinct)
        width=0.05, -> width for the bin
        space=0.1, -> space between bins
        distinct_color_resolution=0.4, -> control the contrast degree between bins, only work for distinct mode 
        negative_color='white', -> color of the bins with a negative height
        difference_color='yellow', -> color of the part caused by severity or others
        stripe_negative_bar=True, -> put stripe on the negative bin
        figure_size=(24, 12), -> figure size
        shift_h = 'adjust', -> the distance between dollar and percentage tags
        see_or_not=False -> the show the process

************************************
 1.USE WITHOUT SensitivityProcessor
************************************

variables_name_used = ['FRB BASE',
                       'Unemployment',
                       'HPI',
                       'FCBC',
                       'Libor',
                       'FRB ADVERSE',
                       'Unemployment',
                       'HPI',
                       'FCBC',
                       'Libor',
                       'FRB SA']
 
values = [17151892.210000001,
         35143763.210000001,
         61008120.530000001,
         65799761.420000002,
         71353793.969999999,
         71353793.969999999,
         146807271.28999999,
         233609215.88999999,
         245638957.03,
         232385987.78,
         232385987.78]
pct_value = [0.27000000000000002,
             0.55000000000000004,
             0.94999999999999996,
             1.03,
             1.1200000000000001,
             1.1200000000000001,
             2.2999999999999998,
             3.6499999999999999,
             3.8399999999999999,
             3.6400000000000001,
             3.6400000000000001]
 
aa = triple_sensitivity_plot(names = variables_name_used,
                             value=values,
                             pct_value= pct_value,
                             title = 'HELOC Sensitivity',
                             dollar_ind = True,
                             color_schema='extra_contrast',
                             see_or_not=False)


************************************
 2.USE WITH SensitivityProcessor
************************************
    ******************************************
    1.Initialize a SensitivityProcessor instance
    ******************************************    
    example = SensitivityProcessor(
		class_type = CREConstruction,
		pd_groups = ["CRE_CONSTRUCTION"],
		model_name= None,
		ejm_ind= True,
		uncertainty_rate=0.,
		as_of_date=datetime.datetime(2016,12,31),
		model_id="2016-SBNA-Loss-Commercial-CREConstruction",
		scenario=["FRB_ADVERSE","FRB_SA"],
		scenario_context='CCAR2017',
         	scenario_date = datetime.datetime(2016,12,31),
		forecast_periods=27)
    ******************************************
    2.Get values
    ******************************************  
    # get value from BASE to ADVERSE
    BASE_A = example.getValue
    
    # then A to SA : just need to change scenario
    A_SA = example.getValue

    # sample output
    BASE_SA  = {'singleInput': [(0.76311396497302897, 16374569.374840943),
      (1.9501212629782307, 41844562.5623537),
      (3.874146181863821, 83129161.467314318),
      (4.3371493259140159, 93058733.586507663),
      (4.3371493259140159, 93058733.586507663)]}
    
    BASE_A = {'singleInput': [(0.76311396497302897, 16374569.374840943),
      (1.128685815902426, 24218748.153511491),
      (1.5713474830412391, 33717149.16350694),
      (1.6454081967520049, 35306305.068417728),
      (1.6454081967520049, 35306305.068417728)]}
    
    A_SA = {'singleInput': [(1.6454081967520049, 35306305.068417728),
      (2.9081856899513503, 62402147.475668475),
      (3.9950844580709832, 85724184.220319271),
      (4.3371493259140159, 93058733.586507663),
      (4.3371493259140159, 93058733.586507663)]}
    
    #CEVF
    BASE_A =  {'singleInput': [(0.55618429679999992, 8243075.7355165118),
      (1.0154461725000012, 15049687.223132465),
      (1.0273840335000011, 15226615.433636142),
      (1.0273840335000011, 15226615.433636142)]}
    A_SA = {'singleInput': [(1.0273840335000011, 15226615.433636142),
      (1.9210417974000014, 28471305.497420836),
      (1.9366331229000011, 28702380.83998809),
      (1.9366331229000011, 28702380.83998809)]}
    ******************************************
    3.Make plot
    ******************************************  

    variables_name = ['FRB_BASE','HOUSING STARTS','CREPI','TREASURY RATE','FRB_ADVERSE','HOUSING STARTS','CREPI','TREASURY RATE','FRB_SA']
    variables_name = ['FRB_BASE','Unemployment Rate','10y Corp Spread','FRB_ADVERSE','Unemployment Rate','10y Corp Spread','FRB_SA']
    
    values = [i[1] for i in BASE_A['singleInput']] + [i[1] for i in A_SA['singleInput'][1:]]
    per_values = [i[0] for i in BASE_A['singleInput']] + [i[0] for i in A_SA['singleInput'][1:]]
    aa = triple_sensitivity_plot(names = variables_name,value=values,per_value= per_values,tags = 'value',title = 'CREConstruction Sensitivity',dollar_ind = True )
    aa.savefig('c:/users/n886528/desktop/joe_999.png')

************************************
 3.USE Retail
************************************
    dat = pd.read_clipboard()
    dat['Sum_rate_9Q'] = pd.to_numeric([i.split('%')[0] for i in dat['Sum_rate_9Q']])
    dat['loss_value'] = pd.to_numeric([i.replace(',','') for i in dat['loss_value ']])
    
    dat1 = dat.iloc[0:7,:]
    dat1 = dat1.set_index(dat1.Scenario)
    variables_name = ['FRB_BASE','H_HPIH1','H_UNH1','FRB_ADVERSE','H_HPIH2','H_UNH2','FRB_SA']
    variables_name_used = ['FRB_BASE','HPI','UNEMPLOYMENT','FRB_ADVERSE','HPI','UNEMPLOYMENT','FRB_SA']
    values = [dat1.loc[i,'loss_value'] for i in variables_name]
    per_values = [dat1.loc[i,'Sum_rate_9Q'] for i in variables_name]
    aa = triple_sensitivity_plot(names = variables_name_used,value=values,per_value= per_values,tags = 'value',title = 'HELOC Sensitivity',dollar_ind = True )
    aa[0].savefig('c:/users/n886528/desktop/joe_HELOC.png')
    
    dat2 = dat.iloc[7:,]
    dat2 = dat2.set_index(dat2.Scenario)
    variables_name = ['FRB_BASE','M_UNM1','M_HPIM1','M_LIBOR1','FRB_ADVERSE','M_UNM2','M_HPIM2','M_LIBOR2','FRB_SA']
    variables_name_used = ['FRB_BASE','UNEMPLOYMENT','HPI','FCBC','FRB_ADVERSE','UNEMPLOYMENT','HPI','FCBC','FRB_SA']
    values = [dat2.loc[i,'loss_value'] for i in variables_name]
    #values[4] = values[5] - values[3]
    per_values = [dat2.loc[i,'Sum_rate_9Q'] for i in variables_name]
    #per_values[4] = per_values[5] - per_values[3]
    aa = triple_sensitivity_plot(names = variables_name_used,value=values,per_value= per_values,tags = 'value',title = 'MORTGAGE Sensitivity ',dollar_ind = True )
    aa.savefig('c:/users/n886528/desktop/joe_MORTGAGE.png')
'''

import os
import sys
import datetime
import pandas as pd
import numpy as np
import itertools
import matplotlib.cm as cm
from matplotlib.colors import Normalize
import matplotlib.pyplot as plt
import copy
import time

def triple_sensitivity_plot(
        names: list,
        value: list,
        pct_value: list =None,
        title: str = '',
        dollar_ind: bool = False,
        color_schema: str = 'distinct',
        width=0.05,
        space=0.1,
        distinct_color_resolution=0.4,
        negative_color='white',
        difference_color='yellow',
        stripe_negative_bar=True,
        figure_size=(24, 12),
        shift_h = 'adjust',
        see_or_not=False):
    # input

    #    names = ['Base','SA-Macro1','SA-Macro2','SA-Macro3','SA-Macro4','SA']
    #    value = [8,12,15,19,40,40]

    mid = int((len(value) + 1) / 2)
    names = [names[0]] + ['+' + i for i in names[1:(mid - 1)]] + [names[mid - 1]] + ['+' + i for i in names[mid:-1]] + [names[-1]]
    # perpare for the bar chart data
    differ = np.diff(value).tolist()
    # change percentage
    change = value[-1] - value[0]
    ch_per = [round(d / change, 4) for d in differ][0:-1]
    # change value
    ch_value = [value[0]] + differ[0:mid - 2] + \
        [value[mid - 1]] + differ[mid - 1:-1] + [value[-1]]
    # number of bins
    posi = np.arange(len(value))

    # bars data : height
    height = ch_value  # this is for each bin
    bottom = [0] + np.cumsum(height[0:(mid - 2)]).tolist() + \
        [0] + np.cumsum(height[(mid - 1):-2]).tolist() + [0]
    left = [space + i * (width + space) for i in posi]

    # decompose into two parts: not stacked bar & stacked bar
    # original
    original_height = [height[0]]
    original_bottom = [0]
    original_left = [left[0]]
    original_value = ch_value[0]
    # individuals
    individuals_height = list(height[1:(mid - 1)]) + list(height[mid:-1])
    individuals_bottom = np.cumsum(
        height[0:(mid - 2)]).tolist() + np.cumsum(height[(mid - 1):-2]).tolist()
    individuals_left = list(left[1:(mid - 1)]) + list(left[mid:-1])
    individuals_value = list(ch_value[1:(mid - 1)]) + list(ch_value[mid:-1])
    # stacked bar:

    # mid
    mid_stacked_height = height[0:(mid - 1)]
    # to correct the difference caused by severity
    mid_stacked_height.append(value[mid - 1] - sum(mid_stacked_height))
    mid_stacked_bottom = bottom[0:(mid - 1)]
    # to correct for the difference caused by severity
    mid_stacked_bottom.append(sum(mid_stacked_height))
    mid_stacked_left = [left[mid - 1]] * len(mid_stacked_height)
    mid_stacked_value = ch_value[mid - 1]
    # right
    right_stacked_height = list(height[0:(mid - 1)]) + list(height[mid:-1])
    # correct difference
    right_stacked_height.append(value[-1] - sum(right_stacked_height))
    right_stacked_bottom = list(bottom[0:(mid - 1)]) + list(bottom[mid:-1])
    # correct difference
    right_stacked_bottom.append(sum(right_stacked_height))
    right_stacked_left = [left[-1]] * len(right_stacked_height)
    right_stacked_value = ch_value[-1]
    # pct_value
    if not pct_value:
        pct_value = [None] * len(value)
    else:
        # same as value
        pct_differ = np.diff(pct_value).tolist()
        pct_ch_value = [pct_value[0]] + pct_differ[0:mid - 2] + \
            [pct_value[mid - 1]] + pct_differ[mid - 1:-1] + [pct_value[-1]]
        original_pct_value = pct_value[0]
        individuals_pct_value = list(
            pct_ch_value[1:(mid - 1)]) + list(pct_ch_value[mid:-1])
        mid_stacked_pct_value = pct_value[mid - 1]
        right_stacked_pct_value = pct_value[-1]

    # personalized color
    # add the new color schema
    if color_schema == 'colormap':
        norm = Normalize(vmin=-min(value), vmax=max(value))
        color = cm.BuPu(norm(height))
    elif color_schema == 'extra_contrast':
        color_seg = np.linspace(0, 1.00, 12)
        color_pairs = color_seg.reshape((6, 2))
        color_pairs_num = int((len(names) - 3) / 2)
        color_select = color_pairs[0:(color_pairs_num)]
        color_dict = {i: j for i, j in zip(names[1:(mid - 1)], color_select)}
        color = [cm.Set2(0)] + cm.Paired([color_dict[i][0] for i in names[1:(mid - 1)]]).tolist() + [
            cm.Set2(0.5)] + cm.Paired([color_dict[i][1] for i in names[(mid):-1]]).tolist() + [cm.Set2(1)]
    elif color_schema == 'distinct':
        color_seg = np.linspace(distinct_color_resolution, 1, len(names) - 3)
        color_select = list(
            zip(color_seg[0:len(color_seg) // 2], color_seg[len(color_seg) // 2:]))
        color_dict = {i: j for i, j in zip(names[1:(mid - 1)], color_select)}
        color = [cm.Set2(0)] + cm.Blues([color_dict[i][0] for i in names[1:(mid - 1)]]).tolist() + [
            cm.Set2(0.5)] + cm.Blues([color_dict[i][1] for i in names[(mid):-1]]).tolist() + [cm.Set2(1)]
    else:
        raise ValueError('Color Schema not found!')
    # adjust for the color
    color = [i if j >= 0 else negative_color for i, j in zip(color, height)]
    # pick out colors
    # original
    original_color = [color[0]]
    # individual
    individuals_color = list(color[1:(mid - 1)]) + list(color[mid:-1])
    # mid_stacked
    mid_stacked_color = color[0:(mid - 1)]
    # right_stacked
    right_stacked_color = list([color[0]]) + individuals_color
#    #****************************#
#    print('*************************',len(right_stacked_color))
#    print('*************************',right_stacked_color)
#    
#    print('*************************',len(right_stacked_bottom))
#    print('*************************',right_stacked_bottom)
#    
#    
#    print('*************************',len(right_stacked_height))
#    print('*************************',right_stacked_height)
#    # make up adding lines data
    starter_x = np.asarray(left[0:-1]) + width
    starter_y = value[0:-1]
    end_x = [left[-1]] * len(starter_x)

    # Create figure: fig ->figure object; axs->subplot object
    fig, axs = plt.subplots(1, 1, figsize=figure_size)
    # set the margins of plots
    axs.set_xlim(space * 0.5, (space + width) * len(value) + space * 0.5)
    axs.set_ylim(0, max(value) * 1.1)

    if shift_h == 'adjust':
        shift_h = 0.028 * max(value)
    # original
    plot_bar(original_left, original_height, original_bottom,
             original_color, axs,original_value, original_pct_value,shift_h=shift_h,width=width, margin=True,see_or_not=see_or_not)
    plot_bar(individuals_left, individuals_height, individuals_bottom,
             individuals_color,axs, individuals_value, individuals_pct_value,shift_h=shift_h,width=width,see_or_not=see_or_not)
    plot_bar(mid_stacked_left, mid_stacked_height, mid_stacked_bottom,
             mid_stacked_color, axs,mid_stacked_value, mid_stacked_pct_value,shift_h=shift_h,width=width,margin=True,see_or_not=see_or_not)
    plot_bar(right_stacked_left[0:], right_stacked_height[0:], right_stacked_bottom,
             right_stacked_color, axs,right_stacked_value, right_stacked_pct_value,shift_h=shift_h,width=width,margin=True,see_or_not=see_or_not)
    # add reference line
    axs.hlines(starter_y, starter_x, end_x,
               linestyle='dashdot', color='pink')

    # labels control system
    axs.tick_params(
        axis='both',
        which='both',
        bottom='off',
        top='off',
        left='off',
        right='off',
        labelbottom='on',
        labelleft='off')
    axs.set_xticks(np.asarray(left) + width / 2)
    axs.set_xticklabels(names, fontsize=15, rotation=10)
    # Titles control
    axs.set_title(title, fontsize=20)
    # adjustment part
    fig.subplots_adjust(left=0.1, right=0.9, bottom=0.1, top=0.9)
    axs.axis('on')
    axs.grid(False)
    return fig

    

def add_bar(axs,alpha=1, linewidth=0.01, stripe_negative_bar=True, **kwargs):
    paras = {i:j for i,j in kwargs.items()}
    if stripe_negative_bar:
        if kwargs.get('height') < 0:
#            print('***********************************')
            return axs.bar(linewidth=linewidth, alpha=alpha,
                           hatch='X', linestyle='dashed', edgecolor='red',**paras)[0]
        else:
#            print('***********************************')
            edgecolor = kwargs.get("edgecolor")
            return axs.bar(edgecolor=edgecolor, linewidth=linewidth, alpha=alpha,**paras)[0]
    else:
        edgecolor = kwargs.get("edgecolor")
        return axs.bar(edgecolor=edgecolor, linewidth=linewidth, alpha=alpha,**paras)[0]


# text function to draw tags on bins
def set_text(bins, ax, value, margin=False,shift_h=0, dollar_ind=True):
    b = bins
    j = value
    if margin :
        if dollar_ind:
            j /= 1000000
            j = '{:,.0f}'.format(j)
            ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                    '$' + j + 'MM', ha='center', va='bottom', fontsize=12)
        else:
            ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                    '%.1f' % (j) + '%', ha='center', va='bottom', fontsize=12)
    else:
        if dollar_ind:
            pp = j
            j /= 1000000
            j = '{:,.0f}'.format(j)
            if pp >= 0:
                ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '+$' + j + 'MM', ha='center', va='bottom', fontsize=12)
            else:
                ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '-$' + j + 'MM', ha='center', va='bottom', color='red', fontsize=12)
        else:
            pp = j
            if pp >= 0:
                ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '+%.2f' % (j) + '%', ha='center', va='bottom', fontsize=12)
            else:
                ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '-%.2f' % (j) + '%', ha='center', va='bottom', color='red', fontsize=12)

# add bars
# individuals
def plot_bar(left, height, bottom, color, axs, value, pct_value,shift_h, width, margin=False, stripe_negative_bar=True, see_or_not=False):
    if not margin:
        for l, h, b, c, v, pct in zip(left, height, bottom, color, value, pct_value):
            per = add_bar(left=l,
                          height=h,
                          bottom=b,
                          width=width,
                          color=c,
                          axs=axs,
                          stripe_negative_bar=stripe_negative_bar)
            set_text(per, axs, v)
            if pct is not None:
                set_text(per, axs, pct, dollar_ind=False,
                         shift_h=shift_h)
            if see_or_not:
                print('SetBar')
    else:
#        print('**********',list(zip(left, height, bottom, color)))
#
#        print('ppppppppppp',left)
#        print('-----------',height)
#        print(';;;;;;;;;;;',bottom)
#        print('++++++++++',color)
        for l, h, b, c in zip(left, height, bottom, color):
#            print('****************sdadasdas******************')
            per = add_bar(left=l,
                          height=h,
                          bottom=b,
                          width=width,
                          color=c,
                          axs=axs,
                          stripe_negative_bar=stripe_negative_bar)
#            print('*******************'+str(type(per))+'*************************')
#            print('*******************',per,'*************************')
            if see_or_not:
                print('SetBar')
        set_text(per, axs, value,margin=True)
        if pct_value is not None:
            set_text(per, axs, pct_value,margin=True, dollar_ind=False,shift_h=shift_h)

def quadruple_sensitivity_plot(
                               names_all: list,
        value_all: list,
        pct_value_all: list =None,
        title: str = '',
        dollar_ind: bool = False,
        color_schema: str = 'distinct',
        width=0.05,
        space=0.1,
        distinct_color_resolution=0.4,
        negative_color='white',
        difference_color='yellow',
        stripe_negative_bar=True,
        figure_size=(24, 12),
        shift_h = 'adjust',
        see_or_not=False):
        
    cut_point = int(3 + ((len(value_all)-4)/3)*2)
    
    take_out_value = value_all[cut_point:]
    value = value_all[0:cut_point]
    
    take_out_names = names_all[cut_point:]
    names = names_all[:cut_point]
                  
    mid = int((len(value) + 1) / 2)
    names = [names[0]] + ['+' + i for i in names[1:(mid - 1)]] + [names[mid - 1]] + ['+' + i for i in names[mid:-1]] + [names[-1]]
    extra_names = ['+'+i for i in take_out_names[0:-1]]+[take_out_names[-1]]
    # perpare for the bar chart data
    
    differ_all = np.diff(value_all).tolist()
    differ = differ_all[0:(cut_point-1)]
    extra_differ = differ_all[(cut_point-1):]
    # change percentage
    change = value[-1] - value[0]
    ch_per = [round(d / change, 4) for d in differ][0:-1]
    # change value
    ch_value = [value[0]] + differ[0:mid - 2] + \
        [value[mid - 1]] + differ[mid - 1:-1] + [value[-1]]
    extra_ch_value = extra_differ[0:-1] + [take_out_value[-1]]
    # number of bins
    posi_all = np.arange(len(value_all))
    posi = posi_all[0:cut_point]
    extra_posi = posi_all[cut_point:]
    # bars data : height
    height = ch_value  # this is for each bin
    extra_height = extra_ch_value
    
    bottom = [0] + np.cumsum(height[0:(mid - 2)]).tolist() + \
        [0] + np.cumsum(height[(mid - 1):-2]).tolist() + [0]
    extra_bottom = [height[-1]]+[height[-1]+i for i in np.cumsum(extra_height[0:-1])[0:-1]] + [0]
    
    left_all = [space + i * (width + space) for i in posi_all]
    left = left_all[:cut_point]
    extra_left = left_all[cut_point:]
    # decompose into two parts: not stacked bar & stacked bar
    # original
    original_height = [height[0]]
    original_bottom = [0]
    original_left = [left[0]]
    original_value = ch_value[0]
    # individuals
    individuals_height = list(height[1:(mid - 1)]) + list(height[mid:-1])
    individuals_bottom = np.cumsum(
        height[0:(mid - 2)]).tolist() + np.cumsum(height[(mid - 1):-2]).tolist()
    individuals_left = list(left[1:(mid - 1)]) + list(left[mid:-1])
    individuals_value = list(ch_value[1:(mid - 1)]) + list(ch_value[mid:-1])
    
    extra_individuals_height = extra_height[0:-1] 
    extra_individuals_bottom = extra_bottom[0:-1]
    extra_individuals_left = extra_left[0:-1]
    extra_individuals_value = extra_ch_value[0:-1]
    # stacked bar:
    
    # mid
    mid_stacked_height = height[0:(mid - 1)]
    # to correct the difference caused by severity
    mid_stacked_height.append(value[mid - 1] - sum(mid_stacked_height))
    mid_stacked_bottom = bottom[0:(mid - 1)]
    # to correct for the difference caused by severity
    mid_stacked_bottom.append(sum(mid_stacked_height))
    mid_stacked_left = [left[mid - 1]] * len(mid_stacked_height)
    mid_stacked_value = ch_value[mid - 1]
    # right
    right_stacked_height = list(height[0:(mid - 1)]) + list(height[mid:-1])
    # correct difference
    right_stacked_height.append(value[-1] - sum(right_stacked_height))
    right_stacked_bottom = list(bottom[0:(mid - 1)]) + list(bottom[mid:-1])
    # correct difference
    right_stacked_bottom.append(sum(right_stacked_height))
    right_stacked_left = [left[-1]] * len(right_stacked_height)
    right_stacked_value = ch_value[-1]
    ## extra
    extra_stacked_height = right_stacked_height[0:-1] + extra_height[0:-1]
    extra_stacked_height.append(value_all[-1] - sum(extra_stacked_height)) 
    extra_stacked_bottom = right_stacked_bottom[0:-1] + extra_bottom[0:-1]
    extra_stacked_bottom.append(sum(extra_stacked_bottom))
    
    extra_stacked_left = [extra_left[-1]]*len(extra_stacked_bottom)
    extra_stacked_value = extra_ch_value[-1]
    
    if not pct_value_all:
            pct_value_all = [None] * len(value)
    else:
        # same as value
        pct_value = pct_value_all[0:cut_point]
        take_out_pct_value = pct_value_all[cut_point:]
        pct_differ_all = np.diff(pct_value_all).tolist()
        pct_differ = pct_differ_all[0:(cut_point-1)]
        extra_pct_differ = pct_differ_all[(cut_point-1):]
        pct_ch_value = [pct_value[0]] + pct_differ[0:mid - 2] + \
            [pct_value[mid - 1]] + pct_differ[mid - 1:-1] + [pct_value[-1]]
        original_pct_value = pct_value[0]
        individuals_pct_value = list(
            pct_ch_value[1:(mid - 1)]) + list(pct_ch_value[mid:-1])
        extra_individual_pct_value = extra_pct_differ[0:-1]
        mid_stacked_pct_value = pct_value[mid - 1]
        right_stacked_pct_value = pct_value[-1]
        extra_stacked_pct_value = pct_value_all[-1]
    
    # personalized color
    # add the new color schema
    color_schema = 'distinct'
    if color_schema == 'distinct':
        color_seg = np.linspace(distinct_color_resolution, 1, len(names_all) - 4)
        onecut = len(color_seg) // 3
        color_select = list(
            zip(color_seg[0:onecut],color_seg[onecut:2*onecut],color_seg[2*onecut:]))
        color_dict = {i: j for i, j in zip(names[1:(mid - 1)], color_select)}
        color = [cm.Set2(0)] + cm.Blues([color_dict[i][0] for i in names[1:(mid - 1)]]).tolist() + [
            cm.Set2(0.5)] + cm.Blues([color_dict[i][1] for i in names[(mid):-1]]).tolist() + [cm.Set2(1)]
        extra_color = cm.Blues([color_dict[i][2] for i in names[1:(mid - 1)]]).tolist() +[cm.Set2(1.5)]
    else:
        raise ValueError('Color Schema not found!')
    # adjust for the color
    color = [i if j >= 0 else negative_color for i, j in zip(color, height)]
    extra_color = [i if j >= 0 else negative_color for i, j in zip(extra_color, extra_height)]
    # pick out colors
    # original
    original_color = [color[0]]
    # individual
    individuals_color = list(color[1:(mid - 1)]) + list(color[mid:-1])
    extra_individual_color = list(extra_color[0:-1])
    # mid_stacked
    mid_stacked_color = color[0:(mid - 1)]
    # right_stacked
    right_stacked_color = list([color[0]]) + individuals_color
    
    # extra_stacked
    extra_stacked_color = list([color[0]]) + individuals_color + extra_individual_color
    
    #    # make up adding lines data
    starter_x = np.asarray(left_all[0:-1]) + width
    starter_y = value_all[0:-1]
    end_x = [left_all[-1]] * len(starter_x)

    # Create figure: fig ->figure object; axs->subplot object
    fig, axs = plt.subplots(1, 1, figsize=figure_size)
    # set the margins of plots
    axs.set_xlim(space * 0.5, (space + width) * len(value_all) + space * 0.5)
    axs.set_ylim(0, max(value_all) * 1.1)

    if shift_h == 'adjust':
        shift_h = 0.028 * max(value_all)
    # original
    see_or_not = False
    plot_bar(original_left, original_height, original_bottom,
             original_color, axs,original_value, original_pct_value,shift_h=shift_h,width=width, margin=True,see_or_not=see_or_not)
    plot_bar(individuals_left, individuals_height, individuals_bottom,
             individuals_color,axs, individuals_value, individuals_pct_value,shift_h=shift_h,width=width,see_or_not=see_or_not)
    plot_bar(mid_stacked_left, mid_stacked_height, mid_stacked_bottom,
             mid_stacked_color, axs,mid_stacked_value, mid_stacked_pct_value,shift_h=shift_h,width=width,margin=True,include_value=value_all,see_or_not=see_or_not)
    plot_bar(right_stacked_left[0:], right_stacked_height[0:], right_stacked_bottom,
             right_stacked_color, axs,right_stacked_value, right_stacked_pct_value,shift_h=shift_h,width=width,margin=True,include_value=value_all,see_or_not=see_or_not)
    plot_bar(extra_individuals_left,extra_individuals_height,extra_individuals_bottom,
             extra_individual_color,axs, extra_individuals_value,extra_individual_pct_value,shift_h=shift_h,width=width,see_or_not=see_or_not)
    plot_bar(extra_stacked_left,extra_stacked_height,extra_stacked_bottom,
             extra_stacked_color,axs,extra_stacked_value,extra_stacked_pct_value,shift_h=shift_h,width=width,margin = True, include_value=value_all,see_or_not=see_or_not)
    # add reference line
    axs.hlines(starter_y, starter_x, end_x,
               linestyle='dashdot', color='pink')
    
    # labels control system
    axs.tick_params(
        axis='both',
        which='both',
        bottom='off',
        top='off',
        left='off',
        right='off',
        labelbottom='on',
        labelleft='off')
    axs.set_xticks(np.asarray(left_all) + width / 2)
    axs.set_xticklabels(names+extra_names, fontsize=15, rotation=10)
    # Titles control
    axs.set_title('', fontsize=20)
    # adjustment part
    fig.subplots_adjust(left=0.1, right=0.9, bottom=0.1, top=0.9)
    axs.axis('on')
    axs.grid(False)


    return fig

def triple_sensitivity_plot(
        names: list,
        value: list,
        pct_value: list =None,
        title: str = '',
        dollar_ind: bool = False,
        color_schema: str = 'distinct',
        width=0.05,
        space=0.1,
        distinct_color_resolution=0.4,
        negative_color='white',
        difference_color='yellow',
        stripe_negative_bar=True,
        figure_size=(24, 12),
        shift_h = 'adjust',
        see_or_not=False):
    # input

    #    names = ['Base','SA-Macro1','SA-Macro2','SA-Macro3','SA-Macro4','SA']
    #    value = [8,12,15,19,40,40]

    mid = int((len(value) + 1) / 2)
    names = [names[0]] + ['+' + i for i in names[1:(mid - 1)]] + [names[mid - 1]] + ['+' + i for i in names[mid:-1]] + [names[-1]]
    # perpare for the bar chart data
    differ = np.diff(value).tolist()
    # change percentage
    change = value[-1] - value[0]
    ch_per = [round(d / change, 4) for d in differ][0:-1]
    # change value
    ch_value = [value[0]] + differ[0:mid - 2] + \
        [value[mid - 1]] + differ[mid - 1:-1] + [value[-1]]
    # number of bins
    posi = np.arange(len(value))

    # bars data : height
    height = ch_value  # this is for each bin
    bottom = [0] + np.cumsum(height[0:(mid - 2)]).tolist() + \
        [0] + np.cumsum(height[(mid - 1):-2]).tolist() + [0]
    left = [space + i * (width + space) for i in posi]

    # decompose into two parts: not stacked bar & stacked bar
    # original
    original_height = [height[0]]
    original_bottom = [0]
    original_left = [left[0]]
    original_value = ch_value[0]
    # individuals
    individuals_height = list(height[1:(mid - 1)]) + list(height[mid:-1])
    individuals_bottom = np.cumsum(
        height[0:(mid - 2)]).tolist() + np.cumsum(height[(mid - 1):-2]).tolist()
    individuals_left = list(left[1:(mid - 1)]) + list(left[mid:-1])
    individuals_value = list(ch_value[1:(mid - 1)]) + list(ch_value[mid:-1])
    # stacked bar:

    # mid
    mid_stacked_height = height[0:(mid - 1)]
    # to correct the difference caused by severity
    mid_stacked_height.append(value[mid - 1] - sum(mid_stacked_height))
    mid_stacked_bottom = bottom[0:(mid - 1)]
    # to correct for the difference caused by severity
    mid_stacked_bottom.append(sum(mid_stacked_height))
    mid_stacked_left = [left[mid - 1]] * len(mid_stacked_height)
    mid_stacked_value = ch_value[mid - 1]
    # right
    right_stacked_height = list(height[0:(mid - 1)]) + list(height[mid:-1])
    # correct difference
    right_stacked_height.append(value[-1] - sum(right_stacked_height))
    right_stacked_bottom = list(bottom[0:(mid - 1)]) + list(bottom[mid:-1])
    # correct difference
    right_stacked_bottom.append(sum(right_stacked_height))
    right_stacked_left = [left[-1]] * len(right_stacked_height)
    right_stacked_value = ch_value[-1]
    # pct_value
    if not pct_value:
        pct_value = [None] * len(value)
    else:
        # same as value
        pct_differ = np.diff(pct_value).tolist()
        pct_ch_value = [pct_value[0]] + pct_differ[0:mid - 2] + \
            [pct_value[mid - 1]] + pct_differ[mid - 1:-1] + [pct_value[-1]]
        original_pct_value = pct_value[0]
        individuals_pct_value = list(
            pct_ch_value[1:(mid - 1)]) + list(pct_ch_value[mid:-1])
        mid_stacked_pct_value = pct_value[mid - 1]
        right_stacked_pct_value = pct_value[-1]

    # personalized color
    # add the new color schema
    if color_schema == 'colormap':
        norm = Normalize(vmin=-min(value), vmax=max(value))
        color = cm.BuPu(norm(height))
    elif color_schema == 'extra_contrast':
        color_seg = np.linspace(0, 1.00, 12)
        color_pairs = color_seg.reshape((6, 2))
        color_pairs_num = int((len(names) - 3) / 2)
        color_select = color_pairs[0:(color_pairs_num)]
        color_dict = {i: j for i, j in zip(names[1:(mid - 1)], color_select)}
        color = [cm.Set2(0)] + cm.Paired([color_dict[i][0] for i in names[1:(mid - 1)]]).tolist() + [
            cm.Set2(0.5)] + cm.Paired([color_dict[i][1] for i in names[(mid):-1]]).tolist() + [cm.Set2(1)]
    elif color_schema == 'distinct':
        color_seg = np.linspace(distinct_color_resolution, 1, len(names) - 3)
        color_select = list(
            zip(color_seg[0:len(color_seg) // 2], color_seg[len(color_seg) // 2:]))
        color_dict = {i: j for i, j in zip(names[1:(mid - 1)], color_select)}
        color = [cm.Set2(0)] + cm.Blues([color_dict[i][0] for i in names[1:(mid - 1)]]).tolist() + [
            cm.Set2(0.5)] + cm.Blues([color_dict[i][1] for i in names[(mid):-1]]).tolist() + [cm.Set2(1)]
    else:
        raise ValueError('Color Schema not found!')
    # adjust for the color
    color = [i if j >= 0 else negative_color for i, j in zip(color, height)]
    # pick out colors
    # original
    original_color = [color[0]]
    # individual
    individuals_color = list(color[1:(mid - 1)]) + list(color[mid:-1])
    # mid_stacked
    mid_stacked_color = color[0:(mid - 1)]
    # right_stacked
    right_stacked_color = list([color[0]]) + individuals_color
#    #****************************#
#    print('*************************',len(right_stacked_color))
#    print('*************************',right_stacked_color)
#    
#    print('*************************',len(right_stacked_bottom))
#    print('*************************',right_stacked_bottom)
#    
#    
#    print('*************************',len(right_stacked_height))
#    print('*************************',right_stacked_height)
#    # make up adding lines data
    starter_x = np.asarray(left[0:-1]) + width
    starter_y = value[0:-1]
    end_x = [left[-1]] * len(starter_x)

    # Create figure: fig ->figure object; axs->subplot object
    fig, axs = plt.subplots(1, 1, figsize=figure_size)
    # set the margins of plots
    axs.set_xlim(space * 0.5, (space + width) * len(value) + space * 0.5)
    axs.set_ylim(0, max(value) * 1.1)

    if shift_h == 'adjust':
        shift_h = 0.028 * max(value)
    # original
    plot_bar(original_left, original_height, original_bottom,
             original_color, axs,original_value, original_pct_value,shift_h=shift_h,width=width, margin=True,see_or_not=see_or_not)
    plot_bar(individuals_left, individuals_height, individuals_bottom,
             individuals_color,axs, individuals_value, individuals_pct_value,shift_h=shift_h,width=width,see_or_not=see_or_not)
    plot_bar(mid_stacked_left, mid_stacked_height, mid_stacked_bottom,
             mid_stacked_color, axs,mid_stacked_value, mid_stacked_pct_value,shift_h=shift_h,width=width,margin=True,see_or_not=see_or_not)
    plot_bar(right_stacked_left[0:], right_stacked_height[0:], right_stacked_bottom,
             right_stacked_color, axs,right_stacked_value, right_stacked_pct_value,shift_h=shift_h,width=width,margin=True,see_or_not=see_or_not)
    # add reference line
    axs.hlines(starter_y, starter_x, end_x,
               linestyle='dashdot', color='pink')

    # labels control system
    axs.tick_params(
        axis='both',
        which='both',
        bottom='off',
        top='off',
        left='off',
        right='off',
        labelbottom='on',
        labelleft='off')
    axs.set_xticks(np.asarray(left) + width / 2)
    axs.set_xticklabels(names, fontsize=15, rotation=10)
    # Titles control
    axs.set_title(title, fontsize=20)
    # adjustment part
    fig.subplots_adjust(left=0.1, right=0.9, bottom=0.1, top=0.9)
    axs.axis('on')
    axs.grid(False)
    return fig

    

def add_bar(axs,alpha=1, linewidth=0.01, stripe_negative_bar=True, **kwargs):
    paras = {i:j for i,j in kwargs.items()}
    if stripe_negative_bar:
        if kwargs.get('height') < 0:
#            print('***********************************')
            return axs.bar(linewidth=linewidth, alpha=alpha,
                           hatch='X', linestyle='dashed', edgecolor='red',**paras)[0]
        else:
#            print('***********************************')
            edgecolor = kwargs.get("edgecolor")
            return axs.bar(edgecolor=edgecolor, linewidth=linewidth, alpha=alpha,**paras)[0]
    else:
        edgecolor = kwargs.get("edgecolor")
        return axs.bar(edgecolor=edgecolor, linewidth=linewidth, alpha=alpha,**paras)[0]


# text function to draw tags on bins
def set_text(bins, ax, value, margin=False,shift_h=0, dollar_ind=True,adjust_h = None):
    b = bins
    j = value
    if margin :
        if dollar_ind:
            j /= 1000000
            j = '{:,.0f}'.format(j)
            if adjust_h is not None:
                ax.text(b.get_x() + b.get_width() / 2, adjust_h + shift_h,
                    '$' + j + 'MM', ha='center', va='bottom', fontsize=12)
            else:
                ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                    '$' + j + 'MM', ha='center', va='bottom', fontsize=12)
        else:
            if adjust_h is not None:
                ax.text(b.get_x() + b.get_width() / 2, adjust_h + shift_h,
                    '%.1f' % (j) + '%', ha='center', va='bottom', fontsize=12)
            else:
                ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                    '%.1f' % (j) + '%', ha='center', va='bottom', fontsize=12)
            
    else:
        if dollar_ind:
            pp = j
            j /= 1000000
            j = '{:,.0f}'.format(j)
            if pp >= 0:
                if adjust_h is not None:
                    ax.text(b.get_x() + b.get_width() / 2, adjust_h + shift_h,
                        '+$' + j + 'MM', ha='center', va='bottom', fontsize=12)
                else:
                    ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '+$' + j + 'MM', ha='center', va='bottom', fontsize=12)
                    
            else:
                if adjust_h is not None:
                    ax.text(b.get_x() + b.get_width() / 2, adjust_h + shift_h,
                        '-$' + j + 'MM', ha='center', va='bottom', color='red', fontsize=12)
                else:
                    ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '-$' + j + 'MM', ha='center', va='bottom', color='red', fontsize=12)
                    
        else:
            pp = j
            if pp >= 0:
                if adjust_h is not None:
                    ax.text(b.get_x() + b.get_width() / 2, adjust_h + shift_h,
                        '+%.2f' % (j) + '%', ha='center', va='bottom', fontsize=12)
                else:
                    ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '+%.2f' % (j) + '%', ha='center', va='bottom', fontsize=12)
                    
            else:
                if adjust_h is not None:
                    ax.text(b.get_x() + b.get_width() / 2, adjust_h + shift_h,
                        '-%.2f' % (j) + '%', ha='center', va='bottom', color='red', fontsize=12)
                else:
                    ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                        '-%.2f' % (j) + '%', ha='center', va='bottom', color='red', fontsize=12)
              
# add bars
# individuals
def plot_bar(left, height, bottom, color, axs, value, pct_value,shift_h, width, include_value = None,margin=False, stripe_negative_bar=True, see_or_not=False):
    if not margin:
        for l, h, b, c, v, pct in zip(left, height, bottom, color, value, pct_value):
            per = add_bar(left=l,
                          height=h,
                          bottom=b,
                          width=width,
                          color=c,
                          axs=axs,
                          stripe_negative_bar=stripe_negative_bar)
            set_text(per, axs, v)
            if pct is not None:
                set_text(per, axs, pct, dollar_ind=False,
                         shift_h=shift_h)
            if see_or_not:
                print('SetBar')
    else:
#        print('**********',list(zip(left, height, bottom, color)))
#
#        print('ppppppppppp',left)
#        print('-----------',height)
#        print(';;;;;;;;;;;',bottom)
#        print('++++++++++',color)
        another_height = [i if i>=0 else -i for i in height]
        for l, h, b, c in zip(left, height, bottom, color):
#            print('****************sdadasdas******************')
            per = add_bar(left=l,
                          height=h,
                          bottom=b,
                          width=width,
                          color=c,
                          axs=axs,
                          stripe_negative_bar=stripe_negative_bar)
#            print('*******************'+str(type(per))+'*************************')
#            print('*******************',per,'*************************')
            if see_or_not:
                print('SetBar')
        if sum(another_height) > per.get_y() + per.get_height() + shift_h:
            set_text(per, axs, value,margin=True,adjust_h=max(include_value))
        else:
            set_text(per, axs, value,margin=True)
        if pct_value is not None:
            if sum(another_height) > per.get_y() + per.get_height() + shift_h:
                set_text(per, axs, pct_value,margin=True, dollar_ind=False,shift_h=shift_h,adjust_h = max(include_value))
            else:
                set_text(per, axs, pct_value,margin=True, dollar_ind=False,shift_h=shift_h)
