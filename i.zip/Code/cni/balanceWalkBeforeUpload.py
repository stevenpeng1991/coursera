import os
import sys
global WD
WD = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if WD not in sys.path:
    sys.path.append(WD)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.utilities.session import CCARSession
import datetime
import getpass
import _pickle
import time
import pandas as pd
from CIFI.config import CONFIG

## IMPORT Balance Walk module
from CIFI.sensitivity import balancewalk

AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,5,31)
SCENARIO_DATE = datetime.datetime(2017,6,30)          
STRESS_TESTING_CYCLE = "P20_MAY"
#SCENARIO_SEVERITY_LEVEL = "STRESS"
#SCENARIO_SEVERITY_LEVEL = "ADVERSE"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 42
FILE_VERSION = 1

SCENARIO = SCENARIO_SEVERITY_LEVEL


# Load
cf_inventory = _pickle.load(open(os.path.join(WD+"/CIFI/Execution/cf_files/","cf_inventory_"+SCENARIO+"_version_"+ str(FILE_VERSION)+".p"), 'rb'))

## Balance Walk
##
if utilities.userInputPrompt(
        message="Would you like to start balance walk? [Y/N]",
        valid_options=('Y', 'N')
) == 'Y':
    
#        cf_entire_inventory=pd.concat(
#                    [cf_inventory[101].getCFData(),
#                     cf_inventory[102].getCFData(),
#                     cf_inventory[103].getCFData(),
#                     cf_inventory[104].getCFData()])
                        
    cf_entire_inventory=pd.DataFrame()
    for contributor_file_id in cf_inventory:  
        data=cf_inventory[contributor_file_id].getCFData()
        # Filter for current vintage
        data=data[data['VINTAGE']==AS_OF_DATE]
        # Filter for current book (no origination)
        if contributor_file_id != 101:
            data=data[~data['MODELSEGMENT'].str.contains('_O')]
            
        cf_entire_inventory=pd.concat([cf_entire_inventory,data])
    
    anchor_query, anchor_data=balancewalk.getBWFormatAnchorData(
        as_of_date= PORTFOLIO_SNAPSHOT_DATE,
        pd_groups=[],
        debug=False
        )      

    while True:
        EJM_MASTER_FILE_PATH=os.path.join("I:\\CRMPO\\CCAR\\",
                                          utilities.userInputPrompt(
                                                  message="Enter the EJM master file folder name (%QYY): "
                                          ),
                                          "5 - EJMs\\Commercial",
                                          "COMMERCIAL_EJM_MASTER_"+
                    utilities.userInputPrompt(
                    message="Enter the EJM master file suffix (%QYY): "
                )+".xlsm") if utilities.userInputPrompt(
                    message="Would you like to specify the entire file path for EJM master file[Y/N]",
                    valid_options=('Y', 'N')
                ) == 'N' else utilities.userInputPrompt(
                                message="Enter the entire file path for EJM file: "
                            )            
        if os.path.exists(EJM_MASTER_FILE_PATH) & os.path.isfile(EJM_MASTER_FILE_PATH)==True:   
            break             
        else:
            print('File path entry is not valid. Please try again.')
            continue   

    segfield2_to_nco_timing_curve=balancewalk.getNCOCurve(        
            forecast_period=FORECAST_PERIODS,
            nco_data_path = EJM_MASTER_FILE_PATH,
            timing_curve_switch = True   
        )      
    t0=time.time()
    
    bw_output = balancewalk.balanceWalk(
        cf_data = cf_entire_inventory,
        anchor_data=anchor_data,
        scenario_list=[SCENARIO],
        segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
        process_ALLL_balances = True,
        debug = True
    )  
    print('Blance walk completed in ' + str(time.time()-t0) + ' s.')
    
    bw_output.to_csv(WD+'/CIFI/Execution/BalanceWalk/'+'BW_output_'+SCENARIO+"_version_"+str(FILE_VERSION)+'.csv')
    
    # Pivot balance walk output
    pivot_bw=balancewalk.balanceWalkPivot(bw_output,FORECAST_PERIODS)        
    pivot_bw.to_csv(WD+'/CIFI/Execution/BalanceWalk/'+'BW_Pivot_'+SCENARIO+"_version_"+str(FILE_VERSION)+'.csv')