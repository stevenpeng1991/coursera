def fetchMacroSeries(self, scenario_combinations=None):


        mv_dict_list = CI_ABL_risk_rating_model_instance._model_properties.getParameters(
            type='operation',
            name='macro_variables'
        )
        mv_group_dict_list=CI_ABL_risk_rating_model_instance._model_properties.getParameters(
            type='operation',
            name='macro_variable_combinations'
        )
        

mv_dict_list = [{'lag': 1,
  'macro_variable_name': 'FLBR_CNER',
  'macro_variables_group': 'FLBR_CNER_d1y',
  'transformation_type': 'd1y'},
 {'lag': 0,
  'macro_variable_name': 'FHOFHOPIQ_CNER',
  'macro_variables_group': 'FHOFHOPIQ_CNER_p1y',
  'transformation_type': 'p1y'},
 {'lag': 1,
  'macro_variable_name': 'FHOFHOPIQ_CNER',
  'macro_variables_group': 'FHOFHOPIQ_CNER_p2q_l1q',
  'transformation_type': 'p2q'},
 {'lag': 0,
  'macro_variable_name': 'FGDPQ_CNER',
  'macro_variables_group': 'FGDPQ_CNER_p1y',
  'transformation_type': 'p1y'}]
        
mv_group_dict_list = [{'combination': 'FLBR_CNER_d1y',
  'operand_1': 'FLBR_CNER_d1y',
  'operand_2': None,
  'operator': None},
 {'combination': 'FHOFHOPIQ_CNER_p1y',
  'operand_1': 'FHOFHOPIQ_CNER_p1y',
  'operand_2': None,
  'operator': None},
 {'combination': 'FHOFHOPIQ_CNER_p2q_l1q',
  'operand_1': 'FHOFHOPIQ_CNER_p2q_l1q',
  'operand_2': None,
  'operator': None},
 {'combination': 'FGDPQ_CNER_p1y',
  'operand_1': 'FGDPQ_CNER_p1y',
  'operand_2': None,
  'operator': None}]      
mv_geo_scope = 'CNER'

        mv_forecast_periods=utilities.convertForecastPeriods(
            n=CI_ABL_risk_rating_model_instance._forecast_periods,
            freq_0=CI_ABL_risk_rating_model_instance._forecast_periods_frequency,
            freq_1=CI_ABL_risk_rating_model_instance._model_properties.getParameters(
                type='property',
                name='scenario_period_frequency'
            )
        )
        mv_geo_scope=CI_ABL_risk_rating_model_instance._model_properties.getParameters(
            type='property',
            name='scenario_geo_scope'
        )
        mv_period_frequency=CI_ABL_risk_rating_model_instance._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )


        if isinstance(self._scenario, str):
            macro_series_object_cner = ScenarioMacroSeries(
                mv_dict_list=mv_dict_list,
                mv_group_dict_list=mv_group_dict_list,
                mv_as_of_date=CI_ABL_risk_rating_model_instance.scenario_date,
                mv_forecast_periods=mv_forecast_periods,
                mv_context=CI_ABL_risk_rating_model_instance._scenario_context,
                mv_scenario=CI_ABL_risk_rating_model_instance._scenario,
                mv_geo_scope=mv_geo_scope,
                mv_period_frequency=mv_period_frequency,
                logger=CI_ABL_risk_rating_model_instance._logger,
                use_RFO=CI_ABL_risk_rating_model_instance.use_RFO_macro_series
            )
            test_transformed = macro_series_object.generateTransformedData()
            test_transformed_cner = macro_series_object_cner.generateTransformedData()
            
            regional_overwrite_dict = {
               'FLBR_US':'FLBR_CNER',
               'FLBR_US_d1y_l1q':'FLBR_CNER_d1y_l1q',
               'FHOFHOPIQ_US': 'FHOFHOPIQ_CNER',
               'FHOFHOPIQ_US_p1y':'FHOFHOPIQ_CNER_p1y',
               'FHOFHOPIQ_US_p2q_l1q':'FHOFHOPIQ_CNER_p2q_l1q',
               'FGDPQ_US':'FGDPQ_CNER',
               'FGDPQ_US_p1y':'FGDPQ_CNER_p1y'                      
               }
            
            for national in regional_overwrite_dict:
                test_transformed[national] = test_transformed_cner[regional_overwrite_dict[national]]
                
            
            data0 = macro_series_object._ScenarioMacroSeries__raw_macro_data
            data1 = macro_series_object_cner._ScenarioMacroSeries__raw_macro_data


        elif isinstance(self._scenario, list):

            # Check scenario_combinations
            if scenario_combinations is None:
                raise ValueError('scenario_combinations CANNOT be None if multiple scenarios are provided.')

            # Validate scenario_combinations format
            macro_combinations = set(scenario_combinations.keys())
            macro_groups = set([i['macro_variable_name'] if i["macro_variable_name"] in i["macro_variables_group"] else i["macro_variables_group"] for i in mv_dict_list])
            if macro_combinations != macro_groups:
                differences = (macro_combinations - macro_groups) | (macro_groups - macro_combinations)
                raise ValueError("The list of macro variable combinations does not match the macro groups found in model properties: {}".format(str(differences)))

            scenarios_a = set(scenario_combinations.values())
            scenarios_b = set(self._scenario)
            if not scenarios_a.issubset(scenarios_b):
                differences = scenarios_a - scenarios_b
                raise ValueError("The list of scenario combinations does not match the input list of scenarios: {}".format(str(differences)))


            def scenario_sensitivity(self,function):
                scenario_container = {}
                for scenario in self._scenario:
                    current_scenario = ScenarioMacroSeries(
                        mv_dict_list=mv_dict_list,
                        mv_group_dict_list=mv_group_dict_list,
                        mv_as_of_date=self._as_of_date,
                        mv_forecast_periods=mv_forecast_periods,
                        mv_context=self._scenario_context,
                        mv_scenario=scenario, # replace with loop scenario value
                        mv_geo_scope=mv_geo_scope,
                        mv_period_frequency=mv_period_frequency,
                        logger=self._logger,
                        use_RFO=self.use_RFO_macro_series
                    )
                    current_scenario.generateTransformedData(return_data = False)
                    scenario_container[scenario] = getattr(current_scenario,function)()
                                      
                # Create combinations
                series_container = []
                for comb_mv_name, comb_scenario in scenario_combinations.items():
                    for col in scenario_container[comb_scenario].keys():
                        if comb_mv_name in col:
                            series_container.append(
                                scenario_container[comb_scenario][col]
                            )
                return(series_container)

            # FINALIZE
            self._transformed_macro_series = pd.concat(scenario_sensitivity(self,'getTransformedMacroData'), axis=1)
            self._transformed_macro_series_include_t0 = pd.concat(scenario_sensitivity(self,'getTransformedMacroDataIncludeT0'), axis=1)
            self._transformed_macro_series_include_all = pd.concat(scenario_sensitivity(self,'getTransformedMacroDataIncludeAll'), axis=1)                
        else:
            raise TypeError("`self._scenario` data type is not valid. Expects str or list.")