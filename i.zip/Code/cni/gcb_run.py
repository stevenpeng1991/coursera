# -*- coding: utf-8 -*-
"""
Created on Tue Aug  8 12:45:38 2017

@author: n882049
"""
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.sensitivity.balancewalk as bw
import CIFI.controllers.models.cniriskrating as cni
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalkMacroSensitivity
import CIFI.controllers.utilities.utilities as utilities
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import matplotlib.cm as cm
import datetime
import numpy as np
import pandas as pd
import itertools
import _pickle 
from matplotlib.backends.backend_pdf import PdfPages
from CIFI.controllers.models.cniriskrating import *
from CIFI.controllers.models.gcbindustry import *

from CIFI.controllers.models.riskratingmodel import RiskRatingModel
from CIFI.controllers.ejm.ejmmaster import ejmDictionaryGenerator, EJMGenerator
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart

############################# MC Round 1 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           # not in run.py
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 42

ccar_session = CCARSession(
    session_id='GCB 2017 Mid Cycle',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

################ GCB data ################
gcb_dataset= CCMISMasterDataset(
                        	asofdate=AS_OF_DATE,
                        	pd_groups=['GCB'],
                        	debug=True
                      ).data

GCB_model_instance = GCBModel(
    as_of_date=AS_OF_DATE,
    dataset_query_date=AS_OF_DATE,
    scenario_date=SCENARIO_DATE,
    model_id = '2016-SBNA-Loss-Commercial-GCB',
    scenario=SCENARIO,
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
    scenario_context=STRESS_TESTING_CYCLE,
    forecast_periods=FORECAST_PERIODS,
    industrytag_file='I:\\CRMPO\\CCAR\\2Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Jun.xlsx',
)

###############  Add model to the shopping cart and execute  ###########
cart.addModel(GCB_model_instance)
cart.checkout()       # execute() is called here

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

## save contributor file to CSV file
cf_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_may/ADVERSE_p20_may_cni_CF_0710.csv", index = False)

## reset cf generator and shopping cart 
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()

### SP20 Run Balance Walk and sensitivity ####
# get portfolio snapshot
anchor_query, anchor_data = bw.getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=['GCB']
            )
## save anchor file to CSV file
anchor_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_may/ADVERSE_p20_may_cni_anchor_0710.csv")

# cf_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_CF.csv")
# anchor_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_anchor.csv")


EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_2Q17.xlsm'

segfield2_to_nco_timing_curve=getNCOCurve(        
        forecast_period=FORECAST_PERIODS,
        nco_data_path = EJM_MASTER_FILE_PATH,
        timing_curve_switch = True   
    )      

t0=time.time()
bw_output = balanceWalk(
    cf_data = cf_data,
    anchor_data=anchor_data,
    scenario_list=[SCENARIO],
    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
    process_ALLL_balances = True,
    debug = True
)  
print('Blance walk completed in ' + str(time.time()-t0) + ' s.')

bw_output.to_csv('I:/CRMPO/DEPT/Steven/run_result/MidCycle_Jun/STRESS_p20_may_cni_BW_Output_0713_testleq.csv')

# Pivot balance walk output
pivot_bw=balanceWalkPivot(bw_output,FORECAST_PERIODS)        
pivot_bw.to_csv('I:/CRMPO/DEPT/Steven/run_result/MidCycle_Jun/midcycle_jun_cni_BW_Pivot_ADVERSE.csv')