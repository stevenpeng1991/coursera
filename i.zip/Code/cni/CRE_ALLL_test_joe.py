'''
@. Input Data Cleanning
    AFS0051907348005191646300519164630000000042 $NETOPERATINGINC/COLLATVALUE
    AFS00519073480051916463005191646300000000420000000059
    AFS0051918535005191853500519185350000000018 UAV/COLLATVALUE
    AFS0052566853005256685300525668530000000018 UAV/COLLATVALUE
    
@. Input max maturity:There are negive m2mat
                      '01/01/9999'
   
   rules for m2mat 
    SAS: 
        tdate = datepart('31Mar2016 00:00:00'dt);
        m2mat = intck('months', tdate, MaximumMaturityDate2); 
    e.g.'AFS0050000285005000028500500002850000000059'
         MaxMaturity:2020-10-01 00:00:00---->3/31/2016
         SAS OUTPUT [M2MAT=52] for first forecast quarter
@.'' Vs .
                 
@.LGD calculation
    dy5 was not used
         
@.BAU version:
    turn off pd 2 steps:noi,occ,crepi
                        pd_mapping
             lgd: UER
             
@ Input restriction?

@ macro inputs CPI was not used


'FacilityNumber_2':'UNIQUE_FACILITY_ID'
'TotalBookBalance':'UtilizationBookBalance'
'NETOPERATINGINC':'Pri_CollatNOI'
'OccupancyRate':'CURRENTOCCUPANCY'
'PropertyType'
'CollatValue':'Pri_CollatValue'    

'''
##########################################
            # Model Property #
##########################################
 # {'model_id':'721 - Commercial Rating Model - CRE Multifamily PD - SBNA',
 #      'name': 'model_name',
 #      'type': 'property',
 #      'value': 'CRE MULTIFAMILY',
 #      'version_date': '3/31/2015'
 # }
 #
 #    'lgd_regression_dict':{
 #        'intercept':0.30092,
 #        'coefficients_pairs':{
 #                              'mat_flag': -0.19017,
 #                              'ltv1': -0.09442,
 #                              'ltv2':-0.10507,
 #                              'ltv3':-0.07741,
 #                              'ltv4':-0.05712,
 #                              'ltv5':-0.03839,
 #                              'occ1': 0.09267,
 #                              'occ2': 0.03723,
 #                              'dy1': 0.05414,
 #                              'dy2': 0.08787,
 #                              'dy3': 0.0734,
 #                              'dy4': 0.04933,
 #                              'MF':0.0299,
 #                              'isRetail':0.02072,
 #                              'UER_YoYDiff_L0':0.0306
 #                          }
 #    }
'''
to_insert = [
     {
         "value":"CRE",
         "model_id":'721 - Commercial Rating Model - CRE Multifamily PD - SBNA',
         "type":"property",
         "name":"model_name",
         "version_date":"3/31/2016"
      },
	{
          'segment':'all',
          'model_id':'721 - Commercial Rating Model - CRE Multifamily PD - SBNA',
          'name': 'model_name',
          'type': 'property',
          'value': 'CRE',
          'version_date': '3/31/2016'
      },
      {
          'segment':'multifamily',
          'model_id':'721 - Commercial Rating Model - CRE Multifamily PD - SBNA',      
          'name': 'regression_coefficients',
          'type': 'operation',
          'value': {'coefficients_pairs': {   'm2mat_2': -1.2544,
                                              'currentoccupancy_2': -0.6659,
                                              'dbtyld_2':-0.999,
                                              'ltv_2':-0.7677,
                                              'division_2':-0.5113},
           'intercept': -3.5409,
           'regression_variable': 'pd'},
           'version_date': '3/31/2016'      
      },
      {
          'segment':'non_multifamily',
          'model_id':'721 - Commercial Rating Model - CRE Multifamily PD - SBNA',      
          'name': 'regression_coefficients',
          'type': 'operation',
          'value': {'coefficients_pairs': {   'm2mat_2': -1.2516,
                                              'currentoccupancy_2': -0.7307,
                                              'dbtyld_2':-0.7049,
                                              'ltv_2':-0.8825,
                                              'division_2':-0.6968,
                                              'proptype_2':-0.4637},
           'intercept': -3.4190,
           'regression_variable': 'pd'},
           'version_date': '3/31/2016'      
      },
      {
          'segment':'lgd_all',
          'model_id':'721 - Commercial Rating Model - CRE Multifamily PD - SBNA',      
          'name': 'regression_coefficients',
          'type': 'operation',
          'value': {'coefficients_pairs': {   'mat_flag': -0.19017,
                                              'ltv1': -0.09442,
                                              'ltv2':-0.10507,
                                              'ltv3':-0.07741,
                                              'ltv4':-0.05712,
                                              'ltv5':-0.03839,
                                              'occ1': 0.09267,
                                              'occ2': 0.03723,
                                              'dy1': 0.05414,
                                              'dy2': 0.08787,
                                              'dy3': 0.0734,
                                              'dy4': 0.04933,
                                              'MF':0.0299,
                                              'isRetail':0.02072,
                                              'UER_YoYDiff_L0':0.0306},
           'intercept': -3.4190,
           'regression_variable': 'lgd'},
           'version_date': '3/31/2016'      
      },
    {'segment': 'occ',
      'model_id': '721 - Commercial Rating Model - CRE Multifamily PD - SBNA',      
      'name': 'macro_variables',
      'type': 'operation',
      'value': [{'lag': 0,
        'macro_variable_name': 'FLBR_US',
        'macro_variables_group': 'FLBR_US_d1y',
        'transformation_type': 'd1y'},
       {'lag': 2,
        'macro_variable_name': 'FHSTQ_US',
        'macro_variables_group': 'FHSTQ_US_p1y_l2q',
        'transformation_type': 'p1y'}],
      'version_date': '3/31/2016'},
     {'segment': 'occ',
      'model_id': '721 - Commercial Rating Model - CRE Multifamily PD - SBNA',      
      'name': 'macro_variable_combinations',
      'type': 'operation',
      'value': [{'combination': 'FLBR_US_d1y',
        'operand_1': 'FLBR_US_d1y',
        'operand_2': None,
        'operator': None},
       {'combination': 'FHSTQ_US_p1y_l2q',
        'operand_1': 'FHSTQ_US_p1y_l2q',
        'operand_2': None,
        'operator': None}],
      'version_date': '3/31/2016'},
     {'model_id': '721 - Commercial Rating Model - CRE Multifamily PD - SBNA',      
      'name': 'scenario_period_frequency',
      'type': 'property',
      'value': 'quarterly',
      'version_date': '3/31/2016'},
     {'model_id': '721 - Commercial Rating Model - CRE Multifamily PD - SBNA',      
      'name': 'scenario_geo_scope',
      'type': 'property',
      'value': 'National&Regional',
      'version_date': '3/31/2016'}     
]


'''


'''Check
data1=raw[raw['FacilityNumber']=='AFS0051769987005176998700517699870000000018']
mapped_data= rr.getMapping(data1)
regression_variables=rr.process_model_inputs(mapped_data,macro_data)
pd_result=rr.calculatePD(mapped_data,regression_variables,macro_data)
lgd=rr.calculateLGD(mapped_data,regression_variables)
ead=rr.calculateEAD(mapped_data,regression_variables)
'''
"""
SAMPLE USE

int_1 = {
    'TYPE' : 'interval_left',
    'IN_VALUES' : (78, 84, 87.5, 89.42, 91, 94),
    'MAPPED_VALUES' : (-1.4, -1.03, -0.64, -0.42, -0.33, 0.07, 0.77),
    'MISSING':0.4,
    'CONSTRAINT':"lambda x : (x>=0) and (x<=100)"
}

int_2 = {
    'IN_VAR': 'Pri_CollatState',
    'OUT_VAR': 'division',
    'TYPE': 'categorical',
    'IN_VALUES': [
        ("NY", "CT", "PA", "NJ"),
        ("ME", "NH", "VT", "MA", "RI"),
        ("WI", "IL", "IN", "MI", "OH"),
        ("ND", "SD", "NE", "KS", "MN", "IA", "MO"),
        ("DE", "MD", "DC", "VA", "WV", "NC", "SC", "GA", "FL"),
        ("KY", "TN", "AL", "MS"),
        ("OK", "AR", "LA", "TX"),
        ("CA", "OR", "WA", "AK", "HI"),
        ("MT", "WY", "ID", "NV", "UT", "CO", "AZ", "NM")
    ],
    'MAPPED_VALUES': [
        "NorthEast-MiddleAtlantic",
        "NorthEast-NewEngland",
        "MidWest-EastNorthCentral",
        "MidWest-WestNorthCentral",
        "South-Atlantic",
        "South-EastSouthCentral",
        "South-WestSouthCentral",
        "West-Pacific",
        "West-Mountain"
    ],
    'MISSING': 'Other',
    'DEFAULT':'Default',
    'CONSTRAINT': "lambda x : len(x)==2"
}

MRS = {
    'IN_VAR': 'MRS',
    'OUT_VAR': 'PD',
    'TYPE': 'categorical',
    'IN_VALUES': (
        1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5,
        5.5, 6, 6.5, 7, 7.5, 8, 8.5
    ),
    'MAPPED_VALUES': (
        1, 0.58, 0.58, 0.58, 0.1198, 0.0744, 0.0462, 0.0287, 0.0178,
        0.0111, 0.0069, 0.0043, 0.0027, 0.0016, 0.001, 0.0006
    ),
    'MISSING': 1
}

MRS_2 = {
    'IN_VAR': 'estimated_PD',
    'OUT_VAR': 'STDR_RR_OPR',
    'TYPE': 'interval_right',
    'IN_VALUES': (
        0.0008, 0.0013, 0.0021, 0.0034, 0.0054,
        0.0087, 0.0141, 0.0226, 0.0364, 0.0586, 0.0944,
        0.1520
    ),
    'MAPPED_VALUES': (
        8.5, 8.0, 7.5, 7.0, 6.5,
        6.0, 5.5, 5.0, 4.5, 4.0,
        3.5, 3.0, 1.5
    ),

    'MISSING': 0,
    'CONSTRAINT': "lambda x : (x>=0) and (x<=1)"
}
map_mrs = Mapping(
    in_map=MRS_2,
    debug=True
)
map_mrs.apply(0.0013)


@@@@@@@@@@@@@@@@@@@@@
Old_ALLL/CONTINGENT

              {
                'IN_VAR':'ALLL_SRR',
                'OUT_VAR':'ALLL', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.0003,
                                    0.0003,
                                    0.00328382,
                                    0.00328382,
                                    0.00328382,
                                    0.003989309,
                                    0.006000559,
                                    0.006513746,
                                    0.009829291,
                                    0.016808584,
                                    0.016808584,
                                    0.025429961,
                                    0.057975551,
                                    0.057975551,
                                    0.076954294,
                                    1,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"
            
              },       
              {
                'IN_VAR':'CONTINGENCY_SRR',
                'OUT_VAR':'CONTINGENCY', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.0003,
                                    0.0003,
                                    0.0003,
                                    0.0015209232,
                                    0.0044590343,
                                    0.0096883558,
                                    0.0176096974,
                                    0.0177059032,
                                    0.0211091871,
                                    0.0236186845,
                                    0.0236186845,
                                    0.0398360096,
                                    0.0422021695,
                                    0.0422021695,
                                    0.0422021695,
                                    1,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"            
              } 
              
#SP20-ALLL
              {
                'IN_VAR':'ALLL_SRR',
                'OUT_VAR':'ALLL', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.00303706834598864,
                                    0.00361549065636095,
                                    0.00361549065636095,
                                    0.00380989948376308,
                                    0.00415015722731034,
                                    0.00472335512545617,
                                    0.00581089615234534,
                                    0.00749076542538648,
                                    0.011641392407255,
                                    0.0124782565180591,
                                    0.0249165586817988,
                                    0.0249165586817988,
                                    0.0249165586817988,
                                    0.0389655141910908,
                                    0.0513829242133796,
                                    1,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"
            
              },       
              {
                'IN_VAR':'CONTINGENCY_SRR',
                'OUT_VAR':'CONTINGENCY', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.0033292173379611,
                                    0.00495093473445592,
                                    0.010950901273945,
                                    0.0135547905070507,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    1,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"            
              }                              
              
'''TEST############################################################################
property={
    'IN_VAR':'PropertyType',
    'OUT_VAR':'property_type',
    'TYPE': 'categorical',
    'IN_VALUES': (1,2,3,4,5,6,7,8,9,10),
    'MAPPED_VALUES': ('RT',
                      'IN',
                      'LO',
                      None,
                      None,
                      None,
                      'OF',
                      'MX',
                      None,
                      None
                      ),
    'MISSING': None,
    'CONSTRAINT': "lambda x : (x>=1) and (x<=10)"
}
map_1 = Mapping(
    in_map=property,
    debug=True
) 
map_1.apply(4)
'''#######################################################################################
#------------------

quick_ratio_binning = {
    'IN_VAR': 'r_quickRatio',
    'OUT_VAR': 'V_QuickR',
    'TYPE': 'interval_left',
    'IN_VALUES': (
        0.46828143021914, 1.06599578750292, 1.61751152073732
    ),
    'MAPPED_VALUES': (
        -0.51, -0.12, 0.59, 0.79,
    ),

    'MISSING': 0.06,
}

quick_ratio_map = Mapping(
    in_map=quick_ratio_binning,
    debug=True
)
quick_ratio_map.apply(0.681333333333333)

#------------------
map_1 = Mapping(
    in_map=int_1,
    debug=True
)
map_1.apply(55)
map_1.apply(94)
map_1.apply(95)
map_1.apply(np.NaN)
map_1.apply(None)
map_1.apply(-10)


map_2 = Mapping(
    in_map=int_2,
    debug=True
)
map_2.apply("MA")
map_2.apply("XY")
map_2.apply("d")
map_2.apply("z")
map_2.apply(94)
map_2.apply(np.NaN)
map_2.apply(None)

map_3 = Mapping(
    in_map=cat_1,
    debug=True
)
map_3.apply(1.5)
map_3.apply('skldfv')

m = {
    'a':map_1,
    'b':map_2
}
m['a'].apply(55)



print(id(map_1))
print(id(map_2))
for key in m.keys():
    print(id(m[key]))

list_of_regression_dict = {
    'multifamily_pd_regression_dict':{

        'intercept': -3.5409,
        'coefficients_pairs':{
                                  'm2mat_2': -1.2544,
                                  'currentoccupancy_2': -0.6659,
                                  'dbtyld_2':-0.999,
                                  'ltv_2':-0.7677,
                                  'division_2':-0.5113
                            }

    },
    'non_multifamily_pd_regression_dict':{
        'intercept': -3.4190,
        'coefficients_pairs':{
                                  'm2mat_2': -1.2516,
                                  'currentoccupancy_2': -0.7307,
                                  'dbtyld_2':-0.7049,
                                  'ltv_2':-0.8825,
                                  'division_2':-0.6968,
                                  'proptype_2':-0.4637
                            }

    },
    'lgd_regression_dict':{
        'intercept':0.30092,
        'coefficients_pairs':{
                              'mat_flag': -0.19017,
                              'ltv1': -0.09442,
                              'ltv2':-0.10507,
                              'ltv3':-0.07741,
                              'ltv4':-0.05712,
                              'ltv5':-0.03839,
                              'occ1': 0.09267,
                              'occ2': 0.03723,
                              'dy1': 0.05414,
                              'dy2': 0.08787,
                              'dy3': 0.0734,
                              'dy4': 0.04933,
                              'MF':-0.0299,
                              'isRetail':0.02072,
                              'UER_YoYDiff_L0':0.0306
                          }
    }
}

rr_model = RiskRatingModel(
    uncertainty_rate=0.10,
    as_of_date=datetime.datetime(2015,12,31),
    model_id='34 - Scenario Analysis Model - CRE PD - SBNA',
    scenario='Base',
    scenario_context='CCAR2016',
    forecast_periods=27,
    debug=True
)
m_dict = rr_model.mappings


rateOne=rr.RateOneContract(data,macro_data)

rr_model.mappings['Pri_CollatState'].apply(to_map="MA")
rr_model.mappings['occrate'].apply(to_map=55)
rr_model.mappings['propertytype'].apply(to_map=input_contract['PropertyType'][0])
rr_model.mappings['Pri_CollatState'].apply(to_map=input_contract.iloc[0]['Pri_Collatstate'])

rr = RiskRatingModel(
    uncertainty_rate=0.10,
    as_of_date=datetime.datetime(2016,3,31),
    model_id='721 - Commercial Rating Model - CRE Multifamily PD - SBNA',
    scenario='Base',
    scenario_context='CCAR2016',
    forecast_periods=27,
    debug=True 
)

rr = RiskRatingModel(
    uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2016,6,30),
    model_id='721 - Commercial Rating Model - CRE Multifamily PD - SBNA',
    scenario='Base',
    scenario_context='CCAR2016',
    forecast_periods=27,
    debug=True 
)

-------------------------------------
# raw dataset
raw=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\t2c_cre_dat_ba_03.xlsx')
data=raw[raw['TotalBookBalance'].apply(lambda x: x>0)]



dataset_path='I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\ccmis_anchor_mar_0513_cre.xlsx'


# Masterdataset_PD_Group (CRE MULTIFAMILY & CRE OTHERS)
anchor0513=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\ccmis_anchor_mar_0513_cre.xlsx')
anchor0819=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\ccmis_anchor_jun_0819_cre.xlsx')
anchor1024=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\ccmis_anchor_jun_1024_cre.xlsx')

macro_data=pd.read_csv('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\sa_loss_forecast_input.csv')
raw_macro_data=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\sas_input_forecast_dataset.xlsx')

##TEST sqlite database 'I:\CRMPO\DEPT\Tracy\2017CCAR\models\CRE\data\CRE_Test_Scenario.csv

########################################################################
############################     Para Run    ###########################
########################################################################
ccar_session = CCARSession(
    session_id='CRE',
    session_date=datetime.datetime(2016,6,30),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)

rr = RiskRatingModel(
    uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2016,6,30),
    model_id='721 - Commercial Rating Model - CRE Multifamily PD - SBNA',
    scenario='ICP_Adverse',
    scenario_context='ICAAP2016',
    forecast_periods=27,
    debug=True,
    bau=None,
    origination=True,
    book_balance_filter=None,
    gl_filter=True,
    read_input=False
)
cart.addModel(rr)
cart.checkout()
cf = ccar_session.contributor_file_generator.contributor_file
cre_cf=cf.getCFData()
cre_cf.to_csv('I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI\\controllers\\models\\RFO submission\\CRE_ICP_Adverse_SB_Comm_Loss.csv',index=False)

# macro_data = CREConst_instance.transformed_macro_series
# d = CREConst_instance.calculate()

########################################################################
############################     Dry Run    ############################
########################################################################
ccar_session = CCARSession(
    session_id='CRE',
    session_date=datetime.datetime(2016,12,31),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)

rr = RiskRatingModel(
    uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2016,12,31),
    dataset_query_date=datetime.datetime(2016,11,30),
    model_id='2016-SBNA-Loss-Commercial-CRE',
    scenario='DR_BASE',
    scenario_severity_level='BASE',
    scenario_context='DryRun2017',
    forecast_periods=27,
    crepi_multifamily_scalar=1,
    debug=True,
    bau=None,
    origination=True,
    book_balance_filter=None,
    gl_filter=True,
    path_dependent=True,
    read_input=False
)
cart.addModel(rr)
cart.checkout()
cf = ccar_session.contributor_file_generator.contributor_file
cre_cf=cf.getCFData()

data=rr.processDataset()
#mapped_data=self.getMapping(data)
# Starting timer
t0 = time.time()
#        print(data[UNIQUE_FACILITY_ID])
result=rr.RateContracts(data,macro_data)
print('processModelInputs completed in ' + str(time.time()-t0) + ' s.')
        
        


cre_cf.to_csv('I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI\\controllers\\models\\RFO submission\\CRE_ICP_Adverse_SB_Comm_Loss.csv',index=False)

# macro_data = CREConst_instance.transformed_macro_series
# d = CREConst_instance.calculate()

%%%%%%%%%%%%%%%%%%%%%%%
########################################################################
############################     Sensitivity   ############################
########################################################################
macro_names = [
              'FLBR_US',
              'FRBBBQ_US',
              'FHSTQ_US',
              'FLBR_US',
              'FRTB3M_US',
              'FLBR_US',
              'FIRBAACI7Q_US',
              'FHSTQ_US',
              'FHOFHOPIQ_US',
              'FRTB3M_US',
              'FLBR_US',
              'FHOFHOPIQ_US',
              'FZFL075035503Q_US',
              'FGDPQ_US'
              ]

all_combos = combo_generator(macro_names,["FRB_BASE","FRB_SA"]) 

def combo(scenario,variable):
    result=[]
    result_dict={}
    for scen in scenario:
        for var in variable:
            result_dict[var]=scen
            if len(result_dict)==len(variable):
                result_copy=copy.copy(result_dict)
                result.append(result_copy)
    return(result)
    
all_combos = combo_generator(["FRB_BASE","FRB_SA"],macro_names) 

rr= RiskRatingModel(
    uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2016,12,31),
    dataset_query_date=datetime.datetime(2016,12,31),
    model_id='2016-SBNA-Loss-Commercial-CRE',
    scenario=["FRB_BASE","FRB_SA"],
    scenario_severity_level='STRESS',
    scenario_context='CCAR2017',
    forecast_periods=27,
    ne_scalar=True,
    crepi_multifamily_scalar=[294,
                              290.945098985984,
                              265.793702550437,
                              240.470453137935,
                              216.942528567195,
                              199.865965980898,
                              185.77279303871,
                              172.563832110162,
                              168.601335302004,
                              169
                              ],
    debug=True,
    bau=None,
    origination=True,
    book_balance_filter=None,
    gl_filter=True,
    path_dependent=True,
    read_input=False,
    scenario_combinations = {
                            "FLBR_US":"FRB_BASE",
                            "FRBBBQ_US":"FRB_BASE",
                            "FHSTQ_US":"FRB_BASE",
                            "FRTB3M_US":"FRB_BASE",
                            "FIRBAACI7Q_US":"FRB_BASE",
                            "FHOFHOPIQ_US":"FRB_BASE",
                            "FRTB3M_US":"FRB_BASE",
                            "FHOFHOPIQ_US":"FRB_BASE",
                            "FGDPQ_US":"FRB_BASE",
                            "FZFL075035503Q_US":"FRB_BASE"}
)

########################################################################
############################     SP20    ############################
########################################################################
ccar_session = CCARSession(
    session_id='CRE',
    session_date=datetime.datetime(2017,3,31),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)

rr= RiskRatingModel(
    uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2017,3,31),
    dataset_query_date=datetime.datetime(2017,2,28),
    scenario_date=datetime.datetime(2017,3,31),
    model_id='2016-SBNA-Loss-Commercial-CRE',
    scenario="BASE",
    scenario_severity_level='BASE',
    scenario_context='P20',
    forecast_periods=45,
    ne_scalar=False,
    crepi_multifamily_scalar=None,
    debug=True,
    bau=None,
    origination=True,
    book_balance_filter=None,
    gl_filter=True,
    path_dependent=True,
    read_input=False
)

rr.execute()



cart.addModel(rr)
cart.checkout()
cf_inventory= ccar_session.contributor_file_generator.generateContributorFileInstance()
cf=cf_inventory.getCFData()
cf_inventory.toCSV('I:\\CRMPO\\CCAR\\1Q17\\CRE_SP20_test_alll_0602.csv')





########################################################################
############################     CCAR R1    ############################
########################################################################
ccar_session = CCARSession(
    session_id='CRE',
    session_date=datetime.datetime(2016,12,31),
    user='n818126'
)
cart = ModelShoppingCart(ccar_session=ccar_session)

#macro_names = ModelProperties(
#	model_id = '37 - Scenario Analysis Model - SBB PD - SBNA',
#	version_date=datetime.datetime(2016,12,31)
#)
macro_names = ['FLBR_US','FRBBBQ_US','FHSTQ_US','FLBR_US','FRTB3M_US','FLBR_US','FIRBAACI7Q_US',
'FHSTQ_US',
'FHOFHOPIQ_US',
'FRTB3M_US',
'FLBR_US',
'FHOFHOPIQ_US',
'FZFL075035503Q_US',
'FGDPQ_US']
  
all_combos = combo_generator(macro_names,["FRB_BASE","FRB_SA"]) 

rr= RiskRatingModel(
    uncertainty_rate=0.00,
    as_of_date=datetime.datetime(2016,12,31),
    dataset_query_date=datetime.datetime(2016,12,31),
    model_id='2016-SBNA-Loss-Commercial-CRE',
    scenario=["FRB_BASE","FRB_SA"],
    scenario_severity_level='STRESS',
    scenario_context='CCAR2017',
    forecast_periods=27,
    ne_scalar=True,
    crepi_multifamily_scalar=[294,
                              290.945098985984,
                              265.793702550437,
                              240.470453137935,
                              216.942528567195,
                              199.865965980898,
                              185.77279303871,
                              172.563832110162,
                              168.601335302004,
                              169
                              ],
    debug=True,
    bau=None,
    origination=True,
    book_balance_filter=None,
    gl_filter=True,
    path_dependent=True,
    read_input=False,
    scenario_combinations = {
                            "FLBR_US":"FRB_BASE",
                            "FRBBBQ_US":"FRB_BASE",
                            "FHSTQ_US":"FRB_BASE",
                            "FRTB3M_US":"FRB_BASE",
                            "FIRBAACI7Q_US":"FRB_BASE",
                            "FHOFHOPIQ_US":"FRB_BASE",
                            "FHOFHOPIQ_US":"FRB_BASE",
                            "FGDPQ_US":"FRB_BASE",
                            "FZFL075035503Q_US":"FRB_BASE"}
)

cart.addModel(rr)
cart.checkout()
cf = ccar_session.contributor_file_generator.contributor_file
cre_cf=cf.getCFData()

data=rr.processDataset()
#mapped_data=self.getMapping(data)
# Starting timer
t0 = time.time()
#        print(data[UNIQUE_FACILITY_ID])
result=rr.RateContracts(data,macro_data)
print('processModelInputs completed in ' + str(time.time()-t0) + ' s.')
        
        


cre_cf.to_csv('I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI\\controllers\\models\\RFO submission\\CRE_ICP_Adverse_SB_Comm_Loss.csv',index=False)

# macro_data = CREConst_instance.transformed_macro_series
# d = CREConst_instance.calculate()

%%%%%%%%%%%%%%%%%%%%%%%

#get macro data 
macro_data=rr.getMacro()
#linked to RFO
data=rr.processDataset()
mapped_data=rr.getMapping(data)

import time
start=time.time() 
result_ALL=rr.RateContracts(mapped_data,macro_data)
print("--- %s seconds ---" % (time.time() - start))

result_ALL.to_csv('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\compare sas_python_result\\python_.csv')
import time
############ Filter TotalBookBalance>0 #############
data=raw['TotalBookBalance'].apply(lambda x: x>0)

start=time.time()
result=rr.RateContracts(data,macro_data)
print("--- %s seconds ---" % (time.time() - start))

result=rr_model.RateContracts(data,macro_data)

print("--- %s seconds ---" % (time.time() - start))

%%%%%%%%%%%%%%%%%%%%%%%
Check RFO
%%%%%%%%%%%%%%%%%%%%%%%
cre_sas=pd.read_excel('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\RFO\\SAS_CCMIS.xlsx')
-------------------------------------------------------


"""
import os
import sys
#wd ='C:\\Users\\n838126\\git\\dryrun'
#wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR'
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)   
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
from CIFI.models.modelproperties.modelproperties import ModelProperties
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.config import CONFIG
import datetime
import time
import dateutil.relativedelta as relativedelta
import bisect
import pandas as pd
import math
import numpy as np
import re

#####################
## Globle variables##
#####################
#Dry run edits
#CCMIS_QUERY_DATE=datetime.datetime(2016,11,30)
#Used in raw data comes from RFO
BOOKBALANCEAMOUNT='BOOKBALANCE'
UNIQUE_FACILITY_ID='UNIQUE_FACILITY_ID'
MAXIMUMMATURITYDATE='MAXIMUMMATURITYDATE'
UTILIZATIONOPENDATE='OPENDATE'
OCCUPANCYRATE='CURRENTOCCUPANCY'
COLLATERALCODE='COLLATERALCODE'
EXISTING_NEW='IS_ORIG'
NEW='Y'

PD_GROUP='PD_GROUP'
PRI_COLLATNOI='PRI_COLLATNOI'
PRI_COLLATVALUE='PRI_COLLATVALUE'
PRI_COLLATSTATE='PRI_COLLATSTATE'
SRR='SRR'
CRE_MULTIFAMILY='CRE_MULTIFAMILY'
CRE_OTHER='CRE_OTHER'
PROPERTY_TYPE='PROPERTY_TYPE_MAP'

M2MAT='m2mat'
MULTIFAMILY_STATUS='Multifamily_Status'

OFFLINE='OFFLINE'
# Match what used in mapping
MULTIFAMILY='Multifamily'
NON_MULTIFAMILY='Non-Multifamily'

#Match what Used in macro data
#UER_YOYDIFF_L0='UER_YoYDiff_L0'
UER_YOYDIFF_L0='FLBR_US_d1y'
CREPI_ALL='FZFL075035503Q_US_p1q'
OCC_MULTIFAMILY='occ_multifamily'
OCC_NON_MULTIFAMILY='occ_non_multifamily'
NOI_MULTIFAMILY='noi_multifamily'
NOI_NON_MULTIFAMILY='noi_non_multifamily'
PD_MAPPING_MF_PASS='PD_mapping_MF_Pass'
PD_MAPPING_MF_NOTPASS='PD_mapping_MF_NotPass'
PD_MAPPING_NMF_PASS='PD_mapping_NMF_Pass'
PD_MAPPING_NMF_NOTPASS='PD_mapping_NMF_NotPass'

#Masterdataset


# Helper functions
#SRRtoMRS = lambda srr:

class Mapping():
    """
    ---------------------------Some Explanations-------------------------------
    ---------------------------------------------------------------------------
    Note: for each regression variable corresponding to interval mapping,
          we need one IntervalMapping object.

    An example of mapping dictionary would be:

        example_mapping = {
            'TYPE' : 'interval_left',
            'IN_VALUES' : (78, 84, 87.5, 89.42, 91, 94),
            'MAPPED_VALUES' : (-1.4, -1.03, -0.64, -0.42, -0.33, 0.07, 0.77),
            'MISSING':0.4,
            'CONSTRAINT':"lambda x : (x>=0) and (x<=100)"
        }

    ---------------------------------------------------------------------------
    """

    # Member properties
    __missing = None
    __precision = None
    __debug = None
    __type = None
    __mapped_values = None
    __input_mapping_constraint = None
    __interval_breakpoints = None
    __values_to_map = None
    __default = None

    # Member methods
    def __init__(self, in_map, precision=CONFIG['MODEL_PRECISION'], debug=False):
        """
        This function serves as constructor of the Mapping class.

        Parameters
        ----------
        in_map (dict) : a dictionary containing all the necessary components of the mapping
        precision (int) : number of decimal places for rounding,
        debug (bool) : whether or not to display debug messages
        """

        # Assign member properties
        utilities.checkDataType(precision,int)
        utilities.checkDataType(debug, bool)
        utilities.checkDataType(in_map['IN_VALUES'],(list, tuple))
        utilities.checkDataType(in_map['MAPPED_VALUES'], (list, tuple))
        self.__precision = precision
        self.__debug = debug

        # Validate mapping type
        if in_map['TYPE'] not in ('interval_left', 'interval_right', 'categorical'):
            raise ValueError("Input `TYPE` not recognized : " + in_map['TYPE'])
        else:
            self.__type = in_map['TYPE']

        # Get default/missing mapped value
        if isinstance(in_map['MISSING'], (int, float)):
            self.__missing = round(float(in_map['MISSING']), precision)
        elif isinstance(in_map['MISSING'],(str,type(None),np.nan)):
            self.__missing = in_map['MISSING']
        else:
            raise TypeError("Input `MISSING` data type not recognized.")

        # Process mapping
        if self.__type in ('interval_left', 'interval_right'):
            # Validate length of intervals
            if self.__debug:
                print('Length IN_VALUES: '+str(len(in_map['IN_VALUES'])))
                print('Length MAPPED_VALUES: ' + str(len(in_map['MAPPED_VALUES'])))
            if (len(in_map['MAPPED_VALUES']) - len(in_map['IN_VALUES'])) != 1:
                raise ValueError("Dimension error! `MAPPED_VALUES` should exceed `IN_VALUES` by 1.")

            # Process interval breakpoints
            if self.__debug:
                print('Number of intervals: ' + str(len(in_map['IN_VALUES']) + 1))
            self.__interval_breakpoints = []
            for value in in_map['IN_VALUES']:
                try:
                    self.__interval_breakpoints.append(round(float(value), precision))
                except ValueError:
                    print("Interval values contain non-numeric data type @ " + str(value))
            if self.__debug:
                print('Interval breakpoints : ' + str(self.__interval_breakpoints))
            self.validIntervalBreakpoints(self.__interval_breakpoints)

            # Process mapped values
            self.__mapped_values = []
            for value in in_map['MAPPED_VALUES']:
                if isinstance(value, (int, float)):
                    self.__mapped_values.append(round(float(value), precision))
                elif isinstance(value, str):
                    self.__mapped_values.append(value)
                else:
                    raise TypeError("Input `MAPPED_VALUES` data type not recognized.")
            if self.__debug:
                print('Mapped values : ' + str(self.__mapped_values))
        else:
            # Process categorical mapping
            # Validate length of intervals
            if self.__debug:
                print('Length IN_VALUES: ' + str(len(in_map['IN_VALUES'])))
                print('Length MAPPED_VALUES: ' + str(len(in_map['MAPPED_VALUES'])))
            if (len(in_map['MAPPED_VALUES']) - len(in_map['IN_VALUES'])) != 0:
                raise ValueError("Dimension error! `MAPPED_VALUES` length should equal `IN_VALUES` length.")

            # Assign mapping arrays
            self.__values_to_map = in_map['IN_VALUES']
            self.__mapped_values = in_map['MAPPED_VALUES']
            if 'DEFAULT' in in_map.keys():
                self.__default = in_map['DEFAULT']

        # Process input constraints
        try:
            constraint_temp = eval(in_map['CONSTRAINT'])
            if callable(constraint_temp):
                self.__input_mapping_constraint = constraint_temp
        except KeyError:
            if self.debug:
                print("No constraint provided.")
            pass

    def validIntervalBreakpoints(self, some_interval_breakpoints):
        utilities.checkDataType(some_interval_breakpoints,(list,tuple))
        for i in range(0, len(some_interval_breakpoints)-1):
            if some_interval_breakpoints[i] >= some_interval_breakpoints[i+1]:
                raise Exception("Error! Interval breakpoints are not monotonically increasing.")

    @property
    def missing(self):
        return self.__missing

    @property
    def mapped_values(self):
        return self.__mapped_values

    @property
    def precision(self):
        return self.__precision

    @property
    def debug(self):
        return self.__debug

    @property
    def type(self):
        return self.__type

    @property
    def input_mapping_constraint(self):
        return self.__input_mapping_constraint

    @property
    def interval_breakpoints(self):
        return self.__interval_breakpoints

    @property
    def values_to_map(self):
        return self.__values_to_map

    def apply(self, to_map):
        def makeList(item):
            if isinstance(item, (str, float, int)):
                return ([item])
            elif isinstance(item, (tuple, list)):
                return (item)
            else:
                raise TypeError()

        if pd.isnull(to_map):
            return(self.missing)
        else:
            if self.input_mapping_constraint is not None:
                if not self.input_mapping_constraint(to_map):
                    raise ValueError("Input `to_map` violates constraint.")
            if self.type == 'interval_left':
                return(
                    self.mapped_values[
                        bisect.bisect_left(
                            self.interval_breakpoints,
                            round(to_map, self.precision)
                        )
                    ]
                )
            elif self.type == 'interval_right':
                return(
                    self.mapped_values[
                        bisect.bisect_right(
                            self.interval_breakpoints,
                            round(to_map, self.precision)
                        )
                    ]
                )
            else:
                position = [
                    x for x
                    in range(len(self.values_to_map))
                    if to_map in makeList(self.values_to_map[x])
                ]
                if len(position) == 1:
                    return (self.mapped_values[position[0]])
                elif len(position) == 0:
                    if self.__default is not None:
                        return(self.__default)
                    else:
                        raise ValueError("Invalid input `to_map`.")


class RiskRatingModel(CCARModel):
    # Member properties


    # Member methods
    def __init__(
        self,
        as_of_date,
        dataset_query_date,
        model_id,
        scenario,
        scenario_context,
        scenario_date,
        scenario_severity_level,
        forecast_periods,
        uncertainty_rate,
        min_input_rating=4.0,
        forecast_periods_frequency='monthly',
        debug=None,
        origination=True,
        bau=None,
        book_balance_filter=None,
        gl_filter=None,
        precision=None,
        auto_fetch_macros=True,
        path_dependent=True,
        read_input=False,
        ne_scalar=False,
        crepi_multifamily_scalar=None,
        **kwargs
    ):
        # Initialize parent class properties
        CCARModel.__init__(
            self,
            as_of_date=as_of_date,
            model_id=model_id,
            scenario=scenario,
            scenario_context=scenario_context,
            scenario_date=scenario_date,
            forecast_periods=forecast_periods,
            forecast_periods_frequency=forecast_periods_frequency,
            precision=precision,
            scenario_combinations=kwargs.get("scenario_combinations")

        )

        # Get macro variables during construction
        if auto_fetch_macros:
            self.fetchMacroSeries(scenario_combinations=kwargs.get('scenario_combinations'))
            
        self.min_input_rating=min_input_rating
        self.debug=debug
        self.bau=bau
        self.origination=origination        
        self.book_balance_filter=book_balance_filter
        self.gl_filter=gl_filter
        self.read_input=read_input
        self.path_dependent=path_dependent
        self.dataset_query_date=dataset_query_date
        self.scenario_severity_level=scenario_severity_level
        self.ne_scalar=ne_scalar
        if self.ne_scalar==True:
            if len(crepi_multifamily_scalar)!= self.forecast_period_quarterly+1:
              raise ValueError ('Input crepi_multifamily_scalar length is not correct for transformation')
            else:  
              self.crepi_multifamily_scalar=crepi_multifamily_scalar
        # Fetch PD regression coefficients
        self.multi_pd_regression_coefficients = self._model_properties.getParameters(
                                					type='operation',
                                					name='regression_coefficients',
                                                         segment='multifamily'
                                			)       

        self.non_multi_pd_regression_coefficients=self._model_properties.getParameters(
                                        					type='operation',
                                        					name='regression_coefficients',
                                        					segment='non_multifamily'
                            )
        # Fetch LGD regression coefficients
        self.lgd_regression_coefficients=self._model_properties.getParameters(
            					type='operation',
            					name='regression_coefficients',
                                        segment='lgd_all'
        			)          
   
        # Process Macro variables
        self.macro_variables=self._model_properties.getParameters(
            					type='operation',
            					name='macro_variables',
                                        segment='macro'
        			)      

        self.macro_variables=self._model_properties.getParameters(
            					type='operation',
            					name='macro_variable_combinations',
                                        segment='macro'
        			)
        self._logger.add(
			type='INFO',
			message='CCAR Model initialization completed.',
			context='CCAR Model : ' + self._model_name,
			model_id=self._model_id
        )           
                  
        # Fetch mappings
        list_of_mappings = [
            {
                'IN_VAR':'PropertyType_P',
                'OUT_VAR':'property',
                'TYPE': 'categorical',
                'IN_VALUES': (1,2,3,4,5,6,7,8,9,10),
                'MAPPED_VALUES': ('Retail',
                                  'Industrial / Warehouse',
                                  'Hotel / Hospitality/Gaming (including Resorts)',
                                  'Multi-family for Rent (including low income housing)',
                                  'Homebuilders except condo',
                                  'Condo/Co-op',
                                  'Office',
                                  'Mixed',
                                  'Land and Lot Development',
                                  'Other'
                                  ),
                'MISSING': 'Other',
                'DEFAULT': 'Other'
            },  
            {
                'IN_VAR':'PropertyType_PT',
                'OUT_VAR':'property_type',
                'TYPE': 'categorical',
                'IN_VALUES': (1,2,3,4,5,6,7,8,9,10),
                'MAPPED_VALUES': ('RT',
                                  'IN',
                                  'LO',
                                  '',
                                  '',
                                  '',
                                  'OF',
                                  'MX',
                                  '',
                                  ''
                                  ),
                'MISSING': None,
                'DEFAULT': ''
            },     
            {
                'IN_VAR':'PropertyType_MS',
                'OUT_VAR':'multifamily_status',
                'TYPE': 'categorical',
                'IN_VALUES': (1,2,3,4,5,6,7,8,9,10),
                'MAPPED_VALUES': ('Non-Multifamily',
                                  'Non-Multifamily',
                                  'Non-Multifamily',
                                  'Multifamily',
                                  'Non-Multifamily',
                                  'Multifamily',
                                  'Non-Multifamily',
                                  'Non-Multifamily',
                                  'Non-Multifamily',
                                  'Non-Multifamily'
                                  ),
                'MISSING': 'Non-Multifamily',
                'DEFAULT': 'Non-Multifamily'
            },              
            {
                'IN_VAR': 'PRI_COLLATSTATE',
                'OUT_VAR': 'division',
                'TYPE': 'categorical',
                'IN_VALUES': [
                    ("NY", "CT", "PA", "NJ"),
                    ("ME", "NH", "VT", "MA", "RI"),
                    ("WI", "IL", "IN", "MI", "OH"),
                    ("ND", "SD", "NE", "KS", "MN", "IA", "MO"),
                    ("DE", "MD", "DC", "VA", "WV", "NC", "SC", "GA", "FL"),
                    ("KY", "TN", "AL", "MS"),
                    ("OK", "AR", "LA", "TX"),
                    ("CA", "OR", "WA", "AK", "HI"),
                    ("MT", "WY", "ID", "NV", "UT", "CO", "AZ", "NM")
                ],
                'MAPPED_VALUES': [
                    "NorthEast-MiddleAtlantic",
                    "NorthEast-NewEngland",
                    "MidWest-EastNorthCentral",
                    "MidWest-WestNorthCentral",
                    "South-Atlantic",
                    "South-EastSouthCentral",
                    "South-WestSouthCentral",
                    "West-Pacific",
                    "West-Mountain"
                ],
                'MISSING': 'Other',
                'DEFAULT': 'Other'
            },
            {
                'IN_VAR':'Ltv_Multifamily',
                'OUT_VAR':'WOE_LTV_Multifamily',
                'TYPE': 'interval_left',
                'IN_VALUES': (0.2957836877,0.3959474162,0.5289698778,
                              0.5850979645,0.7824426208,0.83654772127263,
                              0.9994278019,1.0887007165,1.2286017288),
                'MAPPED_VALUES': (1.92,0.73,0.6,
                                 0.24,0.04,-0.07,
                                 -0.22,-0.56,-0.77,
                                 -0.96),
                'MISSING': 0.1
            },   
            {
                'IN_VAR':'Ltv_Non_Multifamily',
                'OUT_VAR':'WOE_LTV_Non_Multifamily',
                'TYPE': 'interval_left',
                'IN_VALUES': (0.388257496,
                              0.43967162769487,
                              0.7884597706,
                              0.8376397627,
                              0.8937550834,
                              0.9571615309,
                              1.0354949941,
                              1.1625173411
                             ),
                'MAPPED_VALUES': (1.01,
                                  0.78,
                                  0.39,
                                  -0.02,
                                  -0.25,
                                  -0.39,
                                  -0.65,
                                  -0.81,
                                  -1.87
                                 ),
                'MISSING': 0.13
            }, 
            {
                'IN_VAR':'occrate',
                'OUT_VAR':'WOE_currentoccupancy',
                'TYPE': 'interval_left',
                'IN_VALUES': (78, 84, 87.5, 89.42, 91, 94),
                'MAPPED_VALUES': (-1.4, -1.03, -0.64, -0.42, -0.33, 0.07, 0.77),
                'MISSING': 0.4
            },            
            {
                'IN_VAR':'Currentoccupancy_Multifamily',
                'OUT_VAR':'WOE_Currentoccupancy_Multifamily',
                'TYPE': 'interval_left',
                'IN_VALUES': (78,84,87.5,89.42,91,94),
                'MAPPED_VALUES': (-1.4,-1.03,-0.64,-0.42,-0.33,0.07,0.77),                                  
                'MISSING': 0.45
            },             
            {
                'IN_VAR':'Currentoccupancy_Non_Multifamily',
                'OUT_VAR':'WOE_Currentoccupancy_Non_Multifamily',
                'TYPE': 'interval_left',
                'IN_VALUES': (64,73,79,83.69,87,90,92.86,94.67,96.1,98),
                'MAPPED_VALUES': (-1.32,-0.82,-0.53,-0.38,-0.26,-0.02,0.09,0.19,0.34,0.44,0.6),
                'MISSING': 0.51
            },             
            {
                'IN_VAR':'Debtyield_Multifamily',
                'OUT_VAR':'WOE_Debtyield_Multifamily',
                'TYPE': 'interval_left',
                'IN_VALUES': (0.05777196419555,
                              0.0705028851,
                              0.0781741364,
                              0.08434663623782,
                              0.09533745629479,
                              0.1068528819,
                              0.1207621073,
                              0.1557167674,
                              0.18026663219214,
                              0.2354666152
                             ),
                'MAPPED_VALUES': (-1.33,
                                  -0.98,
                                  -0.43,
                                  -0.28,
                                  -0.03,
                                  0.12,
                                  0.35,
                                  0.41,
                                  0.57,
                                  0.83,
                                  1.1
                                 ),
                                  
                'MISSING': 0.48
            },             
            {
                'IN_VAR':'Debtyield_Non_Multifamily',
                'OUT_VAR':'WOE_Debtyield_Non_Multifamily',
                'TYPE': 'interval_left',
                'IN_VALUES': (0.0685,
                              0.08036038454573,
                              0.08788479501247,
                              0.0940943317,
                              0.0998612903,
                              0.10567221470000,
                              0.1250134204,
                              0.1917628053334,
                              0.2332675282,
                              0.4164107582),
                'MAPPED_VALUES': (-1.42,
                                  -0.79,
                                  -0.52,
                                  -0.15,
                                  -0.02,
                                  0.08,
                                  0.18,
                                  0.34,
                                  0.47,
                                  0.63,
                                  0.95
                                 ),
                'MISSING': 0.64
            },  
            {
                'IN_VAR':'division_Multifamily',
                'OUT_VAR':'WOE_division_Multifamily',
                'TYPE': 'categorical',
                'IN_VALUES': (
                                "MidWest-EastNorthCentral",
                                "MidWest-WestNorthCentral",
                                "NorthEast-MiddleAtlantic",
                                "NorthEast-NewEngland",
                                "Other",                                                                      
                                "South-Atlantic",
                                "South-EastSouthCentral",
                                "South-WestSouthCentral",
                                "West-Mountain",
                                "West-Pacific"
                             ),
                'MAPPED_VALUES': (  
                                    -0.24,
                                    0.36,
                                    0.8,
                                    0.55,
                                    -1.31,
                                    -0.25,
                                    -0.35,
                                    -0.45,
                                    -0.16,
                                    0.87
                                ),
                'MISSING': None
            }, 
            {
                'IN_VAR':'division_Non_Multifamily',
                'OUT_VAR':'WOE_division_Multifamily',
                'TYPE': 'categorical',
                'IN_VALUES': (
                                "MidWest-EastNorthCentral",
                                "MidWest-WestNorthCentral",
                                "NorthEast-MiddleAtlantic",
                                "NorthEast-NewEngland",
                                "Other",                                                                      
                                "South-Atlantic",
                                "South-EastSouthCentral",
                                "South-WestSouthCentral",
                                "West-Mountain",
                                "West-Pacific"
                             ),
                'MAPPED_VALUES': (  
                                    -0.36,
                                    -0.12,
                                    0.21,
                                    0.21,
                                    -0.21,
                                    -0.04,
                                    -0.1,
                                    0.05,
                                    -0.36,
                                    0.37
                                ),
                'MISSING': None
            },    
            {
                'IN_VAR':'property_type_Non_Multifamily',
                'OUT_VAR':'proptype_2_Non_Multifamily',
                'TYPE': 'categorical',
                'IN_VALUES': (
                                "OF",
                                "RT",
                                "IN",
                                "LO",
                                "MX"                                                                      
                             ),
                'MAPPED_VALUES': (  
                                    -0.22,
                                    0.1,
                                    0.06,
                                    -0.3,
                                    -0.22,
                                ),
                'MISSING': 0,
                'DEFAULT':1.23
            },                
            {
                'IN_VAR':'estimated_PD',
                'OUT_VAR':'rating', 
                'TYPE' : 'interval_left',
                'IN_VALUES' : (
                                0.0008,0.0013,0.0021,0.0034,0.0054,
                                0.0087,0.0141,0.0226,0.0364,0.0586,
                                0.0944,0.1520,0.2448,0.3941,0.9999
                               ),
                'MAPPED_VALUES' : (
                                    8.5,8,7.5,7,6.5,
                                    6,5.5,5,4.5,4,
                                    3.5,3,2.5,2,1.5,"nan"
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>0) and (x<1)"
              },
              {
                'IN_VAR':'final_rating',
                'OUT_VAR':'pd_mrs', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                1,1.5,2,2.5,3,
                                3.5,4,4.5,5,5.5,
                                6,6.5,7,7.5,8,
                                8.5
                              ),
                'MAPPED_VALUES' : (
                                    1,0.58,0.58,0.58,0.1198,
                                    0.0744,0.0462,0.0287,0.0178,0.0111,
                                    0.0069,0.0043,0.0027,0.0016,0.001,
                                    0.0006
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>0) and (x<10)"
              }, 
              {
                'IN_VAR':'ALLL_SRR',
                'OUT_VAR':'ALLL', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.00303706834598864,
                                    0.00361549065636095,
                                    0.00361549065636095,
                                    0.00380989948376308,
                                    0.00415015722731034,
                                    0.00472335512545617,
                                    0.00581089615234534,
                                    0.00749076542538648,
                                    0.011641392407255,
                                    0.0124782565180591,
                                    0.0249165586817988,
                                    0.0249165586817988,
                                    0.0249165586817988,
                                    0.0389655141910908,
                                    0.0513829242133796,
                                    1,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"
            
              },           
              {
                'IN_VAR':'ALLL_SRR_MF',
                'OUT_VAR':'ALLL', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.002990591,
                                    0.002990591,
                                    0.00299807,
                                    0.00300513,
                                    0.003039972,
                                    0.003106889,
                                    0.003722346,
                                    0.003960706,
                                    0.004199066,
                                    0.004574682,
                                    0.004950299,
                                    0.005701532,
                                    0.015466163,
                                    0.022281749,
                                    0.029097335,
                                    0.267988684,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"            
              },                       
              {
                'IN_VAR':'ALLL_SRR_OTHER',
                'OUT_VAR':'ALLL', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.003294655,
                                    0.003294655,
                                    0.003294655,
                                    0.006167422,
                                    0.007703272,
                                    0.00806367,
                                    0.008424067,
                                    0.011206825,
                                    0.011532659,
                                    0.011858492,
                                    0.028663707,
                                    0.039162181,
                                    0.04323547,
                                    0.047308758,
                                    0.055455335,
                                    0.296341104,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"            
              },                                                                                        
              {
                'IN_VAR':'CONTINGENCY_SRR',
                'OUT_VAR':'CONTINGENCY', 
                'TYPE' : 'categorical',
                'IN_VALUES' : (
                                8.5,
                                8,
                                7.5,
                                7,
                                6.5,
                                6,
                                5.5,
                                5,
                                4.5,
                                4,
                                3.5,
                                3,
                                2.5,
                                2,
                                1.5,
                                1,
                                0
                              ),
                'MAPPED_VALUES' : (
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.00132868829603611,
                                    0.0033292173379611,
                                    0.00495093473445592,
                                    0.010950901273945,
                                    0.0135547905070507,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    0.0186016906425032,
                                    1,
                                    0
                                  ),
                'MISSING':0,
                'CONSTRAINT':"lambda x : (x>=0) and (x<10)"            
              }                              
        ]
        self._mappings = self.processMappings(list_of_mappings=list_of_mappings)
#--------------------------------------------------------------------------------------------------------   
#--------------------------------------------------------------------------------------------------------   
#    alll=pd.read_csv('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\Reference\\ALLL.csv')
#    contingency=pd.read_csv('I:\\CRMPO\\DEPT\\Tracy\\2017CCAR\\models\\CRE\\data\\Reference\\CONTINGENCY.csv')
 
    @property
    def mappings(self):
        return(self._mappings)
    @property
    def crepi_scalar(self):
        return(self.crepi_ne_scalar())         
    # get forecaste period 
    # e.g turn 27 monthly forecast periods into 9 quarterly forecast periods 
    @property
    def forecast_period_quarterly(self):
        return(int(self._forecast_periods/utilities.PERIOD_FREQUENCY_MAP['quarterly']))
      
    def processMappings(self, list_of_mappings):
        mapping_dict = {}
        for mapping in list_of_mappings:
            mapping_dict[mapping['IN_VAR']] = Mapping(
                in_map=mapping,
                precision=self.precision
            )
        return(mapping_dict)
              
    def processDataset(self,dataset_path=None):
        # fetch RFO data
        t0 = time.time()
        self._logger.add(
                type='INFO',
                message='Start RFO query',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )            
        dataset= CCMISMasterDataset(
                    	asofdate=self.dataset_query_date,
                    	pd_groups=[CRE_MULTIFAMILY, CRE_OTHER],
                    	debug=False
                  ).data

        column_name=[    
                         'ASOFDATE',                         
                         'SOURCEID',
                         'ONEOBLIGORNUMBER',
                         'CUSTOMERNUMBER',
                         'FACILITYNUMBER',
                         'FAS114_STATUS',
                         'LOCAL_NPL_FLAG',
                         'TDR',
                         COLLATERALCODE,
                         UNIQUE_FACILITY_ID,
                         OCCUPANCYRATE,
                         MAXIMUMMATURITYDATE,
                         PD_GROUP,
                         PRI_COLLATNOI,
                         PRI_COLLATVALUE,
                         PRI_COLLATSTATE,
                         PROPERTY_TYPE,
                         SRR,
                         BOOKBALANCEAMOUNT,
                         UTILIZATIONOPENDATE,
                         EXISTING_NEW]
        dataset=dataset[column_name] 
#        if self.path_dependent==True:
#          orig=pd.read_excel('C:\\Users\\n838126\\Documents\\orig.xlsx')
#          dataset=dataset.append(orig[column_name])

#       read from excel dataset
#        if os.path.exists(dataset_path) & os.path.isfile(dataset_path):       
#            dataset=pd.read_excel(dataset_path) 
#        else:
#            raise Exception("Input path does not exist")

        if self.debug:
            runtime = time.time()-t0
            self._logger.add(
                    type='INFO',
                    message='End RFO query in ' + str(runtime) + ' s.',
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )            
        # filter positive book balance
        if self.book_balance_filter ==True:
            dataset=dataset[dataset[BOOKBALANCEAMOUNT].apply(lambda x: x>0)] 
        # filter out offline facilities
        if self.gl_filter ==True:
            dataset=dataset[~dataset[UNIQUE_FACILITY_ID].str.contains(OFFLINE)]   
        if self.origination==False:
            dataset=dataset[~dataset[EXISTING_NEW].str.contains(NEW)]
            
        # replace special character
        dataset=dataset.replace({'uav': np.nan,None:np.nan,'NA':np.nan,'na':np.nan,'Unknown':np.nan,' ':np.nan}, regex=True)   
        # check numeric data type
        for field in [COLLATERALCODE,OCCUPANCYRATE,PRI_COLLATNOI,PRI_COLLATVALUE,PROPERTY_TYPE,SRR,BOOKBALANCEAMOUNT]:
          if (pd.isnull(dataset[field][0])) or (type(dataset[field][0]) not in [np.float64,float]):
            dataset[field]=dataset[field].convert_objects(convert_numeric=True) 
        # NOI 0 is missing
        dataset[PRI_COLLATNOI]=dataset[PRI_COLLATNOI].replace({0: np.nan}, regex=True)   
#        if self.debug:            
#          print(dataset.describe())

        self._logger.add(
                type='INFO',
                message='End data filtering',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )            
        return(dataset)
        
    # check missing data per column        
    def checkMissing(dataset):        
        return(dataset.apply(lambda x: sum(x.isnull().values), axis = 0))
    # get macro data
    def getMacro(self):
        '''
        This method fetches all raw/transformed macro variables and calculates all derived parameters
        including:
            occ_multifamily,occ_non_multifamily,
            noi_multifamily,noi_non_multifamily,
            pd_mapping_mf_pass,pd_mapping_mf_not_pass,
            pd_mapping_nmf_pass,pd_mapping_nmf_not_pass
        
        @return: macro variables
        '''       
        if self.debug:
            t0=time.time()
            self._logger.add(
                    type='INFO',
                    message='Start getting macro variables',
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )                     
        #fetch macro variables
        mev_data=self.transformed_macro_series
        if self.debug:
            self._logger.add(
                    type='INFO',
                    message='End getting macro variables in ' + str(time.time()-t0) + ' s.',
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )          

        # ensure no duplicates
        mev_data=mev_data.T.drop_duplicates().T
        if self.debug:
            t0=time.time()
            self._logger.add(
                    type='INFO',
                    message='Start getting macro variable dictionary',
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )             
        
        occ_multifamily_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='occ_multifamily'
                                         )
        occ_non_multifamily_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='occ_non_multifamily'
                                         )       
        noi_multifamily_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='noi_multifamily'
                                         )
        noi_non_multifamily_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='noi_non_multifamily'
                                         )    
        pd_mapping_mf_pass_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='PD_mapping_MF_Pass'
                                         )
        pd_mapping_mf_not_pass_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='PD_mapping_MF_NotPass'
                                         )                                            
        pd_mapping_nmf_pass_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='PD_mapping_NMF_Pass'
                                         )
        pd_mapping_nmf_not_pass_regrssion_dict = self._model_properties.getParameters(
                        					type='operation',
                        					name="regression_coefficients",
                        					segment='PD_mapping_NMF_NotPass'
                                         )                                          
                                         
        # function to calculate regression on macro varibles
        def calculateRegression(mev_data,input_dict,name): 
            '''
            Bases on raw variables, this method calculates derived variables: 
                occ_multifamily,occ_non_multifamily,
                noi_multifamily,noi_non_multifamily,
                pd_mapping_mf_pass,pd_mapping_mf_not_pass,
                pd_mapping_nmf_pass,pd_mapping_nmf_not_pass
            
            @return: derived variables
            '''          
            intercept = input_dict['intercept']
            coeff_pairs = input_dict['coefficients_pairs']
            mev_data[name] = sum([mev_data[item] * coeff_pairs[item] for item in coeff_pairs.keys()]) + intercept
            return(mev_data)     
                                  
        for input_dict in [occ_multifamily_regrssion_dict,
                           occ_non_multifamily_regrssion_dict,
                           noi_multifamily_regrssion_dict,
                           noi_non_multifamily_regrssion_dict,
                           pd_mapping_mf_pass_regrssion_dict,
                           pd_mapping_mf_not_pass_regrssion_dict,
                           pd_mapping_nmf_pass_regrssion_dict,
                           pd_mapping_nmf_not_pass_regrssion_dict]:                              
             mev_data=calculateRegression(mev_data,input_dict,input_dict['regression_variable'])                                 
        if self.debug:
            runtime=time.time()-t0
            self._logger.add(
                    type='INFO',
                    message='End processing macro variable in ' + str(runtime) + ' s.',
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )            
        return(mev_data)    
        
    def RateOneContract(self,data,macro_data):
        # This method rates one lone    
        result=pd.DataFrame()    
        mapped_data=self.getMapping(data)
        #calculate alll and contingency    
#        if mapped_data.loc[MULTIFAMILY_STATUS]==MULTIFAMILY:
#            alll_rate=self.mappings['ALLL_SRR_MF'].apply(to_map=int(mapped_data.loc['SRR']*2)/2)
#        else:
#            alll_rate=self.mappings['ALLL_SRR_OTHER'].apply(to_map=int(mapped_data.loc['SRR']*2)/2)
            
        contingency_rate=self.mappings['CONTINGENCY_SRR'].apply(to_map=int(mapped_data.loc['SRR']*2)/2)   
        
        frequency={'quarterly':1,'monthly':3}
        pd_frequency=frequency[self._forecast_periods_frequency]  
        convert=lambda x,f: np.repeat(np.array(x),f)
        period_date_series=utilities.generateDateSequence(
                      self.as_of_date, 
                      self.forecast_periods, 
                      m_interval=1, 
                      include_init=False
                  )            
        #path dependent for new origination
        if (self.path_dependent==True)&(NEW in data.loc[EXISTING_NEW]): 
          forecast_range=self.forecast_period_quarterly
          forecast_qrt=pd_frequency
        # regular forecast e.g 27 months
        else:
          forecast_range=1 
          forecast_qrt=1
          
        for start_period in range(forecast_range):
          regression_variables=self.process_model_inputs(mapped_data,macro_data,start_period=start_period)          
          pd_result_all=self.calculatePD(mapped_data,regression_variables,macro_data,start_period=start_period)
          pd_result=pd_result_all['pd_1m']  
          final_rating=pd_result_all['final_rating']
          alll_rate=pd_result_all['alll_rate']
          lgd=self.calculateLGD(mapped_data,regression_variables,start_period=start_period)
          
          if start_period==0:
            result=result.append(pd.DataFrame({
                                    'PeriodDate':period_date_series,
                                    'Vintage':self.as_of_date,
                                    'ModelSegment':mapped_data.loc[UNIQUE_FACILITY_ID],
                                    'PD':convert(pd_result,pd_frequency),
#==============================================================================
#                                     'FINAL_RATING':convert(final_rating,pd_frequency),
#==============================================================================
                                    'LGD':convert(lgd,pd_frequency),
                                    'EAD':1,
                                    'EADAVAILABLELINE':0,
                                    'EADBALANCE':1,
                                    'EADLETTEROFCREDIT':1,
                                    'EADTOTALLINE':0,
                                    'ALLLCOVERAGE':convert(alll_rate,pd_frequency),
                                    'CONTINGENTRESERVE':contingency_rate,
                                     EXISTING_NEW:mapped_data.loc[EXISTING_NEW]
                                }))      
          #ead=self.calculateEAD(mapped_data,regression_variables)
          #loss_amount=self.estimateLossAmount(pd_result['pd_1q'],ead,lgd['LGD'])
          if (self.path_dependent==True)&(NEW in data.loc[EXISTING_NEW]):                              
          # generate month result within specific qrt
            for month in range(1,forecast_qrt+1):   
              period_date=utilities.generateDateSequence(
                      utilities.addMonths2date(self.as_of_date,(start_period*3+month)), 
                      self.forecast_periods-start_period*3-month, 
                      m_interval=utilities.PERIOD_FREQUENCY_MAP[self._forecast_periods_frequency], 
                      include_init=False
                  )            
              result=result.append(pd.DataFrame({
                                      'PeriodDate':period_date,
                                      'Vintage':utilities.addMonths2date(self.as_of_date,(start_period*3+month)),
                                      'ModelSegment':mapped_data.loc[UNIQUE_FACILITY_ID],
                                      'PD':convert(pd_result,pd_frequency)[month:],
#==============================================================================
#                                       'FINAL_RATING':convert(final_rating,pd_frequency)[month:],           
#==============================================================================
                                      'LGD':convert(lgd,pd_frequency)[month:],
                                      'EAD':1,
                                      'EADAVAILABLELINE':0,
                                      'EADBALANCE':1,
                                      'EADLETTEROFCREDIT':1,
                                      'EADTOTALLINE':0,
                                      'ALLLCOVERAGE':convert(alll_rate,pd_frequency)[month:],        
                                      'CONTINGENTRESERVE':contingency_rate,
                                       EXISTING_NEW:mapped_data.loc[EXISTING_NEW]
                                  }))
                                               
        return(result)

    def RateContracts(self,data,macro_data):
        result=pd.DataFrame()
        items_to_process = len(data)
        report_breakpoints = list(np.array(list(range(1, 21))) * (items_to_process // 20))
        for index,row in data.iterrows():
            if self.debug:             
                if index in report_breakpoints:
                  self._logger.add(
                      type='INFO',
                      message='Rating portfolio ' + str(
                        (report_breakpoints.index(index) + 1) * 5) + "% complete...",
                      context='CCAR Model : ' + self._model_name,
                      model_id=self._model_id
                  )                     
                    #print('get contract' + str(i))
            result=result.append(self.RateOneContract(row,macro_data=macro_data))
        # check length    
        orig_length=(self.forecast_periods*(self.forecast_periods+1)/2)
        if len(result) !=(
                          len(data[data[EXISTING_NEW]==NEW])*orig_length 
                          +
                          len(data[data[EXISTING_NEW]!=NEW])*self.forecast_periods) :
          raise ValueError('Result length is not correct')

        result_melt = pd.melt(
                             result,
                             id_vars=['PeriodDate','Vintage','ModelSegment',EXISTING_NEW],
                             var_name=['RateName'],
                             value_name='ModelOutputRate'
                             )                           
        return(result_melt)
                
    def getMapping(self,data):
        # process MaximumMaturityDate to get m2mat
#        if self.debug:
#            t0=time.time()
#            print('>>> Start mapping')
        mapped_data=data.copy()

        maxmaturity=data.loc[MAXIMUMMATURITYDATE]
        # get month end date for maximum maturity date
        if pd.isnull(maxmaturity) or maxmaturity=='.':
            monthend_maxmaturity=data.loc[MAXIMUMMATURITYDATE]
        else:            
            if maxmaturity.month == 12:
                monthend_maxmaturity=maxmaturity.replace(year=maxmaturity.year+1,month=1, day=1)-datetime.timedelta(days=1)
            else:
                monthend_maxmaturity=maxmaturity.replace(month=maxmaturity.month+1, day=1)-datetime.timedelta(days=1)

        if (
             pd.isnull(data.loc[MAXIMUMMATURITYDATE])
           ) or (
                   data.loc[MAXIMUMMATURITYDATE] == '.' 
                 ) or (
                         data.loc[MAXIMUMMATURITYDATE] == '01/01/9999'):
            mapped_data[M2MAT]=np.nan
        else:
            if (self.origination != False)&(NEW in data.loc[EXISTING_NEW]) :
                m2mat=relativedelta.relativedelta(monthend_maxmaturity,data.loc[UTILIZATIONOPENDATE])

            else:
                m2mat=relativedelta.relativedelta(monthend_maxmaturity,self._as_of_date)                
                
            mapped_data[M2MAT]=m2mat.years*12+m2mat.months                
            
        # division mapping from Pri_CollatState
        mapped_data['division']=self.mappings[PRI_COLLATSTATE].apply(to_map=data.loc[PRI_COLLATSTATE])
        # property,property_type,multifamily_status mapping from PropertyType
        mapped_data['Property']=self.mappings['PropertyType_P'].apply(to_map=data.loc[PROPERTY_TYPE])
        mapped_data['Property_Type']=self.mappings['PropertyType_PT'].apply(to_map=data.loc[PROPERTY_TYPE])
        mapped_data[MULTIFAMILY_STATUS]=self.mappings['PropertyType_MS'].apply(to_map=data.loc[PROPERTY_TYPE])

#        if self.debug:
#            runtime=time.time()-t0
#            print('>>> End mapping')
#            print('Execution completed in ' + str(runtime) + ' s.')
        return(mapped_data)
    def crepi_ne_scalar(self):
        TRANSFORM_DICT = {
          'none': lambda x, pf: x,
          'p1q': lambda x, pf: x.pct_change(1) if pf == 'quarterly' else x.pct_change(3) if pf == 'monthly' else None,
          'p1y': lambda x, pf: x.pct_change(4) if pf == 'quarterly' else x.pct_change(12) if pf == 'monthly' else None
        }    
        crepi_ne_scalar = TRANSFORM_DICT['p1q'](pd.core.series.Series(self.crepi_multifamily_scalar),'quarterly')[1:]        
        if len(crepi_ne_scalar)!=self.forecast_period_quarterly:
          raise ValueError('CREPI_NE length is not correct')
        return(list(crepi_ne_scalar))   
        
    def process_model_inputs(self,mapped_data,macro_data,start_period=0,debug=False):  
#        if self.debug:
#            print(">>>process model input")
#            print(mapped_data[UNIQUE_FACILITY_ID])
        regression_variables=[]
        # LTV: apply CREPI_ALL to get New_CollatVaule
        # Months to maturity: get dynamic m2mat
        new_collat_value=[]
        new_m2mat=[]
        occ_diff=[]
        noi_diff=[]
        new_occ_rate=[]   
        new_netoperatinginc=[] 
        #if self.debug:
            #print(mapped_data.iloc[0][UNIQUE_FACILITY_ID])
                                  
        for qtr in range(self.forecast_period_quarterly-start_period):
            # process macro dependent variables (crepi,occdiff,noidiff)
            if self.bau == None:
                if (
                     (
                      mapped_data.loc[MULTIFAMILY_STATUS]==MULTIFAMILY
                      ) and
                     (
                      mapped_data.loc['division'] in ["NorthEast-MiddleAtlantic","NorthEast-NewEngland"]
                     ) and
                     (
                      self.scenario_severity_level == 'STRESS'
                     ) and
                     (
                      self.ne_scalar == True
                     )                      
                    ):
                      crepi = self.crepi_scalar[qtr+start_period]
                else:
                      crepi = macro_data.iloc[qtr+start_period][CREPI_ALL]   
                      
                if mapped_data.loc[MULTIFAMILY_STATUS]==MULTIFAMILY:      
                    occdiff = macro_data.iloc[qtr+start_period][OCC_MULTIFAMILY]*0.01
                    noidiff = macro_data.iloc[qtr+start_period][NOI_MULTIFAMILY]*0.01                                                                                          
                
                elif mapped_data.loc[MULTIFAMILY_STATUS]==NON_MULTIFAMILY:
                        occdiff = macro_data.iloc[qtr+start_period][OCC_NON_MULTIFAMILY]*0.01
                        noidiff = macro_data.iloc[qtr+start_period][NOI_NON_MULTIFAMILY]*0.01                                                               
                else:
                    raise ValueError("Input`multifamily_status` is not recognized.")        
            # BAU version: keep inputs as it is                          
            else:
                crepi = 0
                occdiff = 0
                noidiff = 0
            # process ltv and m2mat  
            # from data input COLLATVALUE-->stress by crepi-->newcollatvalue-->newltv                
            if qtr == 0:
                newcollatvalue=float(mapped_data.loc[PRI_COLLATVALUE]) * (1+float(crepi))
                newm2mat=mapped_data.loc[M2MAT]-3                       
            else:
                newcollatvalue=new_collat_value[qtr-1]* (1+float(crepi))
                newm2mat=new_m2mat[qtr-1]-3                
            
            if pd.isnull(newcollatvalue) or newcollatvalue == 0:
                newltv=np.nan
            else:
                newltv=mapped_data.loc[BOOKBALANCEAMOUNT]/newcollatvalue
            
            new_collat_value.append(newcollatvalue)
            new_m2mat.append(newm2mat)  
             
            # New_OCC_Rate: apply occdiff to OccupancyRate
            # New_NETOPERATINGINC:apply (1 + noidiff) to NETOPERATINGINC   
            # Occupancy Rate and Debt yield (based on the first four quarter forecast)    
            if qtr < 4 :
                newoccrate=float(mapped_data.loc[OCCUPANCYRATE])+occdiff                
                newnetoperatinginc=float(mapped_data.loc[PRI_COLLATNOI])*(1+noidiff)
            else:
                newoccrate=new_occ_rate[qtr-4]+occdiff
                newnetoperatinginc=new_netoperatinginc[qtr-4]*(1+noidiff)
                                   
            # New_DY: New_NETOPERATINGINC / BOOKBALANCEAMOUNT    
            if pd.isnull(mapped_data.loc[BOOKBALANCEAMOUNT]) or mapped_data.loc[BOOKBALANCEAMOUNT] == 0:
                newdy=np.nan                
            else:
                newdy=newnetoperatinginc/mapped_data.loc[BOOKBALANCEAMOUNT]  
            
            # get WOE 
            if mapped_data.loc[MULTIFAMILY_STATUS]==MULTIFAMILY:
                # get WOE_LTV(ltv_2)
                ltv2=self.mappings['Ltv_Multifamily'].apply(to_map=newltv)
                # get WOE_division(division_2) 
                division_2=self.mappings['division_Multifamily'].apply(to_map=mapped_data.loc['division'])
                # get proptype_2
                proptype_2=np.nan
                # get WOE_debtyield(dbtyld_2)
                dbtyld2=self.mappings['Debtyield_Multifamily'].apply(to_map=newdy)
                # get WOE_currentoccupancy(currentoccupancy_2)   
                currentoccupancy2=self.mappings['Currentoccupancy_Multifamily'].apply(to_map=newoccrate*100)
                # get WOE_m2mat(m2mat_2)  
                # Treating missing M2M as <=12 M2M is a special treatment for loss forecasting to ensure consistency between PD & LGD                    
                if newm2mat <= 12 or pd.isnull(newm2mat):
                    if self.scenario_severity_level == 'BASE':
                        m2mat2 = 0.35
                    else:
                        m2mat2 =-1.75
                elif newm2mat <= 108:
                    m2mat2 = 0.35
                else:
                    m2mat2 = 1.44                
                
            elif mapped_data.loc[MULTIFAMILY_STATUS]==NON_MULTIFAMILY:
                # get WOE_LTV(ltv_2)
                ltv2=self.mappings['Ltv_Non_Multifamily'].apply(to_map=newltv)                                             
                # get WOE_division(division_2) 
                division_2=self.mappings['division_Non_Multifamily'].apply(to_map=mapped_data.loc['division'])
                # get proptype_2
                proptype_2=self.mappings['property_type_Non_Multifamily'].apply(to_map=mapped_data.loc['Property_Type'])
                # get WOE_debtyield(dbtyld_2)
                dbtyld2=self.mappings['Debtyield_Non_Multifamily'].apply(to_map=newdy)
                # get WOE_currentoccupancy(currentoccupancy_2)   
                currentoccupancy2=self.mappings['Currentoccupancy_Non_Multifamily'].apply(to_map=newoccrate*100)   
                # get WOE_m2mat(m2mat_2)  
                # Treating missing M2M as <=12 M2M is a special treatment for loss forecasting to ensure consistency between PD & LGD                 
                if newm2mat <= 12 or pd.isnull(newm2mat):
                    if self.scenario_severity_level == 'BASE':
                        m2mat2 = 0.25
                    else:
                        m2mat2 =-1.88
                elif newm2mat <= 108:
                    m2mat2 = 0.25
                else:
                    m2mat2 = 1.69                
            else:
                raise ValueError("Input`multifamily_status` is not recognized.")                                  

            occ_diff.append(occdiff)
            new_occ_rate.append(newoccrate)
            noi_diff.append(noidiff)
            new_netoperatinginc.append(newnetoperatinginc)  
                
            # format all regression variables
            regression_variables.append({
                                                              'm2mat':newm2mat,
                                                              'm2mat_2':m2mat2,
                                                              'ltv_2':ltv2,
                                                              'ltv':newltv,
                                                              'debtyield':newdy,
                                                              'dbtyld_2':dbtyld2,
                                                              'currentoccupancy_new':new_occ_rate[qtr]*100,
                                                              'currentoccupancy_2':currentoccupancy2,
                                                              'division_2':division_2,
                                                              'proptype_2':proptype_2,
                                                               UER_YOYDIFF_L0:macro_data.iloc[qtr+start_period][UER_YOYDIFF_L0]
                                                              }) 
                                                                                                                                                                                                            
        return(regression_variables)     
                                           
    def calculatePD(self,mapped_data,regression_variables,macro_data,start_period=0):           
        # use logistic regression to calculate PD  
        pd_result=pd.DataFrame()  
        logistic_mapping = lambda ts : round(1/(1+np.exp(-ts)),self._precision)
        if mapped_data.loc[MULTIFAMILY_STATUS]==MULTIFAMILY:
            intercept = self.multi_pd_regression_coefficients['intercept']
            coeff_pairs = self.multi_pd_regression_coefficients['coefficients_pairs']

        elif mapped_data.loc[MULTIFAMILY_STATUS]==NON_MULTIFAMILY:
            intercept = self.non_multi_pd_regression_coefficients['intercept']
            coeff_pairs = self.non_multi_pd_regression_coefficients['coefficients_pairs']
            
        else:
            raise ValueError("Input`multifamily_status` is not recognized.")
            
            
#        estimated_pd= (logistic_mapping(
#                (sum([regression_variables[item]*coeff_pairs[item] for item in coeff_pairs.keys()])+intercept)
#            ))

        # get quartely pd
        # map estimated pd to rating--> filter by SRR (SRR@[1,4]--Rerate)-->final raing-->map to mrs-->regression pd_mrs & pd_mapping            
        # map estimated pd to rating level (e.g if estimated_pd<0.0008 then rating=8.5)            
        for qtr in range(self.forecast_period_quarterly-start_period):
            estimated_pd=(logistic_mapping(
                (sum([regression_variables[qtr][item]*coeff_pairs[item] for item in coeff_pairs.keys()])+intercept)
            ))          
            rating=self.mappings['estimated_PD'].apply(to_map=estimated_pd)
            if (mapped_data.loc[SRR]<1.0) or (mapped_data.loc[SRR]>self.min_input_rating):
                # get final rating
                final_rating=rating
            else:
                # Ensure mapping to new SRR scale with 0.5 increments
                # get final rating
                final_rating=int(2*mapped_data.loc[SRR])*0.5
                                
            # get ALLL rating using final rating                
            if mapped_data.loc[MULTIFAMILY_STATUS]==MULTIFAMILY:
                alll_rate=self.mappings['ALLL_SRR_MF'].apply(to_map=final_rating)
            else:
                alll_rate=self.mappings['ALLL_SRR_OTHER'].apply(to_map=final_rating)
                
            # map rating to pd_mrs    
            pd_mrs=self.mappings['final_rating'].apply(to_map=final_rating)
            
            # add pd_mapping
            if self.bau == None:
                if mapped_data.loc[MULTIFAMILY_STATUS]==MULTIFAMILY:
                    if final_rating > self.min_input_rating:
                        pd_mapping=macro_data.iloc[qtr+start_period][PD_MAPPING_MF_PASS]
                    else:
                        pd_mapping=macro_data.iloc[qtr+start_period][PD_MAPPING_MF_NOTPASS]  
                else:
                    if final_rating > self.min_input_rating:
                        pd_mapping=macro_data.iloc[qtr+start_period][PD_MAPPING_NMF_PASS]
                    else:
                        pd_mapping=macro_data.iloc[qtr+start_period][PD_MAPPING_NMF_NOTPASS] 
            else:
                pd_mapping=0
            
            if pd_mrs == 1:
                pd_1y=1
            else:
                pd_1y=min(1,(1+np.exp(-(np.log(pd_mrs/(1-pd_mrs)) + pd_mapping)))**(-1))
            
            # convert yerarly pd into quarterly---pd_1q = 1-((1-pd_1y)^0.25)) 
#            pd_1q=utilities.PDPeriodConverter(
#					pd_1y,
#					utilities.PERIOD_FREQUENCY_MAP['yearly'],
#   					utilities.PERIOD_FREQUENCY_MAP['quarterly']
#				   ) 
            pd_1m=utilities.PDPeriodConverter(
					pd_1y,
					utilities.PERIOD_FREQUENCY_MAP['yearly'],
   					utilities.PERIOD_FREQUENCY_MAP[self._forecast_periods_frequency]
				   )  
            
            pd_result=pd_result.append({
                                          'pd_1m':pd_1m,
                                          'final_rating':final_rating,
                                          'alll_rate':alll_rate
                                          },ignore_index=True)   		
        return(pd_result)
        
    def calculateLGD(self,mapped_data,regression_variables,start_period=0):
        #lgd_regression_data = pd.DataFrame()
        # get regression intercept and coefficient pairs
        intercept = self.lgd_regression_coefficients['intercept']
        coeff_pairs = self.lgd_regression_coefficients['coefficients_pairs']
        lgd=[]
        
        for i in range(self.forecast_period_quarterly-start_period):          
            mat_flag = 1 if (regression_variables[i][M2MAT]<=12 or pd.isnull(regression_variables[i][M2MAT])) else 0
            if self.scenario_severity_level == 'BASE': mat_flag = 0
        
            # get ltv1~ltv5
            ltv = regression_variables[i]['ltv']
            ltv1 = 1 if pd.isnull(ltv) else 0
            ltv2 = 1 if ltv <= 0.5 and pd.notnull(ltv) else 0
            ltv3 = 1 if 0.5 < ltv <= 0.6 else 0   
            ltv4 = 1 if 0.6 < ltv <= 0.8 else 0    
            ltv5 = 1 if 0.8 < ltv <= 1.35 else 0   
        
            # get occ1~occ2
            currentoccupancy_new = regression_variables[i]['currentoccupancy_new']
            occ1 = 1 if (currentoccupancy_new <= 65 or pd.isnull(currentoccupancy_new)) else 0
            occ2 = 1 if 65 < currentoccupancy_new <= 85 else 0      
            
            dy1=dy2=dy3=dy4=dy5=0    
        
            # get dy1~dy5
            debtyield = regression_variables[i]['debtyield']
            if pd.isnull(debtyield):
                dy1 = 1
            elif debtyield <= 0.0825:
                dy2 = 1
            elif debtyield <= 0.1035:
                dy3 = 1
            elif debtyield <=0.1375 :
                dy4 = 1
            else:
                dy5 = 1
            
            MF = 1 if mapped_data.loc[MULTIFAMILY_STATUS] == MULTIFAMILY else 0 
            isRetail = 1 if mapped_data.loc['Property_Type'] == 'RT' else 0
            if self.bau == None:
                lgd_regression_data=({                                      
                                              'mat_flag': mat_flag,
                                              'ltv1':ltv1,
                                              'ltv2':ltv2,
                                              'ltv3':ltv3,
                                              'ltv4':ltv4,
                                              'ltv5':ltv5,     
                                              'occ1':occ1,
                                              'occ2':occ2,
                                              'dy1':dy1,
                                              'dy2':dy2,
                                              'dy3':dy3,
                                              'dy4':dy4,
                                              'MF':MF,
                                              'isRetail':isRetail,
                                              'UER_YoYDiff_L0':regression_variables[i][UER_YOYDIFF_L0]})
            else:
                lgd_regression_data=({                                      
                                              'mat_flag': mat_flag,
                                              'ltv1':ltv1,
                                              'ltv2':ltv2,
                                              'ltv3':ltv3,
                                              'ltv4':ltv4,
                                              'ltv5':ltv5,     
                                              'occ1':occ1,
                                              'occ2':occ2,
                                              'dy1':dy1,
                                              'dy2':dy2,
                                              'dy3':dy3,
                                              'dy4':dy4,
                                              'MF':MF,
                                              'isRetail':isRetail,
                                              'UER_YoYDiff_L0':0})
                                                  
            # run lgd regression
            lgd_rate=max(0,(sum([lgd_regression_data[item]*coeff_pairs[item] for item in coeff_pairs.keys()])+intercept))                                      
#            lgd.append({
#                'lgd': lgd_rate,
#                'pd_1q': pd_1q,
#                'pd_1m': pd_1m,
#                'rating': rating,
#                'final_rating': final_rating,
#                'pd_mapping': pd_mapping,
#                'estimated_pd': estimated_pd
#            })
            lgd.append(lgd_rate)
        return(lgd)
          
    def calculatePD_OLD(self,mapped_data,regression_variables,macro_data):           
        # use logistic regression to calculate PD  
        pd_result=pd.DataFrame()  
        logistic_mapping = lambda ts : round(1/(1+np.exp(-ts)),self._precision)
        if mapped_data.iloc[0][MULTIFAMILY_STATUS]==MULTIFAMILY:
            intercept = self.multi_pd_regression_coefficients['intercept']
            coeff_pairs = self.multi_pd_regression_coefficients['coefficients_pairs']

        elif mapped_data.iloc[0][MULTIFAMILY_STATUS]==NON_MULTIFAMILY:
            intercept = self.non_multi_pd_regression_coefficients['intercept']
            coeff_pairs = self.non_multi_pd_regression_coefficients['coefficients_pairs']
            
        else:
            raise ValueError("Input`multifamily_status` is not recognized.")
            
            
        estimated_pd= (logistic_mapping(
                (sum([regression_variables[item]*coeff_pairs[item] for item in coeff_pairs.keys()])+intercept)
            ))

        # get quartely pd
        # map estimated pd to rating--> filter by SRR (SRR@[1,4]--Rerate)-->final raing-->map to mrs-->regression pd_mrs & pd_mapping            
        # map estimated pd to rating level (e.g if estimated_pd<0.0008 then rating=8.5)            
        for qtr in range(self.forecast_period_quarterly):
            rating=self.mappings['estimated_PD'].apply(to_map=estimated_pd[qtr])
            if (mapped_data.iloc[0][SRR]<1.0) or (mapped_data.iloc[0][SRR]>self.min_input_rating):
                # get final rating
                final_rating=rating
            else:
                # Ensure mapping to new SRR scale with 0.5 increments
                # get final rating
                final_rating=int(2*mapped_data.iloc[0][SRR])*0.5
                
            # map rating to pd_mrs    
            pd_mrs=self.mappings['final_rating'].apply(to_map=final_rating)
            
            # add pd_mapping
            if self.bau == None:
                if mapped_data.iloc[0][MULTIFAMILY_STATUS]==MULTIFAMILY:
                    if final_rating > self.min_input_rating:
                        pd_mapping=macro_data.iloc[qtr][PD_MAPPING_MF_PASS]
                    else:
                        pd_mapping=macro_data.iloc[qtr][PD_MAPPING_MF_NOTPASS]  
                else:
                    if final_rating > self.min_input_rating:
                        pd_mapping=macro_data.iloc[qtr][PD_MAPPING_NMF_PASS]
                    else:
                        pd_mapping=macro_data.iloc[qtr][PD_MAPPING_NMF_NOTPASS] 
            else:
                pd_mapping=0
            
            if pd_mrs == 1:
                pd_1y=1
            else:
                pd_1y=min(1,(1+np.exp(-(np.log(pd_mrs/(1-pd_mrs)) + pd_mapping)))**(-1))
            
            # convert yerarly pd into quarterly---pd_1q = 1-((1-pd_1y)^0.25)) 
            pd_1q=utilities.PDPeriodConverter(
					pd_1y,
					utilities.PERIOD_FREQUENCY_MAP['yearly'],
   					utilities.PERIOD_FREQUENCY_MAP['quarterly']
				   ) 
            pd_1m=utilities.PDPeriodConverter(
					pd_1y,
					utilities.PERIOD_FREQUENCY_MAP['yearly'],
   					utilities.PERIOD_FREQUENCY_MAP[self._forecast_periods_frequency]
				   )       

            pd_result=pd_result.append({
                                          'pd_1y':pd_1y,
                                          'pd_1q':pd_1q,
                                          'pd_1m':pd_1m,
                                          'rating':rating,
                                          'final_rating':final_rating,
                                          'pd_mapping':pd_mapping,
                                          'estimated_pd':estimated_pd[qtr] 
                                          },ignore_index=True)                                                                                      				
        return(pd_result)

    def calculateLGD_OLD(self,mapped_data,regression_variables):
        lgd_regression_data = pd.DataFrame()
        # get regression intercept and coefficient pairs
        intercept = self.lgd_regression_coefficients['intercept']
        coeff_pairs = self.lgd_regression_coefficients['coefficients_pairs']
        lgd=[]
        
        for i in range(self.forecast_period_quarterly):          
            mat_flag = 1 if (regression_variables.iloc[i][M2MAT]<=12 or pd.isnull(regression_variables.iloc[i][M2MAT])) else 0
            if self.scenario_severity_level == 'BASE': mat_flag = 0
        
            # get ltv1~ltv5
            ltv = regression_variables.iloc[i]['ltv']
            ltv1 = 1 if pd.isnull(ltv) else 0
            ltv2 = 1 if ltv <= 0.5 and pd.notnull(ltv) else 0
            ltv3 = 1 if 0.5 < ltv <= 0.6 else 0   
            ltv4 = 1 if 0.6 < ltv <= 0.8 else 0    
            ltv5 = 1 if 0.8 < ltv <= 1.35 else 0   
        
            # get occ1~occ2
            currentoccupancy_new = regression_variables.iloc[i]['currentoccupancy_new']
            occ1 = 1 if (currentoccupancy_new <= 65 or pd.isnull(currentoccupancy_new)) else 0
            occ2 = 1 if 65 < currentoccupancy_new <= 85 else 0      
            
            dy1=dy2=dy3=dy4=dy5=0    
        
            # get dy1~dy5
            debtyield = regression_variables.iloc[i]['debtyield']
            if pd.isnull(debtyield):
                dy1 = 1
            elif debtyield <= 0.0825:
                dy2 = 1
            elif debtyield <= 0.1035:
                dy3 = 1
            elif debtyield <=0.1375 :
                dy4 = 1
            else:
                dy5 = 1
            
            MF = 1 if mapped_data.iloc[0][MULTIFAMILY_STATUS] == MULTIFAMILY else 0 
            isRetail = 1 if mapped_data.iloc[0]['Property_Type'] == 'RT' else 0
            if self.bau == None:
                lgd_regression_data=lgd_regression_data.append({                                      
                                              'mat_flag': mat_flag,
                                              'ltv1':ltv1,
                                              'ltv2':ltv2,
                                              'ltv3':ltv3,
                                              'ltv4':ltv4,
                                              'ltv5':ltv5,     
                                              'occ1':occ1,
                                              'occ2':occ2,
                                              'dy1':dy1,
                                              'dy2':dy2,
                                              'dy3':dy3,
                                              'dy4':dy4,
                                              'MF':MF,
                                              'isRetail':isRetail,
                                              'UER_YoYDiff_L0':regression_variables.iloc[i][UER_YOYDIFF_L0]},ignore_index=True)
            else:
                lgd_regression_data=lgd_regression_data.append({                                      
                                              'mat_flag': mat_flag,
                                              'ltv1':ltv1,
                                              'ltv2':ltv2,
                                              'ltv3':ltv3,
                                              'ltv4':ltv4,
                                              'ltv5':ltv5,     
                                              'occ1':occ1,
                                              'occ2':occ2,
                                              'dy1':dy1,
                                              'dy2':dy2,
                                              'dy3':dy3,
                                              'dy4':dy4,
                                              'MF':MF,
                                              'isRetail':isRetail,
                                              'UER_YoYDiff_L0':0},ignore_index=True)
        
                                          
            # run lgd regression
            lgd.append(max(0,(sum([lgd_regression_data[item][i]*coeff_pairs[item] for item in coeff_pairs.keys()])+intercept)))
            lgd_regression_data['LGD']=lgd
        return(lgd_regression_data)  
        
    def calculateEAD(self,mapped_data,regression_variables):
        New_EAD=[]
#        for qtr in range(self.forecast_period_quarterly):
#            if pd.isnull(mapped_data.iloc[0][BOOKBALANCEAMOUNT]) or (mapped_data.iloc[0][BOOKBALANCEAMOUNT]==0):
#                New_EAD.append(0)
#            elif qtr==0:         
#                New_EAD.append(mapped_data.iloc[0][BOOKBALANCEAMOUNT])
#            else:
#                New_EAD.append(New_EAD[qtr-1]*(1-pd_result[qtr-1]))                
        for qtr in range(self.forecast_period_quarterly):
            # set EAD=0 if the contracts' maxmaturitydate is before as of date
            # set EAD=0 for contracts that expired during the forecast
            if regression_variables.iloc[qtr]['m2mat']<0:
                New_EAD.append(0)                 
            else:
                New_EAD.append(1)                
        return(New_EAD)
        
    # Ad hoc for 9Q LTV transition    
    def get_regression_variables(self,data,macro_data):
        regression_variables=pd.DataFrame()
        for index,row in data.iterrows():
            mapped_data=self.getMapping(row)
            result=pd.DataFrame(self.process_model_inputs(mapped_data,macro_data,start_period=0))
            result['UNIQUE_FACILITY_ID']=row.loc['UNIQUE_FACILITY_ID']
            regression_variables=regression_variables.append(result)
        return(regression_variables)
    # Ad hoc for 9Q LTV transition  
    def get_ltv(self,regression_variables,data):  
        cre=pd.merge(regression_variables,data,how='left',on='UNIQUE_FACILITY_ID')
        cre['Quarter']=([i for i in range(self.forecast_period_quarterly)]
                          *
                        int(len(cre)/self.forecast_period_quarterly)  
                        )
        balance_weighted_ltv=dict((i,0) for i in range(self.forecast_period_quarterly))
        for quarter in range(self.forecast_period_quarterly):
          balance_weighted_ltv[quarter]=(cre[cre['Quarter']==quarter]['ltv']
                                          *
                                         cre[cre['Quarter']==quarter]['BOOKBALANCE']
                                        ).sum()/cre[cre['Quarter']==quarter]['BOOKBALANCE'].sum()
        return(pd.DataFrame.from_dict(balance_weighted_ltv, orient='index')) 
               
    def calculateAlllContingent(self,pd_result,alll_contingent,alll_contingent_map):
        # final rating from pd model
        pd_result['final_rating']
        alll_contingent=[]    
        pd_result
        for qtr in range(self.forecast_period_quarterly):  
            alll_contingent=alll_contingent.append({
                                            'ALLLCOVERAGE':1,
                                            'CONTINGENTRESERVE':1
                                          },ignore_index=True)
        return(alll_contingent)

           
    def estimateLossAmount(self,pd_result,ead,lgd):
        loss_amount=pd.DataFrame()
        for qtr in range(self.forecast_period_quarterly):  
            wPD=(pd_result[qtr]*ead[qtr])
            loss=(pd_result[qtr]*ead[qtr]*lgd[qtr])
            loss_amount=loss_amount.append({
                                            'wPD':wPD,
                                            'loss':loss
                                          },ignore_index=True)
        return(loss_amount)
        
    def execute(self, session: CCARSession = None):
        """

        Returns
        -------

        """
        self._logger.add(
            type='INFO',
            message='Executing model...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        
        # get macro data 
        macro_data=self.getMacro()
        #linked to RFO
        data=self.processDataset()
        #mapped_data=self.getMapping(data)
        # Starting timer
        t0 = time.time()
#        print(data[UNIQUE_FACILITY_ID])
        result=self.RateContracts(data,macro_data)
        self._logger.add(
            type='INFO',
            message='Get result in ' + str(time.time()-t0) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )  
        for rate in result['RateName'].unique():
          rate_mean= result[
                            (result['RateName']==rate)
                            &
                            (result['RateName']!='FINAL_RATING')
                            &
                            (result['Vintage']==self.as_of_date)]['ModelOutputRate'].describe()
                            
          if ((rate_mean['min']<0) or (rate_mean['max']>1)):
              raise ValueError (str(rate)+' result is not within 0 to 1')          
              
          self._logger.add(
                              type='INFO',
                              message=str(rate)+'_current vintage mean: '+str(round(rate_mean['mean']*100,5))+'%',
                              context='CCAR Model : ' + self._model_name,
                              model_id=self._model_id
                )          
#        if session is not None:
#            count = 0
#            print(len(result['ModelSegment'].unique()))
#            for segment in result['ModelSegment'].unique():
#                data=result[result['ModelSegment']==segment]
#                count = count + 1
#                print(">>>Start addCFChuck" + str(segment) + "count" + str(count))
#                for rate in ['PD','LGD','EAD','ALLLCOVERAGE','CONTINGENTRESERVE']:
#                    data=data[data['RateName']==rate]
#                    session.contributor_file_generator.addCFChunk(
#                        as_of_date=self._as_of_date,
#                        forecast_periods=self._forecast_periods,
#                        forecast_periods_frequency=self._forecast_periods_frequency,
#                        scenario=self._scenario,
#                        model_segment=[segment],
#                        rate_name=[rate],
#                        rate_type=[4],
#                        vintage_differentiation=True if data[EXISTING_NEW].unique()== 'Y' else False,
#                        model_output_rate=list(data['ModelOutputRate'].values),
#                        uncertainty_adjustment_rate=0.0,
#                        mgmt_adjustment_rate=0.0
#                    )

        if session is not None:
            session.contributor_file_generator.appendCF(
                period_date=result['PeriodDate'].tolist(),    
                scenario=self._scenario,
                model_segment=('SB'+result['ModelSegment']).tolist(),
                rate_name=result['RateName'].tolist(),
                rate_type=4,
                vintage=result['Vintage'].tolist(),
                model_output_rate=result['ModelOutputRate'].tolist(),
                uncertainty_adjustment_rate=0.0,
                mgmt_adjustment_rate=0.0
            )                                
        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Dump log data into session instance
        if session is not None:
            if isinstance(session, CCARSession):
                for log_item in self._logger.items:
                    session.logger.addItem(log_item)
    
#    def compareresult(target_data,result):
#        compare=pd.DataFrame()
#        data_difference_list=[]
#        data_diff=data[data['FacilityNumber'].isin(data_difference_list)]
#                
#        result=pd.DataFrame()
#        mapped_data= rr.getMapping(data)
#        regression_variables=self.process_model_inputs(mapped_data,macro_data)
#        for i in range(len(data_half)):
#            if rr.debug:
#                print('get contract'+str(i))                
#            result=result.append(self.RateOneContract(data[i:i+1],macro_data))
