# -*- coding: utf-8 -*-
"""
Created on Fri Jun 30 10:51:37 2017

@author: n882049
"""
from tinydb import TinyDB, Query
from CIFI.models.modelproperties.modelproperties import ModelProperties
import datetime
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
################## Copy all model properties from last run  ###########
mp = ModelProperties(
	model_id = '743 - Commercial Rating Model - C&I PD - SBNA',
	version_date=datetime.datetime(2017,9,30)
)

all = mp.getAll()
all_with_date = mp.getAllPropertiesWithVersionDate(version_date = datetime.datetime(2018,9,30))

mp.dupAllPropertiesWithDiffVersionDate(new_version_date=datetime.datetime(2018,12,31), old_version_date=datetime.datetime(2018,9,30), only_current_model_id = False)

all_new = mp.getAll()


#################### Update ALLL/CONTINGENCY Covergae Rate ####################
path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties)

path_test = 'I:/CRMPO/DEPT/Steven/test/model_properties.json'
db = TinyDB(path_test)

all_model_property = db.all()

### db search
alll_all_old = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & (Query().name == "alll_coverage")  
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2017, 12, 31))))
alll_all_new = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & (Query().name == "alll_coverage")  
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2018, 3, 31))))

contingent_all_old = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & (Query().name == "contingent_reserve")  
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2017, 12, 31))))
contingent_all_new = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & (Query().name == "contingent_reserve")  
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2018, 3, 31))))

#### Update coverage rates for Feb P21 run ####
## Mar2018 Properties: For Feb P21 run ##
db.update({
'value': [
        {
    0:   0.0,
    1:   0.47560728,
    1.5: 0.069586179495668,
    2: 0.0567993319888651,
    2.5: 0.0440124844820621,
    3: 0.030098149663565,
    3.5: 0.0184387894684562,
    4: 0.0157350986887387,
    4.5: 0.0130314079090212,
    5: 0.00835941904720594,
    5.5: 0.00731985840825317,
    6: 0.00674625439985736,
    6.5: 0.00617265039146155,
    7: 0.00617265039146155,
    7.5: 0.00617265039146155,
    8: 0.00617265039146155,
    8.5: 0.00617265039146155
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '03/31/2018')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.475607278250238,
    1.5: 0.0753194300349269,
    2: 0.0557605400980021,
    2.5: 0.0459810951295397,
    3: 0.0362016501610773,
    3.5: 0.0293590665718941,
    4: 0.022516482982711,
    4.5: 0.013168925139067,
    5: 0.0101860126936113,
    5.5: 0.00815099342410627,
    6: 0.00704722031930942,
    6.5: 0.00638757462245555,
    7: 0.00597230249850343,
    7.5: 0.00544985327365389,
    8: 0.0054074190265509,
    8.5: 0.00536498477944792
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '03/31/2018')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'MIDDLE_MARKET')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.299976879371061,
    1.5: 0.0981112475012843,
    2: 0.0787170307672681,
    2.5: 0.0593228140332519,
    3: 0.0277126915679329,
    3.5: 0.0205343805652195,
    4: 0.0157704098525272,
    4.5: 0.00584026917783752,
    5: 0.00427251816063624,
    5.5: 0.00317842702601299,
    6: 0.00193874259794666,
    6.5: 0.00112337783631087,
    7: 0.00061313658029213,
    7.5: 0.000440970970754525,
    8: 0.000440970970754525,
    8.5: 0.000440970970754525
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '03/31/2018')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'BUSINESS_BANKING')))

# contingent_reserve #
db.update({
'value': [
        {
    0:   0.0,
    1: 0.0125349116536474,
    1.5: 0.0492868173,
    2: 0.0306710794,
    2.5: 0.02136321045,
    3: 0.016709275975,
    3.5: 0.0120553415,
    4: 0.0112259694,
    4.5: 0.0051272741,
    5: 0.0030200972,
    5.5: 0.0024178504,
    6: 0.0008683598,
    6.5: 0.0007099615,
    7: 0.0007099615,
    7.5: 0.0007099615,
    8: 0.0007099615,
    8.5: 0.0007099615
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '03/31/2018')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.0913903513166978,
    1.5: 0.0573455616,
    2: 0.0403544963,
    2.5: 0.03185896365,
    3: 0.023363431,
    3.5: 0.0172258633,
    4: 0.0130513074,
    4.5: 0.0064895995,
    5: 0.0039599357,
    5.5: 0.0025283287,
    6: 0.001536671,
    6.5: 0.0010006447,
    7: 0.0005993078,
    7.5: 0.0003638614,
    8: 0.0003638614,
    8.5: 0.0003638614
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '03/31/2018')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'MIDDLE_MARKET')))

db.update({
'value': [
        {
    0:   0.0,
    1: 0.0779870696603458,
    1.5: 0.0622639601,
    2: 0.0447449836,
    2.5: 0.03598549535,
    3: 0.0272260071,
    3.5: 0.0152703705,
    4: 0.0123308854,
    4.5: 0.0056785311,
    5: 0.0041706128,
    5.5: 0.0030702952,
    6: 0.0018728755,
    6.5: 0.0011564518,
    7: 0.0007113633,
    7.5: 0.0007113633,
    8: 0.0007113633,
    8.5: 0.0007113633
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '03/31/2018')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'BUSINESS_BANKING')))

#### Update coverage rates for Dec ####
## Dec2017 Properties: For Dec CCAR2018 Run ##
db.update({
'value': [
        {
    0:   0.0,
    1: 0.47560728,
    1.5: 0.0660245063170065,
    2: 0.0531812037109993,
    2.5: 0.0403379011049921,
    3: 0.0264053881018183,
    3.5: 0.0146512958929778,
    4: 0.0146702537450688,
    4.5: 0.00952689530761272,
    5: 0.00504308107243152,
    5.5: 0.00379661719827583,
    6: 0.0025147482592694,
    6.5: 0.00123287932026296,
    7: 0.00123287932026296,
    7.5: 0.00123287932026296,
    8: 0.00123287932026296,
    8.5: 0.00123287932026296
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.475607278250238,
    1.5: 0.0752544002418102,
    2: 0.063568964571753,
    2.5: 0.0518835289016959,
    3: 0.0360218926397758,
    3.5: 0.0285126575615816,
    4: 0.0210034224833873,
    4.5: 0.013010178298206,
    5: 0.00989306911264843,
    5.5: 0.00805661574691259,
    6: 0.00695933963937183,
    6.5: 0.00630335051673372,
    7: 0.00626293614487193,
    7.5: 0.00624272895894103,
    8: 0.00622252177301013,
    8.5: 0.00622252177301013
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'MIDDLE_MARKET')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.299976879371061,
    1.5: 0.0646681897458933,
    2: 0.052970942221184,
    2.5: 0.0412736946964748,
    3: 0.0225650537323964,
    3.5: 0.0178791996470564,
    4: 0.0137280752975559,
    4.5: 0.00615414278971677,
    5: 0.00483470197419992,
    5.5: 0.00398477420877684,
    6: 0.00296342048805531,
    6.5: 0.002198808123748,
    7: 0.00154650133711819,
    7.5: 0.00148881316384045,
    8: 0.00148881316384045,
    8.5: 0.00148881316384045
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'BUSINESS_BANKING')))

# contingent_reserve #
db.update({
'value': [
        {
    0:   0.0,
    1: 0.0125349116536474,
    1.5: 0.0125349116536474,
    2: 0.0125349116536474,
    2.5: 0.0125349116536474,
    3: 0.0125349116536474,
    3.5: 0.0125349116536474,
    4: 0.012383160742924,
    4.5: 0.00520350151539166,
    5: 0.00318527545289767,
    5.5: 0.00266895880454292,
    6: 0.000958406046408346,
    6.5: 0.000778524354466235,
    7: 0.000778524354466235,
    7.5: 0.000778524354466235,
    8: 0.000778524354466235,
    8.5: 0.000778524354466235
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.0913903513166978,
    1.5: 0.0913903513166978,
    2: 0.0613267379060445,
    2.5: 0.0462949312007178,
    3: 0.0312631244953912,
    3.5: 0.0175617351536748,
    4: 0.0175617351527373,
    4.5: 0.00774499464386152,
    5: 0.00513372334387576,
    5.5: 0.00423497583788355,
    6: 0.00203689224590937,
    6.5: 0.00195907445080428,
    7: 0.00152584887387283,
    7.5: 0.0013092360854071,
    8: 0.00109262329694138,
    8.5: 0.00109262329694138
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'MIDDLE_MARKET')))

db.update({
'value': [
        {
    0:   0.0,
    1: 0.0779870696603458,
    1.5: 0.0779870696603458,
    2: 0.0614959276704085,
    2.5: 0.0532503566754398,
    3: 0.0450047856804712,
    3.5: 0.0120225017005965,
    4: 0.00924571054990129,
    4.5: 0.00646891939920605,
    5: 0.00569391934716631,
    5.5: 0.00482695105774735,
    6: 0.00482695105774735,
    6.5: 0.00482695105774735,
    7: 0.00482695105774735,
    7.5: 0.00482695105774735,
    8: 0.00482695105774735,
    8.5: 0.00482695105774735
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'BUSINESS_BANKING')))


## Dec2017 Properties: For Nov Dry run ##
db.update({
'value': [
        {
    0:   0.0,
    1: 0.47560728,
    1.5: 0.284054674,
    2: 0.173544188,
    2.5: 0.118288945,
    3: 0.090661324,
    3.5: 0.063033702,
    4: 0.051961566,
    4.5: 0.040889429,
    5: 0.028540895,
    5.5: 0.016192361,
    6: 0.010819104,
    6.5: 0.00126574,
    7: 0.00126574,
    7.5: 0.00126574,
    8: 0.00126574,
    8.5: 0.00126574
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.47560728,
    1.5: 0.14127549,
    2: 0.11318684,
    2.5: 0.08509819,
    3: 0.03574873,
    3.5: 0.02892088,
    4: 0.02209304,
    4.5: 0.01291545,
    5: 0.00992787,
    5.5: 0.0080398,
    6: 0.0069177,
    6.5: 0.00628566,
    7: 0.0062305,
    7.5: 0.00620292,
    8: 0.00617533,
    8.5: 0.00617533
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'MIDDLE_MARKET')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.29997688,
    1.5: 0.07095328,
    2: 0.0576423,
    2.5: 0.04433132,
    3: 0.02322225,
    3.5: 0.01770937,
    4: 0.01326941,
    4.5: 0.00610982,
    5: 0.00484128,
    5.5: 0.00389272,
    6: 0.00294415,
    6.5: 0.00214424,
    7: 0.00151714,
    7.5: 0.00147467,
    8: 0.00147467,
    8.5: 0.00147467
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'BUSINESS_BANKING')))

# contingent_reserve #
db.update({
'value': [
        {
    0:   0.0,
    1: 0.01253491,
    1.5: 0.01253491,
    2: 0.01253491,
    2.5: 0.01253491,
    3: 0.01253491,
    3.5: 0.01253491,
    4: 0.01238316,
    4.5: 0.0052035,
    5: 0.00318528,
    5.5: 0.00266896,
    6: 0.00095841,
    6.5: 0.00077852,
    7: 0.00077852,
    7.5: 0.00077852,
    8: 0.00077852,
    8.5: 0.00077852
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1: 0.09139035,
    1.5: 0.09139035,
    2: 0.06132674,
    2.5: 0.04629493,
    3: 0.03126312,
    3.5: 0.01756174,
    4: 0.01756174,
    4.5: 0.00774499,
    5: 0.00513372,
    5.5: 0.00423498,
    6: 0.00203689,
    6.5: 0.00195907,
    7: 0.00152585,
    7.5: 0.00130924,
    8: 0.00109262,
    8.5: 0.00109262
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'MIDDLE_MARKET')))

db.update({
'value': [
        {
    0:   0.0,
    1: 0.07798707,
    1.5: 0.07798707,
    2: 0.06149593,
    2.5: 0.05325036,
    3: 0.04500479,
    3.5: 0.0120225,
    4: 0.00924571,
    4.5: 0.00646892,
    5: 0.00569392,
    5.5: 0.00482695,
    6: 0.00482695,
    6.5: 0.00482695,
    7: 0.00482695,
    7.5: 0.00482695,
    8: 0.00482695,
    8.5: 0.00482695
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '12/31/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'BUSINESS_BANKING')))

## Sep Properties ##
db.update({
'value': [
        {
    0:   0.0,
    1:   0.47560727825023800,
    1.5: 0.06951760012233880,
    2:   0.04856980626970090,
    2.5: 0.03809590934338190,
    3:   0.02762201241706300,
    3.5: 0.01552345535855610,
    4:   0.01552345535855610,
    4.5: 0.00906674895304037,
    5:   0.00484391393972150,
    5.5: 0.00398767637424400,
    6:   0.00253660102225570,
    6.5: 0.00253660102225570,
    7:   0.00253660102225570,
    7.5: 0.00253660102225570,
    8:   0.00253660102225570,
    8.5: 0.00253660102225570
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '09/30/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1:   0.47560727825023800,
    1.5: 0.07633151928297110,
    2:   0.05502109938547920,
    2.5: 0.04436588943673320,
    3:   0.03371067948798730,
    3.5: 0.02126908451586780,
    4:   0.01995046152067610,
    4.5: 0.01218450870004510,
    5:   0.00883332963733127,
    5.5: 0.00738440469514218,
    6:   0.00613466474580504,
    6.5: 0.00566775766593787,
    7:   0.00528276768828701,
    7.5: 0.00526384678385931,
    8:   0.00526384678385931,
    8.5: 0.00526384678385931
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '09/30/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'MIDDLE_MARKET')))
db.update({
'value': [
        {
    0:   0.0,
    1:   0.29997687937106100,
    1.5: 0.07392042233489210,
    2:   0.04678647838936250,
    2.5: 0.03321950641659770,
    3:   0.01965253444383290,
    3.5: 0.01344597446737720,
    4:   0.00971543660415319,
    4.5: 0.00598489874092921,
    5:   0.00473022741740831,
    5.5: 0.00403777887247867,
    6:   0.00283164577740895,
    6.5: 0.00216406594643973,
    7:   0.00157424645007931,
    7.5: 0.00157424645007931,
    8:   0.00157424645007931,
    8.5: 0.00157424645007931
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '09/30/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'BUSINESS_BANKING')))

# contingent_reserve #
db.update({
'value': [
        {
    0:   0.0,
    1:   0.052804395016525100,
    1.5: 0.052804395016525100,
    2:   0.032223493267721100,
    2.5: 0.021933042393319100,
    3:   0.016787816956118100,
    3.5: 0.011642591518917100,
    4:   0.011642591516997900,
    4.5: 0.005341943110877740,
    5:   0.003133611225209270,
    5.5: 0.002519208315808820,
    6:   0.000958931268185523,
    6.5: 0.000746148817022074,
    7:   0.000746148817022074,
    7.5: 0.000746148817022074,
    8:   0.000746148817022074,
    8.5: 0.000746148817022074
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '09/30/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1:   0.09139035131669780,
    1.5: 0.05964162152073760,
    2:   0.04224521124054910,
    2.5: 0.03354700610045490,
    3:   0.02484880096036070,
    3.5: 0.01610774474287550,
    4:   0.01526752622173440,
    4.5: 0.00794247547814155,
    5:   0.00543992111763947,
    5.5: 0.00420200495947962,
    6:   0.00314167801766733,
    6.5: 0.00264660411486566,
    7:   0.00238303270046783,
    7.5: 0.00209430732751049,
    8:   0.00209430732751049,
    8.5: 0.00209430732751049
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '09/30/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'MIDDLE_MARKET')))

db.update({
'value': [
        {
    0:   0.0,
    1:   0.07798706966034580,
    1.5: 0.07172251285802890,
    2:   0.04953646346284250,
    2.5: 0.03844343876524930,
    3:   0.02735041406765610,
    3.5: 0.01537081822110930,
    4:   0.01320553828283490,
    4.5: 0.00591857418331576,
    5:   0.00514679422087760,
    5.5: 0.00470412003399761,
    6:   0.00457839911846293,
    6.5: 0.00378697254476035,
    7:   0.00314983487963262,
    7.5: 0.00314983487963262,
    8:   0.00314983487963262,
    8.5: 0.00314983487963262
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '09/30/2017')
            &(Query().name == 'contingent_reserve')
            &(Query().segment == 'BUSINESS_BANKING')))



#### Update coverage rates for June  ####
## June Properties ##
db.update({
'value': [
        {
    0:   0.0,
    1:   0.47560727825023800,
    1.5: 0.09581420869018500,
    2:   0.07524126573345830,
    2.5: 0.06495479425509490,
    3:   0.02901964170723930,
    3.5: 0.01651088099056530,
    4:   0.01651088099056530,
    4.5: 0.00666152968448696,
    5:   0.00412655124385288,
    5.5: 0.00346835905906722,
    6:   0.00131200770378878,
    6.5: 0.00102724321181979,
    7:   0.00102724321181979,
    7.5: 0.00102724321181979,
    8:   0.00102724321181979,
    8.5: 0.00102724321181979
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '06/30/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'ABL')))
db.update({
'value': [
        {
    0:   0.0,
    1:   0.47560727825023800,
    1.5: 0.06578267333533660,
    2:   0.05517689959558430,
    2.5: 0.04987401272570810,
    3:   0.04457112585583190,
    3.5: 0.02634348263429600,
    4:   0.02602907025815220,
    4.5: 0.01337033525062970,
    5:   0.00971472305522655,
    5.5: 0.00855615717414322,
    6:   0.00598179351297975,
    6.5: 0.00582162666938686,
    7:   0.00549445781562111,
    7.5: 0.00518345373582334,
    8:   0.00487244965602558,
    8.5: 0.00487244965602558
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '06/30/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'MIDDLE_MARKET')))

db.update({
'value': [
        {
    0:   0.0,
    1:   0.29997687937106100,
    1.5: 0.09581420869018500,
    2:   0.07524126573345830,
    2.5: 0.06495479425509490,
    3:   0.05466832277673150,
    3.5: 0.02173138231884960,
    4:   0.01630060628203390,
    4.5: 0.00784977435356298,
    5:   0.00634182651982286,
    5.5: 0.00571404815674714,
    6:   0.00511486112994903,
    6.5: 0.00416927161014821,
    7:   0.00416927161014821,
    7.5: 0.00391379829016784,
    8:   0.00391379829016784,
    8.5: 0.00391379829016784
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '06/30/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'BUSINESS_BANKING')))

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'alll_coverage',
  'segment': 'ABL',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   0.475607,
    1.5: 0.093709,
    2:   0.06291,
    2.5: 0.049874,
    3:   0.02902,
    3.5: 0.016511,
    4:   0.016511,
    4.5: 0.006662,
    5:   0.004127,
    5.5: 0.003468,
    6:   0.001312,
    6.5: 0.001027,
    7:   0.001027,
    7.5: 0.001027,
    8:   0.001027,
    8.5: 0.001027
    }],
  'version_date': '06/30/2017'})


db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'alll_coverage',
  'segment': 'MIDDLE_MARKET',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   0.4756073,
    1.5: 0.0657827,
    2:   0.0551769,
    2.5: 0.049874,
    3:   0.0445711,
    3.5: 0.0263435,
    4:   0.0260291,
    4.5: 0.0133703,
    5:   0.0097147,
    5.5: 0.0085562,
    6:   0.0059818,
    6.5: 0.0058216,
    7:   0.0054945,
    7.5: 0.0051835,
    8:   0.0048724,
    8.5: 0.0048724
    }],
  'version_date': '06/30/2017'})

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'alll_coverage',
  'segment': 'BUSINESS_BANKING',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   0.242598,
    1.5: 0.093709,
    2:   0.06291,
    2.5: 0.04751,
    3:   0.03211,
    3.5: 0.0201,
    4:   0.015833,
    4.5: 0.007825,
    5:   0.006324,
    5.5: 0.005658,
    6:   0.004993,
    6.5: 0.003913,
    7:   0.003675,
    7.5: 0.001568,
    8:   0.001568,
    8.5: 0.001568
    }],
  'version_date': '06/30/2017'})

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'contingent_reserve',
  'segment': 'ABL',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   0.012534911653647400,
    1.5: 0.012534911653647400,
    2:   0.012534911653647400,
    2.5: 0.012534911653647400,
    3:   0.012534911653647400,
    3.5: 0.012534911653647400,
    4:   0.012383160742924000,
    4.5: 0.005203501515391660,
    5:   0.003185275452897670,
    5.5: 0.002668958804542920,
    6:   0.000958406046408346,
    6.5: 0.000778524354466235,
    7:   0.000778524354466235,
    7.5: 0.000778524354466235,
    8:   0.000778524354466235,
    8.5: 0.000778524354466235
    }],
  'version_date': '06/30/2017'})

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'contingent_reserve',
  'segment': 'MIDDLE_MARKET',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   0.09139035131669780,
    1.5: 0.09139035131669780,
    2:   0.06132673790604450,
    2.5: 0.04629493120071780,
    3:   0.03126312449539120,
    3.5: 0.01756173515367480,
    4:   0.01756173515273730,
    4.5: 0.00774499464386152,
    5:   0.00513372334387576,
    5.5: 0.00423497583788355,
    6:   0.00203689224590937,
    6.5: 0.00195907445080428,
    7:   0.00152584887387283,
    7.5: 0.00130923608540710,
    8:   0.00109262329694138,
    8.5: 0.00109262329694138
    }],
  'version_date': '06/30/2017'})

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'contingent_reserve',
  'segment': 'BUSINESS_BANKING',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   0.07798706966034580,
    1.5: 0.07798706966034580,
    2:   0.06149592767040850,
    2.5: 0.05325035667543980,
    3:   0.04500478568047120,
    3.5: 0.01202250170059650,
    4:   0.00924571054990129,
    4.5: 0.00646891939920605,
    5:   0.00569391934716631,
    5.5: 0.00482695105774735,
    6:   0.00482695105774735,
    6.5: 0.00482695105774735,
    7:   0.00482695105774735,
    7.5: 0.00482695105774735,
    8:   0.00482695105774735,
    8.5: 0.00482695105774735
    }],
  'version_date': '06/30/2017'})

## March and Dec properties ##
db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'alll_coverage',
  'segment': 'all',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   1.0,
    1.5: 0.08000787461908640,
    2:   0.04213040171593060,
    2.5: 0.04213040171593060,
    3:   0.04213040171593060,
    3.5: 0.02240132949709560,
    4:   0.02240132949709560,
    4.5: 0.01067245322391010,
    5:   0.00632362559562368,
    5.5: 0.00539579582736586,
    6:   0.00374188691780179,
    6.5: 0.00296509442918514,
    7:   0.00296509442918514,
    7.5: 0.00296509442918514,
    8:   0.00296509442918514,
    8.5: 0.0
    }],
  'version_date': '03/31/2017'})

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'contingent_reserve',
  'segment': 'all',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   1.0,
    1.5: 0.08301502318147710,
    2:   0.03362732862529540,
    2.5: 0.03362732862529540,
    3:   0.03362732862529540,
    3.5: 0.01720233474802670,
    4:   0.01720233474802670,
    4.5: 0.00805734394429038,
    5:   0.00476987208177036,
    5.5: 0.00427644862967514,
    6:   0.00326388004229534,
    6.5: 0.00247785819928539,
    7:   0.00247785819928539,
    7.5: 0.00247785819928539,
    8:   0.00247785819928539,
    8.5: 0.00247785819928539
    }],
  'version_date': '03/31/2017'})

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'alll_coverage',
  'segment': 'all',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   1.0,
    1.5: 0.10954131570809000,
    2:   0.04322477811323930,
    2.5: 0.04322477811323930,
    3:   0.04322477811323930,
    3.5: 0.02823524319542700,
    4:   0.02546107551547280,
    4.5: 0.01040888813916340,
    5:   0.00534494642713878,
    5.5: 0.00433069239371464,
    6:   0.00328001749826394,
    6.5: 0.00124467444165074,
    7:   0.00124467444165074,
    7.5: 0.00124467444165074,
    8:   0.00124467444165074,
    8.5: 0.00124467444165074
    }],
  'version_date': '12/31/2016'})

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'contingent_reserve',
  'segment': 'all',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   1.0,
    1.5: 0.090811005337961300,
    2:   0.033198246358040600,
    2.5: 0.033198246358040600,
    3:   0.033198246358040600,
    3.5: 0.013276330523239500,
    4:   0.013276330523239500,
    4.5: 0.007532788729151410,
    5:   0.004013340378488210,
    5.5: 0.003461134734479940,
    6:   0.002157413885741090,
    6.5: 0.001017557668752610,
    7:   0.001017557668752610,
    7.5: 0.000920626504788438,
    8:   0.000920626504788438,
    8.5: 0.000920626504788438
    }],
  'version_date': '12/31/2016'})


#### update coverage rates  ####
db.update({
'value': [
        {
    0:   0.0,
    1:   1.0,
    1.5: 0.08000787461908640,
    2:   0.04213040171593060,
    2.5: 0.04213040171593060,
    3:   0.04213040171593060,
    3.5: 0.02240132949709560,
    4:   0.02240132949709560,
    4.5: 0.01067245322391010,
    5:   0.00632362559562368,
    5.5: 0.00539579582736586,
    6:   0.00374188691780179,
    6.5: 0.00296509442918514,
    7:   0.00296509442918514,
    7.5: 0.00296509442918514,
    8:   0.00296509442918514,
    8.5: 0.0
        }
        ]},((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') 
            &(Query().version_date == '03/31/2017')
            &(Query().name == 'alll_coverage')
            &(Query().segment == 'all')))

### test db search
alll = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & (Query().name == "alll_coverage")  
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2017, 3, 31))))
# get/remove record by Element IDs
test = db.get(eid = 320)
db.remove(eids = [313,314,315,316])

# close the connection
db.close()

self.alll = CI_instance_test._model_properties.getParameters(
                            type='property',
                            name='alll_coverage'                            
                        )[0]
                                                             
############### Coverage Rate update for GCB  ######################                                                            
import sys
import os
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import datetime
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from tinydb import TinyDB, Query
import pandas as pd
from json import JSONDecodeError

path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties)

db.update({
'value': [{'rating_group_1':0.00191750123200960,
           'rating_group_2':0.00191750123200960,
           'rating_group_3':0.00213692324437301,
           'rating_group_4':0.00299515134590428,
           'rating_group_5':0.00628815490691390,
           'rating_group_6':0.05353062634821830,
           'rating_group_7':0.07715186206887050,
           'rating_group_8':0.10077309778952300,
           'rating_group_9':0.45000000000000000}]},
           ((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') & (Query().version_date=='06/30/2017') & (Query().name=='alll_coverage')))

db.update({
'value': [{
           'rating_group_1': 0.00168177678067541,
           'rating_group_2': 0.00168177678067541,
           'rating_group_3': 0.00187469514795583,
           'rating_group_4': 0.00206761351523625,
           'rating_group_5': 0.0342967747697222,
           'rating_group_6': 0.0504113553969652,
           'rating_group_7': 0.0584686457105866,
           'rating_group_8': 0.0665259360242081,
           'rating_group_9': 0.280108555866787}]},
           ((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') & (Query().version_date=='06/30/2017') & (Query().name=='contingent_reserve')))


############### Update C&I macro variable for CCAR 2019  ######################        

db = TinyDB(CONFIG['MODEL_PROPERTIES']['FILE_PATH'])
test_gcb = db.search((Query().model_id=='2016-SBNA-Loss-Commercial-GCB') & (Query().version_date=='12/31/2018') & (Query().name=='alll_coverage'))
test_cre = db.search((Query().model_id == '2016-SBNA-Loss-Commercial-CRE') & ((Query().name == "macro_variables") | (Query().name == "macro_variable_combinations"))
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2018,12,31))))
test_cevf = db.search((Query().model_id == '53 - Scenario Analysis Model - CEVF PD - SBNA') & ((Query().name == "macro_variables") | (Query().name == "macro_variable_combinations"))
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2018,12,31))))

test_cni = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & ((Query().name == "macro_variables") | (Query().name == "macro_variable_combinations"))
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2018,12,31))))
















