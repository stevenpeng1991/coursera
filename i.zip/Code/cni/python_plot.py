# Example 1:
# Import the necessary packages and modules
import matplotlib.pyplot as plt
import numpy as np

# Prepare the data
x = np.linspace(0, 10, 100)

# Plot the data
plt.plot(x, x, label='linear')

# Add a legend
plt.legend()

# Show the plot
plt.show()

# Example 2:
#All methods of an Axes object exist as a function in the pyplot module and vice versa. 
# (1)For simple plots, you’ll use the functions of the pyplot module because they’re much cleaner
# choice 1: use ax
import matplotlib.pyplot as plt
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot([1, 2, 3, 4], [10, 20, 25, 30], color='lightblue', linewidth=3)
ax.scatter([0.3, 3.8, 1.2, 2.5], [11, 25, 9, 26], color='darkgreen', marker='^')
ax.set_xlim(0.5, 4.5)
plt.show()

# choice 2: use pyplot (cleaner)
import matplotlib.pyplot as plt
plt.plot([1, 2, 3, 4], [10, 20, 25, 30], color='lightblue', linewidth=3)
plt.scatter([0.3, 3.8, 1.2, 2.5], [11, 25, 9, 26], color='darkgreen', marker='^')
plt.xlim(0.5, 4.5)
plt.show()

# (2)For complex plots (have multiple axes), you want to make use of the Axes object ax.

# Example 3: Difference Between add_axes() and add_subplot()

# Example of add_axes(): pass a list to add_axes() which is the lower left point, the width and the height
# This means that the axes object is positioned in absolute coordinates.
# Import `pyplot`
import matplotlib.pyplot as plt

# Initialize a Figure 
fig = plt.figure()

# Add Axes to the Figure
fig.add_axes([1,1,1,1])

# Example of add_subplot(): doesn’t provide the option to put the axes at a certain position: 
# it does, however, allow the axes to be situated according to a subplot grid, as you have seen in the section above.
# Import the necessary packages and modules
import matplotlib.pyplot as plt
import numpy as np

# Create a Figure
fig = plt.figure()

# Set up Axes
#111 is equal to 1,1,1, which means that you actually give three arguments to add_subplot(). 
#The three arguments designate the number of rows (1), the number of columns (1) and the plot number (1).
ax = fig.add_subplot(111)
#ax = fig.add_subplot(2,2,1)

# Scatter the data
ax.scatter(np.linspace(0, 1, 5), np.linspace(0, 5, 5))

# Show the plot
plt.show()

# Example 4: Change The Size of Figures
# Import `pyplot` from `matplotlib`
import matplotlib.pyplot as plt

# Initialize the plot
fig = plt.figure(figsize=(10,5))
ax1 = fig.add_subplot(121)
ax2 = fig.add_subplot(122)

# or replace the three lines of code above by the following line: 
#fig, (ax1, ax2) = plt.subplots(1,2, figsize=(10,5))

# Plot the data
ax1.bar([1,2,3],[3,4,5])
ax2.barh([0.5,1,2.5],[0,1,2])

# Show the plot
plt.show()

# Example 5: different plots
    # Import `pyplot` from `matplotlib`
import matplotlib.pyplot as plt

# Initialize the plot
fig = plt.figure()
ax1 = fig.add_subplot(131)
ax2 = fig.add_subplot(132)
ax3 = fig.add_subplot(133)

# Plot the data
ax1.bar([1,2,3],[3,4,5])
ax2.barh([0.5,1,2.5],[0,1,2])
ax2.axhline(0.45)
ax1.axvline(0.65)
ax3.scatter([0.3, 3.8, 1.2, 2.5], [11, 25, 9, 26])

# Show the plot
plt.show()

#Example 6: deleting an axes

# Import `pyplot` from `matplotlib`
import matplotlib.pyplot as plt
import numpy as np

# Initialize the plot
fig = plt.figure()
ax1 = fig.add_subplot(131)
ax2 = fig.add_subplot(132)
ax3 = fig.add_subplot(133)

# Plot the data
ax1.bar([1,2,3],[3,4,5])
ax2.barh([0.5,1,2.5],[0,1,2])
ax2.axhline(0.45)
ax1.axvline(0.65)
ax3.scatter(np.linspace(0, 1, 5), np.linspace(0, 5, 5))

# Delete `ax3`
fig.delaxes(ax3)

# Show the plot
plt.show()




"""
Sample Use

################ SPECIFICATION ############
########### Commercial
RETAIL_PLOT = False
PERIOD_FREQUENCY = 'quarterly'
model_id = ['743 - Commercial Rating Model - C&I PD - SBNA']


############################################################################################################################################
#################### TEST: Compare CCAR2018 & CCAR2019 (Using CCAR 2019 macro!): 9Q forecast; for both commercial and retail #########################################
## Start from the same point: Q0-Q1-Q2-........Q9 #########################################################################################
###########################################################################################################################################
CONTEXT_SCENARIO_DICT = {
                'CCAR2018': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA'],
                'CCAR2019': ['FRB_BASE', 'FRB_ADVERSE', 'FRB_SA']
                        }
# Note: change config; the line config will follow the legend list instead of scenrio list
LEGEND_LIST = ['CCAR2018_BASE', 'CCAR2018_AD', 'CCAR2018_SA','CCAR2019_BASE', 'CCAR2019_AD', 'CCAR2019_SA']
CYCLE1 = 'CCAR2018'
CYCLE2 = 'CCAR2019'
PLOT_START_DATE1 = datetime.datetime(2017, 12, 31)
PLOT_START_DATE2 = datetime.datetime(2018, 12, 31)
VERSION_DATE1 = datetime.datetime(2018, 12, 31)
VERSION_DATE2 = datetime.datetime(2018, 12, 31)
ADD_HISTORICAL = False
FORECAST_PERIOD = 72
SAVEPATH = "I:/MTHDO/Dept/LossImplementation/Steven/cni/plot_test/"
SHIFTING_TO_SAME_START_POINT = False


###############  GENERATION OF PLOTS  ##################
# to plot comparison of two cycles' macro scenario (start from the as-of-date)
context_scenario_dict = CONTEXT_SCENARIO_DICT
geo_scope = 'National&Regional'
period_frequency = PERIOD_FREQUENCY
cycle1 = CYCLE1
cycle2 = CYCLE2
plot_start_date1 = PLOT_START_DATE1
plot_start_date2 = PLOT_START_DATE2
version_date1 = VERSION_DATE1
version_date2 = VERSION_DATE2
forecast_period = FORECAST_PERIOD
plotSavePath = SAVEPATH
model_id = model_id
rfo_environment = 'PROD_ENV'
save_to_file = True
add_historical = ADD_HISTORICAL
add_description = False
retail_plot = RETAIL_PLOT
shift_to_same_start_point = SHIFTING_TO_SAME_START_POINT
plotMacroScenarioComparison(
    context_scenario_dict = CONTEXT_SCENARIO_DICT,
    geo_scope = 'National&Regional',
    period_frequency = PERIOD_FREQUENCY,
    cycle1 = CYCLE1,
    cycle2 = CYCLE2,
    plot_start_date1 = PLOT_START_DATE1,
    plot_start_date2 = PLOT_START_DATE2,
    version_date1 = VERSION_DATE1,
    version_date2 = VERSION_DATE2,
    forecast_period = FORECAST_PERIOD,
    plotSavePath = SAVEPATH,
    model_id = model_id,
    rfo_environment = 'PROD_ENV',
    save_to_file = True,
    add_historical = ADD_HISTORICAL,
    add_description = False,
    retail_plot = RETAIL_PLOT,
    shift_to_same_start_point = SHIFTING_TO_SAME_START_POINT
    )


"""
import sys
import CIFI.controllers.utilities.utilities as utilities
import CIFI.models.macrovariables.macrovariables as mv
import CIFI.models.modelproperties.modelproperties as mp
from CIFI.config import CONFIG
from tinydb import TinyDB, Query
import matplotlib.pyplot as plt
import pandas as pd
import datetime
import time
import pandas as pd
import numpy as np
import copy
import json
import os
import matplotlib as mpl
from matplotlib.dates import DateFormatter, YearLocator, MonthLocator
from datetime import timedelta
mpl.rcParams.update(mpl.rcParamsDefault)
import matplotlib.dates as mdates

# config for plot (color, shape)
PLOT_CONFIG = {
        "FRB_BASE": ('green', '--'),
        "FRB_ADVERSE": ('orange', '--'),
        "FRB_SA": ('red', '--'),
        "BHC_SA": ('black', '--'),
        "BHC_STRESS": ('black', '--'),
        "Historical": ('grey', '-'),
        "DR_BASE": ('lime', '-'),
        "DR_SA": ('red', '-'),
        "MC_BASE": ('lime', '--'),
        "MC_ADVERSE": ('darkorange', '--'),
        "MC_SA": ('red', '--'),
        "MC_STRESS": ('red', '--'),
        "BASE": ('green', '--'),
        "ADVERSE": ('orange', '--'),
        "STRESS": ('red', '--'),
        "GLOBAL_STRESS": ('orange', '-'),
        "IFRS9_BASE": ('lime', '-'),
        "IFRS9_POSITIVE": ('darkorange', '-'),
        "IFRS9_NEGATIVE": ('red', '-'),
        "CCAR2018_BASE": ('green', '--'),
        "CCAR2018_AD": ('orange', '--'),
        "CCAR2018_SA": ('red', '--'),
        "CCAR2018_BHC": ('black', '--'), 
        "CCAR2018_STRESS": ('red', '--'),      
        "CCAR2019_BASE": ('green', '-'),
        "CCAR2019_AD": ('orange', '-'),
        "CCAR2019_SA": ('red', '-'),
        "CCAR2019_HCR": ('black', '-'),    
        "CCAR2017_BASE": ('green', '--'),
        "CCAR2017_AD": ('orange', '--'),
        "CCAR2017_SA": ('red', '--'),
        "CCAR2017_BHC_SA": ('black', '--'),
        "EBA_BASE": ('green', '--'),
        "EBA_STRESS": ('red', '--'),
        "P21_BASE": ('green', '-'),
        "M9_BASE": ('lime', '--'),
        "M9_POSITIVE": ('darkorange', '--'),
        "M9_NEGATIVE": ('red', '--'),
        "M2_BASE": ('lime', '-'),
        "M2_POSITIVE": ('darkorange', '-'),
        "M2_NEGATIVE": ('red', '-'),
        "MidCycle2018_BASE": ('green', '--'),
        "MidCycle2018_ADVERSE": ('darkorange', '--'),
        "MidCycle2018_STRESS": ('red', '--'),
        "ICAAP_BASE": ('green', '--'),
        "ICAAP_DOWNSIDE": ('lime', '--'),
        "ICAAP_GLOBAL_STRESS": ('orange', '--'),
        "ICAAP_BHC_STRESS": ('black', '--')
        }         

# function to plot comparison of two cycles' macro scenario (start from the as-of-date)
def plotMacroScenarioComparison(
    context_scenario_dict: dict,
    model_id: (str, list),
    cycle1: str,
    cycle2: str,
    plot_start_date1: datetime.datetime,
    plot_start_date2: datetime.datetime,
    version_date1: datetime.datetime,
    version_date2: datetime.datetime,
    forecast_period: int,
    plotSavePath: str,
    geo_scope: str = 'National&Regional',
    period_frequency: str = 'quarterly',
    rfo_environment = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
    save_to_file = False,
    add_historical = True,
    add_description = False,
    retail_plot = False,
    shift_to_same_start_point = False
):

    # validate inputs
    if not os.path.isdir(plotSavePath):
        raise ValueError("Invalid plotSavePath!") 
        
    #  Path to model_properties JSON file for TinyDB usage
    if not retail_plot:
        path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
    else:
        path_to_model_properties = CONFIG['WORKING_DIRECTORY'] + 'database/retail_macro_information.json'
    
    db = TinyDB(path_to_model_properties)
#    all_model_property = db.all()
    """ ### test db search
    a = db.search((Query().model_id == '53 - Scenario Analysis Model - CEVF PD - SBNA') & (Query().name == "macro_variables")  
                            & (Query().version_date.test(
                           lambda s: utilities.str2date(s) == datetime.datetime(2016, 12, 31))))
    """
    
    # If not specify model_id, get all unique model id for macro variables in model_property JSON file
    if model_id is None:
        unique_model_id = list(
            pd.core.series.Series(
                [item['model_id'] for item in db.search((Query().model_id.exists()) 
                    & (Query().version_date1.test(
                           lambda s: utilities.str2date(s) == version_date1)) 
                    & (Query().name == "macro_variables"))]
                ).unique()
        )
    else:
        unique_model_id = model_id[:]
 
    # calculate length of plot period
    if period_frequency == 'quarterly':
        if forecast_period % 3 == 0:
#            plot_period = int(forecast_period / 3) + utilities.datetimeDiffInQuarter(plot_start_date1, version_date1) + 1
            plot_period = int(forecast_period / 3) + 1
        else:
            raise ValueError("Invalid forecast period(month) for quarterly forecast") 
    elif period_frequency == 'monthly':
#        plot_period = forecast_period + utilities.datetimeDiffInMonth(plot_start_date1, version_date1) + 1
        plot_period = forecast_period + 1
            
    # container for macro and group macro variable dictionary                                                  
    mv_dict_list = []
    mv_group_dict_list = []

    # create ModelProperties instance given model_id and version_date and get properties into dictionary list
#    model = '2016-SBNA-Loss-Retail-AUTOLEASE'
    for model in unique_model_id:
        model_properties = mp.ModelProperties(
            model_id = model,
            version_date = version_date1,
            path_to_model_properties = path_to_model_properties
            )
        macro_variables = model_properties.getParameters(type = 'operation', name = 'macro_variables')
        macro_group_variables = model_properties.getParameters(type = 'operation', name = 'macro_variable_combinations')
        mv_dict_list.extend(macro_variables) 
        mv_group_dict_list.extend(macro_group_variables)     
    
    # containers for macro variables/raw data/transformed data
    all_macro_vars = []
    raw_macro_data = []
    trans_macro_data = []
    count = 0
    # scenario container
    scenario_list = []
    
    
    # create ScenarioMacroSeries instances and fetch/transform macro variables
    for cycle, plot_start_date in zip([cycle1, cycle2], [plot_start_date1, plot_start_date2]):
        for item in context_scenario_dict[cycle]:
            print (item)
            scenario_list.append(item)
            
            # decide which RFO database should fetch from
            if cycle in ['CCAR2017', 'DryRun2017', 'P20_MAY']:
                rfo_environment = 'PROD_ENV'
            elif cycle in ['ICAAP2016', 'MidCycle2016']:
                rfo_environment = 'UAT_ENV'
            else:
                rfo_environment = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"]

            # create ScenarioMacroSeries instances
            all_macro_vars.append(mv.ScenarioMacroSeries(
                mv_dict_list = mv_dict_list,
                mv_group_dict_list = mv_group_dict_list,
                mv_as_of_date = plot_start_date - timedelta(days=1),
                mv_forecast_periods = plot_period,
                mv_context = cycle,
                mv_scenario = item,
                mv_geo_scope = geo_scope,
                mv_period_frequency = period_frequency,
                rfo_environment = rfo_environment,
                dataViz = True
                )
            )
            # fetch macro data from RFO
            print('The scenario combo is:' + cycle + '+' + item)
            print('>>> Fetching raw macro series...')
            raw_macro_data.append(all_macro_vars[count].fetchSQLiteMacroSeries())
            print('>>> Transforming macro series...')
            #  generate transformed data and remove the duplicate variables
            trans_macro_data.append(all_macro_vars[count].generateTransformedData().T.drop_duplicates().T)
            trans_macro_data[count]['Period'] = [('Q' + str(x)) for x in range(plot_period)] if period_frequency == 'quarterly' \
                                else [('M' + str(x)) for x in range(plot_period)]
            trans_macro_data[count].set_index('Period', inplace = True)
            count += 1
    
    scenario_list_length = len(scenario_list)        
    
    # added 02192018: shift to the same starting point
    if shift_to_same_start_point:
        if (scenario_list_length % 2 == 0):
            for i in range(int(scenario_list_length/2)):
                trans_temp = trans_macro_data[i].copy(deep=True)
                for column in trans_macro_data[i].columns:
                    diff = trans_macro_data[i+int(scenario_list_length/2)][column][0] - trans_macro_data[i][column][0]
                    trans_temp[column] = trans_temp[column] + diff
                trans_macro_data[i] = trans_temp
        else:
            raise ValueError('Number of scenario must be even for shifting macro)')    
    
    # save raw data
    pd.concat(trans_macro_data).to_excel(plotSavePath + "rawdata.xlsx")
    
    if scenario_list_length > 8:
            raise ValueError('Number of input scenarios is not within allowable range(1 to 8)')    
    
    # add macro variable description
    print('>>> Adding description for macro variables...')
    if add_description:
        macro_inventory = pd.read_excel(
            io = "I:/CRMPO/CCAR/4Q16/9 - Scenarios/BHC Stress macro selection_20170111.xlsm",
            sheetname = "Macrovariable Inventory"
            )
        macro_inventory = macro_inventory.set_index('Concept')
        macro_inventory = macro_inventory.groupby(macro_inventory.index).first()

    # config for plot (color, shape)
    plot_config = PLOT_CONFIG
    legend_list = LEGEND_LIST
    
    # create plots for transformed macro data and save the figures
    for column in trans_macro_data[0].columns:
        # set plot title
        if add_description:
            plot_title = macro_inventory.loc[column.split('_US')[0], 'Description']
        else:
            plot_title = 'Scenario Trends for %s' % column 
        line_width = 1.5
        
        if period_frequency == 'quarterly':
            if scenario_list_length <= 4:
                legend_loc = -0.05
            else:
                legend_loc = -0.04
        elif period_frequency == 'monthly':
            legend_loc = -0.05

        
        # no title
        # ax = trans_macro_data[0].plot(y = column, color = plot_config[scenario_list[0]][0], linewidth = line_width, linestyle = plot_config[scenario_list[0]][1])
        ax = trans_macro_data[0].plot(y = column, title = plot_title, color = plot_config[legend_list[0]][0], linewidth = line_width, linestyle = plot_config[legend_list[0]][1])
        for i in range(1,scenario_list_length):
                trans_macro_data[i].plot (y = column, ax = ax, color = plot_config[legend_list[i]][0], linewidth = line_width, linestyle = plot_config[legend_list[i]][1])
        ax.legend(legend_list, loc = 'upper center', fontsize = 'xx-small', bbox_to_anchor=(0.5, legend_loc), ncol = 4 if scenario_list_length > 6 else 7, handlelength = 2.8)
        # remove x axis tick
        ax.xaxis.label.set_visible(False)
        
        ax.tick_params(
            axis='both',
            which='both',
            bottom='on',
            top='off',
            left='on',
            right='off',
            labelbottom='on',
            labelleft='on')
        
        ax.yaxis.grid(True)
        
        fig = ax.get_figure()
        # if comparing between different context, file name will be different
        completeContext = cycle1 + '&' + cycle2
        if save_to_file:
            print('>>> Creating macro variables plots for ' + column)
            plot_file = plotSavePath + column + "_" + completeContext + ".png"
            fig.savefig(
                plot_file,
                dpi=300,
                transparent=False
                )  
