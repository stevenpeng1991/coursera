import os
import sys
import datetime
import pandas as pd
from pandasql import sqldf
import numpy as np
import dateutil.relativedelta as relativedelta
import bisect
import math
import time
from tinydb import TinyDB, Query
import matplotlib.pyplot as plt
import copy

rfo_predefault_dataset = pd.read_excel(
            io='I:/CRMPO/CCAR/4Q17/1 - Data/Pre_Default/2017Dec PreDefault Information.xlsx',
            converters={'ONEOBLIGORNUMBER':str,'CUSTOMERNUMBER':str,'FACILITYNUMBER':str})

# temp fix
#rfo_predefault_dataset = rfo_predefault_dataset[rfo_predefault_dataset["CUSTOMERNUMBER"] != '60364-2']


ccmis_predefault_dataset = pd.read_excel(
            io='I:/CRMPO/CCAR/4Q17/1 - Data/Pre_Default/ccmis_default_date_nov17_2.xlsx',
            converters={'OneObligorNUmber':str,'CustomerNumber':str,'facilityNumber':str}
)
ccmis_predefault_dataset['SourceID'] = ccmis_predefault_dataset['SourceID'].apply(lambda x: x.upper())

#-- Merge with dbo.tbl_commercial_model_v2_3
final = rfo_predefault_dataset.merge(
                            ccmis_predefault_dataset,
                            left_on=['SOURCEID','ONEOBLIGORNUMBER','CUSTOMERNUMBER','FACILITYNUMBER'],
                            right_on=['SourceID','OneObligorNUmber','CustomerNumber','facilityNumber'],
                            how='left'                            
                            )

#-- Merge with dbo.tbl_alll_customer_defaults
final = rfo_predefault_dataset.merge(
                            ccmis_predefault_dataset,
                            left_on=['SOURCEID','ONEOBLIGORNUMBER','CUSTOMERNUMBER'],
                            right_on=['SourceID','OneObligorNUmber','CustomerNumber'],
                            how='left'                            
                            )

final.to_excel('I:/CRMPO/CCAR/4Q17/1 - Data/Pre_Default/predefault_merged_Nov_2.xlsx', index = False)
