# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 14:09:04 2017

@author: n882049
"""
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.cniriskrating import CNIMasterDataset, CNIModel
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
from CIFI.models.modelproperties.modelproperties import ModelProperties
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.models.riskratingmodel import Mapping
from CIFI.config import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.models.masterdataset.financialstatements import getRawMRA, getSourceSystemToMRAMap
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalk, balanceWalkMacroSensitivity, getNCOCurve, balanceWalkPivot
import datetime
import pandas as pd
from pandasql import sqldf
import numpy as np
import dateutil.relativedelta as relativedelta
import bisect
import math
import time
from tinydb import TinyDB, Query
import matplotlib.pyplot as plt
import copy
import _pickle
##########################################################################
################ 0. run C&I model ########################################
##########################################################################

# before run the following, run the whole cniriskrating.py file
############################# CCAR 2017 RUN ##############################
AS_OF_DATE = datetime.datetime(2016,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2016,12,31)
SCENARIO_DATE = datetime.datetime(2016,12,31)           
MRA_ASOFDATE = datetime.datetime(2016,12,31)            
SCENARIO = "FRB_ADVERSE"
STRESS_TESTING_CYCLE = "CCAR2017"
SCENARIO_SEVERITY_LEVEL = "STRESS"
FORECAST_PERIODS = 27
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = False

############################# SP20 RUN Round 1 ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,2,28)
SCENARIO_DATE = datetime.datetime(2017,3,31)           
MRA_ASOFDATE = datetime.datetime(2016,12,31)            
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "P20"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 45
STATEMENT_DAYS_THRESHOLD = 426           

############################# SP20 RUN Round 2 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,5,31)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,5,31)            
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "MidCycle2017_May"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 396           
FINANCIAL_IN_RFO_SWITCH = False

############################# MC Round 1  ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)            
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = False

############################# MC Round 1 setting (CCAR scenario) ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2016,12,31)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)            
SCENARIO = "FRB_SA"
STRESS_TESTING_CYCLE = "CCAR2017"
SCENARIO_SEVERITY_LEVEL = "STRESS"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = True

############################# MC Round 2 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)            
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = True

############################# ALLL RUN ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)     
FINANCIAL_IN_RFO_SWITCH = True
       
SCENARIO = "BASE" 
STRESS_TESTING_CYCLE = "ALLL_MidCycle2017"  
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 30
STATEMENT_DAYS_THRESHOLD = 366           
PD_LAG1Q_SWITCH = False
USE_RFO_MACRO_SERIES = False
NEW_LEQ_SWITCH = False
DISCOUNTING_LGD_SWITCH = False
ADD_UAT_COLUMNS = True

############################# IFRS testing ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)     
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "S3" # BASE/S1/S3
STRESS_TESTING_CYCLE = "IFRS9"  
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 27
STATEMENT_DAYS_THRESHOLD = 366      

###### IFRS RUN ######    
PD_LAG1Q_SWITCH = True    # lag 1Q for macro for PD computation
PD_SPECIAL_SET1 = True    # If SRR in (1.0, 1.1, 1.2) or (SRR<1 and LOCAL_NPL_FLAG=”Y”) then PD=1 
USE_RFO_MACRO_SERIES = False   # Use macro in SQLite
NEW_LEQ_SWITCH = True    # Use new LEQ factors(44Q)
DISCOUNTING_LGD_SWITCH = True   # discounting LGD using interest rate and nco curve
ADD_UAT_COLUMNS = True    # add detailed columns for UAT
STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
#STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_dec16org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
MATURITY_SWITCH = True   # mature loans (check monthly)
MAXIMUM_MATURITY_DATE_IMPUTATION = True  # if maxMaturityDate missing, add 11 year from origination date
FORECAST_RESULT_FREQUENCY = 'quarterly'   # the output dataset is monthly(official run) or quarterly(uat purpose)
STAGE_DIFF_SWITCH = False  # forecast horizon different for stage 1 (4Q) and stage 2/3 (44Q)
PROVIDE_TEST_FACILITY = False  # provide specific facilities to test
MRS_SRR_SWITCH = True # convert SRR from 0.1 interval to 0.5 interval (downward)
FIX_FORECAST_PERIOD = True # fixed or dynamic decide forecast period for each facility  

###### CCAR Model RUN ######    
PD_LAG1Q_SWITCH = True    # lag 1Q for macro for PD computation
PD_SPECIAL_SET1 = False    # If SRR in (1.0, 1.1, 1.2) or (SRR<1 and LOCAL_NPL_FLAG=”Y”) then PD=1 
USE_RFO_MACRO_SERIES = False   # Use macro in SQLite
NEW_LEQ_SWITCH = True    # Use new LEQ factors(44Q)
DISCOUNTING_LGD_SWITCH = False   # discounting LGD using interest rate and nco curve
ADD_UAT_COLUMNS = True    # add detailed columns for UAT
STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
#STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_dec16org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
MATURITY_SWITCH = False   # mature loans (check monthly)
MAXIMUM_MATURITY_DATE_IMPUTATION = False  # if maxMaturityDate missing, add 11 year from origination date
FORECAST_RESULT_FREQUENCY = 'quarterly'   # the output dataset is monthly(official run) or quarterly(uat purpose)
STAGE_DIFF_SWITCH = False  # forecast horizon different for stage 1 (4Q) and stage 2/3 (44Q)
PROVIDE_TEST_FACILITY = False  # provide specific facilities to test
MRS_SRR_SWITCH = True # convert SRR from 0.1 interval to 0.5 interval (downward)
FIX_FORECAST_PERIOD = True # fixed or dynamic decide forecast period for each facility  

ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 Mid Cycle',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

##########################################################################
######################## IFRS TESTING ####################################
##########################################################################
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    PD_lag1Q_switch = PD_LAG1Q_SWITCH,
    PD_special_set1 = PD_SPECIAL_SET1,
    use_RFO_macro_series = USE_RFO_MACRO_SERIES,
    new_LEQ_switch = NEW_LEQ_SWITCH,
    discounting_LGD_switch = DISCOUNTING_LGD_SWITCH,
    add_uat_columns = ADD_UAT_COLUMNS,
    staging_dataset_input_path = STAGING_DATASET_INPUT_PATH,
    stage_diff_switch = STAGE_DIFF_SWITCH,
    fix_forecast_period = FIX_FORECAST_PERIOD,
    maturity_switch = MATURITY_SWITCH,
    maximum_maturity_date_imputation = MAXIMUM_MATURITY_DATE_IMPUTATION,
    mrs_srr_switch = MRS_SRR_SWITCH,
    forecast_result_frequency = FORECAST_RESULT_FREQUENCY,
    provide_test_facility = PROVIDE_TEST_FACILITY,
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True,
    show_result_plot = True
)

###############  Add model to the shopping cart and execute  ###########
cart.addModel(CI_ABL_risk_rating_model_instance)
cart.checkout()       # execute() is called here

## Check portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = CI_ABL_risk_rating_model_instance.portfolio_snapshot

## Check raw and transformed macro series
transformed_macro_series = CI_ABL_risk_rating_model_instance.transformed_macro_series

## Check raw and transformed macro series including t0
transformed_macro_series_include_t0 = CI_ABL_risk_rating_model_instance.transformed_macro_series_include_t0

## Check raw and transformed macro series including all
transformed_macro_series_include_all = CI_ABL_risk_rating_model_instance.transformed_macro_series_include_all

## Check change in sales, profit margin and pd mapping stress time series
macro_data = CI_ABL_risk_rating_model_instance.macro_data

## Check a list of all mapping objects as a dict
mapping_objects = CI_ABL_risk_rating_model_instance.mappings

## Get all rated contracts as a dict (quarterly forecast)
results_dictionary = CI_ABL_risk_rating_model_instance.results_set

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = CI_ABL_risk_rating_model_instance.results_df

## Get LEQ factors
leq_df = CI_ABL_risk_rating_model_instance.LEQ_df

## Get C&I portfolio average interest rate
portfolio_average_interestrate = CI_ABL_risk_rating_model_instance.portfolio_average_interestrate


########### Generate UAT dataset ###########
RESULT_CLEAN_FIELDS = [
    'UNIQUE_FACILITY_ID',
    'FORECAST_PERIOD',
    'PeriodDate',
    'OPENDATE',
    'MAXIMUMMATURITYDATE',
    'MAXIMUMMATURITYDATE_NEW',
    'm2mat',
    'PD_GROUP',
    'IS_Stage1',
    'stage',
    'forecast_period_quarterly',
    'forecast_period_month',
    'SRR',
    'LOCAL_NPL_FLAG',
    'FACILITYTYPE',
    'StatementDate',
    'StatementMonths',
    'AuditMethod',
    'StatementID',
    'InterestExpense',
    'CashAndEquivs',
    'NetTradeAcctsRec',
    'TotalCurLiabs',
    'ProfitBeforeTax',
    'NetSales',
    'DebtToTNW',
    'r_DebtToTNW1',
    'r_EBITDAoIntrst',
    'r_quickRatio',  
    'r_proftmargin',
    'diff_proftmargin',
    'pct_chg_netsales',
    'V_Debt2TNW',
    'V_EBITDA2IntExp',
    'V_QuickR',
    'V_day_to_stmt2',
    'V_ProfitM',
    'V_ChgSales',
    'estimated_pd',
    'rating',
    'final_rating',
    'pd_mrs',
    'pd_mapping',
    'pd_1y',
    'pd_1q',
    'pd_1m',
    'COLLATERAL_TYPE',
    'lgd_macro',
    'avg_interestrate',
    'LGD',
    'New_LGD_ifrs',
    'EAD',
    'EAD_BOOK_BALANCE',
    'EAD_LETTER_OF_CREDIT',
    'EAD_AVAILABLE_LINE',
    'EAD_TOTAL_LINE',
]			

test1 = results_df.sort_values(by = ['UNIQUE_FACILITY_ID','FORECAST_PERIOD'])
test1['SCENARIO'] = SCENARIO
final = test1[['SCENARIO'] + RESULT_CLEAN_FIELDS]
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/CCAR/3Q17/2 - IFRS/Commercial/C&I/UAT/test/cni_ifrs_s3_10112017.xlsx")
final.to_excel(writer,'Sheet1', index = False)
writer.save()