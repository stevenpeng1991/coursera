# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 14:57:02 2017

@author: n886528
"""

import pandas as pd
import numpy as np
import os
import pprint
import sys
import time
import matplotlib.cm as cm
from matplotlib.colors import Normalize
import matplotlib.pyplot as plt
##
os.chdir('c:/users/n886528/desktop')
#def process_timing_curve(path):
dat_all = pd.read_excel(io = 'Pre-Defaults_whole data.xlsx',
                    sheetname = 'Sheet1',
                    header = 0,
                    index_col= None)
dat_oc = pd.read_excel(io = 'NCO Curve_used by CCAR.xlsx',
                       sheetname = 'Sheet1',
                       header =0,
                       index_col = None)

dat_all['Loan Key'] = dat_all.apply(lambda r : str(r['CustomerNumber']) + '-' + str(r['facilityNumber']),axis = 1)
gggggg = np.unique(dat_all['Curve_Used'].tolist())
dat_all = dat_all.groupby('Curve_Used')

#check
[i in dat_oc.keys() for i in gggggg]

#dat.keys()
#
#g_dat = dat.groupby("Loan Key")
#g_dat_dict = g_dat.groups
#new_g_dat_dict = g_dat_dict.copy()
#for i,j in new_g_dat_dict.items():
#    make_sub_dict = {}
#    if len(j) > 1:    
#        dat_extract = dat.iloc[j,:]['Net_Chargeoffs'].tolist()
#        peak = dat_extract[0]
#        for ind,theta in zip(j,dat_extract):
#            if theta > peak:
#                make_sub_dict[ind] = {'change_type':'increase','change_amount':(theta - peak)}
#                peak = theta
#            elif theta < peak:
#                make_sub_dict[ind] = {'change_type':'increase','change_amount':(theta - peak)}
#            else:
#                make_sub_dict[ind] = {'change_type':'','change_amount':None}            
#    else:
#        # doing nothing
#        make_sub_dict = {j[0]:{'change_type':'','change_amount':None}}
#    g_dat_dict[i] = make_sub_dict
#
#for_check = {}
#for i in g_dat_dict.values():
#    for_check.update(i)
#
## auto_detection
#for r_ind in range(len(dat)):
#    real_row = dat.iloc[r_ind,:]
#    row_info = for_check[r_ind]
#    if 


# ouput
out_put  = {}
## make data
for theme in gggggg:
    dat = dat_all.get_group(theme)
    dat = dat[~(dat['Net_Chargeoffs'] < 0)]
    #dat=dat.reindex(index = list(range(len(dat)))) -> cause some problem
    
    dat_dict = {}
    dat_g_time = dat.groupby('Month_Since_Default')
    for k in np.unique(dat['Month_Since_Default'].tolist()):
        dat_dict[k] = dat_g_time.get_group(k)
    #
    peak = {}
    def check_c(r):
        i = r['Net_Chargeoffs_x']
        j = r['Net_Chargeoffs_y']
        k = r['Loan Key']
        if k not in peak.keys():
                peak[k] = i if not pd.isnull(i) else j
         
        if i == j :
            return 0
        elif i>j:        
            return 0
        elif i < j :
            if j > peak[k]:
                old_peak = peak[k]
                peak[k] = j
                return j - old_peak
            else:
                return 0
        elif pd.isnull(i) and not pd.isnull(j):
            return j
        elif pd.isnull(j) and not pd.isnull(i):
            return 0        
        else:
            return 0
    
    def fill_na(r):
        i = r['Net_Chargeoffs_x']
        j = r['Net_Chargeoffs_y']
        k = r['Loan Key']
        c = r['change']
        if pd.isnull(i):
            return c
        elif c != 0 :
            return i+c
        else:
            return i
        
    # GOGOGO
    
    # dat_dict is a dictionary of dataframes
    # set a original one and comparision and change the peak if necessary
    # need a dict to document the peak to check the change
    
    t_ind = sorted(dat_dict.keys())
    o_ind = t_ind[0]
    u_ind = t_ind[1:]
    
    original = dat_dict[o_ind]
    peak.update( {i:j for i,j in zip(original['Loan Key'],original['Net_Chargeoffs'])})
    
    final_result = {o_ind : {'total':sum(original['Net_Chargeoffs']),'change':sum(original['Net_Chargeoffs'])}}
    kept = ['Loan Key','Net_Chargeoffs']
    #len(orignal) #72
    #len(dat_dict[u_ind[1]]) #78
    #final  = original[kept].merge(dat_dict[u_ind[1]][kept], how = 'outer', on = 'Loan Key')
    #
    #final['change'] = final.apply(check_c,axis = 1)
    
    for t in u_ind:
        inter = original[kept].merge(dat_dict[t][kept], how = 'outer', on = 'Loan Key')
        inter['change'] = inter.apply(check_c,axis = 1)
        final_result.update({t:{'total':sum(dat_dict[t]['Net_Chargeoffs']),'change':sum(inter['change'])}})
    #    print(inter)
        # update the original 
        used = inter.apply(fill_na,axis =1)
        inter['Net_Chargeoffs'] = used
        original = inter[['Loan Key','Net_Chargeoffs']]
    #    time.sleep(10)
    print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> data process')
    to_df = pd.DataFrame(final_result)
    to_df = to_df.transpose()
    to_df['since'] = list(range(len(to_df)))
    non_zero_df = to_df[~(to_df['change'] ==0)]
    f_to_df = to_df[~((to_df['change'] == 0) | (to_df['since'] >= 80))]
    to_df_c = to_df[~(to_df['since'] >= 80)]
    to_df_c['pct'] = [i/sum(to_df_c['change']) for i in to_df_c['change']]
    
    while len(to_df_c) < 80 :
        print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> length deal %d'%len(to_df_c))
        to_df_c = to_df_c.append(to_df_c.iloc[-1],ignore_index = True)
        
    # check the wrong data point
    #if check_the_result:
    max_d = dat.groupby('Loan Key').agg({'Net_Chargeoffs':np.max}).to_dict()['Net_Chargeoffs']
    '''
    the loan id is:0051515315-00515153150000000018
    max_d is 4896.3
    peak is 4491.7
    the loan id is:0051683337-00516833370000000018
    max_d is 115969.7
    peak is 11189.0
    the loan id is:0051979685-00519796850000000034
    max_d is 4150.0
    peak is 2350.0
    the loan id is:0051154883-00511548830000000042
    max_d is 6007.7
    peak is 5859.3
    '''
    wronged = []
    for i in max_d.keys():
        if max_d[i] != peak[i] and peak[i] != 0:
            print('the loan id is:%s'%i)
            wronged.append(i)
            print('max_d is %.1f'%max_d[i])
            print('peak is %.1f'%peak[i])
    for i in wronged:
        print(dat[dat['Loan Key']==i])
    
    
    fig, ax = plt.subplots()
    ax.set_ylim(0, 1)
    ax.plot(to_df_c['since'],np.cumsum(to_df_c['pct']),linewidth = 2, color = 'lightblue',
            label = 'New')
    out_put[theme] = np.cumsum(to_df_c['pct'])
    line, = ax.plot(to_df_c['since'],dat_oc[theme],linewidth = 2, color = 'red',
            label = 'Old')
    line.set_dashes([10,5,10,5])
    
    ax.set_xlabel('Month since default')
    ax.set_ylabel('Cumulative')
    ax.set_title(':%s'%theme)
    ax.legend(loc = 'lower right')
    ax.tick_params(
        axis='both',
        which='both',
        bottom='off',
        top='off',
        left='off',
        right='off',
        labelbottom='on',
        labelleft='on')
    make_path = os.getcwd() + '\\' + 'curve' + '\\' + theme + '.png' 
    fig.savefig(make_path)

out_put = pd.DataFrame(out_put)
out_put.to_clipboard()        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    














