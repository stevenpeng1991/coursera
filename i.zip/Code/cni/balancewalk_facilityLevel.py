def balanceWalk(
    cf_data: pd.DataFrame,
    anchor_data: pd.DataFrame,
    scenario_list: list,
    process_ALLL_balances: bool,
    debug: bool =True,
    **kwargs   
) -> pd.DataFrame:
    """

    Args:
        cf_data (pd.DataFrame) :
        anchor_data (pd.DataFrame) :
        scenario_list (list) :
        debug (bool) :
        segfield2_to_nco_timing_curve (optional) :
    Return:
        bw_results_pivot (pd.DataFrame) : the aggregated balance walk results.

    """
    segfield2_to_nco_timing_curve = kwargs.get('segfield2_to_nco_timing_curve')
    
    raw_anchor_balance_check = anchor_data.BOOKBALANCE.sum() / (len(anchor_data.RATENAME.unique()))
    cf_data_tmp = cf_data.copy(deep=True)
    
    # sum values for three columns in case of overlay
    cf_data_tmp['MODELOUTPUTRATE'] =  cf_data_tmp['MODELOUTPUTRATE'] + cf_data_tmp['MGMTADJUSTMENTRATE'] + cf_data_tmp['UNCERTAINTYADJUSTMENTRATE']

    pre_bw_data = anchor_data[['UNIQUE_FACILITY_ID','RATENAME', 'MODELSEGMENT']].merge(
        cf_data_tmp[
            ['SCENARIO', 'MODELOUTPUTRATE', 'RATENAME', 'MODELSEGMENT', 'PERIODDATE']
        ],
        on=['RATENAME', 'MODELSEGMENT'],
        how='left'
    )

    period_date_index = pd.Series(pre_bw_data['PERIODDATE'].unique()).sort_values()
    period_date_index = period_date_index[~pd.isnull(period_date_index)]
    period_date_index.reset_index(drop=True, inplace=True)
    forecast_periods = len(period_date_index)

    if len(pre_bw_data)!=(len(anchor_data)*forecast_periods*len(scenario_list)):
        raise Exception("Length of anchor_data != pre_bw_data.")

    pre_bw_data.drop('MODELSEGMENT', axis=1, inplace=True)

    bw_data_wide = pd.pivot_table(
        pre_bw_data,
        values='MODELOUTPUTRATE',
        index=list(set(list(pre_bw_data.columns)) - set(['RATENAME', 'MODELOUTPUTRATE'])),
        columns=['RATENAME'],
        aggfunc=np.mean
    ).reset_index()

    dups_check = bw_data_wide.duplicated(['UNIQUE_FACILITY_ID', 'SCENARIO', 'PERIODDATE'])
    if len(bw_data_wide[dups_check]) != 0:
        raise Exception("Duplicate in pivot table.")

    bw_data_wide_additional_fields = anchor_data[anchor_data.RATENAME=='PD'].merge(
        bw_data_wide,
        on=['UNIQUE_FACILITY_ID'],
        how='left'
    )
    bw_data_wide_additional_fields.drop('RATENAME', axis=1, inplace=True)

    bw_data_wide_balance_check = bw_data_wide_additional_fields.BOOKBALANCE.sum()/(len(scenario_list) *
        forecast_periods
    )
    if round(raw_anchor_balance_check - bw_data_wide_balance_check, -1) != 0:
        raise Exception("Balance check 2 failed.")

    indexed_bw_data = bw_data_wide_additional_fields.set_index([
        'SCENARIO',
        'UNIQUE_FACILITY_ID'
    ])

    if debug:
        print("Computing list of unique facilities...")
    unique_facilities = indexed_bw_data.index.get_level_values('UNIQUE_FACILITY_ID').unique().tolist()

    if debug:
        print("Computing counter breakpoints...")
    breakpoints = [int((len(unique_facilities) / 100) * (m + 1)) for m in range(100)]

    if debug:
        print("Beginning balance walk process...")
    bw_results = []

    for scenario in scenario_list:
        print("****** Processing scenario {} ******".format(scenario))
        for unique_facility_idx, unique_facility_id in enumerate(unique_facilities):
            if unique_facility_idx in breakpoints:
                print("Process {}% completed".format(str(
                    (breakpoints.index(unique_facility_idx) + 1) * 1
                )))
            current_facility = indexed_bw_data.loc[scenario, unique_facility_id].to_dict(orient='list')

            # VERSION 1
            current_facility_v1 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve, 
                loc_default_reduction_switch=True,
                loc_maturity_treatment_switch=True,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances
            )

#            # VERSION 2
#            current_facility_v2 = processBWFacility(
#                forecast_periods=forecast_periods,
#                current_facility=copy.deepcopy(current_facility),
#                scenario_name=scenario,
#                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,  
#                loc_default_reduction_switch=False,
#                loc_maturity_treatment_switch=True,
#                apply_curve=True,
#                process_ALLL_balances=process_ALLL_balances
#            )
#
#            # VERSION 3
#            current_facility_v3 = processBWFacility(
#                forecast_periods=forecast_periods,
#                current_facility=copy.deepcopy(current_facility),
#                scenario_name=scenario,
#                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,  
#                loc_default_reduction_switch=True,
#                loc_maturity_treatment_switch=False,
#                apply_curve=True,
#                process_ALLL_balances=process_ALLL_balances
#            )
#
#            # VERSION 4
#            current_facility_v4 = processBWFacility(
#                forecast_periods=forecast_periods,
#                current_facility=copy.deepcopy(current_facility),
#                scenario_name=scenario,
#                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,  
#                loc_default_reduction_switch=False,
#                loc_maturity_treatment_switch=False,
#                apply_curve=True,
#                process_ALLL_balances=process_ALLL_balances
#            )

            current_facility_v1['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
#            current_facility_v2['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
#            current_facility_v3['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
#            current_facility_v4['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods

            try:
                bw_results.append(pd.DataFrame(current_facility_v1))
            except ValueError as e:
                print(current_facility_v1)

#            try:
#                bw_results.append(pd.DataFrame(current_facility_v2))
#            except ValueError as e:
#                print(current_facility_v2)
#
#            try:
#                bw_results.append(pd.DataFrame(current_facility_v3))
#            except ValueError as e:
#                print(current_facility_v3)
#
#            try:
#                bw_results.append(pd.DataFrame(current_facility_v4))
#            except ValueError as e:
#                print(current_facility_v4)

    bw_results_final = pd.concat(bw_results)
    

    return(bw_results_final)

    
# balance walk in facility level
segfield2_to_nco_timing_curve = None
SCENARIO = 'FRB_BASE'
bw_output = balanceWalk(
    cf_data = cf_data_new,
    anchor_data=anchor_data,
    scenario_list=[SCENARIO],   
    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
    process_ALLL_balances = True,
    debug = True
)  
    
# add finalrat_ind:
portfolio_snapshot = CI_ABL_risk_rating_model_instance.portfolio_snapshot
final = bw_output.merge(
    portfolio_snapshot[['UNIQUE_FACILITY_ID', 'finalrat_ind']],
    left_on = 'UNIQUE_FACILITY_ID',
    right_on = 'UNIQUE_FACILITY_ID',
    how='left'
)
final.to_csv('I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/Balance Walk/C&I/cf_id_102_BW_output_FRB_BASE_version_1_.csv')
