# -*- coding: utf-8 -*-
"""
Created on Fri May 18 09:07:14 2018

@author: n882049
"""

from pptx import Presentation



prs = Presentation('c:/Users/n882049/Downloads/testPlaceholder.pptx')

#prs = Presentation()
slide = prs.slides.add_slide(prs.slide_layouts[14])
for shape in slide.shapes:
    if shape.is_placeholder:
        phf = shape.placeholder_format
        print('%d, %s' % (phf.idx, phf.type))
        
placeholder = slide.placeholders[13]
picture = placeholder.insert_picture('c:/Users/n882049/Downloads/testpic.png')

title_placeholder = slide.shapes.title
title_placeholder.text = 'Air-speed Velocity of Unladen Swallows'

prs.save('c:/Users/n882049/Downloads/testPlaceholder.pptx')



title = slide.shapes.title
subtitle = slide.placeholders[1]

title.text = "Hello, World!"
subtitle.text = "python-pptx was here!"



>>> prs = Presentation()
>>> slide = prs.slides.add_slide(prs.slide_layouts[14])
>>> placeholder = slide.placeholders[1]  # idx key, not position
>>> placeholder.name
'Picture Placeholder 2'
>>> placeholder.placeholder_format.type
PICTURE (18)
>>> picture = placeholder.insert_picture('my-image.png')