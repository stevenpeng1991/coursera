import os
import sys
# wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
# if wd not in sys.path:
#    sys.path.append(wd)
import datetime
import pandas as pd
import numpy as np
import cx_Oracle
import time
import itertools
import matplotlib.cm as cm
from matplotlib.colors import Normalize
import matplotlib.pyplot as plt
import types
import copy
from CIFI.config import CONFIG
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
from CIFI.models.modelproperties.modelproperties import ModelProperties
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.models.riskratingmodel import Mapping
from CIFI.config import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.controllers.models.creconstruction17 import CREConstruction
from CIFI.controllers.utilities.session import CCARSession

from CIFI.controllers.ejm.ejmmaster import EJMGenerator, ejmDictionaryGenerator
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalkMacroSensitivity
from CIFI.models.modelproperties.modelproperties import ModelProperties


'''
--------------User Guide----------------

# create an instance of CREConstruction model

				
# parameters passed:
# 	part I:  additional parameters
# 		class_type: the class of model
# 		pd_groups: a list to get anchor data
# 		model_name : used for plot title. Default is None. If is None, will use class_type name as model_name
# 		ejm_ind : Default is True. To indicate whether your model need ejm.

# 	part II: model parameters
# 		make sure put all needed parameters of the model when creating instance.
example = SensitivityProcessor(
		class_type = CREConstruction,
		pd_groups = ["CRE_CONSTRUCTION"],
		model_name= None,
		ejm_ind= True,
		uncertainty_rate=0.,
		as_of_date=datetime.datetime(2016,12,31),
		model_id="2016-SBNA-Loss-Commercial-CREConstruction",
		scenario=["FRB_ADVERSE",'FRB_SA'],
		scenario_context='CCAR2017',
     	scenario_date = datetime.datetime(2016,12,31),
		forecast_periods=27)
# to store ejm file:
# ejm_file = example._ejm_cf

# to pass ejm_cf value:
# example.PassEJM(ejm_file)

# to active the instance to store CF:
# example.TurnOnStorage()

# to get CF data
# CFs = example.getCFContainer()
# to pass CF files into existing instance (to eliminate CF processing time):
# example.PassCF(CFs)

# change variable order
# @@@PAY ATTENTION@@@: the changing order is the reversed variables list @@@__@@@ 
example.ShowVariables
example.ChangeVariable(new = ['FHSTQ_US', 'FZFL075035503Q_US','FRGT5Y_US'])
example.ChangeVariable(new = ['FZFL075035503Q_US','FRGT5Y_US', 'FHSTQ_US'])
# cut variables into small groups
example.ChangeVariable(new = ['FHSTQ_US', 'FZFL075035503Q_US','FRGT5Y_US'],cutpoint= 'FZFL075035503Q_US')

# make plots
plots = example.getPlot(rename = {'FHSTQ_US':'Housing Starts','FZFL075035503Q_US':'CREPI','FRGT5Y_US':'Treasury Rate'})


# save plots
plot1 = plots[0]
plot1.savegfig('to/where/you/want')

# decompose getPlot
# example is a SensitivityProcessor instance and the input class_type is CREConstruction

anchor = example.getAnchor(example.pd_groups, example._getAsOfDate())
CF = example.CFGenerator(example._para_dict)
BW = example.BWGenerator(CF,anchor)
values = example._getValue(BW,LOC_DEFAULT_REDUCTION_FLAG = 'N',LOC_DEFAULT_REDUCTION_FLAG = 'N')
# values is the a list of tuples
amounts = [i[1] for i in values ]
rates = [i[0] for i in values]
variables = ['BASE'] + example.ShowVariables + ['SA']
plot1 = example.sensitivity_plot(variables,amounts,...)

# Show the contributor files
example.CFGenerator(example._para_dict)
next(example.CFGenerator(example._para_dict))

----------------------------------------

from CIFI.controllers.models.riskratingmodel import *

example = SensitivityProcessor(
		class_type = RiskRatingModel,
		pd_groups = ["CRE_MULTIFAMILY", "CRE_OTHER"],
		model_name= 'CRE',
		ejm_ind= False,
		uncertainty_rate=0.00,
   		as_of_date=datetime.datetime(2016,12,31),
   	 	dataset_query_date=datetime.datetime(2016,12,31),
      scenario_date = datetime.datetime(2016,12,31),
    	model_id='2016-SBNA-Loss-Commercial-CRE',
    	scenario=["FRB_BASE","FRB_SA"],
    	scenario_severity_level='STRESS',
    	scenario_context='CCAR2017',
    	forecast_periods=27,
    	ne_scalar=True,
    	crepi_multifamily_scalar=[294,
                              290.945098985984,
                              265.793702550437,
                              240.470453137935,
                              216.942528567195,
                              199.865965980898,
                              185.77279303871,
                              172.563832110162,
                              168.601335302004,
                              169
                              ],
    	debug=True,
    	bau=None,
    	origination=True,
    	book_balance_filter=None,
    	gl_filter=True,
    	path_dependent=True,
    	read_input=False)

example.ShowVariables
example.ChangeVariable(new = 
                             ['FLBR_US',
                             'FRBBBQ_US',
                             'FHSTQ_US',
                             'FLBR_US',
                             'FLBR_US',
                             'FIRBAACI7Q_US',
                             'FHSTQ_US',
                             'FHOFHOPIQ_US',
                             'FRTB3M_US',
                             'FLBR_US',
                             'FHOFHOPIQ_US',
                             'FZFL075035503Q_US',
                             'FGDPQ_US'],cutpoint = 'FRTB3M_US')

--------------Design Guide--------------

parent class: SensitivityProcessorBase
	Description : Define basic operations and aggregated operations

	Tools:
	sensitivity_plot: Draw the sensitivity plot
	ChangeVariableGroup: Change a list of discrete variables into a list of both discrete and grouped variables
		e.g. ['a','b','c','d']  -> with cutpoint = 'c'-> ['a','b',('c','d')]
	combo_generator: with input variables list and scenarios list, to get a combination dictionary
	DictWithTupleKeyConvertor: convert dictionary with tuple keys into the one without Tuple keys
	getEJM: to get EJM 
	getAnchor: to get Anchor data
	CFGenerator: to get Contributor file generator
	BWGenerator: to get Balance walk generator

	private operations:
		To get the properties of model:
			_getVariable 
			_getAsOfDate
			_getScenarios
			_getValue
			_getModelName
			_getEJMswitch
		To prepare for aggregated operation
			_makeTheTitle
	public operations:
		getPlot: An aggregated tool to make sensitivity plot.
			the sequence of operations:
			get anchor data -> get Contributor file -> put them into Balance walk
			-> pick out loss Amount and Loss rate from balance walk
			-> make the variable names which will be shown in the sensitivity plot
			-> draw plots of Loss Amount and Loss Rate individually
			-> out put : matplotlib figure objects.
Child class: SensitivityProcessor
	Description: Define specified operations and can be used to create instances of different models

	initialize: A necessary parameter needed is a Type(Class) object

	methods:
		inherited tools
		inherited operations

		private methods:
			_getVariable 
			_getAsOfDate
			_getScenarios
			_getValue
			_getModelName
			_getEJMswitch
		public methods:
			CFGenerator : make it into functional
----------------------------------------

'''


class SensitivityProcessorBase:

	@classmethod
	def sensitivity_plot(cls,
						 names: list,
						 value: list,
						 per_value : list = None,
						 tags: str = 'percent',
						 title: str = '',
						 dollar_ind: bool = False):
		plot_config = {"FRB_BASE": ('lime', '-'),
					   "FRB_ADVERSE": ('royalblue', '-'),
					   "FRB_SA": ('gold', '-'),
					   "BHC_SA": ('red', '-'),
					   "Historical": ('grey', '-'),
					   "DR_BASE": ('lime', '-'),
					   "DR_SA": ('red', '-'),
					   "MC_BASE": ('lime', '-'),
					   "MC_ADVERSE": ('darkorange', '-'),
					   "MC_SA": ('red', '-')}
		# input

		#    names = ['Base','SA-Macro1','SA-Macro2','SA-Macro3','SA-Macro4','SA']
		#    value = [8,12,15,19,40,40]

		names = [names[0]] + ['+' + i for i in names[1:-1]] + [names[-1]]

		# make the data
		differ = np.diff(value).tolist()
		posi = np.arange(len(value))

		change = value[-1] - value[0]
		ch_per = [round(d / change, 4) for d in differ][0:-1]
		ch_value = [value[0]] + differ[0:-1] + [value[-1]]
		# adjust for height and bottom
		height = [value[0]] + differ[0:-1] + [value[-1]]
		bottom = [0] + np.cumsum(height).tolist()[0:-2] + [0]
		width = 0.05
		space = 0.1
		left = [space + i * (width + space) for i in posi]

		# adjust for the last bin
		lastheight = height[0:-1]
		lastheight.append(value[-1] - sum(lastheight))
		lastbottom = bottom[0:-1]
		lastbottom.append(sum(height[0:-1]))
		lastleft = [left[-1]] * len(lastheight)

		# personalized color
		norm = Normalize(vmin=-min(value), vmax=max(value))
		color = cm.PuBu(norm(height))
		lastcolor = color[0:-1]

		# make up adding lines data
		starter_x = np.asarray(left[0:-1]) + width
		starter_y = value[0:-1]
		end_x = [left[-1]] * len(starter_x)
		end_y = starter_y

		# Create figure: fig ->figure object; axs->subplot object
		fig, axs = plt.subplots(1, 1, figsize=(12, 8))
		# set the margins of plots
		axs.set_xlim(space * 0.5, (space + width) * len(value) + space * 0.5)
		axs.set_ylim(0, max(value) * 1.1)

		# add bars
		bar1 = axs.bar(left=left[0:-1],
					   height=height[0:-1],
					   bottom=bottom[0:-1],
					   width=[width] * (len(value) - 1),
					   color=color[0:-1],
					   alpha=0.75,
					   edgecolor=color[0:-1],
					   linewidth=0.01)
		bar2 = axs.bar(left=lastleft,
					   height=lastheight,
					   bottom=lastbottom,
					   width=[width] * len(lastheight),
					   color=lastcolor,
					   alpha=0.75,
					   edgecolor=lastcolor,
					   linewidth=0.01)

		# add reference line
		axs.hlines(starter_y, starter_x, end_x,
				   linestyle='dashdot', color='pink')

		# labels control system
		axs.tick_params(
			axis='both',
			which='both',
			bottom='off',
			top='off',
			left='off',
			right='off',
			labelbottom='on',
			labelleft='off')
		axs.set_xticks(np.asarray(left) + width / 2)
		axs.set_xticklabels(names, fontsize=15, rotation=20)

		# Titles control
		axs.set_title(title, fontsize=20)

		# text function to draw tags on bins
		def set_text(bins, ax, value, tags,shift_h = 0, dollar_ind = True):
			for b, j in zip(bins, value):
				height = b.get_height()
				if j == value[0]:
					if tags == 'percent':
						ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height()+shift_h,
								'%.2f' % (100 * j) + '%', ha='center', va='bottom', fontsize=12)
					else:
						if dollar_ind:
							j /= 1000000
							j = '{:,.0f}'.format(j)
							ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height()+shift_h,
									'$' + j + 'MM', ha='center', va='bottom', fontsize=12)
						else:
							ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height()+shift_h,
									'%.1f' % (j) + '%', ha='center', va='bottom', fontsize=12)
				else:
					if tags == 'percent':
						ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height()+shift_h,
								'%.2f' % (100 * j) + '%', ha='center', va='bottom', fontsize=12)
					else:
						if dollar_ind:
							j /= 1000000
							j = '{:,.0f}'.format(j)
							ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height()+shift_h,
									'+$' + j + 'MM', ha='center', va='bottom', fontsize=12)
						else:
							ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height()+shift_h,
									'+%.2f' % (j) + '%', ha='center', va='bottom', fontsize=12)

		if tags == 'percent':
			set_text(bar1[1:], axs, ch_per, tags)
		elif tags == 'value':
			set_text(bar1, axs, ch_value[0:-1], tags,dollar_ind = dollar_ind)
			set_text([bar2[-1]], axs, [ch_value[-1]], tags,dollar_ind = dollar_ind)
		elif tags == 'both':
			set_text(bar1, axs, ch_value[0:-1], tags = 'value', dollar_ind = dollar_ind)
			set_text([bar2[-1]], axs, [ch_value[-1]], tags= 'value', dollar_ind = dollar_ind)
			if per_value is not None:
				differ = np.diff(per_value).tolist()
				ch_value = [per_value[0]] + differ[0:-1] + [per_value[-1]]
				set_text(bar1, axs, ch_value[0:-1], tags= 'value',dollar_ind=False,shift_h = 0.028*max(value))
				set_text([bar2[-1]], axs,[ch_value[-1]], tags= 'value',dollar_ind=False,shift_h = 0.028*max(value))
			else:
				raise ValueError("in BOTH mode percent value cannot be None!")			
		else:
			raise ValueError("Input type cannot find.")
		# adjustment part
		fig.subplots_adjust(left=0.1, right=0.9, bottom=0.1, top=0.9)
		axs.axis('on')
		axs.grid(False)
		return (fig,axs)
	# tools
	@classmethod
	def ChangeVariableGroup(cls,variables:list,cutpoint:(str,int)):
		if isinstance(cutpoint,str):
			try:
				cutpoint_index = variables.index(cutpoint)
			except ValueError:
				raise ValueError('cutpoint cannot be found!')
			before = variables[(cutpoint_index+1):]
			before.insert(0,tuple(variables[0:(cutpoint_index+1)]))
			return before
		elif isinstance(cutpoint,int):
			# list index transformation
			cutpoint -= 1
			try:
				before = variables[(cutpoint+1):1]
			except IndexError:
				raise IndexError('cutpoint is out of index range!')
			before.insert(0,tuple(variables[0:(cutpoint_index+1)]))
			return before
	@classmethod
	def combo_generator(cls,
						variables: list,
						scenarios: list,
						triangle=True):
		if isinstance(scenarios, str) or len(scenarios) == 1:
			return {i: j for i, j in zip(variables, [scenarios] * len(variables))}
		if triangle:
			all_combos = itertools.combinations_with_replacement(
				scenarios, len(variables))
			outputs = []
			start = next(all_combos)
			while start is not None:
				per = {v: s for v, s in zip(variables, start)}
				outputs.append(per)
				try:
					start = next(all_combos)
				except StopIteration:
					start = None
			return outputs
		else:
			outputs = []
			raw_all_combos = list(itertools.combinations_with_replacement(
				scenarios * len(variables), len(variables)))
			processed = set(raw_all_combos)
			for combo in processed:
				per = {v: s for v, s in zip(variables, combo)}
				outputs.append(per)
			return outputs
	@classmethod
	def DictWithTupleKeyConvertor(cls,combo: dict):
		# for specific use
		rewrite = {}
		for k,v in combo.items():
			if isinstance(k,(int,str)):
				rewrite[k] = v 
			if isinstance(k,tuple):
				for pi in k:
					rewrite[pi] = v
		return rewrite


	@classmethod
	def getEJM(cls, as_of_date: datetime.datetime, forecast_periods: int, scenario_list: (str, list), level="BASE"):
		EJM_SCENARIO_SEVERITY_LEVEL = level
		ejm_session = CCARSession(session_id='EJMs', session_date=as_of_date)
		ejm_cart = ModelShoppingCart(ccar_session=ejm_session)
		commercial_ejm_generator = EJMGenerator(
			as_of_date=as_of_date,
			ejm_dictionary=ejmDictionaryGenerator(
				asofdate=as_of_date,
				version_date=as_of_date,
				scenario_pairs={EJM_SCENARIO_SEVERITY_LEVEL: scenario_list[0]},
				pd_group_field=CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][
					"CURRENT_PD_GROUP_FIELD_NAME"],
				rfo_commercial_anchor_tb=CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][
					"TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
				rfo_commercial_orig_tb=CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][
					"TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
				debug=False,
				logger=ejm_session._logger),
			forecast_periods=forecast_periods,
			process_additional_ead=False,
			debug=False,
			logger=ejm_session._logger)
		ejm_cart.addModel(commercial_ejm_generator)
		ejm_cart.checkout()
		ejm_cf = ejm_session.contributor_file_generator.generateContributorFileInstance().getCFData()
		return ejm_cf

	@classmethod
	def getAnchor(cls, pd_groups,
				  as_of_date: datetime.datetime,
				  debug: bool =False):
		anchor_query, const_data = getBWFormatAnchorData(as_of_date=as_of_date,
														 debug=debug,
														 pd_groups=pd_groups)
		if debug:
			print(anchor_query)
		return const_data

	# instance method
	def CFGenerator(self):
		raise NotImplementedError('Not supported in this Base Class')

	@classmethod
	def BWGenerator(cls,
					CF: types.GeneratorType,
					anchor_data: pd.DataFrame):
		if not isinstance(CF, types.GeneratorType):
			raise TypeError("Use generator instead for memory efficiency!")
		while True:
			try:
				d = next(CF)
#                name = 'CF' + str(np.random.randint(5,100) * np.random.randint(1,35)) +'.csv'
#                print(name)
#                d.to_csv('C:/Users/n886528/Desktop/files/BW/test/'+name)
				yield balanceWalkMacroSensitivity(cf_data=d,
												  anchor_data=anchor_data,
												  process_ALLL_balances=False,
												  debug=False)
			except StopIteration:
				break

	def _getValue(cls,
				  BW: types.GeneratorType,
				  percent: bool = True,
				  LOC_DEFAULT_REDUCTION_FLAG: str = 'Y',
				  LOC_MATURITY_TREATMENT_FLAG: str = 'Y',
				  seperator=False):
		'''
		the sequence actually is determined by the list input in combo_generator method
		the triangle structure:
		1 1 1 1
		1 1 1 2
		1 1 2 2
		1 2 2 2
		2 2 2 2

		the value sequence should be the reversed value sequence
		'''
		if not isinstance(BW, types.GeneratorType):
			raise TypeError("Use generator instead for memory efficiency!")

		out = {}
		if seperator:
			while True:
				try:
					cur = next(BW)
					cur = cur.reset_index()
#                    name = 'BW' + str(np.random.randint(5,100) * np.random.randint(1,35)) +'.csv'
#                    print(name)
#                    cur.to_csv('C:/Users/n886528/Desktop/files/BW/test/'+name)
					pivot_tab_per = cur[(cur["LOC_DEFAULT_REDUCTION_FLAG"] == LOC_DEFAULT_REDUCTION_FLAG) & (
						cur["LOC_MATURITY_TREATMENT_FLAG"] == LOC_MATURITY_TREATMENT_FLAG)]
					pivot_tab = pivot_tab_per.groupby(["LOANTYPE", "PERIODDATE"]).agg(
						{"BALANCE": np.sum, "NCOAMOUNT": np.sum})
					for i in pd.unique(cur['LOANTYPE']):
						if i not in out.keys():
							out[i] = []
						per = pivot_tab.loc[i]
						per.index = per.index.map(pd.to_datetime)
						per = per.sort_index()
						dollar_value = per['NCOAMOUNT'].sum()
						rate = dollar_value / per['BALANCE'][0]
						out[i].append((rate*100, dollar_value))
				except StopIteration:
					break
#            print(
#                '**************************************************************************')
#            print(out)
			return out
		else:
			while True:
				try:
					cur = next(BW)
					cur = cur.reset_index()
#                    name = 'BW' + str(np.random.randint(5,100) * np.random.randint(1,35)) +'.csv'
#                    print(name)
#                    cur.to_csv('C:/Users/n886528/Desktop/files/BW/test/'+name)
					cur = cur[(cur["LOC_DEFAULT_REDUCTION_FLAG"] == LOC_DEFAULT_REDUCTION_FLAG) & (
						cur["LOC_MATURITY_TREATMENT_FLAG"] == LOC_MATURITY_TREATMENT_FLAG)]
					pivot_tab = cur.groupby(["PERIODDATE"]).agg(
						{"BALANCE": np.sum, "NCOAMOUNT": np.sum})
					if 'singleInput' not in out.keys():
						out['singleInput'] = []
					pivot_tab.index = pivot_tab.index.map(pd.to_datetime)
					pivot_tab = pivot_tab.sort_index()
					dollar_value = sum(pivot_tab['NCOAMOUNT'])
					rate = dollar_value / pivot_tab['BALANCE'][0]
					out['singleInput'].append((rate*100, dollar_value))
				except StopIteration:
					break
#            print(
#                '**************************************************************************')
#            print(out)

			return out

	def _getVariable(cls):
		raise NotImplementedError("Not supported in this Base Class")

	def _getScenarios(cls):
		raise NotImplementedError("Not supported in this Base Class")

	def _getEJMswitch(cls):
		raise NotImplementedError("Not supported in this Base Class")

	def _getModelName(cls):
		raise NotImplementedError("Not supported in this Base Class")

	@classmethod
	def _getAsOfDate(cls):
		raise NotImplementedError("Not supported in this Base Class")

	# instance methods
#    def OrderDetector(self, macro, CF,anchor):
#
#        # change the order
#        self._variables  = new_seq
#

	def _makeTheTitle(cls, segname, valueType):
		model_name = cls._getModelName()
		return model_name + ':' + ' ' + segname + ' ' + valueType


	# instance method
	def getPlot(self, rename: dict = {"variable":"name"}):
		anchor = self.getAnchor(
			as_of_date=self._getAsOfDate(), pd_groups=self.pd_groups)
		variables = self._getVariable()
		scenarios = self._getScenarios()
		CF = self.CFGenerator(self._para_dict)
		BW = self.BWGenerator(CF, anchor)
		values = self._getValue(BW)
		self._values = values
		# the reversed sequence is the adding sequence
		variables.reverse()
		if rename:
			per = []
			for i in variables:
				if i in rename.keys():
					per.append(rename[i])
				elif isinstance(i,tuple):
					per.append('Others')
				else:
					per.append(i)
			variables = [scenarios[0]] + per + [scenarios[-1]]
		else:
			variables = [scenarios[0]]  + variables + [scenarios[-1]]
		output_plots = []
		for i in values.keys():
			per_value = values[i]
			title1 = self._makeTheTitle('', "Loss Rate")
			pic1 = self.sensitivity_plot(
				variables, [i[0] for i in per_value],tags='value', title=title1)
			title2 = self._makeTheTitle('', "Loss Amount")
			pic2 = self.sensitivity_plot(variables, [i[1] for i in per_value],
										 title=title2, tags='value', dollar_ind=True)
			title3 = self._makeTheTitle('','Loss Rate and Loss Amount')
			pic3 = self.sensitivity_plot(variables,[i[1] for i in per_value], [i[0] for i in per_value],tags='both',title=title3,dollar_ind=True)
			output_plots.append(pic1)
			output_plots.append(pic2)
			output_plots.append(pic3)

		return output_plots

'''
_CF_container is an option to store CF files
'''

class SensitivityProcessor(SensitivityProcessorBase):

	__doc__ = 'all the operations are list below (the order show the operations order): \n'
	__ModelName__ = None
	_values = None

	def __init__(self,
		class_type: type,
		pd_groups: list,
		model_name: str = None,
		ejm_ind: bool = False,
		order: list = None,
		**kwargs):
		# check
		if not issubclass(class_type, CCARModel):
			raise TypeError('Class Type is not CCAR Model!')
		if not hasattr(class_type, '__call__'):
			raise TypeError('Check your Class is a callable type!')
		# make-up step
		self.__ModelName__ = class_type.__name__ if model_name is None else model_name
		self._class = class_type
		self.pd_groups = pd_groups
		self._ejm_cf = None
		self._CF_container = None
		self._ejm_ind = ejm_ind
		self._as_of_date = kwargs.get('as_of_date')
		self._scenario = kwargs.get('scenario')
		self._forecast_periods = kwargs.get('forecast_periods')
		if not all([self._as_of_date is not None, self._scenario is not None, self._forecast_periods is not None]):
			raise ValueError('Important Variables Not Found!')
		self._para_dict = {k: v for k, v in kwargs.items()}
		if order is None:
			mp = ModelProperties(
				model_id=kwargs['model_id'],
				version_date=kwargs['as_of_date'])
			self._variables_dict = mp.getParameters(
				type='operation', name="macro_variables")
			self._variables = [i['macro_variable_name'] for i in self._variables_dict]
		else:
			self._variables = order

	def CFGenerator(self,paras):
		if self._CF_container is not None and len(self._CF_container) > 0 :
			for i in self._CF_container:
				yield i
		else:	
			if self._ejm_ind and (self._ejm_cf is None):
				self._ejm_cf = super().getEJM(as_of_date=self._as_of_date,forecast_periods=self._forecast_periods, scenario_list=self._scenario)
			ccar_session = CCARSession(
					session_id='Macro Sensitivity',
					session_date=self._as_of_date)
			cart = ModelShoppingCart(ccar_session=ccar_session)
			combos = super().combo_generator(self._variables, paras.get('scenario'))
			# contributor file generator
			for comb in combos:
				# to document
				self.__doc__ += "get " + self.__ModelName__ + " instance with: \n "
				for k, v in comb.items():
					self.__doc__ += str(k) + ' within ' + str(v) + '|'
				self.__doc__ += '\n'
				# combo make up
				comb = self.DictWithTupleKeyConvertor(comb)
				# pass the keywords
				paras['scenario_combinations'] = comb if isinstance(paras.get('scenario'),list) else None 
				per_instance = self._class.__call__(**paras)
				cart.addModel(per_instance)
				cart.checkout()
				cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
				ccar_session.contributor_file_generator.resetGenerator()
				cart.resetCart()
				if self._CF_container is not None and isinstance(self._CF_container,list):
					self._CF_container.append(pd.concat([cf.getCFData(), self._ejm_cf]))
				yield pd.concat([cf.getCFData(), self._ejm_cf])
			# the severly adverse
			if len(combos) > 1 :
				paras['scenario_combinations'] = None
				paras['scenario'] = paras.get('scenario')[-1]
				per_instance = self._class.__call__(**paras)
				cart.addModel(per_instance)
				cart.checkout()
				cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
				ccar_session.contributor_file_generator.resetGenerator()
				cart.resetCart()
				if self._CF_container is not None and isinstance(self._CF_container,list):
					self._CF_container.append(pd.concat([cf.getCFData(), self._ejm_cf]))
				yield pd.concat([cf.getCFData(), self._ejm_cf])
		
	# the operation
	def ChangeVariable(self,new,cutpoint= None):
		self._variables = new
		if cutpoint is not None:
			self._variables = self.ChangeVariableGroup(self._variables,cutpoint)
	def setModelName(self,name):
		self.__ModelName__ = name

	def TurnOnStorage(self):
		self._CF_container = []
	def CheckStorageSwith(self):
		return self._CF_container is None

	def PassEJM(self,ejm_cf):
		self._ejm_cf = ejm_cf
	def PassCF(self,CF):
		self._CF_container = CF
	
	# inherited operations
	def _getVariable(self):
		return self._variables

	def _getScenarios(self):
		return self._scenario

	def _getEJMswitch(self):
		return self._ejm_ind

	def _getModelName(self):
		return self.__ModelName__

	def _getAsOfDate(self):
		return self._as_of_date

	# properites
	@property
	def Doc(self):
		print(self.__doc__)
	@property
	def ShowVariables(self):
		return (self._variables)
	@property
	def getValue(self):
		return self._values
	@property
	def getCFContainer(self):
		return self._CF_container

# make triple sensitivity plot
#************************example************************#
'''
example = SensitivityProcessor(
		class_type = CREConstruction,
		pd_groups = ["CRE_CONSTRUCTION"],
		model_name= None,
		ejm_ind= True,
		uncertainty_rate=0.,
		as_of_date=datetime.datetime(2016,12,31),
		model_id="2016-SBNA-Loss-Commercial-CREConstruction",
		scenario=["FRB_BASE",'FRB_ADVERSE'],
		scenario_context='CCAR2017',
     	scenario_date = datetime.datetime(2016,12,31),
		forecast_periods=27)
# to store something
ejm_file = example._ejm_cf
example.ChangeVariable(new = ['FRGT5Y_US', 'FZFL075035503Q_US','FHSTQ_US'])
plots = example.getPlot(rename = {'FHSTQ_US':'Housing Starts','FZFL075035503Q_US':'CREPI','FRGT5Y_US':'Treasury Rate'})
# get value from BASE to SA
BASE_SA = example.getValue

example = SensitivityProcessor(
		class_type = CREConstruction,
		pd_groups = ["CRE_CONSTRUCTION"],
		model_name= None,
		ejm_ind= True,
		uncertainty_rate=0.,
		as_of_date=datetime.datetime(2016,12,31),
		model_id="2016-SBNA-Loss-Commercial-CREConstruction",
		scenario=["FRB_ADVERSE","FRB_SA"],
		scenario_context='CCAR2017',
     	scenario_date = datetime.datetime(2016,12,31),
		forecast_periods=27)
# example._ejm_cf = ejm_file
example.ChangeVariable(new = ['FZFL075035503Q_US','FRGT5Y_US','FHSTQ_US'])
plots = example.getPlot(rename = {'FHSTQ_US':'Housing Starts','FZFL075035503Q_US':'CREPI','FRGT5Y_US':'Treasury Rate'})
# get value from BASE to ADVERSE
BASE_A = example.getValue

# then A to SA : just need to change scenario
A_SA = example.getValue
# sample output
BASE_SA  = {'singleInput': [(0.76311396497302897, 16374569.374840943),
  (1.9501212629782307, 41844562.5623537),
  (3.874146181863821, 83129161.467314318),
  (4.3371493259140159, 93058733.586507663),
  (4.3371493259140159, 93058733.586507663)]}

BASE_A = {'singleInput': [(0.76311396497302897, 16374569.374840943),
  (1.128685815902426, 24218748.153511491),
  (1.5713474830412391, 33717149.16350694),
  (1.6454081967520049, 35306305.068417728),
  (1.6454081967520049, 35306305.068417728)]}

A_SA = {'singleInput': [(1.6454081967520049, 35306305.068417728),
  (2.9081856899513503, 62402147.475668475),
  (3.9950844580709832, 85724184.220319271),
  (4.3371493259140159, 93058733.586507663),
  (4.3371493259140159, 93058733.586507663)]}

variables_name = ['FRB_BASE','HOURSING STARTS','TREASURY RATE','CREPI','FRB_ADVERSE','HOURSING STARTS','CREPI','TREASURY RATE','FRB_SA']
values = [i[1] for i in BASE_A['singleInput']] + [i[1] for i in A_SA['singleInput'][1:]]
per_values = [i[0] for i in BASE_A['singleInput']] + [i[0] for i in A_SA['singleInput'][1:]]
aa = triple_sensitivity_plot(names = variables_name,value=values,per_value= per_values,tags = 'value',title = 'CREContruction Sensitivity',dollar_ind = True )
aa[0].savefig('c:/users/n886528/desktop/joe_444.png')
'''
def triple_sensitivity_plot(
        names: list,
        value: list,
        per_value: list =None,
        tags: str = 'percent',
        title: str = '',
        dollar_ind: bool = False, color_schema: str = 'distinct'):
    plot_config = {"FRB_BASE": ('lime', '-'),
                   "FRB_ADVERSE": ('royalblue', '-'),
                   "FRB_SA": ('gold', '-'),
                   "BHC_SA": ('red', '-'),
                   "Historical": ('grey', '-'),
                   "DR_BASE": ('lime', '-'),
                   "DR_SA": ('red', '-'),
                   "MC_BASE": ('lime', '-'),
                   "MC_ADVERSE": ('darkorange', '-'),
                   "MC_SA": ('red', '-')}
    # input

    #    names = ['Base','SA-Macro1','SA-Macro2','SA-Macro3','SA-Macro4','SA']
    #    value = [8,12,15,19,40,40]
    mid = int((len(value) + 1) / 2)
    names = [names[0]] + ['+' + i for i in names[1:(mid - 1)]] + [names[mid - 1]] + [
        '+' + i for i in names[mid:-1]] + [names[-1]]

    # make the data
    differ = np.diff(value).tolist()
    posi = np.arange(len(value))

    change = value[-1] - value[0]
    ch_per = [round(d / change, 4) for d in differ][0:-1]
    ch_value = [value[0]] + differ[0:mid - 2] + \
        [value[mid - 1]] + differ[mid - 1:-1] + [value[-1]]
    # adjust for height and bottom
    height = ch_value
    last_height = [value[0]] + differ[0:-1] + [value[-1]]
    bottom = [0] + np.cumsum(height[0:(mid - 2)]).tolist() + \
        [0] + np.cumsum(height[(mid - 1):-2]).tolist() + [0]
    last_bottom = [0] + np.cumsum(last_height).tolist()[0:-2] + [0]
    width = 0.05
    space = 0.1
    left = [space + i * (width + space) for i in posi]

    # adjust for the last bin
    lastheight = last_height[0:-1]
    lastheight.append(value[-1] - sum(lastheight))
    lastbottom = last_bottom[0:-1]
    lastbottom.append(sum(last_height[0:-1]))
    lastleft = [left[-1]] * len(lastheight)

    midheight = height[0:(mid - 1)]
    midheight.append(value[mid - 1] - sum(midheight))
    midbottom = bottom[0:(mid - 1)]
    midbottom.append(sum(last_height[0:(mid - 1)]))
    midleft = [left[mid - 1]] * len(midheight)
    # personalized color
    # add the new color schema
    if color_schema == 'colormap':
        norm = Normalize(vmin=-min(value), vmax=max(value))
        color = cm.BuPu(norm(height))
        lastcolor = color[0:-1]
    elif color_schema == 'extra_contrast':
        color_seg = np.linspace(0,1.00,12)
        color_pairs = color_seg.reshape((6,2))
        color_pairs_num = int((len(names)-3)/2)
        color_select = color_pairs[0:(color_pairs_num)]
        color_dict = {i:j for i,j in zip(names[1:(mid-1)],color_select)}
        color = [cm.Set2(0)] + cm.Paired([color_dict[i][0] for i in names[1:(mid-1)]]).tolist() + [cm.Set2(0.5)] +cm.Paired([color_dict[i][1] for i in names[(mid):-1]]).tolist() + [cm.Set2(1)]
        lastcolor = color[0:-1]
    elif color_schema == 'distinct':
        color_seg = np.linspace(0.4,1,len(names)-3)
        color_select = list(zip(color_seg[0:len(color_seg)//2],color_seg[len(color_seg)//2:]))
        color_dict = {i:j for i,j in zip(names[1:(mid-1)],color_select)}
        color = [cm.Set2(0)] + cm.Blues([color_dict[i][0] for i in names[1:(mid-1)]]).tolist() + [cm.Set2(0.5)] +cm.Blues([color_dict[i][1] for i in names[(mid):-1]]).tolist() + [cm.Set2(1)]
        lastcolor = color[0:-1]
                
    else:
    	raise ValueError('Color Schema not found!')

    # make up adding lines data
    starter_x = np.asarray(left[0:-1]) + width
    starter_y = value[0:-1]
    end_x = [left[-1]] * len(starter_x)
    end_y = starter_y

    # Create figure: fig ->figure object; axs->subplot object
    fig, axs = plt.subplots(1, 1, figsize=(24, 12))
    # set the margins of plots
    axs.set_xlim(space * 0.5, (space + width) * len(value) + space * 0.5)
    axs.set_ylim(0, max(value) * 1.1)

    # add bars
    bar1 = axs.bar(left=left[0:(mid - 1)],
                   height=height[0:(mid - 1)],
                   bottom=bottom[0:(mid - 1)],
                   width=[width] * (mid - 1),
                   color=color[0:(mid - 1)],
                   alpha=0.75,
                   edgecolor=color[0:(mid - 1)],
                   linewidth=0.01)
    bar3 = axs.bar(left=midleft,
                   height=midheight,
                   bottom=midbottom,
                   width=[width] * (mid),
                   color=color[0:(mid - 1)],
                   alpha=0.75,
                   edgecolor=color[0:-1],
                   linewidth=0.01)
    bar4 = axs.bar(left=left[mid:-1],
                   height=height[mid:-1],
                   bottom=bottom[mid:-1],
                   width=[width] * (mid - 2),
                   color=color[mid:-1],
                   alpha=0.75,
                   edgecolor=color[mid:-1],
                   linewidth=0.01)
    bar2 = axs.bar(left=lastleft,
                   height=lastheight,
                   bottom=lastbottom,
                   width=[width] * len(lastheight),
                   color=lastcolor,
                   alpha=0.75,
                   edgecolor=lastcolor,
                   linewidth=0.01)

    # add reference line
    axs.hlines(starter_y, starter_x, end_x,
               linestyle='dashdot', color='pink')

    # labels control system
    axs.tick_params(
        axis='both',
        which='both',
        bottom='off',
        top='off',
        left='off',
        right='off',
        labelbottom='on',
        labelleft='off')
    axs.set_xticks(np.asarray(left) + width / 2)
    axs.set_xticklabels(names, fontsize=15, rotation=10)

    # Titles control
    axs.set_title(title, fontsize=20)

    # text function to draw tags on bins
    def set_text(bins, ax, value, tags, triple=False, shift_h=0, dollar_ind=True):
        for b, j in zip(bins, value):
            height = b.get_height()
            if j == value[0] and not triple:
                if tags == 'percent':
                    ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                            '%.2f' % (100 * j) + '%', ha='center', va='bottom', fontsize=12)
                else:
                    if dollar_ind:
                        j /= 1000000
                        j = '{:,.0f}'.format(j)
                        ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                                '$' + j + 'MM', ha='center', va='bottom', fontsize=12)
                    else:
                        ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                                '%.1f' % (j) + '%', ha='center', va='bottom', fontsize=12)
            else:
                if tags == 'percent':
                    ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                            '%.2f' % (100 * j) + '%', ha='center', va='bottom', fontsize=12)
                else:
                    if dollar_ind:
                        j /= 1000000
                        j = '{:,.0f}'.format(j)
                        ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                                '+$' + j + 'MM', ha='center', va='bottom', fontsize=12)
                    else:
                        ax.text(b.get_x() + b.get_width() / 2, b.get_y() + b.get_height() + shift_h,
                                '+%.2f' % (j) + '%', ha='center', va='bottom', fontsize=12)

    if tags == 'percent':
        set_text(bar1[1:], axs, ch_per, tags)
    elif tags == 'value':
        set_text(bar1, axs, ch_value[0:mid - 1], tags)
        set_text([bar2[-1]], axs, [ch_value[-1]], tags)
        set_text([bar3[-1]], axs, [ch_value[mid - 1]], tags)
        set_text(bar4, axs, ch_value[mid:-1], tags, triple=True)
        if per_value:
            differ = np.diff(per_value).tolist()
            ch_value = [per_value[0]] + differ[0:mid - 2] + \
                [per_value[mid - 1]] + differ[mid - 1:-1] + [per_value[-1]]
            set_text(bar1, axs, ch_value[0:mid - 1], tags,
                     dollar_ind=False, shift_h=0.028 * max(value))
            set_text([bar2[-1]], axs, [ch_value[-1]], tags,
                     dollar_ind=False, shift_h=0.028 * max(value))
            set_text([bar3[-1]], axs, [ch_value[mid - 1]], tags,
                     dollar_ind=False, shift_h=0.028 * max(value))
            set_text(bar4, axs, ch_value[
                     mid:-1], tags, triple=True, dollar_ind=False, shift_h=0.028 * max(value))
    else:
        raise ValueError("Input type cannot find.")
    # adjustment part
    fig.subplots_adjust(left=0.1, right=0.9, bottom=0.1, top=0.9)
    axs.axis('on')
    axs.grid(False)
    return (fig, axs, bar1, bar2)

