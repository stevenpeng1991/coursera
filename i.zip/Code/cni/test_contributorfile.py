# -*- coding: utf-8 -*-
"""
Created on Thu Dec  7 10:18:27 2017

@author: n882049
"""
from CIFI.controllers.contributorfile.contributorfile import ContributorFileGenerator, CFCheckerResponse
import CIFI.controllers.utilities.utilities as utilities
import datetime
import pandas as pd
import numpy as np
import copy

cfg = ContributorFileGenerator(
    run_id='Test Run',
    verbose=True
)

model_output_rate=[0.0019373875,
     0.0019373875,
     0.0019373875,
     0.0017652653999999999,
     0.0017652653999999999,
     0.0017652653999999999,
     0.0022947745,
     0.0022947745,
     0.0022947745,
     0.0024575810999999999,
     0.0024575810999999999,
     0.0024575810999999999,
     0.0027941677,
     0.0027941677,
     0.0027941677,
     0.0026856248,
     0.0026856248,
     0.0026856248,
     0.0026618956999999999,
     0.0026618956999999999,
     0.0026618956999999999,
     0.0024223742999999998,
     0.0024223742999999998,
     0.0024223742999999998,
     0.0022803726999999999,
     0.0022803726999999999,
     0.0022803726999999999]

model_output_rate=[0.01,
     0.01,
     0.01,
     0.02,
     0.02,
     0.02,
     0.03,
     0.03,
     0.03,
     0.0024575810999999999,
     0.0024575810999999999,
     0.0024575810999999999,
     0.0027941677,
     0.0027941677,
     0.0027941677,
     0.0026856248,
     0.0026856248,
     0.0026856248,
     0.0026618956999999999,
     0.0026618956999999999,
     0.0026618956999999999,
     0.0024223742999999998,
     0.0024223742999999998,
     0.0024223742999999998,
     0.0022803726999999999,
     0.0022803726999999999],
     0.0022803726999999999]


##### Test addCFChunk() #####
#good: no need to specify period date, will generate automatically by as_of_date/forecast_periods/frequency
#        use utilities.generateDateSequence inside the function
#      can generate vintage_differentiation CF automatically
#bad: vintage default to be as_of_date unless use vintage_differentiation

# test non-orig loan
cfg.addCFChunk(
            as_of_date=datetime.datetime(2017,12,31),
            forecast_periods=27,
            forecast_periods_frequency='monthly',
            model_segment='SB123456789',
            scenario='Base',
            rate_name='PD',
            rate_type=4,
            vintage_differentiation=False,
            vintage_differentiation_shift=False,
            model_output_rate=model_output_rate,
            uncertainty_adjustment_rate=0.0,
            mgmt_adjustment_rate=0.0,
            process_additional_ead = False
        )
# test orig loan:PD
cfg.addCFChunk(
            as_of_date=datetime.datetime(2017,12,31),
            forecast_periods=27,
            forecast_periods_frequency='monthly',
            model_segment='SB123456789_O',
            scenario='Base',
            rate_name='PD',
            rate_type=4,
            vintage_differentiation=True,
            vintage_differentiation_shift=False,
            model_output_rate=model_output_rate,
            uncertainty_adjustment_rate=0.0,
            mgmt_adjustment_rate=0.0,
            process_additional_ead = False
        )

# test orig loan:EAD_AVAILABLE_LINE
cfg.addCFChunk(
            as_of_date=datetime.datetime(2017,6,30),
            forecast_periods=27,
            forecast_periods_frequency='monthly',
            model_segment='SB123456789_O',
            scenario='Base',
            rate_name='EAD_AVAILABLE_LINE',
            rate_type=4,
            vintage_differentiation=True,
            vintage_differentiation_shift=True,
            model_output_rate=model_output_rate,
            uncertainty_adjustment_rate=0.0,
            mgmt_adjustment_rate=0.0,
            process_additional_ead = False
        )

cfg.setVintage(datetime.datetime(2017,6,30))
    def setVintage(self, as_of_date):
        self.__data["VINTAGE"].replace(
            to_replace=as_of_date,
            value=datetime.datetime(1900,1,31),
            inplace=True
        )

# Two ways to check cf dataframe #
# method 1: create a contributorfile instance and use getCFData() to see CF 
cf = cfg.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data_addCF = cf.getCFData()

# method 2: use dataConcat() to get CF
cf_data_addCF = cfg.dataConcat()


##### TEST appendCF() #####
##
cfg = ContributorFileGenerator(
    run_id='Test Run',
    verbose=True
)
PERIOD_FREQ_MAP = {
    'monthly': 1,
    'quarterly': 3,
    'yearly': 12
}

period_date = utilities.generateDateSequence(
                as_of_date=datetime.datetime(2017,6,30),
                forecast_periods=45,
                m_interval=PERIOD_FREQ_MAP['monthly']
            ).tolist()

cfg.appendCF(
    scenario="BASE",
    model_segment='SB123456789',
    period_date=period_date,
    vintage=datetime.datetime(2017,6,30),
    rate_type=4,
    rate_name="PD",
    model_output_rate=model_output_rate,
    uncertainty_adjustment_rate=0.,
    mgmt_adjustment_rate=0.
)

cf_data_appendCF = cfg.dataConcat()

expectedCFLength = lambda fp, v_diff: int(fp * (fp + 1) / 2 + fp) if v_diff else int(fp)

