# -*- coding: utf-8 -*-
"""
Created on Wed Apr  4 10:52:19 2018

Month	Updated Run_Signature
Jan	                                                                                                                                                                                                                                                                                                                             
Feb	
Mar	
Apr	
May	
Jun	Jun17_1530
Jul	Jul17_1540
Aug	Aug17_1540
Sep	Feb28_1700
Oct	Oct17_1545
Nov	Nov17_1610
Dec	Dec17_1545
MARCH Mar31_1110 


@author: n886528
"""
def query_gen(pd_group,run_sig,date = '30-JUN-17'):
    if 'ABL' not in pd_group:
        kept = ['UNIQUE_FACILITY_ID','FACILITY_INTEREST_RATE','PD_GROUP_2017']
    else:
        kept  = ['ASOFDATE','UNIQUE_FACILITY_ID','FACILITY_INTEREST_RATE']
    return '''
            	SELECT DISTINCT {kept}
            	FROM MACCAR.STG_RFO_COMMERCIAL_TABLE
            	WHERE
            		 ASOFDATE = \'{d}\'
            		 AND
            		 PD_GROUP_2017 in {pd_group}
                        AND 
                        RUN_SIGNATURE = \'{run_sig}\'
                        AND
                        UPPER(SOURCEID) NOT IN ('OFFLINE')
            '''.format(d = date,
                       pd_group = '(' + ','.join(["\'" + i +"\'" for i in pd_group])+')',
                       run_sig = run_sig,
                       kept = ','.join(kept))
            
            
query = query_gen(pd_group=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],run_sig='Jun17_1530',date='30-JUN-17')

query = query_gen(pd_group=['CRE_OTHER', 'CRE_MULTIFAMILY'],run_sig='Jun17_1530',date='30-JUN-17')

def generate_lable(portfolio,name,query):
    if portfolio == 'CRE':
        tt = queryRFO(
        	query=query,
        	moodys_rfo_env = "UAT_ENV",
        	debug= False
        )
        
        tt['STAGE'] = [None] * len(tt['UNIQUE_FACILITY_ID'])
        tt = tt.rename(index = str, columns= {'PD_GROUP_2017':'PD_GROUP_2017',
                        'FACILITY_INTEREST_RATE':'avg_interestrate',
                        'UNIQUE_FACILITY_ID':'unique_facility_id',
                        'STAGE':'STAGE'})
        filename = 'staging_cre_opt2b_' + name+'org_new.xlsx'
        tt.to_excel('C:/users/n886528/desktop/interest_rate/'+filename,index=None)
    elif portfolio == 'CI':
        tt = queryRFO(
        	query=query,
        	moodys_rfo_env = "UAT_ENV",
        	debug= False
        )
        
        tt['STAGE'] = [None] * len(tt['UNIQUE_FACILITY_ID'])
        tt = tt.rename(index = str, columns = {'ASOFDATE':'AsOfDate',
                        'FACILITY_INTEREST_RATE':'avg_interestrate',
                        'UNIQUE_FACILITY_ID':'unique_facility_id',
                        'STAGE':'stage'})
        filename = 'staging_cni_opt2b_' + name+'org_new_interestrate.csv'
        tt.to_csv('C:/users/n886528/desktop/interest_rate/'+filename,index=None)
    else:
        raise ValueError('NoTReallY!')
        
def generate_interest(portfolio,asofdate,name,run_sig):
    if portfolio == 'CI':
        query = query_gen(pd_group=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
                          run_sig=run_sig,
                          date = asofdate)
    elif portfolio == 'CRE':
        query = query_gen(pd_group=['CRE_OTHER', 'CRE_MULTIFAMILY'],
                          run_sig=run_sig,
                          date = asofdate)
    else:
        raise ValueError('NoTReallY!')
    generate_lable(portfolio,name,query)
    
#-------------------------------------------------------------#
#
#run_dict = {
#'30-JUN-17': 'Jun17_1530',
#'31-JUL-17': 'Jul17_1540',
#'31-AUG-17': 'Aug17_1540',
#'31-OCT-17': 'Oct17_1545',
#'31-DEC-17': 'Dec17_1545'}

run_dict = {'31-MAY-18': 'May31_1100'}
for i,j in run_dict.items():
    n = i.split('-')[1] + i.split('-')[2]
    generate_interest('CI',i,n.lower(),j) 
    generate_interest('CRE',i,n.lower(),j)        