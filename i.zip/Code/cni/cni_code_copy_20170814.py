"""
SAMPLE USE
----------

# GETTING SAMPLE CONTRACT-LEVEL DATA
## Getting contract-level data for the CNI Risk Rating model
sample_mds = CNIMasterDataset(
    asofdate=datetime.datetime(2017,3,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2017,3,31),
    financial_in_rfo = False
)

## Accessing the most complete version of the data within the CNIMasterDataset instance
df = sample_mds.mds_mra_additional_fields
df.to_clipboard(index=False) # in case you wish to copy it to an Excel spreadsheet


# KICKING-OFF A FULL RUN
## Create a session instance and a model shopping cart to run the CNIModel
ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 UAT',
    session_date=datetime.datetime(2016,12,31)
)
cart = ModelShoppingCart(ccar_session=ccar_session)

## Create CNIModel instance
cni_model_instance = CNIModel(
    as_of_date=datetime.datetime(2016,12,31),                    # scenario as-of-date
    scenario="FRB_SA",                                           # scenario name
    scenario_context="CCAR2017",                                 # stress testing cycle
    scenario_date=datetime.datetime(2016,12,31),                 # scenario as-of-date
    scenario_severity_level="STRESS",                            # scenario severity level
    forecast_periods=27,                                         # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes, number of random contracts to pick
    portfolio_snapshot_date=datetime.datetime(2016,12,31),       # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = datetime.datetime(2016,12,31),
    scenario_combinations = None
)

## Getting raw and transformed macro series
transformed_macro_series = cni_model_instance.transformed_macro_series

## Getting change in sales, profit margin and pd mapping stress time series
macro_data = cni_model_instance.macro_data

## Getting a list of all mapping objects as a dict
mapping_objects = cni_model_instance.mappings

## Run rating, PD, LGD, EAD's, and ALLL and CONTINGENT coverage modules for all contracts
cni_model_instance.ratePortfolio()

## Get portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = cni_model_instance.portfolio_snapshot

## Get all rated contracts as a dict (quarterly forecast)
results_dictionary = cni_model_instance.results_set

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = cni_model_instance.results_df
results_df.to_clipboard(index=False) # in case you would like to copy to Excel

## Add model to the shopping cart and execute
cart.addModel(cni_model_instance)
cart.checkout() # execute() is called here

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()


#########  Create CNIModel instance for sensitivity  #########
# macro combination
macro_names = ['FLBR_US', 'FZ_US', 'FHOFHOPIQ_US', 'FGDPQ_US']
all_combos = combo_generator(macro_names,["FRB_BASE","FRB_SA"]) 
cni_model_instance = CNIModel(
    as_of_date=datetime.datetime(2016,12,31),                    # scenario as-of-date
    scenario=["FRB_BASE","FRB_SA"],                              # scenario name
    scenario_context="CCAR2017",                                 # stress testing cycle
    scenario_date=datetime.datetime(2016,12,31),                 # scenario as-of-date
    scenario_severity_level="STRESS",                            # scenario severity level
    forecast_periods=27,                                         # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes, number of random contracts to pick
    portfolio_snapshot_date=datetime.datetime(2016,12,31),       # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = datetime.datetime(2016,12,31),
    scenario_combinations = all_combos[4]
)

# INSERT MODEL PROPERTIES ITEM
from tinydb import TinyDB, Query

path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties)

property_to_insert = {
    
}
db.insert(property_to_insert)
db.close()


#################### Update ALLL/CONTINGENCY Covergae Rate ####################
path_to_model_properties = CONFIG['MODEL_PROPERTIES']['FILE_PATH']
db = TinyDB(path_to_model_properties)

db.insert({'model_id': '743 - Commercial Rating Model - C&I PD - SBNA',
  'name': 'alll_coverage',
  'segment': 'all',
  'type': 'property',
  'value': [{
    0:   0.0,
    1:   1.0,
    1.5: 0.0800078746190864,
    2:   0.0421304017159306,
    2.5: 0.0421304017159306,
    3:   0.0421304017159306,
    3.5: 0.0224013294970956,
    4:   0.0224013294970956,
    4.5: 0.0106724532239101,
    5:   0.00632362559562368,
    5.5: 0.00539579582736586,
    6:   0.00374188691780179,
    6.5: 0.00296509442918514,
    7:   0.00296509442918514,
    7.5: 0.00296509442918514,
    8:   0.00296509442918514,
    8.5: 0.0
    }],
  'version_date': '03/31/2017'})

### test db search
alll = db.search((Query().model_id == '743 - Commercial Rating Model - C&I PD - SBNA') & (Query().name == "alll_coverage")  
                        & (Query().version_date.test(
                       lambda s: utilities.str2date(s) == datetime.datetime(2017, 3, 31))))
# get/remove record by Element IDs
db.get(eid = 314)
db.remove(eids = [313,314])

# close the connection
db.close()

alll = CI_instance_test._model_properties.getParameters(
                            type='property',
                            name='alll_coverage',
                            segemtn='all'
                        )[0]


############################# SP20 RUN Round 1 ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,2,28)
SCENARIO_DATE = datetime.datetime(2017,3,31)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2016,12,31)            # not in run.py
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "P20"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 45
STATEMENT_DAYS_THRESHOLD = 426           # not in run.py

############################# SP20 RUN Round 2 ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,3,31)
SCENARIO_DATE = datetime.datetime(2017,3,31)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2017,3,31)            # not in run.py
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "P20"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 45
STATEMENT_DAYS_THRESHOLD = 540           # not in run.py

ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 STRATPLAN',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

## Create CNIModel instance
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None
)

## Check portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = CI_ABL_risk_rating_model_instance.portfolio_snapshot

## Check raw and transformed macro series
transformed_macro_series = CI_ABL_risk_rating_model_instance.transformed_macro_series

## Check change in sales, profit margin and pd mapping stress time series
macro_data = CI_ABL_risk_rating_model_instance.macro_data

## Check a list of all mapping objects as a dict
mapping_objects = CI_ABL_risk_rating_model_instance.mappings

## Get all rated contracts as a dict (quarterly forecast)
results_dictionary = CI_ABL_risk_rating_model_instance.results_set

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = CI_ABL_risk_rating_model_instance.results_df

###############  Add model to the shopping cart and execute  ###########
cart.addModel(CI_ABL_risk_rating_model_instance)
cart.checkout()       # execute() is called here

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

## save contributor file to CSV file
cf_data.to_csv("I:/CRMPO/CCAR/1Q17/3 - Contributor Files/Wholesale/cf_files/archive/p20_feb_cni_CF_0517.csv", index = False)

## reset cf generator and shopping cart 
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()

### SP20 Run Balance Walk and sensitivity ####
# get portfolio snapshot
anchor_query, anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=["MIDDLE_MARKET", "BUSINESS_BANKING", "ABL"]
            )
## save anchor file to CSV file
anchor_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_feb/p20_feb_cni_anchor.csv")

# cf_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_CF.csv")
# anchor_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_anchor.csv")

# NOTE: need to update the switch and length of SEGFIELD2_TO_NCO_TIMING_CURVE in balancewalk.py
bw_output = balanceWalk(
    cf_data = cf_data,
    anchor_data = anchor_data,
    scenario_list = ['BASE'],
    process_ALLL_balances = False,
    debug = True
    )

bw_output.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_feb/p20_feb_cni_BW_Output_test.csv")


### Upload CF to RFO
FILE_VERSION = 1
#cf.writeToMoodysRFO(
#    p_reporting_date=PORTFOLIO_SNAPSHOT_DATE,
#    as_of_date=AS_OF_DATE,
#    p_rerun='N',
#    p_engine='ME_LOSS_ENGINE',
#    p_cycle='CCAR',
#    debug=True,
#    moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
#    table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
#    overwrite_vintage_asofdate=CONFIG['CONTRIBUTOR_FILE']["VINTAGE_ASOFDATE_VALUE"],
#    contributor_file_id=contributor_file_id,
#    file_version=FILE_VERSION
#)

"""
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
from CIFI.models.modelproperties.modelproperties import ModelProperties
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.models.riskratingmodel import Mapping
from CIFI.config import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.models.masterdataset.financialstatements import getRawMRA, getSourceSystemToMRAMap
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalk, balanceWalkMacroSensitivity, getNCOCurve, balanceWalkPivot
import datetime
import pandas as pd
from pandasql import sqldf
import numpy as np
import dateutil.relativedelta as relativedelta
import bisect
import math
import time
from tinydb import TinyDB, Query
import matplotlib.pyplot as plt
import copy


##
## GLOBAL VARIABLES
##
global MDS_SOURCEID
MDS_SOURCEID = 'SOURCEID'

global MIDDLE_MARKET_PD_GROUP
MIDDLE_MARKET_PD_GROUP = "MIDDLE_MARKET"

global BUSINESS_BANKING_PD_GROUP
BUSINESS_BANKING_PD_GROUP = "BUSINESS_BANKING"

global ABL_PD_GROUP
ABL_PD_GROUP = "ABL"

global CNI_PD_GROUP_LIST
CNI_PD_GROUP_LIST = [MIDDLE_MARKET_PD_GROUP, BUSINESS_BANKING_PD_GROUP, ABL_PD_GROUP]

global MRA_STATEMENT_MONTHS
MRA_STATEMENT_MONTHS = 12

global MRA_PRIMARY_KEY
MRA_PRIMARY_KEY = [
    'MasterCustomerID',
    'StatementDate',
    'AuditMethod'
]

global MRA_RAW_FIELDS
MRA_RAW_FIELDS = [
    'MasterCustomerID',
    'StatementID',
    'StatementDate',
    'StatementMonths',
    'AuditMethod',
    'DebtToTNW',
    'EBITDA',
    'InterestExpense',
    'CashAndEquivs',
    'NetTradeAcctsRec',
    'TotalCurLiabs',
    'ProfitBeforeTax',
    'NetSales'
]

global MRA_CLEAN_FIELDS
MRA_CLEAN_FIELDS = [
    'MasterCustomerID',
    'StatementID',
    'StatementDate',
    'StatementMonths',
    'AuditMethod',
    'DebtToTNW',
    'EBITDA',
    'InterestExpense',
    'CashAndEquivs',
    'NetTradeAcctsRec',
    'TotalCurLiabs',
    'ProfitBeforeTax',
    'NetSales'
]

global INVALID_AUDIT_METHODS
INVALID_AUDIT_METHODS = [
    'Projection',
    '',
    ' ',
    '  ',
    'Other',
    'other',
    'Interim',
    None
]
global AUDIT_METHOD_RANK_MAP
AUDIT_METHOD_RANK_MAP = {
    "Unqualif'd": 1,
    'Unqual': 2,
    'Unqual.': 3,
    'Qualified': 4,
    'Reviewed': 5,
    'Review': 6,
    'Compiled': 7,
    "Co.Prep'd": 8,
    'Co. Prep.': 9,
    'CO-PREP': 10,
    'Tax Return': 11,
    'Tax': 12
}


##
## CONTRACT-LEVEL DATASET CLASS DEFINITION
##
class CNIMasterDataset(CCMISMasterDataset):
    """
    This class inherits from CCMISMasterDataset and provides an interface with CCMIS
    portfolio granular (contract-level) data adding financial statement fields from the 
    Moody's Risk Analyst monthly extract.


    Note:
        Properties created with the ``@property`` decorator should be documented in 
        the property's getter method.

    Attributes:
        __mds_mra (pandas.DataFrame) : Result of merge between master dataset and MRA fields.
        __mds_mra_financial_ratios (pandas.DataFrame) : Master dataset with calculated financial ratios.
        __mds_mra_additional_fields (pandas.DataFrame) : Master dataset with additional fields, ready for use.
        __processed_mra_data (pandas.DataFrame) : MRA data after cleaning process.
        __raw_mra_data (pandas.DataFrame) : MRA data unaltered from original source.
        __sourcesystem_to_mra (pandas.DataFrame) : mapping from CCMIS to CCLM id system.
        __pass_SRR (float) : inclusive upper bound SRR for non-pass ratings.
        __statement_days_threshold (int) : max age of a valid/current statement (in days).

    """
    # Member properties
    __mds_mra = None
    __mds_mra_financial_ratios = None
    __mds_mra_additional_fields = None
    __processed_mra_data = None
    __raw_mra_data = None
    __sourcesystem_to_mra = None
    __pass_SRR = None
    __statement_days_threshold = None
    __mra_asofdate = None
    __financial_in_rfo = None
    __new_financial_logic = None

    # Member methods
    def __init__(
        self,
        asofdate: datetime.datetime,
        pd_groups: list,
        pass_SRR: float = 4.,
        statement_days_threshold: int = 366,
        include_originations: bool = True,
        debug: bool = False,
        limit_contracts: int = None,
        mra_asofdate: datetime.datetime = None,
        financial_in_rfo: bool = False,
        new_financial_logic: bool = True
    ):
        """
        Class constructor for the CNIMasterDataset class. 

        Note:
            As CNIMasterDataset inherits from CCMISMasterDataset, the latter's constructor will be called first. 

        Args:
            asofdate (datetime.datetime) : portfolio date (use only month ends).
            pd_groups () : list of PD_GROUPs to fetch from data source.
            pass_SRR (float) : inclusive upper bound SRR for non-pass ratings.
            statement_days_threshold (int) : max age of a valid/current statement (in days).
            include_originations (bool) : 
            debug (bool) :

        Raises:
            TypeError: If `pass_SRR` is not a float.
            TypeError: If `statement_days_threshold` is not an int.

        Examples:
            >>> sample_mds = CNIMasterDataset(
                    asofdate=datetime.datetime(2016,12,31),
                    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
                    pass_SRR=4.,
                    debug=True,
                    include_originations=True
                )

        """
        # Initialize parent class properties
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Initializing parent class..."
            )
        # If financial_in_rfo is true, call fetchCNIData() in masterdataset.py, otherwise call fetchData()
        CCMISMasterDataset.__init__(
            self,
            asofdate=asofdate,
            pd_groups=pd_groups,
            include_originations=include_originations,
            debug=debug,
            limit_contracts=limit_contracts,
            fetchCNI = financial_in_rfo
        )

        # Validating data types for derived class inputs
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Validating data types for derived class inputs..."
            )
        utilities.checkDataType(pass_SRR,float)
        utilities.checkDataType(statement_days_threshold, int)

        if mra_asofdate is not None:
            utilities.checkDataType(mra_asofdate, datetime.datetime)
            self.__mra_asofdate = mra_asofdate
        else:
            self.__mra_asofdate = self.asofdate

        # Assigning member properties
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Assigning member properties..."
            )
        self.__statement_days_threshold = statement_days_threshold
        self.__pass_SRR = pass_SRR
        self.__financial_in_rfo = financial_in_rfo
        self.__new_financial_logic = new_financial_logic

        # old method: fetch financials(raw MRA & mapping table) from source files
        if not self.financial_in_rfo:
            # Fetch and process/clean raw MRA data
            print(
                self.__class__.__name__ + " : " +
                "Fetching and processing raw MRA data {}...".format(str(self.mra_asofdate))
            )
            self.__processed_mra_data, self.__raw_mra_data = self.preProcessMRAData(
                mra_extract_asofdate=self.mra_asofdate,
                portfolio_asofdate=self.asofdate
            )
    
            # Fetch Source System to MRA Mapping table
            print(
                self.__class__.__name__ + " : " +
                "Fetching Source System to MRA Mapping table for {}...".format(str(self.mra_asofdate))
            )
            self.__sourcesystem_to_mra = getSourceSystemToMRAMap(as_of_date=self.mra_asofdate)
            
            # Merge Financails with master datasets, and calculate ratios
            print(
                self.__class__.__name__ + " : " +
                "Merging Master Data with processed MRA data using Mapping table..."
            )
            self.mergeMRA2MDS()
            
        # Process fanancial ratios
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "Process financial ratios..."
            )
        self.processFinancialRatios()
        self.processAdditionalFields()
        if debug:
            print(
                self.__class__.__name__ + " : " +
                "C&I Dataset instance initialization completed ..."
            )

    @staticmethod
    def preProcessMRAData(mra_extract_asofdate: datetime.datetime, portfolio_asofdate: datetime.datetime):
        """
        This method .

        Args:
            asofdate (datetime.datetime) : portfolio date (use only month ends).

        Raises:
            TypeError: If `pass_SRR` is not a float.
            TypeError: If `statement_days_threshold` is not an int.

        Examples:
            >>> sample_mds = CNIMasterDataset(
                    asofdate=datetime.datetime(2016,12,31),
                    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
                    pass_SRR=4.,
                    debug=True,
                    include_originations=True
                )
        """
        all_audit_method_known_values = list(AUDIT_METHOD_RANK_MAP.keys())+INVALID_AUDIT_METHODS


        raw_mra = getRawMRA(source_data_set_date=mra_extract_asofdate)

        # Filter for invalid statements
        # Include Annual Statements only/Valid audit method/statement date prior to run date
        mra_1 = raw_mra[
            (raw_mra['StatementMonths'] == MRA_STATEMENT_MONTHS)
            &
            (~raw_mra['AuditMethod'].isin(INVALID_AUDIT_METHODS))
            &
            (~pd.isnull(raw_mra['AuditMethod']))
            &
            (raw_mra['StatementDate'] <= portfolio_asofdate)
        ]

        # Check for audit method values assumption
        set_of_input_audit_method_values = set(mra_1.AuditMethod.unique().tolist())
        set_audit_method_known_values = set(all_audit_method_known_values)
        if len(set_of_input_audit_method_values - set_audit_method_known_values) != 0:
            raise ValueError("AuditMethod values have changed and don't match current list: {}".format(
                list(set_of_input_audit_method_values - set_audit_method_known_values)
            ))

        # Get the MAX StatementDate for each obligor/customer
        mra_2 = mra_1.groupby(['MasterCustomerID']).apply(
            lambda df: df['StatementDate'].values[df['StatementDate'].values.argmax()]
        ).rename("MAX_StatementDate").reset_index()

        # Merge back to the main data frame with MAX_StatementDate
        mra_3 = mra_1.merge(
            mra_2,
            left_on='MasterCustomerID',
            right_on='MasterCustomerID',
            how='left'
        )

        # Filter for all statements per obligor/customer that are the most recent
        mra_4 = mra_3[mra_3['StatementDate'] == mra_3['MAX_StatementDate']]

        # Assign AuditMethodRank
        applyAuditMethodRank = lambda x: AUDIT_METHOD_RANK_MAP[x]
        pd.set_option('mode.chained_assignment', None)  # Temp removal of warnings
        mra_4.loc[:,'AuditMethodRank'] = np.vectorize(applyAuditMethodRank)(mra_4['AuditMethod'])
        pd.set_option('mode.chained_assignment', 'warn')  # Reestablish warning message

        # Get the MIN AuditMethodRank for each obligor/customer
        mra_5 = mra_4.groupby(['MasterCustomerID']).apply(
            lambda df: df['AuditMethodRank'].values[df['AuditMethodRank'].values.argmin()]
        ).rename("MIN_AuditMethodRank").reset_index()

        # Merge back to the main data frame with MIN_AuditMethodRank
        mra_6 = mra_4.merge(
            mra_5,
            left_on='MasterCustomerID',
            right_on='MasterCustomerID',
            how='left'
        )

        # Filter for all statements per obligor/customer have highest ranking audit method
        mra_7 = mra_6[mra_6['MIN_AuditMethodRank'] == mra_6['AuditMethodRank']]

        # Remove duplicates based on primary key:
        # ['MasterCustomerID', 'StatementDate', 'AuditMethod']
        # mra_dups = mra_7[mra_7.duplicated(MRA_PRIMARY_KEY)]
        mra_8 = mra_7[~mra_7.duplicated(MRA_PRIMARY_KEY)][MRA_CLEAN_FIELDS]

        # Finish process, return data
        return(mra_8, raw_mra[list(mra_8.columns)])

    def mergeMRA2MDS(self):
        """

        Returns
        -------

        """
        # Check source id equivalence
        if self.data is None:
            raise Exception('`self.data` is None.')
        if self.sourcesystem_to_mra is None:
            raise Exception('`self.sourcesystem_to_mra` is None.')
        if len(set(self.data[MDS_SOURCEID].unique()) - set(self.sourcesystem_to_mra['SourceId'].unique())) != 0:
            raise Exception("SourceID in mapping are not subset of source id in MDS.")

        # Create temporary dataframes
        mds_tmp = self.data
        mapping_df = self.sourcesystem_to_mra
        processed_mra_data = self.processed_mra_data

        # Merge
        if self.new_financial_logic:       
            mrg_1 = sqldf("""
                SELECT DISTINCT
                    master_dataset.*,
                    srcsysmap_1.MasterCustomerId,
                    srcsysmap_1.MasterOneObligorId
                FROM
                    mds_tmp AS master_dataset
                LEFT JOIN
                    mapping_df AS srcsysmap_1
                    ON
                    (master_dataset.SOURCEID = srcsysmap_1.SourceId)
                    AND
                    (master_dataset.CUSTOMERNUMBER = srcsysmap_1.CustomerNumber)
                ORDER BY
                    master_dataset.UNIQUE_FACILITY_ID;
            """)
        
        else:
            # old merge logic
            mrg_1 = sqldf("""
                SELECT DISTINCT
                    master_dataset.*,
                    COALESCE(srcsysmap_1.MasterCustomerId, srcsysmap_2.MasterCustomerId) AS MasterCustomerId,
                    COALESCE(srcsysmap_1.MasterOneObligorId, srcsysmap_2.MasterOneObligorId) AS MasterOneObligorId
                FROM
                    mds_tmp AS master_dataset
                LEFT JOIN
                    mapping_df AS srcsysmap_1
                    ON
                    (master_dataset.SOURCEID = srcsysmap_1.SourceId)
                    AND
                    (master_dataset.ONEOBLIGORNUMBER = srcsysmap_1.OneObligorNumber)
                LEFT JOIN
                    mapping_df AS srcsysmap_2
                    ON
                    (master_dataset.SOURCEID = srcsysmap_2.SourceId)
                    AND
                    (master_dataset.CUSTOMERNUMBER = srcsysmap_2.CustomerNumber)
                ORDER BY
                    master_dataset.UNIQUE_FACILITY_ID;
            """)
        
        mrg_dups_1 = mrg_1[mrg_1.duplicated(['ASOFDATE', 'UNIQUE_FACILITY_ID', 'IS_ORIG'], keep=False)]
        if mrg_dups_1.__len__() != 0:
            raise Exception("First step merger created duplicates.")
            
        if self.new_financial_logic:   
            mrg_2 = sqldf("""
            SELECT
                master_dataset.*,
                COALESCE(t1.MasterCustomerID, t2.MasterCustomerID) AS MC_MasterCustomer_ID,
                COALESCE(t1.StatementMonths, t2.StatementMonths) AS StatementMonths,
                COALESCE(t1.StatementID, t2.StatementID) AS StatementID,
                COALESCE(t1.AuditMethod, t2.AuditMethod) AS AuditMethod,
                COALESCE(t1.StatementDate, t2.StatementDate) AS StatementDate,
                COALESCE(t1.DebtToTNW, t2.DebtToTNW) AS DebtToTNW,
                COALESCE(t1.EBITDA, t2.EBITDA) AS EBITDA,
                COALESCE(t1.InterestExpense, t2.InterestExpense) AS InterestExpense,
                COALESCE(t1.CashAndEquivs, t2.CashAndEquivs) AS CashAndEquivs,
                COALESCE(t1.NetTradeAcctsRec, t2.NetTradeAcctsRec) AS NetTradeAcctsRec,
                COALESCE(t1.TotalCurLiabs, t2.TotalCurLiabs) AS TotalCurLiabs,
                COALESCE(t1.ProfitBeforeTax, t2.ProfitBeforeTax) AS ProfitBeforeTax,
                COALESCE(t1.NetSales, t2.NetSales) AS NetSales
            FROM
                mrg_1 AS master_dataset
            LEFT JOIN
                processed_mra_data AS t1
                ON
                (master_dataset.MasterCustomerId = t1.MasterCustomerID)
            LEFT JOIN
                processed_mra_data AS t2
                ON
                (master_dataset.MasterOneObligorId = t2.MasterCustomerID)
            ORDER BY
                master_dataset.FacilityNumber;
            """)
        else:
            # old merge logic
            mrg_2 = sqldf("""
            SELECT
                master_dataset.*,
                COALESCE(t1.StatementDate, t2.StatementDate) AS StatementDate,
                COALESCE(t1.DebtToTNW, t2.DebtToTNW) AS DebtToTNW,
                COALESCE(t1.EBITDA, t2.EBITDA) AS EBITDA,
                COALESCE(t1.InterestExpense, t2.InterestExpense) AS InterestExpense,
                COALESCE(t1.CashAndEquivs, t2.CashAndEquivs) AS CashAndEquivs,
                COALESCE(t1.NetTradeAcctsRec, t2.NetTradeAcctsRec) AS NetTradeAcctsRec,
                COALESCE(t1.TotalCurLiabs, t2.TotalCurLiabs) AS TotalCurLiabs,
                COALESCE(t1.ProfitBeforeTax, t2.ProfitBeforeTax) AS ProfitBeforeTax,
                COALESCE(t1.NetSales, t2.NetSales) AS NetSales
            FROM
                mrg_1 AS master_dataset
            LEFT JOIN
                processed_mra_data AS t1
                ON
                (master_dataset.MasterOneObligorId = t1.MasterCustomerID)
            LEFT JOIN
                processed_mra_data AS t2
                ON
                (master_dataset.MasterCustomerId = t2.MasterCustomerID)
            ORDER BY
                master_dataset.FacilityNumber;
            """)
        
        mrg_dups_2 = mrg_2[mrg_2.duplicated(['ASOFDATE', 'UNIQUE_FACILITY_ID', 'IS_ORIG'], keep=False)]
        if mrg_dups_2.__len__() != 0:
            raise Exception("Second step merger created duplicates.")

        if mds_tmp.__len__() != mrg_2.__len__():
            print("MDS : " + str(mds_tmp.__len__()))
            print("MERGE : " + str(mrg_2.__len__()))

        # Parse date fields
        parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S.%f')
        mrg_2["StatementDate"] = mrg_2["StatementDate"].apply(parse_date)
        mrg_2["ASOFDATE"] = mrg_2["ASOFDATE"].apply(parse_date)
        mrg_2["MAXIMUMMATURITYDATE"] = mrg_2["MAXIMUMMATURITYDATE"].apply(parse_date)

        self.__mds_mra = mrg_2

    def processFinancialRatios(self, new_ratio_approach: bool= True):
        """

        Returns
        -------

        """
        # Check for master data
        if self.data is None:
            raise Exception('`self.data` is None.')
            
        # If financials fetched from MV_LOSS_COMMERCIAL, parse date field and assign self.data to mds_mra_tmp 
        if self.financial_in_rfo:
            # Parse date fields
            parse_date = lambda x: pd.NaT if pd.isnull(x) else x
            self.data["StatementDate"] = self.data["StatementDate"].apply(parse_date)
#            self.data["ASOFDATE"] = self.data["ASOFDATE"].apply(parse_date)
#            self.data["MAXIMUMMATURITYDATE"] = self.data["MAXIMUMMATURITYDATE"].apply(parse_date)
            mds_mra_tmp = self.data.copy(deep=True)
        else:
            mds_mra_tmp = self.mds_mra.copy(deep=True)
            
        # Checks
        if mds_mra_tmp is None:
            raise Exception('`self.mds_mra or self.data` is None.')
        utilities.checkDataType(new_ratio_approach, bool)
        
        # Process ratios
        if new_ratio_approach:

            # DebtToTNW
            mds_mra_tmp['r_DebtToTNW1'] = round(
                mds_mra_tmp['DebtToTNW'],
                self.precision
            )

            # r_EBITDAoIntrst
            def r_EBITDAoIntrst(line):
                if pd.isnull(line['EBITDA']):
                    return (np.NaN)
                elif (pd.isnull(line['InterestExpense'])) or (line['InterestExpense'] < 0):
                    return (np.NaN)
                elif (line['InterestExpense'] == 0) and (pd.notnull(line['EBITDA'])):
                    return (line['EBITDA'])
                else:
                    return (line['EBITDA'] / line['InterestExpense'])
            mds_mra_tmp['r_EBITDAoIntrst'] = round(
                mds_mra_tmp.apply(
                    func=r_EBITDAoIntrst,
                    axis=1
                ),
                self.precision
            )

            # r_quickRatio
            def r_quickRatio(line):
                if pd.isnull(line['CashAndEquivs'] + line['NetTradeAcctsRec']):
                    return (np.NaN)
                elif (pd.isnull(line['TotalCurLiabs'])) or (line['TotalCurLiabs'] < 0):
                    return (np.NaN)
                elif (line['TotalCurLiabs'] == 0) and (pd.notnull(line['CashAndEquivs'] + line['NetTradeAcctsRec'])):
                    return (line['CashAndEquivs'] + line['NetTradeAcctsRec'])
                else:
                    return ((line['CashAndEquivs'] + line['NetTradeAcctsRec']) / line['TotalCurLiabs'])
            mds_mra_tmp['r_quickRatio'] = round(
                mds_mra_tmp.apply(
                    func=r_quickRatio,
                    axis=1
                ),
                self.precision
            )

            # r_proftmargin
            def r_proftmargin(line):
                if pd.isnull(line['ProfitBeforeTax']):
                    return (np.NaN)
                elif (pd.isnull(line['NetSales'])) or (line['NetSales'] < 0):
                    return (np.NaN)
                elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] >= 0):
                    return (np.NaN)
                elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] < 0):
                    return (line['ProfitBeforeTax'])
                else:
                    return (line['ProfitBeforeTax'] / line['NetSales'])
            mds_mra_tmp['r_proftmargin'] = round(
                mds_mra_tmp.apply(
                    func=r_proftmargin,
                    axis=1
                ),
                self.precision
            )

        else:
            # DebtToTNW
            mds_mra_tmp['r_DebtToTNW1'] = round(
                mds_mra_tmp['DebtToTNW'],
                self.precision
            )

            # r_EBITDAoIntrst
            def r_EBITDAoIntrst(line):
                if line['InterestExpense'] == 0:
                    return (np.NaN)
                else:
                    return (line['EBITDA'] / line['InterestExpense'])
            mds_mra_tmp['r_EBITDAoIntrst'] = round(
                mds_mra_tmp.apply(
                    func=r_EBITDAoIntrst,
                    axis=1
                ),
                self.precision
            )

            # r_quickRatio
            def r_quickRatio(line):
                if line['TotalCurLiabs'] == 0:
                    return (np.NaN)
                else:
                    return ((line['CashAndEquivs'] + line['NetTradeAcctsRec']) / line['TotalCurLiabs'])
            mds_mra_tmp['r_quickRatio'] = round(
                mds_mra_tmp.apply(
                    func=r_quickRatio,
                    axis=1
                ),
                self.precision
            )

            # r_proftmargin
            def r_proftmargin(line):
                if line['NetSales'] == 0:
                    return (np.NaN)
                else:
                    return (line['ProfitBeforeTax'] / line['NetSales'])
            mds_mra_tmp['r_proftmargin'] = round(
                mds_mra_tmp.apply(
                    func=r_proftmargin,
                    axis=1
                ),
                self.precision
            )

        # Finalize
        self.__mds_mra_financial_ratios = mds_mra_tmp

    def processAdditionalFields(self):
        """

        Returns
        -------

        """
        # Checks
        if self.mds_mra_financial_ratios is None:
            raise Exception('`self.mds_mra_financial_ratios` is None.')

        # Prepare data
        mds_additional_fields_tmp = self.mds_mra_financial_ratios.copy(deep=True)

        # Process SRR pass/non-pass
        def SRR_rating_pass(line):
            if line["SRR"] <= self.__pass_SRR:
                return False
            else:
                return True
        mds_additional_fields_tmp["SRR_rating_pass"] = mds_additional_fields_tmp.apply(
            func=SRR_rating_pass,
            axis=1
        )

        # Compute statement age in days
        def statementAgeInDays(line):
            # old code
            # return(utilities.daysDifference(line["ASOFDATE"],line["StatementDate"]))
            diff = utilities.daysDifference(line["ASOFDATE"],line["StatementDate"]) 
            # for missing statement date, return -1
            if int(diff) < 0:
                return -1
            else:
                return int(diff)
        
        mds_additional_fields_tmp["asofdate2stmtdate"] = mds_additional_fields_tmp.apply(
            func=statementAgeInDays,
            axis=1
        )

        # Compute months to maturity
        def monthsToMaturity(line):
            mat_d = line["MAXIMUMMATURITYDATE"]
            as_of_d = line["ASOFDATE"]

            try:
                r_delta = relativedelta.relativedelta(mat_d, as_of_d)
            except (TypeError, AssertionError):
                m2mat = np.nan
            else:
                m2mat = r_delta.years * 12 + r_delta.months
            return(m2mat)
        mds_additional_fields_tmp["m2mat"] = mds_additional_fields_tmp.apply(
            func=monthsToMaturity,
            axis=1
        )

        # Compute maturity indicator
        def maturityIndicator(line):
            if pd.isnull(line["m2mat"]):
                return(False)
            elif line["m2mat"] <= 0:
                return(True)
            else:
                return(False)

        mds_additional_fields_tmp["matureInd"] = mds_additional_fields_tmp.apply(
            func=maturityIndicator,
            axis=1
        )

        # Collateral Type
        COLLATERAL_TYPE_MAP = Mapping(
            in_map={
                'IN_VAR': 'COLLATERALCODE',
                'OUT_VAR': 'COLLATERAL_TYPE',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    '14',
                    '30',
                    '38',
                    '123',
                    '140',
                    '170',
                    '199',
                    '204',
                    '219',
                    '230',
                    '253',
                    '257',
                    '258',
                    '259',
                    '260',
                    '264',
                    '265',
                    '269',
                    '270',
                    '310',
                    '402',
                    '406',
                    '502',
                    '552',
                    '800',
                    '812',
                    '816',
                    '899',
                    '1',
                    '10',
                    '100',
                    '103',
                    '104',
                    '106',
                    '12',
                    '120',
                    '127',
                    '20',
                    '200',
                    '208',
                    '209',
                    '210',
                    '212',
                    '22',
                    '232',
                    '235',
                    '240',
                    '250',
                    '251',
                    '252',
                    '254',
                    '255',
                    '256',
                    '261',
                    '262',
                    '263',
                    '266',
                    '267',
                    '268',
                    '271',
                    '272',
                    '273',
                    '274',
                    '275',
                    '276',
                    '290',
                    '300',
                    '304',
                    '308',
                    '312',
                    '318',
                    '321',
                    '34',
                    '400',
                    '404',
                    '419',
                    '50',
                    '52',
                    '60',
                    '61',
                    '999'
                ),
                'MAPPED_VALUES': (
                    'FINANCIAL ASSETS',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'ALL ASSETS/OTHER',
                    'RESIDENTIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'FINANCIAL ASSETS',
                    'RESIDENTIAL PROPERTIES',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'UNSECURED',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER',
                    'ALL ASSETS/OTHER',
                    'RESIDENTIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'HOSPITAL/ MEDICAL CARE PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'COMMERCIAL PROPERTIES',
                    'RESIDENTIAL PROPERTIES',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'FINANCIAL ASSETS',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'COMMERCIAL PROPERTIES',
                    'EQUIPMENT/VEHICLE',
                    'EQUIPMENT/VEHICLE',
                    'ALL ASSETS/OTHER',
                    'FINANCIAL ASSETS',
                    'ALL ASSETS/OTHER'
                ),
                'MISSING': 'ALL ASSETS/OTHER',
                'DEFAULT': 'ALL ASSETS/OTHER'
            },
            debug=False
        )
        mds_additional_fields_tmp['COLLATERAL_TYPE'] = [
            COLLATERAL_TYPE_MAP.apply(item) \
            for item in mds_additional_fields_tmp['COLLATERALCODE']
        ]


        # Finalize
        self.__mds_mra_additional_fields = mds_additional_fields_tmp

    @property
    def pass_SRR(self):
        return(self.__pass_SRR)

    @property
    def statement_days_threshold(self):
        return(self.__statement_days_threshold)

    @property
    def mds_mra(self):
        return(self.__mds_mra)

    @property
    def raw_mra_data(self):
        return (self.__raw_mra_data)

    @property
    def processed_mra_data(self):
        return (self.__processed_mra_data)

    @property
    def sourcesystem_to_mra(self):
        return(self.__sourcesystem_to_mra)

    @property
    def mds_mra_financial_ratios(self):
        return(self.__mds_mra_financial_ratios)

    @property
    def mds_mra_additional_fields(self):
        return(self.__mds_mra_additional_fields)

    @property
    def mra_asofdate(self):
        return (self.__mra_asofdate)

    @property
    def financial_in_rfo(self):
        return (self.__financial_in_rfo)

    @property
    def new_financial_logic(self):
        return (self.__new_financial_logic)

##
## C&I MODEL CLASS DEFINITION
##
class CNIModel(CCARModel):
    # Member properties
    __pass_srr = None
    __portfolio_snapshot = None
    __cni_mds_instance = None
    __include_originations_switch = None
    __scenario_severity_level_level = None
    __pd_groups = None
    __results_set = None
    __scenario_period_frequency = None
    __statement_days_threshold = None
    __SRR_overlay_switch = None
    __PD_mapping_switch = None
    __calculation_periods = None
    __results_df = None
    __MRS_notch_down_switch = None
    __portfolio_snapshot_date = None
    __mature_non_pass_locs = None
    __mra_asofdate = None
    __financial_in_rfo = None
    __new_financial_logic = None

    # Member methods
    def __init__(
        self,
        as_of_date: datetime.datetime,
        scenario: str,
        scenario_context: str,
        scenario_date: datetime.datetime,
        scenario_severity_level: str,
        forecast_periods: int,
        pass_srr: (int, float) = 4.0,
        model_id: str = "2016-SBNA-Loss-Commecial-CI",
        forecast_periods_frequency: str = 'monthly',
        debug: bool = False,
        include_originations_switch: bool = True,
        precision: int = None,
        auto_fetch_macros: bool = True,
        pd_groups: list = CNI_PD_GROUP_LIST,
        limit_contracts=None,
        statement_days_threshold=366,
        SRR_overlay_switch: bool =True,
        PD_mapping_switch: bool =True,
        MRS_notch_down_switch=False,
        portfolio_snapshot_date=None,
        mature_non_pass_locs: bool=True,
        mra_asofdate: datetime.datetime = None,
        financial_in_rfo: bool = False,
        new_financial_logic: bool = True,
        **kwargs
    ):
        # Initialize parent class properties
        CCARModel.__init__(
            self,
            as_of_date=as_of_date,
            model_id=model_id,
            scenario=scenario,
            scenario_date=scenario_date,
            scenario_context=scenario_context,
            forecast_periods=forecast_periods,
            forecast_periods_frequency=forecast_periods_frequency,
            precision=precision,
            scenario_combinations=kwargs.get("scenario_combinations")
        )

        # Check data types
        utilities.checkDataType(debug, bool)
        utilities.checkDataType(pass_srr, float)
        utilities.checkDataType(include_originations_switch, bool)
        utilities.checkDataType(auto_fetch_macros, bool)
        utilities.checkDataType(scenario_severity_level, str)
        utilities.checkDataType(pd_groups, list)
        utilities.checkDataType(statement_days_threshold, int)
        utilities.checkDataType(SRR_overlay_switch, bool)
        utilities.checkDataType(PD_mapping_switch, bool)
        utilities.checkDataType(MRS_notch_down_switch, bool)
        utilities.checkDataType(mature_non_pass_locs, bool)
        utilities.checkDataType(financial_in_rfo, bool)
        utilities.checkDataType(new_financial_logic, bool)
        

        # Process portfolio snapshot date
        if portfolio_snapshot_date is not None:
            utilities.checkDataType(portfolio_snapshot_date, datetime.datetime)
        else:
            portfolio_snapshot_date = self.as_of_date
        
        # Process mra as of date
        if mra_asofdate is not None:
            utilities.checkDataType(mra_asofdate, datetime.datetime)
        else:
            mra_asofdate = self.as_of_date
        
        # Assign member properties
        self.debug = debug
        self.__pass_srr = pass_srr
        self.__include_originations_switch = include_originations_switch
        self.__pd_groups = pd_groups
        self.__statement_days_threshold = statement_days_threshold
        self.__SRR_overlay_switch = SRR_overlay_switch
        self.__PD_mapping_switch = PD_mapping_switch
        self.__MRS_notch_down_switch = MRS_notch_down_switch
        self.__portfolio_snapshot_date = portfolio_snapshot_date
        self.__mature_non_pass_locs = mature_non_pass_locs
        self.__financial_in_rfo = financial_in_rfo
        self.__new_financial_logic = new_financial_logic

        # Get macro variables during construction
        if auto_fetch_macros:
            self.fetchMacroSeries(scenario_combinations=kwargs.get('scenario_combinations'))

        # Validate scenario severity
        if scenario_severity_level in utilities.SCENARIO_SEVERITY_LEVELS:
            self.__scenario_severity_level = utilities.SCENARIO_SEVERITY_LEVELS[scenario_severity_level]
        else:
            raise ValueError("Invalid input `scenario_severity_level`.")

        # Get scenario period frequency
        self.__scenario_period_frequency = self._model_properties.getParameters(
            type='property',
            name='scenario_period_frequency'
        )
        self.__calculation_periods = int(
            self.forecast_periods / utilities.PERIOD_FREQUENCY_MAP[
                self.scenario_period_frequency
            ]
        )

        # Get portfolio snapshot/data
        # self.portfolio_snapshot = pd.read_csv('C:\\Users\\n844639\\Desktop\\MyABL\\cni_data.csv')
        self._logger.add(
            type='INFO',
            message='Fetching portfolio snapshot from RFO for date {}'.format(
                str(self.__portfolio_snapshot_date)
            ),
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        # Starting timer
        t_0 = time.time()
        self.__cni_mds_instance = CNIMasterDataset(
            asofdate=portfolio_snapshot_date,
            pd_groups=pd_groups,
            pass_SRR=pass_srr,
            limit_contracts=limit_contracts,
            include_originations=include_originations_switch,
            statement_days_threshold=statement_days_threshold,
            mra_asofdate = mra_asofdate,
            financial_in_rfo = financial_in_rfo,
            new_financial_logic = new_financial_logic
        )
        self.__portfolio_snapshot = self.__cni_mds_instance.mds_mra_additional_fields

        # Calculating runtime
        t_1 = time.time()
        runtime = round((t_1 - t_0), 4)
        self._logger.add(
            type='INFO',
            message='Fetching snapshots completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Fetching coverage rates from model property JSON file
        self._logger.add(
            type='INFO',
            message='Fetching Coverage rates from JSON file...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        ## ALLL mapping ##
        alll_abl = self._model_properties.getParameters(
                            type = 'property',
                            name = 'alll_coverage',
                            segment = 'ABL' 
                        )[0]
        alll_mm = self._model_properties.getParameters(
                            type = 'property',
                            name = 'alll_coverage',
                            segment = 'MIDDLE_MARKET' 
                        )[0]
        alll_ubb = self._model_properties.getParameters(
                            type = 'property',
                            name = 'alll_coverage',
                            segment = 'BUSINESS_BANKING' 
                        )[0]   
        alll_all = self._model_properties.getParameters(
                            type = 'property',
                            name = 'alll_coverage',
                            segment = 'all' 
                        )[0]   
        # Begin from Mid-cycle 2017, use different ALLL rates for each PD Groups
        if self.as_of_date >= datetime.datetime(2017,6,30):          
            if (alll_abl is None) or (alll_mm is None) or (alll_ubb is None):
                raise Exception('`alll_abl/alll_mm/alll_ubb` is None.')                                                
        else:
            if alll_all is None:
                raise Exception('`alll_all` is None.')
                
        alll_srr_sorted = [float(key) for key in sorted(alll_all, reverse = True)]
        alll_rate_sorted = [alll_all[item] for item in sorted(alll_all, reverse = True)]

        alll_abl_srr_sorted = [float(key) for key in sorted(alll_abl, reverse = True)]
        alll_abl_rate_sorted = [alll_abl[item] for item in sorted(alll_abl, reverse = True)]

        alll_mm_srr_sorted = [float(key) for key in sorted(alll_mm, reverse = True)]
        alll_mm_rate_sorted = [alll_mm[item] for item in sorted(alll_mm, reverse = True)]

        alll_ubb_srr_sorted = [float(key) for key in sorted(alll_ubb, reverse = True)]
        alll_ubb_rate_sorted = [alll_ubb[item] for item in sorted(alll_ubb, reverse = True)]

        ## CONTINGENCY mapping ##
        contingent_abl = self._model_properties.getParameters(
                            type = 'property',
                            name = 'contingent_reserve',
                            segment = 'ABL' 
                        )[0]                                                              
        contingent_mm = self._model_properties.getParameters(
                            type = 'property',
                            name = 'contingent_reserve',
                            segment = 'MIDDLE_MARKET' 
                        )[0]
        contingent_ubb = self._model_properties.getParameters(
                            type = 'property',
                            name = 'contingent_reserve',
                            segment = 'BUSINESS_BANKING' 
                        )[0]   
        contingent_all = self._model_properties.getParameters(
                            type = 'property',
                            name = 'contingent_reserve',
                            segment = 'all' 
                        )[0]   
        # Begin from Mid-cycle 2017, use different Coverage rates for each PD Groups
        if self.as_of_date >= datetime.datetime(2017,6,30):          
            if (contingent_abl is None) or (contingent_mm is None) or (contingent_ubb is None):
                raise Exception('`contingent_abl/contingent_mm/contingent_ubb` is None.')                                                
        else:
            if contingent_all is None:
                raise Exception('`contingent_all` is None.')
                
        contingent_srr_sorted = [float(key) for key in sorted(contingent_all, reverse = True)]
        contingent_rate_sorted = [contingent_all[item] for item in sorted(contingent_all, reverse = True)]

        contingent_abl_srr_sorted = [float(key) for key in sorted(contingent_abl, reverse = True)]
        contingent_abl_rate_sorted = [contingent_abl[item] for item in sorted(contingent_abl, reverse = True)]

        contingent_mm_srr_sorted = [float(key) for key in sorted(contingent_mm, reverse = True)]
        contingent_mm_rate_sorted = [contingent_mm[item] for item in sorted(contingent_mm, reverse = True)]

        contingent_ubb_srr_sorted = [float(key) for key in sorted(contingent_ubb, reverse = True)]
        contingent_ubb_rate_sorted = [contingent_ubb[item] for item in sorted(contingent_ubb, reverse = True)]
          
        # Fetch mappings
        list_of_mappings = [
            {
                'IN_VAR': 'estimated_PD',
                'OUT_VAR': 'STDR_RR_OPR',
                'TYPE': 'interval_right',
                'IN_VALUES': (
                    0.0008, 0.0013, 0.0021, 0.0034, 0.0054,
                    0.0087, 0.0141, 0.0226, 0.0364, 0.0586, 0.0944,
                    0.1520
                ),
                'MAPPED_VALUES': (
                    8.5, 8.0, 7.5, 7.0, 6.5,
                    6.0, 5.5, 5.0, 4.5, 4.0,
                    3.5, 3.0, 1.5
                ),

                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<=1)"
            },
            {
                'IN_VAR': 'final_rating',
                'OUT_VAR': 'MRS_PD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    1, 1.5, 2, 2.5, 3,
                    3.5, 4, 4.5, 5, 5.5,
                    6, 6.5, 7, 7.5, 8,
                    8.5
                ),
                'MAPPED_VALUES': (
                    1.0, 0.58, 0.58, 0.58,
                    0.1198, 0.0744, 0.0462, 0.0287,
                    0.0178, 0.0111, 0.0069, 0.0043,
                    0.0027, 0.0016, 0.001, 0.0006
                ),
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=1) and (x<=8.5)"

            },
            {
                'IN_VAR': 'r_DebtToTNW1',
                'OUT_VAR': 'V_Debt2TNW',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -1.009854, 0.752294, 2.113506, 3.357537
                ),
                'MAPPED_VALUES': (
                    -0.64, 0.69, 0.54, 0.31, -0.24
                ),

                'MISSING': -0.64,
            },
            {
                'IN_VAR': 'r_EBITDAoIntrst',
                'OUT_VAR': 'V_EBITDA2IntExp',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    1.13793103448275, 3.46031746031746, 8.00684931506849, 20.8333333333333
                ),
                'MAPPED_VALUES': (
                    -0.96, -0.21, 0.09, 0.7, 1.28
                ),

                'MISSING': 0.52,

            },
            {
                'IN_VAR': 'r_quickRatio',
                'OUT_VAR': 'V_QuickR',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    0.46828143021914, 1.06599578750292, 1.61751152073732
                ),
                'MAPPED_VALUES': (
                    -0.51, -0.12, 0.59, 0.79,
                ),

                'MISSING': 0.06,
            },
            {
                'IN_VAR': 'ChgSales',
                'OUT_VAR': 'V_ChgSales',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -0.12697919900651, -0.04720423778693, 0, 0.0835806132542,
                    0.15284210526315, 0.30612244897959
                ),
                'MAPPED_VALUES': (
                    -0.65, -0.11, 0.17, 0.39, 0.7, 0.06, -0.27
                ),

                'MISSING': 0.35,
            },
            {
                'IN_VAR': 'r_proftmargin',
                'OUT_VAR': 'V_ProfitM',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -0.01217656, 0.0040471885, 0.02028458976687, 0.29189044038668,
                ),
                'MAPPED_VALUES': (
                    -0.78, 0.1, 0.19, 0.33, 0.75
                ),

                'MISSING': 0.81,
            },
            {
                'IN_VAR': 'LGD_BASE_BUSINESS_BANKING',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.44, 0.32, 0.26, 0.36, 0.33, 0.18, 0.5, 0.41
                ),
                'MISSING': 0.44,
                'DEFAULT': 0.44
            },
            {
                'IN_VAR': 'LGD_ADVERSE_BUSINESS_BANKING',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.465, 0.36, 0.285, 0.385, 0.355, 0.215, 0.52, 0.435
                ),
                'MISSING': 0.465,
                'DEFAULT': 0.465
            },
            {
                'IN_VAR': 'LGD_STRESS_BUSINESS_BANKING',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.49, 0.38, 0.31, 0.41, 0.38, 0.25, 0.54, 0.46
                ),

                'MISSING': 0.49,
                'DEFAULT': 0.49
            },
            {
                'IN_VAR': 'LGD_BASE_MIDDLE_MARKET',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.37, 0.32, 0.26, 0.36, 0.33, 0.18, 0.5, 0.41
                ),
                'MISSING': 0.37,
                'DEFAULT': 0.37
            },
            {
                'IN_VAR': 'LGD_ADVERSE_MIDDLE_MARKET',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.38, 0.36, 0.285, 0.385, 0.355, 0.215, 0.52, 0.435
                ),
                'MISSING': 0.38,
                'DEFAULT': 0.38
            },
            {
                'IN_VAR': 'LGD_STRESS_MIDDLE_MARKET',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'All Assets',
                    'Commercial Properties < 300000', 'Commercial Properties >= 300000',
                    'Residential Properties', 'Equipment/Vehicle', 'Financial Assets', 'Unsecured',
                    'Aviation'
                ),
                'MAPPED_VALUES': (
                    0.39, 0.38, 0.31, 0.41, 0.38, 0.25, 0.54, 0.46
                ),

                'MISSING': 0.39,
                'DEFAULT': 0.39
            },
            {
                'IN_VAR': 'LGD_ABL_AR',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'BASE', 'ADVERSE', 'STRESS'
                ),
                'MAPPED_VALUES': (
                    0.125, 0.16, 0.195
                ),
                'MISSING': 0.125
            },
            {
                'IN_VAR': 'LGD_ABL_NonAR',
                'OUT_VAR': 'NEW_LGD',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'BASE', 'ADVERSE', 'STRESS'
                ),
                'MAPPED_VALUES': (
                    0.175, 0.208, 0.241
                ),
                'MISSING': 0.175
            },
            {
                'IN_VAR': 'ALLL_SRR',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_srr_sorted,
                'MAPPED_VALUES': alll_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'ALLL_SRR_ABL',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_abl_srr_sorted,
                'MAPPED_VALUES': alll_abl_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'ALLL_SRR_MM',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_mm_srr_sorted,
                'MAPPED_VALUES': alll_mm_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'ALLL_SRR_UBB',
                'OUT_VAR': 'ALLL',
                'TYPE': 'categorical',
                'IN_VALUES': alll_ubb_srr_sorted,
                'MAPPED_VALUES': alll_ubb_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'CONTINGENCY_SRR',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_srr_sorted,
                'MAPPED_VALUES': contingent_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
                        {
                'IN_VAR': 'CONTINGENCY_SRR_ABL',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_abl_srr_sorted,
                'MAPPED_VALUES': contingent_abl_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'CONTINGENCY_SRR_MM',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_mm_srr_sorted,
                'MAPPED_VALUES': contingent_mm_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
            {
                'IN_VAR': 'CONTINGENCY_SRR_UBB',
                'OUT_VAR': 'CONTINGENCY',
                'TYPE': 'categorical',
                'IN_VALUES': contingent_ubb_srr_sorted,
                'MAPPED_VALUES': contingent_ubb_rate_sorted,
                'MISSING': 0,
                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
            },
        ]

        # Processing macro drivers
        self._logger.add(
            type='INFO',
            message='Processing macro drivers...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self.macro_data = self.transformMacroData()


        # Processing all mappings
        self._logger.add(
            type='INFO',
            message='Processing mappings...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        self._mappings = self.processMappings(list_of_mappings=list_of_mappings)  
        
        # Finalize and clean up
        self._logger.add(
            type='INFO',
            message='CCAR Model initialization completed.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

    @property
    def mappings(self):
        return self._mappings

    @property
    def portfolio_snapshot(self):
        return(self.__portfolio_snapshot)

    @property
    def portfolio_snapshot_date(self):
        return(self.__portfolio_snapshot_date)

    @property
    def mra_asofdate(self):
        return(self.__mra_asofdate)
    
    @property
    def pass_srr(self):
        return (self.__pass_srr)

    @property
    def scenario_severity_level(self):
        return(self.__scenario_severity_level)

    @property
    def pd_groups(self):
        return(self.__pd_groups)

    @property
    def results_set(self):
        return(self.__results_set)

    @property
    def scenario_period_frequency(self):
        return(self.__scenario_period_frequency)

    @property
    def statement_days_threshold(self):
        return (self.__statement_days_threshold)

    @property
    def include_originations_switch(self):
        return (self.__include_originations_switch)

    @property
    def SRR_overlay_switch(self):
        return (self.__SRR_overlay_switch)

    @property
    def PD_mapping_switch(self):
        return (self.__PD_mapping_switch)

    @property
    def calculation_periods(self):
        return (self.__calculation_periods)

    @property
    def results_df(self):
        return (self.__results_df)

    @property
    def MRS_notch_down_switch(self):
        return (self.__MRS_notch_down_switch)

    @property
    def mature_non_pass_locs(self):
        return (self.__mature_non_pass_locs)
        
    @property
    def financial_in_rfo(self):
        return (self.__financial_in_rfo)

    @property
    def new_financial_logic(self):
        return (self.__new_financial_logic)

    def transformMacroData(self):
        """This function computes macro_data from regression, using methods in slide 34 of CCAR/DFAST 2016 Wholesale models

        Return:
            a data frame, row -> different quarters, column -> different macro variables necessary for CNI/ABL models
        """
        macro_coef = {
            'diff_proftmargin': {
                'intercept': -0.00093,
                'FZ_US_p1y': 0.01588
            },
            'pct_chg_netsales': {
                'intercept': 0.00061,
                'FGDPQ_US_p1y': 1.49628
            },
            'PD_mapping_NonPass': {
                'intercept': -0.08708,
                'FLBR_US_d1y_l1q': 0.26289,
                'FHOFHOPIQ_US_p1y': -1.79959
            },
            'PD_mapping_Pass': {
                'intercept': -0.02841,
                'FLBR_US_d1y_l1q': 0.22778,
                'FHOFHOPIQ_US_p1y': -1.68640
            }
        }
        self.transformed_macro_series['intercept'] = 1 # needed for loop computation
        temp = []
        for i in range(self.calculation_periods):
            temp.append({})
            for elem in macro_coef.keys():
                temp_sum = 0
                for key, value in macro_coef[elem].items():
                    temp_sum += value * self.transformed_macro_series.iloc[i][key]
                temp[-1][elem] = temp_sum
        return pd.DataFrame(temp)

    def processMappings(self, list_of_mappings):
        """ This function associates some mappings with the CNI Model

        Args:
            list_of_mapping: a mapping list, which will be the keys of the mapping dictionaries
        Return:
            mapping_dict: a mapping dictionary, key-> 'IN_VAR' of the mapping, value->mapping object corresponding
                             to the key
        """
        mapping_dict = {}
        for mapping in list_of_mappings:
            mapping_dict[mapping['IN_VAR']] = Mapping(
                in_map=mapping,
                precision=self.precision
            )
        return mapping_dict

    def getRegVariables(self, macro_data, input_data):
        """This function transforms data to get ready for mapping, then calls the mapping function 'process_model_inputs',
           finally returns processed regression variable, which will be ready to calculate PD

        Args:
            macro_data: a dataframe containing r_proftmargin, pct_chg_netsales, and PD_mapping, rows corresponding to
                        different quarters
            input_data: the data of one contract, read directly from excel file

        Return:
            dictionary: mapped value as explanatory variables for computing PD

        """
        invariant_data = {}
        invariant_data['asofdate2stmtdate'] = input_data['asofdate2stmtdate']
        invariant_data['r_EBITDAoIntrst'] = input_data['r_EBITDAoIntrst']
        invariant_data['r_quickRatio'] = input_data['r_quickRatio']
        invariant_data['r_DebtToTNW1'] = input_data['r_DebtToTNW1']
        invariant_data['PD_GROUP'] = input_data['PD_GROUP']

        regression_variables = self.process_model_inputs(macro_data, invariant_data)
        return regression_variables

    # apply mapping to input data
    def process_model_inputs(self, macro_data, invariant_data):
        """This function apply mapping to input data, then it is called in the function getRegVariables()

        Args:
            macro_data: same as getRegVariables()
            invariant_data: same as input_data in getRegVariables()

        Return:
            dictionary: mapped value as explanatory variables for computing PD
        """
        regression_variables = []

        ###############################
        V_Debt2TNW = self._mappings['r_DebtToTNW1'].apply(to_map=invariant_data['r_DebtToTNW1'])
        V_EBITDA2IntExp = self._mappings['r_EBITDAoIntrst'].apply(to_map=invariant_data['r_EBITDAoIntrst'])
        V_QuickR = self._mappings['r_quickRatio'].apply(to_map=invariant_data['r_quickRatio'])

        for qtr in range(self.calculation_periods):
            """
            if qtr == 0:
                newm2mat = mapped_data.iloc[qtr][M2MAT] - 3
            else:
                newm2mat = new_m2mat[qtr - 1] - 3
            new_m2mat.append(newm2mat)
            """
            asofdate2stmtdate = invariant_data['asofdate2stmtdate']
            '''
            if qtr < 5:
                V_ProfitM = self._mappings['r_proftmargin'].apply(to_map=invariant_data['r_proftmargin'])
            else:
                V_ProfitM = self._mappings['r_proftmargin'].apply(to_map=(invariant_data['r_proftmargin'] +
                                                                          macro_data.iloc[qtr]['ProfitM']))
            '''
            V_ProfitM = self._mappings['r_proftmargin'].apply(to_map=macro_data.iloc[qtr]['r_proftmargin'])
            V_ChgSales = self._mappings['ChgSales'].apply(to_map=macro_data.iloc[qtr]['pct_chg_netsales'])

            if pd.isnull(asofdate2stmtdate) or asofdate2stmtdate is -1:
                V_days_to_stmt2 = -0.82
            elif asofdate2stmtdate > self.statement_days_threshold:
                V_days_to_stmt2 = -0.82
            else:
                V_days_to_stmt2 = 0.27

            regression_variables.append({
                'V_Debt2TNW': V_Debt2TNW,
                'V_EBITDA2IntExp': V_EBITDA2IntExp,
                'V_QuickR': V_QuickR,
                'V_ProfitM': V_ProfitM,
                'V_ChgSales': V_ChgSales,
                'V_day_to_stmt2': V_days_to_stmt2
            })

        return regression_variables

    def calculatePD(self, input_data):
        """This functions computes LGD thru some mappings

            Args:
                macro_data: a dataframe containing r_proftmargin, pct_chg_netsales, and PD_mapping, rows corresponding to
                            different quarters
                input_data: the data of one contract, read directly from excel file
                overlay: True by default
                PDMappingSwitch: determine whether we need to exponentiate the pd_mrs by PDMapping, True by default

            Return:
                PD of all forecast_periods, contained in a list. Each element of the list is a dictionary. Inside the
                dictionary is different measures of PD.
        """

        pd_result = []
        logistic_mapping = lambda ts: round(1 / (1 + np.exp(-ts)), self._precision)

        # Compute contract-specific macro sensitivity
        macro_data = self.macro_data.copy(deep=True)
        temp = []
        init_profit_margin = input_data['r_proftmargin'] #if pd.notnull(input_data['r_proftmargin']) else 0
        for j in range(self.calculation_periods):
            if j < 4:
                temp.append(init_profit_margin + macro_data.iloc[j]['diff_proftmargin'])
            else:
                temp.append(temp[j - 4] + macro_data.iloc[j]['diff_proftmargin'])
        macro_data['r_proftmargin'] = temp

        # intercept = self.pd_regression_coefficients['intercept']
        # coeff_pairs = self.pd_regression_coefficients['coefficients_pairs']
        intercept = -3.6118
        coeff_pairs = {
            'V_Debt2TNW': -0.4527,
            'V_EBITDA2IntExp': - 0.5294,
            'V_QuickR': -0.4761,
            'V_ProfitM': -0.2426,
            'V_ChgSales': -0.7667,
            'V_day_to_stmt2': -0.8797
        }
        estimated_pd = []

        regression_variables = self.getRegVariables(macro_data, input_data)
        SRR = input_data['SRR']

        for qtr in range(self.calculation_periods):
            estimated_pd.append(logistic_mapping(
                (sum([regression_variables[qtr][item] * coeff_pairs[item] for item in coeff_pairs.keys()]) + intercept)
            ))
            rating = self.mappings['estimated_PD'].apply(to_map=estimated_pd[qtr])
            # in mapping above, two keys of same IN_VAR estimated_PD
            if not pd.isnull(SRR) and (SRR >= 1.0) and (SRR <= self.pass_srr) and self.SRR_overlay_switch:
                final_rating = int(2 * SRR) * 0.5
            else:
                final_rating = rating

            # MRS Stress Notch Down
            if self.MRS_notch_down_switch:
                if (self.scenario_severity_level in ['STRESS', 'ADVERSE']) and (SRR > self.pass_srr or pd.isnull(SRR)):
                    final_rating = max(final_rating - 0.5, 1.5)

            if self.PD_mapping_switch:
                if final_rating > self.pass_srr:
                    pd_mapping = macro_data.iloc[qtr]['PD_mapping_Pass']
                else:
                    pd_mapping = macro_data.iloc[qtr]['PD_mapping_NonPass']
            else:
                pd_mapping = 1
            # map rating to pd_mrs

            # old version
            # pd_mrs = (self.mappings['final_rating'].apply(to_map=final_rating))**pd_mapping
            # pd_1y = pd_mrs

            # new version
            pd_mrs = self.mappings['final_rating'].apply(to_map=final_rating)
            if pd_mrs == 1:
                pd_1y = 1
            else:
                pd_1y = min(1, (1 + np.exp(-(np.log(pd_mrs / (1 - pd_mrs)) + pd_mapping))) ** (-1))
            pd_1q = utilities.PDPeriodConverter(
                pd_1y,
                utilities.PERIOD_FREQUENCY_MAP['yearly'],
                utilities.PERIOD_FREQUENCY_MAP['quarterly']
            )

            pd_result.append({
                'pd_1y': pd_1y,
                'pd_1q': pd_1q,
                'rating': rating,
                'final_rating': final_rating,
                'pd_mapping': pd_mapping,
                'estimated_pd': estimated_pd[qtr],
                'SRR': SRR,
                'r_proftmargin': macro_data.iloc[qtr]['r_proftmargin'],
                'pct_chg_netsales': macro_data.iloc[qtr]['pct_chg_netsales'],
                'V_Debt2TNW': regression_variables[qtr]['V_Debt2TNW'],
                'V_EBITDA2IntExp': regression_variables[qtr]['V_EBITDA2IntExp'],
                'V_QuickR': regression_variables[qtr]['V_QuickR'],
                'V_ProfitM': regression_variables[qtr]['V_ProfitM'],
                'V_ChgSales': regression_variables[qtr]['V_ChgSales'],
                'V_day_to_stmt2': regression_variables[qtr]['V_day_to_stmt2'],
            })
        return pd_result

    def calculateLGD(self, invariant_data, contract_results):
        """This functions computes LGD thru some mappings

        Args:
            macro_data: a dataframe containing r_proftmargin, pct_chg_netsales, and PD_mapping, rows corresponding to
                        different quarters
            invariant_data: the data of one contract, read directly from excel file

        Return:
            LGD of all forecast_periods, contained in a list
        """
        if self.debug: print("BEGIN - LGD Calculation for {}".format(invariant_data["UNIQUE_FACILITY_ID"]))
        lgd = []
        ABL_AR_flag = AR_flag = ['NOT ABL_AR'] * self.calculation_periods
        bizseg = invariant_data['PD_GROUP']
        coldesc = invariant_data['COLLATERAL_DESCRIPTION']
        coltyp = invariant_data['COLLATERAL_TYPE']
        exposure = invariant_data['EXPOSURE']
        if bizseg not in self.pd_groups:
            raise ValueError("Invalid Business Segment")

        if bizseg == ABL_PD_GROUP:
            # if coltyp not in ['AR', 'NonAR'] and (not pd.isnull(coltyp)):
            #    raise ValueError("Invalid collateral type for ABL model")
            # if not isinstance(coltyp, int):
            #    raise ValueError("Invalid collateral type for CNI/ABL model")
            if self.scenario_severity_level not in ['BASE', 'ADVERSE', 'STRESS']:
                raise ValueError("Invalid Scenario")

            if coldesc[:16].lower() == 'accts receivable':
                lgd_value = self._mappings['LGD_ABL_AR'].apply(to_map=self.scenario_severity_level)
                ABL_AR_flag = ['ABL_AR'] * self.calculation_periods
            else:
                lgd_value = self._mappings['LGD_ABL_NonAR'].apply(to_map=self.scenario_severity_level)
            lgd = [lgd_value for i in range(0, self.calculation_periods)]
        elif bizseg == MIDDLE_MARKET_PD_GROUP:
            if coltyp == 'COMMERCIAL PROPERTIES':
                lgd = list(
                    0.30393 - 0.12343 - 3.50762*self.transformed_macro_series[
                        "FHOFHOPIQ_US_p2q_l1q"
                    ].as_matrix()
                )
            elif coltyp in (
                'HOSPITAL/ MEDICAL CARE PROPERTIES',
                'RESIDENTIAL PROPERTIES',
                'FINANCIAL ASSETS',
                'ALL ASSETS/OTHER'
            ):
                lgd = list(
                    0.30393 - 3.50762 * self.transformed_macro_series[
                        "FHOFHOPIQ_US_p2q_l1q"
                    ].as_matrix()
                )
            elif coltyp == 'EQUIPMENT/VEHICLE':
                lgd = list(
                    0.35917 - 1.77606 * self.transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
            elif coltyp == 'UNSECURED':
                lgd = list(
                    0.35917 + 0.22583 - 1.77606 * self.transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
            else:
                raise ValueError("Invalid coltyp for Middle Market loan.")
        elif bizseg == BUSINESS_BANKING_PD_GROUP:
            if coltyp == 'COMMERCIAL PROPERTIES':
                lgd = list(
                    0.35917 - 0.17765 - 1.77606 * self.transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
            elif coltyp in (
                'EQUIPMENT/VEHICLE',
                'HOSPITAL/ MEDICAL CARE PROPERTIES',
                'RESIDENTIAL PROPERTIES',
                'FINANCIAL ASSETS',
                'ALL ASSETS/OTHER'
            ):
                lgd = list(
                    0.35917 - 1.77606 * self.transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
            elif coltyp == 'UNSECURED':
                lgd = list(
                    0.35917 + 0.22583 - 1.77606 * self.transformed_macro_series[
                        "FHOFHOPIQ_US_p1y"
                    ].as_matrix()
                )
            else:
                raise ValueError("Invalid coltyp for Middle Market loan.")
        else:
            raise ValueError("Invalid Business Segment")
            # if pd.isnull(exposure):
            #     exposure = 0.0
            # if coltyp == 'Commercial Properties':
            #     if exposure < 300000.:
            #         coltyp += ' < 300000'
            #     else:
            #         coltyp += ' >= 300000'
            # map_key = 'LGD_' + self.scenario_severity_level + '_' + bizseg
            # if coltyp not in self._mappings[map_key].values_to_map:
            #     #if self.debug:
            #         #print("warning: mapping rule for %s not found, treat it as missing value" % coltyp)
            #     coltyp = None
            # for qtr in range(self.calculation_periods):
            #     # scenario = macro_data.iloc[qtr]['scenario_type']
            #     # scenario = invariant_data['scenario_type']
            #     if self.scenario_severity_level not in ['BASE', 'ADVERSE', 'STRESS']:
            #         raise ValueError("Invalid Scenario")
            #     # map_key = 'LGD_' + self.scenario_severity_level + '_' + bizseg
            #     lgd.append(self._mappings[map_key].apply(to_map=coltyp))

        contract_results['LGD']=lgd
        contract_results['ABL_AR_flag']=ABL_AR_flag
        if self.debug: print(">>>>>> LGD : {}".format(str(lgd)))
        if self.debug: print(">>>>>> ABL_AR_flag : {}".format(str(ABL_AR_flag)))
        return(True)

    def estimateLossAmount(self, invariant_data, contract_results):
        BOOK_VALUE_Q = []
        LEQ_AMOUNT_Q = []
        EAD_AMOUNT_Q = []
        DEFAULT_AMOUNT_Q = []
        LOSS_AMOUNT_Q = []
        IS_RLOC = []
        FACILITYTYPE = []
        MATURITY_INDICATOR = []
        INITIAL_BOOK_VALUE = []

        if self.debug: print("BEGIN - EAD Amount calculation for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(self.calculation_periods):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            # Main info
            FACILITYTYPE.append(invariant_data['FACILITYTYPE'])
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )
            INITIAL_BOOK_VALUE.append(
                max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
            )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(FACILITYTYPE)))


            # Process book value
            if qtr == 0:
                BOOK_VALUE_Q.append(
                    (
                        max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
                    )
                    # * (
                    #     1 - contract_results['pd_1q'][qtr]
                    # )
                )
            else:
                BOOK_VALUE_Q.append(
                    BOOK_VALUE_Q[qtr - 1] * (1 - contract_results['pd_1q'][qtr - 1])
                )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(BOOK_VALUE_Q)))

            # Case REVOLVING LINE OF CREDIT
            if ('REVOLVING LINE OF CREDIT' == FACILITYTYPE[qtr].upper()):
                IS_RLOC.append('RLOC')
                LEQ_AMOUNT_Q.append(contract_results['EAD_TOTAL_LINE'][qtr]*invariant_data['EXPOSURE'])

                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(
                        min(
                            BOOK_VALUE_Q[qtr] + LEQ_AMOUNT_Q[qtr],
                            invariant_data['EXPOSURE']
                        )
                    )
            # Case TERM or NON-REVOLVING LOC
            else:
                IS_RLOC.append('OTHER')
                LEQ_AMOUNT_Q.append(0)
                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(BOOK_VALUE_Q[qtr])
            if self.debug: print(">>>>>> IS_RLOC : {}".format(str(IS_RLOC)))
            if self.debug: print(">>>>>> LEQ_AMOUNT_Q : {}".format(str(LEQ_AMOUNT_Q)))
            if self.debug: print(">>>>>> EAD_AMOUNT_Q : {}".format(str(EAD_AMOUNT_Q)))

        if self.debug: print("EAND - EAD Amount Estimation")

        # Estimate loss amount
        if self.debug: print("BEGIN - Estimate Loss Amount for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(self.calculation_periods):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            DEFAULT_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr])
            LOSS_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr] * contract_results['LGD'][qtr])
            if self.debug: print(">>>>>> DEFAULT_AMOUNT_Q : {}".format(str(DEFAULT_AMOUNT_Q)))
            if self.debug: print(">>>>>> LOSS_AMOUNT_Q : {}".format(str(LOSS_AMOUNT_Q)))

        # Write results to contract results container
        contract_results['BOOK_VALUE_Q'] = BOOK_VALUE_Q
        contract_results['LEQ_AMOUNT_Q'] = LEQ_AMOUNT_Q
        contract_results['EAD_AMOUNT_Q'] = EAD_AMOUNT_Q
        contract_results['DEFAULT_AMOUNT_Q'] = DEFAULT_AMOUNT_Q
        contract_results['LOSS_AMOUNT_Q'] = LOSS_AMOUNT_Q
        contract_results['IS_RLOC'] = IS_RLOC
        contract_results['FACILITYTYPE'] = FACILITYTYPE
        contract_results['MATURITY_INDICATOR'] = MATURITY_INDICATOR
        contract_results['INITIAL_BOOK_VALUE'] = INITIAL_BOOK_VALUE

    def estimateLossAmountAlt(self, invariant_data, contract_results):
        BOOK_VALUE_Q = []
        LEQ_AMOUNT_Q = []
        EAD_AMOUNT_Q = []
        DEFAULT_AMOUNT_Q = []
        LOSS_AMOUNT_Q = []
        IS_RLOC = []
        FACILITYTYPE = []
        MATURITY_INDICATOR = []
        INITIAL_BOOK_VALUE = []

        if self.debug: print("BEGIN - EAD Amount calculation for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(self.calculation_periods):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            # Main info
            FACILITYTYPE.append(invariant_data['FACILITYTYPE'])
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )
            INITIAL_BOOK_VALUE.append(
                max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
            )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(FACILITYTYPE)))

            # Process book value
            if qtr == 0:
                BOOK_VALUE_Q.append(
                    (
                        max(0.0, (invariant_data['BOOKBALANCE'] + invariant_data['LCAMOUNT']))
                    )
                    # * (
                    #     1 - contract_results['pd_1q'][qtr]
                    # )
                )
            else:
                BOOK_VALUE_Q.append(
                    BOOK_VALUE_Q[qtr - 1] * (1 - contract_results['pd_1q'][qtr - 1])
                )
            if self.debug: print(">>>>>> FACILITYTYPE : {}".format(str(BOOK_VALUE_Q)))

            # Case REVOLVING LINE OF CREDIT
            if ('REVOLVING LINE OF CREDIT' == FACILITYTYPE[qtr].upper()):
                IS_RLOC.append('RLOC')
                LEQ_AMOUNT_Q.append(contract_results['EAD_TOTAL_LINE'][qtr] * invariant_data['EXPOSURE'])

                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(
                        min(
                            BOOK_VALUE_Q[qtr] + LEQ_AMOUNT_Q[qtr],
                            invariant_data['EXPOSURE']
                        )
                    )
            # Case TERM or NON-REVOLVING LOC
            else:
                IS_RLOC.append('OTHER')
                LEQ_AMOUNT_Q.append(0)
                if MATURITY_INDICATOR[qtr]:
                    EAD_AMOUNT_Q.append(0)
                else:
                    EAD_AMOUNT_Q.append(BOOK_VALUE_Q[qtr])
            if self.debug: print(">>>>>> IS_RLOC : {}".format(str(IS_RLOC)))
            if self.debug: print(">>>>>> LEQ_AMOUNT_Q : {}".format(str(LEQ_AMOUNT_Q)))
            if self.debug: print(">>>>>> EAD_AMOUNT_Q : {}".format(str(EAD_AMOUNT_Q)))

        if self.debug: print("END - EAD Amount Estimation")

        # Estimate loss amount
        if self.debug: print("BEGIN - Estimate Loss Amount for {}".format(invariant_data['UNIQUE_FACILITY_ID']))
        for qtr in range(self.calculation_periods):
            if self.debug: print(">>> ITERATION/QUARTER {}".format(str(qtr)))
            DEFAULT_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr])
            LOSS_AMOUNT_Q.append(contract_results['pd_1q'][qtr] * EAD_AMOUNT_Q[qtr] * contract_results['LGD'][qtr])
            if self.debug: print(">>>>>> DEFAULT_AMOUNT_Q : {}".format(str(DEFAULT_AMOUNT_Q)))
            if self.debug: print(">>>>>> LOSS_AMOUNT_Q : {}".format(str(LOSS_AMOUNT_Q)))

        # Write results to contract results container
        contract_results['BOOK_VALUE_Q'] = BOOK_VALUE_Q
        contract_results['LEQ_AMOUNT_Q'] = LEQ_AMOUNT_Q
        contract_results['EAD_AMOUNT_Q'] = EAD_AMOUNT_Q
        contract_results['DEFAULT_AMOUNT_Q'] = DEFAULT_AMOUNT_Q
        contract_results['LOSS_AMOUNT_Q'] = LOSS_AMOUNT_Q
        contract_results['IS_RLOC'] = IS_RLOC
        contract_results['FACILITYTYPE'] = FACILITYTYPE
        contract_results['MATURITY_INDICATOR'] = MATURITY_INDICATOR
        contract_results['INITIAL_BOOK_VALUE'] = INITIAL_BOOK_VALUE

    def calculateLEQ(self, invariant_data, contract_results):
        """This function computes EAD according to Page 34 of the slides CCAR/DFAST 2016 Wholesale Models:
           Upper Business Banking and Middle Market

        Args:
            input_data: the data of one contract, read directly from excel file
        Return: a vector containing EAD of all quarters

        Possible Further Improvement:
            if we allow the mapped value to be lists, then we don't need to use if-else statement block
        """
        # scenario = input_data['scenario_type']
        if self.scenario_severity_level not in ['BASE', 'ADVERSE', 'STRESS']:
            raise ValueError("Invalid Scenario")
        LEQ_FACTOR = []
        MATURITY_INDICATOR = []
        #SRR = invariant_data['SRR']
        bizseg = invariant_data['PD_GROUP']
        facility_type = invariant_data['FACILITYTYPE']

        # LEQ Factor List
        PASS_BASE_LEQ = [0, 0, 0, 0, 0.0148, 0.056, 0.056, 0.0694, 0.124]
        PASS_ADVERSE_LEQ = [0, 0, 0, 0, 0.018, 0.0679, 0.0679, 0.0801, 0.1572]
        PASS_STRESS_LEQ = [0, 0, 0, 0, 0.0211, 0.0799, 0.0799, 0.0907, 0.1904]
        NON_PASS_BASE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.017, 0.038]
        NON_PASS_ADVERSE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.0173, 0.0386]
        NON_PASS_STRESS_LEQ = [0, 0, 0, 0, 0, 0, 0, 0.0176, 0.0392]
        ABL_BASE_LEQ = [0, 0, 0, 0, 0, 0, 0, 0, 0]

        # when forecast periods larger than 9Q, use the last value to extend the LEQ list
        if self.calculation_periods > 9:
            PASS_BASE_LEQ.extend([PASS_BASE_LEQ[-1]] * (self.calculation_periods - 9))
            PASS_ADVERSE_LEQ.extend([PASS_ADVERSE_LEQ[-1]] * (self.calculation_periods - 9))
            PASS_STRESS_LEQ.extend([PASS_STRESS_LEQ[-1]] * (self.calculation_periods - 9))
            NON_PASS_BASE_LEQ.extend([NON_PASS_BASE_LEQ[-1]] * (self.calculation_periods - 9))
            NON_PASS_ADVERSE_LEQ.extend([NON_PASS_ADVERSE_LEQ[-1]] * (self.calculation_periods - 9))
            NON_PASS_STRESS_LEQ.extend([NON_PASS_STRESS_LEQ[-1]] * (self.calculation_periods - 9))
            ABL_BASE_LEQ.extend([ABL_BASE_LEQ[-1]] * (self.calculation_periods - 9))

        """
        if (SRR > 4.0 or pd.isnull(SRR)):
            ead = self._mappings['EAD_PASS'].apply(to_map=scenario)
        else:
            ead = self._mappings['EAD_NON_PASS'].apply(to_map=scenario)
        """
        for qtr in range(self.calculation_periods):
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )                    
            if ('REVOLVING LINE OF CREDIT' == facility_type.upper()):
                if (
                    (contract_results['final_rating'][qtr] > self.pass_srr)
                    or
                    (pd.isnull(contract_results['final_rating'][qtr]))
                ):
                    if self.scenario_severity_level == 'BASE':
                        if bizseg == ABL_PD_GROUP:
                            LEQ_FACTOR.append(ABL_BASE_LEQ[qtr])
                        else:
                            LEQ_FACTOR.append(PASS_BASE_LEQ[qtr])
                    elif self.scenario_severity_level == 'ADVERSE':
                        LEQ_FACTOR.append(PASS_ADVERSE_LEQ[qtr])
                    else:
                        LEQ_FACTOR.append(PASS_STRESS_LEQ[qtr])
                else:
                    if MATURITY_INDICATOR[qtr]:
                        LEQ_FACTOR.append(0)
                    else:
                        if self.scenario_severity_level == 'BASE':
                            if bizseg == ABL_PD_GROUP:
                                LEQ_FACTOR.append(ABL_BASE_LEQ[qtr])
                            else:
                                LEQ_FACTOR.append(NON_PASS_BASE_LEQ[qtr])
                        elif self.scenario_severity_level == 'ADVERSE':
                            LEQ_FACTOR.append(NON_PASS_ADVERSE_LEQ[qtr])
                        else:
                            LEQ_FACTOR.append(NON_PASS_STRESS_LEQ[qtr])
            else:
                LEQ_FACTOR.append(0)
                
        return(LEQ_FACTOR)

    def calculateMaturedEAD(self, invariant_data, contract_results):
        EAD_FACTOR_MATURED = []
        MATURITY_INDICATOR = []
        bizseg = invariant_data['PD_GROUP']
        facility_type = invariant_data['FACILITYTYPE']
        for qtr in range(self.calculation_periods):
            # ESTIMATE MATURITY INDICATOR
            MATURITY_INDICATOR.append(
                False if (
                    (invariant_data['m2mat'] - ((qtr + 1) * 3)) > 0
                    or
                    pd.isnull(invariant_data['m2mat'])
                ) else True
            )

            if ('LINE OF CREDIT' in facility_type.upper()):
                if MATURITY_INDICATOR[qtr]:
                    if (
                        (contract_results['final_rating'][qtr] > self.pass_srr)
                        or
                        (pd.isnull(contract_results['final_rating'][qtr]))
                    ):
                        EAD_FACTOR_MATURED.append(1)
                    else:
                        EAD_FACTOR_MATURED.append(0)
                else:
                    EAD_FACTOR_MATURED.append(1)

            else:
                EAD_FACTOR_MATURED.append(1)

        return EAD_FACTOR_MATURED
        
    def ratePortfolio(self, mature_non_pass_locs: bool= True, return_results: bool= False):
        """This function computes for all contracts in the portfolio

        Return: a 2-D dictionary : key-> UNIQUE_FACILITY_ID, value-> pd, lgd, ead, new_ead
        """
        self._logger.add(
            type='INFO',
            message='Rating portfolio...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Initialize empty portfolio container
        portfolio = {}

        # Determine total number of record and completion meter breakpoints
        items_to_process = len(self.portfolio_snapshot)
        report_breakpoints = list(np.array(list(range(1, 21))) * (items_to_process // 20))

        # Begin looping through portfolio (rating contracts)
        for i in range(items_to_process):

            # Contract data
            input_data = self.portfolio_snapshot.iloc[i]
            unique_contract_id = input_data['UNIQUE_FACILITY_ID']

            # Check for contract duplicate in portfolio forecast container
            if unique_contract_id in portfolio.keys():
                raise KeyError("duplicate contracts, the UNIQUE_FACILITY_ID already exists in the portfolio")

            # Rate one contract
            portfolio[unique_contract_id] = self.rateOneContract(
                input_data=input_data,
                mature_non_pass_locs=mature_non_pass_locs
            )

            # Show % complete
            if i in report_breakpoints:
                self._logger.add(
                    type='INFO',
                    message='Rating portfolio ' + str(
                        (report_breakpoints.index(i) + 1) * 5) + "% complete...",
                    context='CCAR Model : ' + self._model_name,
                    model_id=self._model_id
                )

        # Accounting checks
        if items_to_process != len(portfolio):
            raise Exception("Initial number of contracts to process is different from portfolio forecast length.")

        # Clean up and finalize
        self.__results_set = portfolio
        del portfolio
        self.resultsToDataFrame()
        self._logger.add(
            type='INFO',
            message='Rating portfolio completed for {} contracts.'.format(str(items_to_process)),
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        if return_results:
            return(self.__results_set)

    def rateOneContract(self, input_data, mature_non_pass_locs: bool= True):
        """

        Args:
            input_data: one row of the portfolio_snapshot data frame
        Return:
             a dictionary: keys-> pd, lgd, ead, new_ead, values-> their coresponding values
        """

        # Initialize empty contract container
        results = {}
        results['PD_GROUP'] = [input_data['PD_GROUP']]*self.calculation_periods

        # Compute PD
        pd_result = self.calculatePD(input_data=input_data)
        for i in range(self.calculation_periods):
            for key, value in pd_result[i].items():
                if i == 0:
                    results[key] = []
                results[key].append(value)

        # Compute LGD
        self.calculateLGD(
            invariant_data=input_data,
            contract_results=results
        )

        # Compute EAD
        results['EAD'] = [1] * self.calculation_periods
        results['EAD_TOTAL_LINE'] = self.calculateLEQ(
            invariant_data=input_data,
            contract_results=results
        )

        if mature_non_pass_locs:
            results['EAD_AVAILABLE_LINE'] = [0] * self.calculation_periods
            EAD_matured = self.calculateMaturedEAD(
                invariant_data=input_data,
                contract_results=results
            )
            results['EAD_BOOK_BALANCE'] = EAD_matured
            results['EAD_LETTER_OF_CREDIT'] = EAD_matured
        else:
            results['EAD_AVAILABLE_LINE'] = [0] * self.calculation_periods
            results['EAD_BOOK_BALANCE'] = [1] * self.calculation_periods
            results['EAD_LETTER_OF_CREDIT'] = [1] * self.calculation_periods

        # old version of coverage rates mapping
        # ALLL COVERAGE Mapping
#        ALLLCOVERAGE_MAP = Mapping(
#            in_map={
#                'IN_VAR': 'ALLL_SRR',
#                'OUT_VAR': 'ALLL',
#                'TYPE': 'categorical',
#                'IN_VALUES': (
#                    8.5,
#                    8,
#                    7.5,
#                    7,
#                    6.5,
#                    6,
#                    5.5,
#                    5,
#                    4.5,
#                    4,
#                    3.5,
#                    3,
#                    2.5,
#                    2,
#                    1.5,
#                    1,
#                    0
#                ),
#                'MAPPED_VALUES': (
#                    0.000000000000000000,
#                    0.002965094429185140,
#                    0.002965094429185140,
#                    0.002965094429185140,
#                    0.002965094429185140,
#                    0.003741886917801790,
#                    0.005395795827365860,
#                    0.006323625595623680,
#                    0.010672453223910100,
#                    0.022401329497095600,
#                    0.022401329497095600,
#                    0.042130401715930600,
#                    0.042130401715930600,
#                    0.042130401715930600,
#                    0.080007874619086400,
#                    1.000000000000000000,
#                    0
#                ),
#                'MISSING': 0,
#                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
#
#            },
#            debug=False
#        )
#        CONTINGENTRESERVE_MAP = Mapping(
#            in_map={
#                'IN_VAR': 'CONTINGENCY_SRR',
#                'OUT_VAR': 'CONTINGENCY',
#                'TYPE': 'categorical',
#                'IN_VALUES': (
#                    8.5,
#                    8,
#                    7.5,
#                    7,
#                    6.5,
#                    6,
#                    5.5,
#                    5,
#                    4.5,
#                    4,
#                    3.5,
#                    3,
#                    2.5,
#                    2,
#                    1.5,
#                    1,
#                    0
#                ),
#                'MAPPED_VALUES': (
#                    0.002477858199285390,
#                    0.002477858199285390,
#                    0.002477858199285390,
#                    0.002477858199285390,
#                    0.002477858199285390,
#                    0.003263880042295340,
#                    0.004276448629675140,
#                    0.004769872081770360,
#                    0.008057343944290380,
#                    0.017202334748026700,
#                    0.017202334748026700,
#                    0.033627328625295400,
#                    0.033627328625295400,
#                    0.033627328625295400,
#                    0.083015023181477100,
#                    1.000000000000000000,
#                    0
#                ),
#                'MISSING': 0,
#                'CONSTRAINT': "lambda x : (x>=0) and (x<10)"
#            },
#            debug=False
#        )

        # Checks for coverage rates mapping
        if self._mappings['ALLL_SRR'] is None:
            raise Exception('`self.mappings` for ALLL_SRR is None.')
        if self._mappings['CONTINGENCY_SRR'] is None:
            raise Exception('`self.mappings` for CONTINGENCY_SRR is None.')
            
        # Assign coverage rates using final rating and mapping
        if self.as_of_date >= datetime.datetime(2017,6,30): 
            if input_data['PD_GROUP'] == 'ABL':
                results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR_ABL'].apply(item) \
                    for item in results['final_rating']
                ]
                results['CONTINGENTRESERVE'] = [
                    self._mappings['CONTINGENCY_SRR_ABL'].apply(item) \
                    for item in results['final_rating']
                ]            
            elif input_data['PD_GROUP'] == 'MIDDLE_MARKET':
                results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR_MM'].apply(item) \
                    for item in results['final_rating']
                ]
                results['CONTINGENTRESERVE'] = [
                    self._mappings['CONTINGENCY_SRR_MM'].apply(item) \
                    for item in results['final_rating']
                ]                  
            elif input_data['PD_GROUP'] == 'BUSINESS_BANKING':
                results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR_UBB'].apply(item) \
                    for item in results['final_rating']
                ]
                results['CONTINGENTRESERVE'] = [
                    self._mappings['CONTINGENCY_SRR_UBB'].apply(item) \
                    for item in results['final_rating']
                ]                  
        else:
            results['ALLLCOVERAGE'] = [
                    self._mappings['ALLL_SRR'].apply(item) \
                    for item in results['final_rating']
                ]    
            results['CONTINGENTRESERVE'] = [
                self._mappings['CONTINGENCY_SRR'].apply(item) \
                for item in results['final_rating']
            ]

        # Compute NEW EAD ($ loss)
        self.estimateLossAmountAlt(invariant_data=input_data, contract_results=results)


        return results

    def resultsToDataFrame(self):
        if self.results_set is None:
            raise ValueError('Portfolio has not been rated, `results_set` is null.')

        contract_df_container = []
        for contract_id in self.results_set:
            contract_df = pd.DataFrame(self.results_set[contract_id])
            contract_df['FORECAST_PERIOD'] = list(range(1,self.calculation_periods+1))
            contract_df['UNIQUE_FACILITY_ID'] = contract_id
            contract_df_container.append(contract_df)
            del contract_df

        self.__results_df = pd.concat(contract_df_container)
        del contract_df_container

    def checkResultRates(self, rate_map):
        """This function checks validility of the rates for all contracts in the portfolio
        """
        self._logger.add(
            type='INFO',
            message='Checking rating results...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        if self.results_df is None:
            raise ValueError('Portfolio has not been rated, `results_df` is null.')
        result_rates = self.results_df.copy(deep=True)
        # convert quarterly PD to monthly PD
        result_rates['pd_1q'] = result_rates['pd_1q'].apply(lambda x: 1-(1-x)**(1/3))
        
        for metric in rate_map:
            statistics = result_rates[metric].describe()
            if ((statistics['min']<0) or (statistics['max']>1)):
                raise ValueError (rate_map[metric]+' result is not within 0 to 1')                            
            self._logger.add(
                      type='INFO',
                      message=rate_map[metric] + ' mean: ' +str(round(statistics['mean']*100,5))+'%',
                      context='CCAR Model : ' + self._model_name,
                      model_id=self._model_id
            )          
            
    def plotResultRates(self, rate_map):
        """This function plots distribution of result rates for all contracts in the portfolio
        """
        self._logger.add(
            type='INFO',
            message='Ploting rating results...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )
        if self.results_df is None:
            raise ValueError('Portfolio has not been rated, `results_df` is null.')
        result_rates = self.results_df.copy(deep=True)
        # convert quarterly PD to monthly PD
        result_rates['pd_1q'] = result_rates['pd_1q'].apply(lambda x: 1-(1-x)**(1/3))
        
        # add additional metrics to plot
        rate_map_copy = copy.deepcopy(rate_map)
        rate_map_copy['final_rating'] = 'FinalRating'

        for metric in sorted(rate_map_copy):
            print('---- Ploting Average Forecasted Rates for: ' + rate_map_copy[metric] + ' ---')
            result_rates['Forecast_Period'] = result_rates.index
            rate_mean = result_rates.groupby('Forecast_Period').mean()
            plt.plot(rate_mean['FORECAST_PERIOD'], rate_mean[metric], 'r-')
            plt.xlabel('Forecast Period')
            plt.ylabel('Rate')
            plt.xticks(np.arange(min(rate_mean['FORECAST_PERIOD']), max(rate_mean['FORECAST_PERIOD'])+1, 1.0))
            plt.title('Average of forecast monthly ' + rate_map_copy[metric] + ' rates')
            plt.show()
            
    def execute(self, session: CCARSession = None):
        """

        Returns
        -------

        """
        self._logger.add(
            type='INFO',
            message='Executing model...',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Starting timer
        t0 = time.time()

        # Begin calculation
        if self.__results_set is None:
            self.ratePortfolio(mature_non_pass_locs=self.mature_non_pass_locs)

        rate_map = {
            'pd_1q':"PD",
            'LGD':"LGD",
            'EAD':'EAD',
            'EAD_BOOK_BALANCE':'EADBALANCE',
            'EAD_LETTER_OF_CREDIT':'EADLETTEROFCREDIT',
            'EAD_AVAILABLE_LINE':'EADAVAILABLELINE',
            'EAD_TOTAL_LINE':"EADTOTALLINE",
            'ALLLCOVERAGE':'ALLLCOVERAGE',
            'CONTINGENTRESERVE':'CONTINGENTRESERVE'
        }
        
        # Check result rates
        self.checkResultRates(rate_map)

        # Plot result rates
        if self.debug: 
            self.plotResultRates(rate_map)
        
        if session is not None:
            # Set initial completion counter
            items_to_process = len(self.results_set)
            report_breakpoints = list(np.array(list(range(1, 21))) * (items_to_process // 20))

            # Generate period date sequence
            period_freq_map = {
                'monthly': 1,
                'quarterly': 3,
                'yearly': 12
            }
            period_date = utilities.generateDateSequence(
                as_of_date=self.as_of_date,
                forecast_periods=self.forecast_periods,
                m_interval=period_freq_map[self.forecast_periods_frequency]
            )

            # Begin contributor file generation
            self._logger.add(
                type='INFO',
                message='Beginning contributor data generation...',
                context='CCAR Model : ' + self._model_name,
                model_id=self._model_id
            )
            cnt = 0
            for unique_facility in self.results_set.keys():
                # Update counter
                if cnt in report_breakpoints:
                    self._logger.add(
                        type='INFO',
                        message='Contributor data generation ' + str((report_breakpoints.index(cnt) + 1) * 5) + "% complete...",
                        context='CCAR Model : ' + self._model_name,
                        model_id=self._model_id
                    )

                for metric in list(rate_map.keys()):
                    model_output_rate = (
                        np.repeat(self.results_set[unique_facility][metric], 3).tolist() \
                        if rate_map[metric] != "PD" \
                        else np.apply_along_axis(
                            lambda x: 1-(1-x)**(1/3),
                            0,
                            np.repeat(self.results_set[unique_facility][metric], 3)
                        ).tolist()
                    )
                    session.contributor_file_generator.appendCF(
                        scenario=self.scenario,
                        model_segment="SB"+unique_facility,
                        period_date=period_date.tolist(),
                        vintage=self.as_of_date,
                        rate_type=4,
                        rate_name=rate_map[metric],
                        model_output_rate=model_output_rate,
                        uncertainty_adjustment_rate=0.0,
                        mgmt_adjustment_rate=0.0
                    )
                cnt += 1

        # Calculating runtime
        t1 = time.time()
        runtime = round((t1 - t0), 4)
        self._logger.add(
            type='INFO',
            message='Execution completed in ' + str(runtime) + ' s.',
            context='CCAR Model : ' + self._model_name,
            model_id=self._model_id
        )

        # Dump log data into session instance
        if session is not None:
            if isinstance(session, CCARSession):
                for log_item in self._logger.items:
                    session.logger.addItem(log_item)

