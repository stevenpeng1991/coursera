import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.controllers.models.cniriskrating import *
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
import CIFI.controllers.utilities.utilities as utilities
import datetime
import numpy as np
import pandas as pd
import itertools
import _pickle 


# KICKING-OFF A FULL RUN
## Create a session instance and a model shopping cart to run the CNIModel
ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 UAT',
    session_date=datetime.datetime(2016,12,31)
)
cart = ModelShoppingCart(ccar_session=ccar_session)

## Create CNIModel instance
cni_model_base_instance = CNIModel(
    as_of_date=datetime.datetime(2016,12,31),                    # scenario as-of-date
    scenario="FRB_BASE",                                           # scenario name
    scenario_context="CCAR2017",                                 # stress testing cycle
    scenario_date=datetime.datetime(2016,12,31),                 # scenario as-of-date
    scenario_severity_level="BASE",                            # scenario severity level
    forecast_periods=27,                                         # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    pd_groups = ["MIDDLE_MARKET"],
    limit_contracts=None,                                        # for testing purposes, number of random contracts to pick
    portfolio_snapshot_date=datetime.datetime(2016,12,31),       # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = datetime.datetime(2016,12,31),
    scenario_combinations = None
)

cni_model_bhc_stress_instance = CNIModel(
    as_of_date=datetime.datetime(2016,12,31),                    # scenario as-of-date
    scenario="BHC_SA",                                           # scenario name
    scenario_context="CCAR2017",                                 # stress testing cycle
    scenario_date=datetime.datetime(2016,12,31),                 # scenario as-of-date
    scenario_severity_level="STRESS",                            # scenario severity level
    forecast_periods=27,                                         # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    pd_groups = ["MIDDLE_MARKET"],
    limit_contracts=None,                                        # for testing purposes, number of random contracts to pick
    portfolio_snapshot_date=datetime.datetime(2016,12,31),       # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = datetime.datetime(2016,12,31),
    scenario_combinations = None
)

## Check portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = cni_model_base_instance.portfolio_snapshot

## Check raw and transformed macro series
transformed_macro_series = cni_model_base_instance.transformed_macro_series

## Check change in sales, profit margin and pd mapping stress time series
macro_data = cni_model_base_instance.macro_data

## Check a list of all mapping objects as a dict
mapping_objects = cni_model_base_instance.mappings

## Get all rated contracts as a dict (quarterly forecast)
results_dictionary = cni_model_base_instance.results_set

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = cni_model_base_instance.results_df

###############  Add model to the shopping cart and execute  ###########
cart.addModel(cni_model_base_instance)
cart.addModel(cni_model_bhc_stress_instance)
cart.checkout()       # execute() is called here

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data_BASE = cf.getCFData()
cf_data_STRESS = cf.getCFData()

## save contributor file to CSV file
cf_data.to_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/cf_MM_BASE.csv", index = False)

## reset cf generator and shopping cart 
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()

### SP20 Run Balance Walk and sensitivity ####
# get portfolio snapshot
anchor_query, anchor_data = getBWFormatAnchorData(
                as_of_date=datetime.datetime(2016,12,31),
                debug=True,
                pd_groups=["MIDDLE_MARKET"]
            )
## save anchor file to CSV file
anchor_data.to_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/anchor_MM_BASE.csv")

#cf_data_BASE = pd.read_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/cf_MM_BASE.csv")
#anchor_data = pd.read_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/anchor_MM_BASE.csv")

### Balance Walk ###
# Note: need to first run the Balance Walk module below #

# Balance walk for BASE senario
bw_results_BASE, bw_results_final_BASE, bw_output_BASE = balanceWalk_concentration(
    cf_data = cf_data_BASE,
    anchor_data = anchor_data,
    scenario_list = ['FRB_BASE'],
    process_ALLL_balances = False,
    debug = True
    )
bw_output_BASE.to_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/bw_output_MM_BASE.csv")

# Balance walk for BHC_STRESS senario
bw_results_STRESS, bw_results_final_STRESS, bw_output_STRESS = balanceWalk_concentration(
    cf_data = cf_data_STRESS,
    anchor_data = anchor_data,
    scenario_list = ['BHC_SA'],
    process_ALLL_balances = False,
    debug = True
    )
bw_output_STRESS.to_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/bw_output_MM_STRESS.csv")

bw_results_test = bw_results_final_BASE.groupby(
    by=[
        'UNIQUE_FACILITY_ID',
        'SCENARIO',
        'BW_MODE'
    ]
)[[
    'BALANCE',
    'CALCULATEDLINE',
    'STARTINGBALANCE',
    'FINALBALANCE',
    'DEFAULTBALANCE',
    'LGDAMOUNT',
    'NCOAMOUNT',
    'EADAMOUNT',
    'ALLLRESERVEAMOUNT',
    'CONTINGENTRESERVEAMOUNT'
]].sum()

bw_results_test_2 = bw_results_test[bw_results_test.index.get_level_values('BW_MODE') == 2]
bw_results_test_3 = bw_results_test_2.reset_index()[['UNIQUE_FACILITY_ID', 'SCENARIO', 'STARTINGBALANCE', 'NCOAMOUNT']]
bw_results_test_3['STARTINGBALANCE'].sum()
bw_results_test_3['NCOAMOUNT'].sum()

# Read and clean the mapping table between facility number to NAICS Code
facilityToNaicsCode_raw = pd.read_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/PD_GROUP_NAICS.csv")
facilityToNaicsCode_dups = facilityToNaicsCode_raw[facilityToNaicsCode_raw.duplicated(['sourceid', 'customernumber', 'facilitynumber' ])]
facilityToNaicsCode = facilityToNaicsCode_raw.copy(deep=True)
facilityToNaicsCode['UNIQUE_FACILITY_ID'] = facilityToNaicsCode['sourceid'] + facilityToNaicsCode['pdgroup_obligor'] + facilityToNaicsCode['customernumber'] + facilityToNaicsCode['facilitynumber']

# Merge balance walk output with mapping table above
bw_result_merge_naics = bw_results_test_3.merge(
    facilityToNaicsCode,
    left_on='UNIQUE_FACILITY_ID',
    right_on='UNIQUE_FACILITY_ID',
    how='left'
)
# Drop missing NAICS code facility (missing count: 6)
bw_result_merge_naics['naicscode'] = bw_result_merge_naics['naicscode'].replace('\\0', np.nan)
bw_result_merge_naics = bw_result_merge_naics.dropna().reset_index(drop=True)
bw_result_merge_naics.naicscode = bw_result_merge_naics.naicscode.astype(np.int64)

# Read the maaping table between NAICS code and Sector
naicsCodeToSector_raw = pd.read_excel("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/NAICS Codes (2012).xlsx")

# Merge with the mapping table to get the sector information for each facility
bw_result_merge_sector = bw_result_merge_naics.merge(
    naicsCodeToSector_raw,
    left_on='naicscode',
    right_on='NAICS',
    how='left'
)
bw_result_merge_sector.to_csv("I:/CRMPO/CCAR/1Q17/NAICS MM Concentrations/data/bw_output_MM_BASE_merged.csv",  index = False)

# to see NCO rates for each sector
sector_nco = bw_result_merge_sector.groupby('OCC Sector').sum()['NCOAMOUNT']
sector_balance = bw_result_merge_sector.groupby('OCC Sector').sum()['STARTINGBALANCE']
sector_nco_rate = sector_nco / sector_balance
sum(sector_nco)
sum(sector_balance)















#### Balance Walk Module  #####
import sys
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.config import CONFIG
import CIFI.controllers.utilities.utilities as utilities
from CIFI.models.masterdataset.masterdataset import to_sql_array
import datetime
import pandas as pd
import numpy as np
from scipy.ndimage.interpolation import shift
import copy



# HELPERS
date2str = lambda x : x.strftime("%Y%m%d")
date2OracleSTR = lambda x : x.strftime("%d-%b-%Y").upper()

# SEGMENTATION MAPS
global PORTFOLIO_SEGMENTATION_MAP
PORTFOLIO_SEGMENTATION_MAP = {
    'CI_RR': 'CCB Portfolio',
    'GCB': 'GCB',
    'CEVF_RETAIL': 'CCB Portfolio',
    'GOVERNMENT_BANKING': 'CCB Portfolio',
    'DFP_CHRYSLER': 'Auto Portfolio',
    'MWH': 'CCB Portfolio',
    'CRE_CONSTRUCTION': 'CRE - Portfolio',
    'MIDDLE_MARKET': 'CCB Portfolio',
    'CEVF_RR': 'CCB Portfolio',
    'CRE_UNSECURED': 'CCB Portfolio',
    'ABL': 'CCB Portfolio',
    'EQUIPMENT_FINANCE_LEASING': 'CCB Portfolio',
    'RUNOFF_CCRC': 'CCB Portfolio',
    'BUSINESS_BANKING': 'CBB',
    'CRE_OTHER': 'CRE - Portfolio',
    'CI_OTHERS': 'CCB Portfolio',
    'CRE_MULTIFAMILY': 'CRE - Portfolio',
    'ENERGY_FINANCE': 'CCB Portfolio',
    'DFP_FOOTPRINT': 'Auto Portfolio',
    'CRE_REITS': 'CCB Portfolio'
}

global MODEL_SEGMENTATION_MAP
MODEL_SEGMENTATION_MAP = {
    'CI_RR': 'Other EJMs',
    'GCB': 'GCB',
    'CEVF_RETAIL': 'CEVF',
    'GOVERNMENT_BANKING': 'Other EJMs',
    'DFP_CHRYSLER': 'Chrysler',
    'MWH': 'Other EJMs',
    'CRE_CONSTRUCTION': 'CRE - Construction',
    'MIDDLE_MARKET': 'MM model',
    'CEVF_RR': 'Other EJMs',
    'CRE_UNSECURED': 'Other EJMs',
    'ABL': 'ABL',
    'EQUIPMENT_FINANCE_LEASING': 'Other EJMs',
    'RUNOFF_CCRC': 'Other EJMs',
    'BUSINESS_BANKING': 'UBB',
    'CRE_OTHER': 'CRE-Others',
    'CI_OTHERS': 'Other EJMs',
    'CRE_MULTIFAMILY': 'CRE - Multifamily',
    'ENERGY_FINANCE': 'Other EJMs',
    'DFP_FOOTPRINT': 'Core',
    'CRE_REITS': 'Other EJMs'
}

generateFlatNCOTimingCurve = lambda forecast_periods : [1]+np.repeat(0,forecast_periods-1).tolist()
# global SEGFIELD2_TO_NCO_TIMING_CURVE
# SEGFIELD2_TO_NCO_TIMING_CURVE = {
#     'SBB': generateFlatNCOTimingCurve(forecast_periods=27),
#     'CRE': generateFlatNCOTimingCurve(forecast_periods=27),
#     'C&I': generateFlatNCOTimingCurve(forecast_periods=27),
#     'CEVF': generateFlatNCOTimingCurve(forecast_periods=27),
# }

FORECAST_PERIOD=27
global SEGFIELD2_TO_NCO_TIMING_CURVE
# switch of whether using timing curve for NCO curve
timing_curve_switch = False
forecast_period = FORECAST_PERIOD
if timing_curve_switch:
    nco_data = pd.read_excel(
        io=CONFIG["EJM"]["COMMERCIAL_EJM_MASTER_PATH"],
        sheetname='NCO_BalanceWalk',
        na_values = [],
        keep_default_na = False
    )
    SEGFIELD2_TO_NCO_TIMING_CURVE = {}
    for segment in ('SBB', 'CRE', 'C&I', 'CEVF') :
        SEGFIELD2_TO_NCO_TIMING_CURVE[segment] = nco_data[segment][:forecast_period].tolist()
else:
    SEGFIELD2_TO_NCO_TIMING_CURVE = {
        'SBB': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
        'CRE': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
        'C&I': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
        'CEVF': generateFlatNCOTimingCurve(forecast_periods=forecast_period),
    }

def processNCOTimingCurves(
    lgd_amount: (np.ndarray, list, tuple),
    nco_curve: (np.ndarray, list, tuple),
    apply_curve: bool
) -> np.ndarray:
    """

    """
    if len(lgd_amount) != len(nco_curve):
        raise ValueError("Input vector-like parameters have unequal lengths.")
    utilities.checkDataType(lgd_amount, (np.ndarray, list, tuple))
    utilities.checkDataType(nco_curve, (np.ndarray, list, tuple))
    utilities.checkDataType(apply_curve, bool)

    lgd_amount = np.array(lgd_amount)
    dim1_len = len(lgd_amount)
    if apply_curve:
        nco_curve = np.array(nco_curve)
    else:
        nco_curve = np.zeros(dim1_len)
        nco_curve[0] = 1

    result = lgd_amount.transpose() * np.matrix([
        shift(row, idx) for idx, row in enumerate(nco_curve * np.ones([dim1_len, dim1_len]))
    ])

    return np.array(result.tolist()[0])


def processBWFacility(
    forecast_periods: int,
    current_facility: dict,
    scenario_name: str,
    loc_default_reduction_switch: bool,
    loc_maturity_treatment_switch: bool,
    apply_curve: bool,
    process_ALLL_balances: bool
):
    """

    Args:
        forecast_periods:
        current_facility:
        scenario_name:
        loc_default_reduction_switch:
        loc_maturity_treatment_switch:
        apply_curve:
        process_ALLL_balances:

    Return:

    """
    # INITIAL CHECKS
    for forecast_var in [
        'STARTINGBALANCE',
        'FINALBALANCE',
        'DEFAULTBALANCE',
        'BALANCE',
        'CALCULATEDLINE',
        'LGDAMOUNT',
        'NCOAMOUNT',
        'EADAMOUNT',
        'ALLLRESERVEAMOUNT',
        'CONTINGENTRESERVEAMOUNT',
        'FACILITYTYPE',
        'PORTFOLIO',
        'MODEL',
        'SCENARIO',
        'LOC_DEFAULT_REDUCTION_FLAG',
        'LOC_MATURITY_TREATMENT_FLAG',
        'LOANTYPE',
        'BW_MODE'
    ]:
        if forecast_var not in list(current_facility.keys()):
            current_facility[forecast_var] = [np.NaN]*forecast_periods

    for idx in range(forecast_periods):
        # SET INITIAL PROPERTIES
        current_facility['SCENARIO'][idx] = scenario_name
        current_facility['PORTFOLIO'][idx] = PORTFOLIO_SEGMENTATION_MAP[current_facility['PD_GROUP'][idx]]
        current_facility['MODEL'][idx] = MODEL_SEGMENTATION_MAP[current_facility['PD_GROUP'][idx]]

        # SET INITIAL FLAGS
        if loc_default_reduction_switch:
            current_facility['LOC_DEFAULT_REDUCTION_FLAG'][idx] = 'Y'

            if loc_maturity_treatment_switch:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'Y'
                current_facility['BW_MODE'][idx] = 1
            else:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'N'
                current_facility['BW_MODE'][idx] = 2

        else:
            current_facility['LOC_DEFAULT_REDUCTION_FLAG'][idx] = 'N'

            if loc_maturity_treatment_switch:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'Y'
                current_facility['BW_MODE'][idx] = 3
            else:
                current_facility['LOC_MATURITY_TREATMENT_FLAG'][idx] = 'N'
                current_facility['BW_MODE'][idx] = 4


       # DEFINE BOP BALANCES
        if idx == 0:
            current_facility['STARTINGBALANCE'][idx] = current_facility['BOOKBALANCE'][idx]

            current_facility['BALANCE'][idx] = current_facility['BOOKBALANCE'][idx] + \
                                                current_facility['LCAMOUNT'][idx]
            current_facility['CALCULATEDLINE'][idx] = current_facility['EXPOSURE'][idx]
        else:
            current_facility['STARTINGBALANCE'][idx] = 0

            current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx-1]
            current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx-1]

        # CALCULATE EAD BALANCES
        ead_balance = current_facility['BALANCE'][idx] * current_facility['EADBALANCE'][idx]
        ead_available_line = (
            current_facility['CALCULATEDLINE'][idx] - current_facility['BALANCE'][idx]
        ) * current_facility['EADAVAILABLELINE'][idx]
        ead_total_line = current_facility['CALCULATEDLINE'][idx] * current_facility['EADTOTALLINE'][idx]

        # CURRENT EAD AMOUNT
        if 'LINE OF CREDIT' in current_facility['FACILITYTYPE'][idx].upper():
            current_facility['LOANTYPE'][idx] = 'LINE OF CREDIT'

            current_facility['EADAMOUNT'][idx] = min(
                current_facility['CALCULATEDLINE'][idx],
                ead_balance + ead_available_line + ead_total_line
            )
        else:
            current_facility['LOANTYPE'][idx] = 'TERM_CCC'

            current_facility['EADAMOUNT'][idx] = current_facility['BALANCE'][idx]

        # CHECK MATURITY
        if 'LINE OF CREDIT' in current_facility['FACILITYTYPE'][idx].upper():

            # VERSION 1 - Reduce Balances & Mature LOCs
            if loc_default_reduction_switch & loc_maturity_treatment_switch:
                if pd.isnull(current_facility['MAXIMUMMATURITYDATE'][idx]):
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                       current_facility['DEFAULTBALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                              current_facility['DEFAULTBALANCE'][idx]
                elif(
                    ((current_facility['MAXIMUMMATURITYDATE'][idx] - current_facility['PERIODDATE'][idx]).days < 0)
                ):
                    current_facility['EADAMOUNT'][idx] = 0

                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = 0

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = 0
                    current_facility['CALCULATEDLINE'][idx] = 0
                else:
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                       current_facility['DEFAULTBALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                              current_facility['DEFAULTBALANCE'][idx]

            # VERSION 2 - DO NOT Reduce Balances & Mature LOCs
            elif (not loc_default_reduction_switch) & loc_maturity_treatment_switch:

                if pd.isnull(current_facility['MAXIMUMMATURITYDATE'][idx]):
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx]
                elif (
                    ((current_facility['MAXIMUMMATURITYDATE'][idx] - current_facility['PERIODDATE'][idx]).days < 0)
                ):
                    current_facility['EADAMOUNT'][idx] = 0

                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = 0

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = 0
                    current_facility['CALCULATEDLINE'][idx] = 0
                else:
                    # CALCULATE DEFAULT BALANCE
                    current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                              current_facility['PD'][idx]

                    # UPDATE BALANCES
                    current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx]
                    current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx]

            # VERSION 3 - Reduce Balances & DO NOT Mature LOCs
            elif loc_default_reduction_switch & (not loc_maturity_treatment_switch):
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * \
                                                          current_facility['PD'][idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                   current_facility['DEFAULTBALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                          current_facility['DEFAULTBALANCE'][idx]

            # VERSION 4 - DO NOT Reduce Balances & DO NOT Mature LOCs
            else:
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * current_facility['PD'][idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx]

        else:
            if pd.isnull(current_facility['MAXIMUMMATURITYDATE'][idx]):
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * current_facility['PD'][
                    idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                   current_facility['DEFAULTBALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                          current_facility['DEFAULTBALANCE'][idx]
            elif (
                ((current_facility['MAXIMUMMATURITYDATE'][idx] - current_facility['PERIODDATE'][idx]).days < 0)
            ):
                current_facility['EADAMOUNT'][idx] = 0

                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = 0

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = 0
                current_facility['CALCULATEDLINE'][idx] = 0
            else:
                # CALCULATE DEFAULT BALANCE
                current_facility['DEFAULTBALANCE'][idx] = current_facility['EADAMOUNT'][idx] * current_facility['PD'][
                    idx]

                # UPDATE BALANCES
                current_facility['BALANCE'][idx] = current_facility['BALANCE'][idx] - \
                                                   current_facility['DEFAULTBALANCE'][idx]
                current_facility['CALCULATEDLINE'][idx] = current_facility['CALCULATEDLINE'][idx] - \
                                                          current_facility['DEFAULTBALANCE'][idx]
        # CALCULATE LGD AMOUNT
        current_facility['LGDAMOUNT'][idx] = current_facility['DEFAULTBALANCE'][idx] * current_facility['LGD'][idx]

        # FINAL BALANCE
        if idx == (forecast_periods - 1):
            current_facility['FINALBALANCE'][idx] = current_facility['BALANCE'][idx]
        else:
            current_facility['FINALBALANCE'][idx] = 0

        # ALLOWANCE CALCULATIONS
        if process_ALLL_balances:
            current_facility['ALLLRESERVEAMOUNT'][idx] = current_facility['BALANCE'][idx] * \
                                                         current_facility['ALLLCOVERAGE'][idx]
            current_facility['CONTINGENTRESERVEAMOUNT'][idx] = (
                current_facility['CALCULATEDLINE'][idx] - current_facility['BALANCE'][idx]
            ) * current_facility['ALLLCOVERAGE'][idx]


    # APPLY NCO TIMING CURVE
    current_facility['NCOAMOUNT'] = processNCOTimingCurves(
        lgd_amount=current_facility['LGDAMOUNT'],
        nco_curve=SEGFIELD2_TO_NCO_TIMING_CURVE[current_facility['SEGMENTATIONFIELD2'][0]],
        apply_curve=apply_curve
    )

    return current_facility


def getBWFormatAnchorData(
    as_of_date: datetime.datetime,
    debug: bool,
    pd_groups: list =[]
) -> (str, pd.DataFrame):
    """

    Args:
        as_of_date (datetime.datetime) :
        debug (bool) :
        pd_groups (list) :

    Return:

    Example:
        >>> anchor_query, anchor_data = getBWFormatAnchorData(
                as_of_date=datetime.datetime(2016, 12, 31),
                debug=True,
                pd_groups=["CRE_CONSTRUCTION"]
            )
    """
    query="""
        SELECT
            ANCHOR.SOURCEID,
            ANCHOR.ONEOBLIGORNUMBER,
            ANCHOR.CUSTOMERNUMBER,
            ANCHOR.FACILITYNUMBER,
            ANCHOR.UNIQUE_FACILITY_ID,
            ANCHOR.BOOKBALANCE,
            ANCHOR.LCAMOUNT,
            ANCHOR.EXPOSURE,
            ANCHOR.SEGMENTNAME,
            ANCHOR.PD_GROUP,
            ANCHOR.MAXIMUMMATURITYDATE,
            ANCHOR.FACILITYTYPE,
            ANCHOR.SEGMENTATIONFIELD2,
            ANCHOR.MODELSEGMENT,
            ANCHOR.RATENAME
        FROM (
            (
            SELECT INTER.*
             FROM (SELECT
                UPPER(SOURCEID) AS SOURCEID,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                UNIQUE_FACILITY_ID,
                SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                SUM(CALCULATED_LINE) AS EXPOSURE,
                MAX(SEGMENTNAME) AS SEGMENTNAME,
                MAX({}) AS PD_GROUP,
                MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                FACILITYTYPE,
                SEGMENTATIONFIELD2,
                TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                TO_CHAR(EADAVAILABLELINE) AS EADAVAILABLELINE,
                TO_CHAR(EADBALANCE) AS EADBALANCE,
                TO_CHAR(EADLETTEROFCREDIT) AS EADLETTEROFCREDIT,
                TO_CHAR(EADTOTALLINE) AS EADTOTALLINE,
                TO_CHAR(EAD) AS EAD,
                TO_CHAR(LGD) AS LGD,
                TO_CHAR(PD) AS PD
            FROM {}
            WHERE
                ASOFDATE = '{}'
                AND
                UPPER({}) NOT IN ('SMALL BUSINESS BANKING', 'SBB')
                {}
                AND
                 (
                     (
                         FAS114_STATUS = 'A - NOT REQUIRED'
                         AND
                         LOCAL_NPL_FLAG = 'N'
                     )
                     OR
                     TDR = 'Y'
                 )
                AND
                UPPER(SOURCEID) NOT IN ('OFFLINE')
            GROUP BY
                SOURCEID,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                UNIQUE_FACILITY_ID,
                FACILITYTYPE,
                SEGMENTATIONFIELD2,
                TO_CHAR(ALLLCOVERAGE),
                TO_CHAR(CONTINGENTRESERVE),
                TO_CHAR(EADAVAILABLELINE),
                TO_CHAR(EADBALANCE),
                TO_CHAR(EADLETTEROFCREDIT),
                TO_CHAR(EADTOTALLINE),
                TO_CHAR(EAD),
                TO_CHAR(LGD),
                TO_CHAR(PD)
            HAVING
                SUM(CALCULATED_LINE) > 0) INTER
        )
        UNPIVOT (
            MODELSEGMENT FOR RATENAME IN (
                PD,
                LGD,
                EAD,
                EADAVAILABLELINE,
                EADBALANCE,
                EADLETTEROFCREDIT,
                EADTOTALLINE,
                ALLLCOVERAGE,
                CONTINGENTRESERVE
            )
        ) ) ANCHOR
        ORDER BY
            ANCHOR.UNIQUE_FACILITY_ID,
            ANCHOR.RATENAME
        """.format(
            CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
            CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
            date2OracleSTR(as_of_date),
            CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
            " AND {} IN ".format(CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"]) + to_sql_array(
            a=pd_groups, quote=True) if len(pd_groups) > 0 else ""
        )
    anchor_data = queryRFO(
        query=query,
        moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']['CURRENT'],
        debug=debug
    )
    # 02282017 RFO GCB C&I fix
    if as_of_date==datetime.datetime(2017,2,28):
        anchor_data = anchor_data[anchor_data["ONEOBLIGORNUMBER"] != '0052690273']
    return(query, anchor_data)





def balanceWalk_concentration(
    cf_data: pd.DataFrame,
    anchor_data: pd.DataFrame,
    scenario_list: list,
    process_ALLL_balances: bool,
    debug: bool =True
) -> pd.DataFrame:
    """

    Args:
        cf_data (pd.DataFrame) :
        anchor_data (pd.DataFrame) :
        scenario_list (list) :
        debug (bool) :

    Return:
        bw_results_pivot (pd.DataFrame) : the aggregated balance walk results.

    """
    raw_anchor_balance_check = anchor_data.BOOKBALANCE.sum() / (len(anchor_data.RATENAME.unique()))

    pre_bw_data = anchor_data[['UNIQUE_FACILITY_ID','RATENAME', 'MODELSEGMENT']].merge(
        cf_data[
            ['SCENARIO', 'MODELOUTPUTRATE', 'RATENAME', 'MODELSEGMENT', 'PERIODDATE']
        ],
        on=['RATENAME', 'MODELSEGMENT'],
        how='left'
    )

    period_date_index = pd.Series(pre_bw_data['PERIODDATE'].unique()).sort_values()
    period_date_index = period_date_index[~pd.isnull(period_date_index)]
    period_date_index.reset_index(drop=True, inplace=True)
    forecast_periods = len(period_date_index)

    if len(pre_bw_data)!=(len(anchor_data)*forecast_periods*len(scenario_list)):
        raise Exception("Length of anchor_data != pre_bw_data.")

    pre_bw_data.drop('MODELSEGMENT', axis=1, inplace=True)

    bw_data_wide = pd.pivot_table(
        pre_bw_data,
        values='MODELOUTPUTRATE',
        index=list(set(list(pre_bw_data.columns)) - set(['RATENAME', 'MODELOUTPUTRATE'])),
        columns=['RATENAME'],
        aggfunc=np.mean
    ).reset_index()

    dups_check = bw_data_wide.duplicated(['UNIQUE_FACILITY_ID', 'SCENARIO', 'PERIODDATE'])
    if len(bw_data_wide[dups_check]) != 0:
        raise Exception("Duplicate in pivot table.")

    bw_data_wide_additional_fields = anchor_data[anchor_data.RATENAME=='PD'].merge(
        bw_data_wide,
        on=['UNIQUE_FACILITY_ID'],
        how='left'
    )
    bw_data_wide_additional_fields.drop('RATENAME', axis=1, inplace=True)

    bw_data_wide_balance_check = bw_data_wide_additional_fields.BOOKBALANCE.sum()/(len(scenario_list) *
        forecast_periods
    )
    if round(raw_anchor_balance_check - bw_data_wide_balance_check, -1) != 0:
        raise Exception("Balance check 2 failed.")

    indexed_bw_data = bw_data_wide_additional_fields.set_index([
        'SCENARIO',
        'UNIQUE_FACILITY_ID'
    ])

    if debug:
        print("Computing list of unique facilities...")
    unique_facilities = indexed_bw_data.index.get_level_values('UNIQUE_FACILITY_ID').unique().tolist()

    if debug:
        print("Computing counter breakpoints...")
    breakpoints = [int((len(unique_facilities) / 100) * (m + 1)) for m in range(100)]

    if debug:
        print("Beginning balance walk process...")
    bw_results = []

    for scenario in scenario_list:
        print("****** Processing scenario {} ******".format(scenario))
        for unique_facility_idx, unique_facility_id in enumerate(unique_facilities):
            if unique_facility_idx in breakpoints:
                print("Process {}% completed".format(str(
                    (breakpoints.index(unique_facility_idx) + 1) * 1
                )))
            current_facility = indexed_bw_data.loc[scenario, unique_facility_id].to_dict(orient='list')

            # VERSION 1
            current_facility_v1 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                loc_default_reduction_switch=True,
                loc_maturity_treatment_switch=True,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances
            )

            # VERSION 2
            current_facility_v2 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                loc_default_reduction_switch=False,
                loc_maturity_treatment_switch=True,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances
            )

            # VERSION 3
            current_facility_v3 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                loc_default_reduction_switch=True,
                loc_maturity_treatment_switch=False,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances
            )

            # VERSION 4
            current_facility_v4 = processBWFacility(
                forecast_periods=forecast_periods,
                current_facility=copy.deepcopy(current_facility),
                scenario_name=scenario,
                loc_default_reduction_switch=False,
                loc_maturity_treatment_switch=False,
                apply_curve=True,
                process_ALLL_balances=process_ALLL_balances
            )

            current_facility_v1['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
            current_facility_v2['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
            current_facility_v3['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods
            current_facility_v4['UNIQUE_FACILITY_ID'] = [unique_facility_id] * forecast_periods

            try:
                bw_results.append(pd.DataFrame(current_facility_v1))
            except ValueError as e:
                print(current_facility_v1)

            try:
                bw_results.append(pd.DataFrame(current_facility_v2))
            except ValueError as e:
                print(current_facility_v2)

            try:
                bw_results.append(pd.DataFrame(current_facility_v3))
            except ValueError as e:
                print(current_facility_v3)

            try:
                bw_results.append(pd.DataFrame(current_facility_v4))
            except ValueError as e:
                print(current_facility_v4)

    bw_results_final = pd.concat(bw_results)
#    bw_results_pivot = bw_results_final.groupby(
#        by=[
#            'PERIODDATE',
#            'LOANTYPE',
#            'PORTFOLIO',
#            'MODEL',
#            'SCENARIO',
#            'LOC_DEFAULT_REDUCTION_FLAG',
#            'LOC_MATURITY_TREATMENT_FLAG',
#            'BW_MODE'
#        ]
#    )[[
#        'BALANCE',
#        'CALCULATEDLINE',
#        'STARTINGBALANCE',
#        'FINALBALANCE',
#        'DEFAULTBALANCE',
#        'LGDAMOUNT',
#        'NCOAMOUNT',
#        'EADAMOUNT',
#        'ALLLRESERVEAMOUNT',
#        'CONTINGENTRESERVEAMOUNT'
#    ]].sum()
    
    bw_results_pivot = bw_results_final.groupby(
        by=[
            'PD_GROUP',
            'PERIODDATE',
            'LOANTYPE',
            'PORTFOLIO',
            'MODEL',
            'SCENARIO',
            'LOC_DEFAULT_REDUCTION_FLAG',
            'LOC_MATURITY_TREATMENT_FLAG',
            'BW_MODE'
        ]
    )[[
        'BALANCE',
        'CALCULATEDLINE',
        'STARTINGBALANCE',
        'FINALBALANCE',
        'DEFAULTBALANCE',
        'LGDAMOUNT',
        'NCOAMOUNT',
        'EADAMOUNT',
        'ALLLRESERVEAMOUNT',
        'CONTINGENTRESERVEAMOUNT'
    ]].sum()

    return(bw_results, bw_results_final, bw_results_pivot)

