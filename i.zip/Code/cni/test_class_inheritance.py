# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 10:10:47 2017

@author: n882049
"""

class Person:
    lastname = None
    def __init__(self, first, last):
        self.firstname = first
        self.lastname = last

    def Name(self):
        return self.firstname + " " + self.lastname

class Employee(Person):

    def __init__(self, first, last, staffnum, last_change):
        Person.__init__(self,first, last)
        self.staffnumber = staffnum
        super().lastname = last_change

    def GetEmployee(self):
        return self.Name() + ", " +  self.staffnumber

x = Person("Marge", "Simpson")
y = Employee("Homer", "Simpson", "1007", "Peng")

print (Person.lastname)
print (x.lastname)
print (y.lastname)

print(x.Name())
print(y.GetEmployee())


class Car(object):
    wheels = 4

    def __init__(self, make):
        self.make = make

newCar = Car("Honda")
print ("My new car is a {}".format(newCar.make))
print ("My car, like all cars, has {%d} wheels".format(Car.wheels))