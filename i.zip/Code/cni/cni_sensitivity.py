'''
# sample use      
## Using ms_test_class ##
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2017,6,30)            # not in run.py
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO = ["ADVERSE","STRESS"]
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           # not in run.py
FINANCIAL_IN_RFO_SWITCH = False

# pd_groups = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL']

example = SensitivityProcessor(
		class_type = CNIModel,
		pd_groups = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
		model_name= 'C&I',
		ejm_ind= False,
            as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
            scenario=SCENARIO,                                           # scenario name
            scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
            scenario_date=AS_OF_DATE,                                    # scenario 'real' as-of-date
            scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
            forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
            forecast_periods_frequency='monthly',                        # forecast periods frequency
            pass_srr=4.0,                                                # initial passing SRR
            model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
            debug=False,                                                 # debug mode, if True more messages will be displayed
            include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
            auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
            limit_contracts=None,                                        # for testing purposes, number of random contracts to pick
            statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
            portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
            mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
            mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
            scenario_combinations = None,
            financial_in_rfo = FINANCIAL_IN_RFO_SWITCH
            )


# change variable order
# @@@PAY ATTENTION@@@: the changing order is the reversed variables list @@@__@@@ 
example.ShowVariables
# cut variables into small groups
example.ChangeVariable(new = ['FZ_US', 'FGDPQ_US', 'FLBR_US', 'FHOFHOPIQ_US'],cutpoint= 'FGDPQ_US')

# make plots
plots = example.getPlot(rename = {'FHOFHOPIQ_US': 'HPI', 'FLBR_US':'Unemployment Rate'})

BASE_ADVERSE = example.getValue


SCENARIO = ["FRB_ADVERSE","FRB_SA"]
SCENARIO_SEVERITY_LEVEL = "ADVERSE"
example_2 = SensitivityProcessor(
		class_type = CNIModel,
		pd_groups = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
		model_name= 'C&I',
		ejm_ind= False,
		uncertainty_rate=0.,
            as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
            scenario=SCENARIO,                                           # scenario name
            scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
            scenario_date=AS_OF_DATE,                                    # scenario 'real' as-of-date
            scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
            forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
            forecast_periods_frequency='monthly',                        # forecast periods frequency
            pass_srr=4.0,                                                # initial passing SRR
            model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
            debug=False,                                                 # debug mode, if True more messages will be displayed
            include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
            auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
            limit_contracts=None,                                        # for testing purposes, number of random contracts to pick
            statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
            portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
            mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
            mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
            scenario_combinations = None)
example_2.ChangeVariable(new = ['FZ_US', 'FGDPQ_US', 'FLBR_US', 'FHOFHOPIQ_US'],cutpoint= 'FGDPQ_US')
example_2.ShowVariables
plots_2 = example_2.getPlot(rename = {'FHOFHOPIQ_US': 'HPI', 'FLBR_US':'Unemployment Rate'})
ADVERSE_SA = example_2.getValue

# save plots
plot1 = plots[0]
plot1.savegfig('to/where/you/want')

# decompose getPlot
# example is a SensitivityProcessor instance and the input class_type is CREConstruction

anchor = example.getAnchor(example.pd_groups, example._getAsOfDate())
CF = example.CFGenerator(example._para_dict)
BW = example.BWGenerator(CF,anchor)
values = example._getValue(BW,LOC_DEFAULT_REDUCTION_FLAG = 'N',LOC_DEFAULT_REDUCTION_FLAG = 'N')
# values is the a list of tuples
amounts = [i[1] for i in values ]
rates = [i[0] for i in values]
variables = ['BASE'] + example.ShowVariables + ['SA']
plot1 = example.sensitivity_plot(variables,amounts,...)

# Show the contributor files
example.CFGenerator(example._para_dict)
next(example.CFGenerator(example._para_dict))


# test my code
all_combos[2]
all_combos[3]
cni_model_instance_HPI = cni.CNIModel(
    as_of_date=datetime.datetime(2016,12,31),                    
    scenario=scenario_list,                              # scenario list
    scenario_context="CCAR2017",                                 
    scenario_date=datetime.datetime(2016,12,31),                 # scenario as-of-date
    scenario_severity_level="ADVERSE",                              # scenario severity level
    forecast_periods=27,                                         
    forecast_periods_frequency='monthly',                        
    pass_srr=4.0,                                                
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    
    debug=False,                                                 
    include_originations_switch=True,                            
    auto_fetch_macros=True,                                      
    limit_contracts=None,                                        
    portfolio_snapshot_date=datetime.datetime(2016,12,31),       
    mature_non_pass_locs=True,                                   
    mra_asofdate = datetime.datetime(2016,12,31),
    scenario_combinations = all_combos[2]                                 # scenario_combinations
    )
cni_model_instance_GDP = cni.CNIModel(
    as_of_date=datetime.datetime(2016,12,31),                    
    scenario=scenario_list,                              # scenario list
    scenario_context="CCAR2017",                                 
    scenario_date=datetime.datetime(2016,12,31),                 # scenario as-of-date
    scenario_severity_level="ADVERSE",                              # scenario severity level
    forecast_periods=27,                                         
    forecast_periods_frequency='monthly',                        
    pass_srr=4.0,                                                
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    
    debug=False,                                                 
    include_originations_switch=True,                            
    auto_fetch_macros=True,                                      
    limit_contracts=None,                                        
    portfolio_snapshot_date=datetime.datetime(2016,12,31),       
    mature_non_pass_locs=True,                                   
    mra_asofdate = datetime.datetime(2016,12,31),
    scenario_combinations = all_combos[3]                                 # scenario_combinations
    )
## Getting raw and transformed macro series
transformed_macro_series_1 = cni_model_instance_HPI.transformed_macro_series
transformed_macro_series_2 = cni_model_instance_GDP.transformed_macro_series

## Getting change in sales, profit margin and pd mapping stress time series
macro_data_1 = cni_model_instance_HPI.macro_data
macro_data_2 = cni_model_instance_GDP.macro_data



'''       

import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.sensitivity.balancewalk as bw
from CIFI.controllers.models.cniriskrating import CNIModel
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalkMacroSensitivity
import CIFI.controllers.utilities.utilities as utilities
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import matplotlib.cm as cm
import datetime
import numpy as np
import pandas as pd
import itertools
import _pickle 
import itertools
from matplotlib.backends.backend_pdf import PdfPages
from CIFI.controllers.models.cniriskrating import *
from CIFI.sensitivity.triple_plot import triple_sensitivity_plot, quadruple_sensitivity_plot
# new way of combo
comb = {
        'FHOFHOPIQ_US': 'FRB_SA',
        'FLBR_US': 'FRB_SA',
        'FGDPQ_US': 'BHC_STRESS',
        'FZ_US': 'BHC_STRESS'}
scenario_severity_level = 'STRESS'
scenario_list = ['FRB_SA', 'BHC_STRESS']   # FRB_BASE/FRB_ADVERSE/FRB_SA

AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018  # ICAAP2018_CCAR
FORECAST_PERIODS = 27   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"

cni_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                    
    scenario=scenario_list,                              # scenario list
    scenario_context=STRESS_TESTING_CYCLE,                                 
    scenario_date=SCENARIO_DATE,                 # scenario as-of-date
    scenario_severity_level=scenario_severity_level,                              # scenario severity level
    forecast_periods=FORECAST_PERIODS,                                         
    forecast_periods_frequency='monthly',                        
    pass_srr=4.0,                                                
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    
    debug=False,                                                 
    include_originations_switch=True,                            
    auto_fetch_macros=True,                                      
    limit_contracts=None,   
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,                                     
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,       
    mature_non_pass_locs=True,                                   
    scenario_combinations = comb,                                 # scenario_combinations
    show_result_plot = True,
    risk_rating_dataset_input_path = RISK_RATING_DATASET_INPUT_PATH
    )

## Create a session instance and a model shopping cart to run the CNIModel
ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 UAT',
    session_date=datetime.datetime(2017,12,31)
)
cart = ModelShoppingCart(ccar_session=ccar_session)
## Add model to the shopping cart and execute
cart.addModel(cni_model_instance)
cart.checkout() # execute() is called here

cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

# get anchor from risk rating dataset(From Joe; Using PD_GROUP_TOOL instead of PD_GROUP_2017)
anchor_data = getBWFormatAnchorData(
                as_of_date = PORTFOLIO_SNAPSHOT_DATE,
                risk_rating_switch = True,
                only_risk_rating = True,
                cni_dataset_path = RISK_RATING_DATASET_INPUT_PATH, 
                overwrite_calculated_line = True,
                debug=True
    )

## reset CF generator and shopping cart
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()


segfield2_to_nco_timing_curve = None
t0=time.time()
bw_output = balanceWalkMacroSensitivity(
                cf_data = cf_data,
                anchor_data = anchor_data,
                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
                process_ALLL_balances = True,
                debug = True
            )
print('Blance walk completed in ' + str(time.time()-t0) + ' s.')

# Pivot balance walk output
pivot_bw=balanceWalkPivot(bw_output,27, AS_OF_DATE, bw_output_from_csv = False)        
pivot_bw.drop(['LGDAMOUNT', 'LGD(%)', 'Annulized LGD(%)', 'Annulized NCO(%)'], axis=1, inplace = True)
pivot_bw.to_csv('C:/Users/n882049/Downloads/BW_Pivot_FRB_SA_FGDPQ_BHC_FZ_BHC.csv')

# UBB
BASE_A = {'singleInput': [
 (1.33139544908342, 17788105.0693175), 
 (2.22599062969891, 29740341.4077012), 
 (2.64766372938219, 35374103.643583), 
 (2.69467934255741, 36002255.6082265),
 (2.69467934255741, 36002255.6082265)
  ]}

A_SA = {'singleInput': [ 
 (2.69467934255741, 36002255.6082265), 
 (5.29962019531393, 70805560.3814933), 
 (6.33778384738709, 84675942.8699847), 
 (7.01626619687048, 93740804.3494171),
 (7.01626619687048, 93740804.3494171)
 ]}
SA_BHC = {'singleInput': [ 
 (7.01626619687048, 93740804.3494171), 
 (5.77869247470444, 77206204.1928136), 
 (5.66279450183752, 75657749.6595666), 
 (5.5545540042583, 74211602.8028833), 
 (5.5545540042583, 74211602.8028833)
 ]}
variables_name = ['FRB BASE', 'HPI', 'Unemployment', 'Others', 'FRB ADVERSE', 'HPI', 'Unemployment','Others','FRB SA', 'HPI', 'Unemployment', 'Others', 'BHC STRESS']
 
# ABL
BASE_A = {'singleInput': [
 (0.619581779820545, 6724942.05887322), 
 (0.81617897981386, 8858808.51839804), 
 (0.93925202867563, 10194643.6729502), 
 (1.03348756464603, 11217476.396455), 
 (1.12772310061643, 12240309.1199598),
 (1.12772310061643, 12240309.1199598)
  ]}
  
A_SA = {'singleInput': [ 
 (1.12772310061643, 12240309.1199598), 
 (1.56161103430639, 16949729.7471356), 
 (1.84990052569574, 20078824.5477234), 
 (2.13793104802033, 23205108.4974886), 
 (2.30357039457957, 25002958.3448536),
 (2.30357039457957, 25002958.3448536)
 ]}
SA_BHC = {'singleInput': [ 
 (2.30357039457957, 25002958.3448536), 
 (2.15092363187356, 23346130.0324235), 
 (2.12167998046666, 23028719.3729973), 
 (2.09791522379935, 22770776.6496377), 
 (2.09791522379935, 22770776.6496377), 
 (2.09791522379935, 22770776.6496377)
 ]}
variables_name = ['FRB BASE', 'Unemployment', 'HPI', 'GDP', 'Corp Profit', 'FRB ADVERSE', 'Unemployment', 'HPI','GDP', 'Corp Profit', 'FRB SA', 'HPI', 'Unemployment','GDP', 'Corp Profit','BHC STRESS']
 
# MM
BASE_A = {'singleInput': [
 (0.998327973467348, 33540950.6970353), 
 (1.62665267792059, 54650854.9508448), 
 (2.07204227067206, 69614665.2100775), 
 (2.18836002890061, 73522607.5873539),
 (2.18836002890061, 73522607.5873539)
  ]}
  
A_SA = {'singleInput': [ 
 (2.18836002890061, 73522607.5873539), 
 (4.30721987185794, 144710208.671722), 
 (5.37305865461197, 180519328.533583), 
 (6.09618381877382, 204814255.775479),
 (6.09618381877382, 204814255.775479)
 ]} 
SA_BHC = {'singleInput': [ 
 (6.09618381877382, 204814255.775479), 
 (5.14855367948513, 172976606.600415), 
 (5.02143320782536, 168705724.09903), 
 (4.92116361969042, 165336954.114187), 
 (4.92116361969042, 165336954.114187)
 ]}
variables_name = ['FRB BASE', 'HPI', 'Unemployment', 'Others', 'FRB ADVERSE', 'HPI', 'Unemployment','Others','FRB SA', 'HPI', 'Unemployment','Others','BHC STRESS']



values = [i[1] for i in BASE_A['singleInput']] + [i[1] for i in A_SA['singleInput'][1:]] + [i[1] for i in SA_BHC['singleInput'][1:]]
pct_value = [i[0] for i in BASE_A['singleInput']] + [i[0] for i in A_SA['singleInput'][1:]] + [i[0] for i in SA_BHC['singleInput'][1:]]

# IF 3 scenario
aa = triple_sensitivity_plot(names = variables_name,value=values,pct_value=pct_value,title = 'MM Sensitivity',dollar_ind = True )
# IF 4 scenario
aa = quadruple_sensitivity_plot(names_all = variables_name,
                             value_all=values,
                             pct_value_all= pct_value,
                             title = '',
                             dollar_ind = True,
                             color_schema='distinct',
                             see_or_not=False)

aa.savefig('c:/Users/n882049/Downloads/testabl.png')

############ CEVF sensitivity  ###############
# new way of combo
comb = {
        'FLBR_US': 'FRB_BASE',
        'bond_spread_lag_diff': 'FRB_BASE}
FLBR_US / bond_spread_lag_diff
scenario_severity_level = 'ADVERSE'
scenario_list = ['FRB_BASE', 'FRB_ADVERSE']   # FRB_BASE/FRB_ADVERSE/FRB_SA


AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018  # ICAAP2018_CCAR
FORECAST_PERIODS = 27   # number of forecast month

TwoFLogitModel_CEVF_model_instance = TwoFLogitModel(
                uncertainty_rate=0.,
                as_of_date=AS_OF_DATE,
                scenario_date=SCENARIO_DATE,
                model_id='53 - Scenario Analysis Model - CEVF PD - SBNA',
                scenario=SCENARIO,
                scenario_context=STRESS_TESTING_CYCLE,
                forecast_periods=FORECAST_PERIODS,
                scenario_combinations = comb
            )

###############  Add model to the shopping cart and execute  ###########
cart.addModel(TwoFLogitModel_CEVF_model_instance)
cart.checkout()       # execute() is called here



######## CRE Construction ######
from CIFI.controllers.ejm.ejmmaster import ejmDictionaryGenerator, EJMGenerator
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalk, balanceWalkMacroSensitivity, getNCOCurve, balanceWalkPivot
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "FRB_ADVERSE"   # FRB_BASE/FRB_ADVERSE/FRB_SA/BHC_STRESS   # GLOBAL_STRESS
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018/ICAAP2018_CCAR
EJM_SCENARIO_SEVERITY_LEVEL = "ADVERSE"  # BASE/ADVERSE/STRESS/BHC_STRESS/BHC_ADVERSE
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 27   # Attention: max length in ejm master is 45, if larger than 45, addCFChunk will give missing;
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'
ONLY_RUN_CEVF_CRECONSTRUCTION = True
ENERGY_FINANCE_FACILITY_RATE = False

ccar_session = CCARSession(
    session_id='Commercial EJM 2017',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

commercial_ejm_generator = EJMGenerator(
    as_of_date = AS_OF_DATE,
    ejm_dictionary=ejmDictionaryGenerator(
        asofdate = PORTFOLIO_SNAPSHOT_DATE,
        version_date=AS_OF_DATE,
        scenario_pairs = {
            EJM_SCENARIO_SEVERITY_LEVEL:SCENARIO
        },
        pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
        rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
        rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
        ejm_master_file_path = EJM_MASTER_FILE_PATH,
        only_run_cevf_creconstruction = ONLY_RUN_CEVF_CRECONSTRUCTION,
        energy_finance_facility_rate = ENERGY_FINANCE_FACILITY_RATE,
        forecast_periods = FORECAST_PERIODS,
        debug=False,
        logger=ccar_session._logger
    ),
    forecast_periods=FORECAST_PERIODS,
    process_additional_ead=False,
    debug=False,
    logger=ccar_session._logger
)
    
cart.addModel(commercial_ejm_generator)
    
from CIFI.controllers.models.creconstruction17 import CREConstruction
comb = {
        'FHSTQ_US': 'FRB_ADVERSE',
        'FRGT5Y_US': 'FRB_BASE',
        'FZFL075035503Q_US': 'FRB_BASE'}
        
scenario_severity_level = 'ADVERSE'
scenario_list = ['FRB_BASE', 'FRB_ADVERSE']   # FRB_BASE/FRB_ADVERSE/FRB_SA


AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018  # ICAAP2018_CCAR
FORECAST_PERIODS = 27   # number of forecast month

CRE_construction_model_instance = CREConstruction(
    uncertainty_rate=0.,
    as_of_date=AS_OF_DATE,
    model_id="2016-SBNA-Loss-Commercial-CREConstruction",
    scenario=scenario_list,
    scenario_date=SCENARIO_DATE,
    scenario_context=STRESS_TESTING_CYCLE,
    forecast_periods=FORECAST_PERIODS,
    scenario_combinations = comb
)


## Add model to the shopping cart and execute
cart.addModel(CRE_construction_model_instance)
cart.checkout() # execute() is called here

cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

# get anchor from risk rating dataset(From Joe; Using PD_GROUP_TOOL instead of PD_GROUP_2017)
anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=False,
                pd_groups=['CRE_CONSTRUCTION'],
                overwrite_calculated_line = True
                )     

## reset CF generator and shopping cart
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()


segfield2_to_nco_timing_curve = None
t0=time.time()
bw_output = balanceWalkMacroSensitivity(
                cf_data = cf_data,
                anchor_data = anchor_data,
                segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
                process_ALLL_balances = True,
                debug = True
            )
print('Blance walk completed in ' + str(time.time()-t0) + ' s.')

# Pivot balance walk output
pivot_bw=balanceWalkPivot(bw_output,27, AS_OF_DATE, bw_output_from_csv = False)        
pivot_bw.drop(['LGDAMOUNT', 'LGD(%)', 'Annulized LGD(%)', 'Annulized NCO(%)'], axis=1, inplace = True)
pivot_bw.to_csv('C:/Users/n882049/Downloads/BW_Pivot_FRB_ADVERSE_FZFL075035503Q_SA.csv')



################################### 2017 MidCycle Version ###################################
# Change the scenarios cumulatively #
#[{'FGDPQ_US': 'FRB_ADVERSE',
#  'FHOFHOPIQ_US': 'FRB_ADVERSE',
#  'FLBR_US': 'FRB_ADVERSE',
#  'FZ_US': 'FRB_ADVERSE'},
# {'FGDPQ_US': 'FRB_ADVERSE',
#  'FHOFHOPIQ_US': 'FRB_SA',
#  'FLBR_US': 'FRB_ADVERSE',
#  'FZ_US': 'FRB_ADVERSE'},
# {'FGDPQ_US': 'FRB_ADVERSE',
#  'FHOFHOPIQ_US': 'FRB_SA',
#  'FLBR_US': 'FRB_SA',
#  'FZ_US': 'FRB_ADVERSE'},
# {'FGDPQ_US': 'FRB_SA',
#  'FHOFHOPIQ_US': 'FRB_SA',
#  'FLBR_US': 'FRB_SA',
#  'FZ_US': 'FRB_ADVERSE'},
# {'FGDPQ_US': 'FRB_SA',
#  'FHOFHOPIQ_US': 'FRB_SA',
#  'FLBR_US': 'FRB_SA',
#  'FZ_US': 'FRB_SA'}]


# get the combination of macro and scenario
def combo_generator(variables,scenarios,triangle = True):
    if isinstance(scenarios,str) or len(scenarios) == 1:
        return {i:j for i,j in zip(variables,[scenarios]*len(variables))}
    if triangle:
        all_combos = itertools.combinations_with_replacement(scenarios, len(variables))
        outputs = []
        start = next(all_combos)
        while start is not None:
            per = {v:s for v,s in zip(variables,start)}
            outputs.append(per)
            try:
                start = next(all_combos)
            except StopIteration:
                start = None
        return outputs
    else:
        outputs = []
        raw_all_combos = list(itertools.combinations_with_replacement(scenarios*len(variables), len(variables)))
        processed = set(raw_all_combos)
        for combo in processed:
            per = {v:s for v,s in zip(variables,combo)}
            outputs.append(per)
        return outputs

# return last day of the month in datatime format
def last_day_of_month(date):
    if date.month == 12:
        return date.replace(day=31)
    return date.replace(month=date.month+1, day=1) - datetime.timedelta(days=1)

# get a list of (loss rate, loss amount) pairs from balance walk outputs
def getLossFromBW(bw_output_list, bw_mode, curve_switch, as_of_date, forecast_month):
    # check validility of inputs
    if bw_mode not in [1,2,3,4]:
        raise ValueError("Invalid balance walk mode! Valid values are 1,2,3,4")
    utilities.checkDataType(curve_switch, bool)
    # get the end date of the forecast    
    end_date = last_day_of_month(utilities.addMonths2date(as_of_date, forecast_month))
        
    loss = []
    for item in bw_output_list:
        # get subset of bw output by filtering the BW mode and period date
        bw_output_sub = item[
                    (item.index.get_level_values('BW_MODE') == bw_mode)
                    &
                    (item.index.get_level_values('PERIODDATE') > as_of_date)
                    &
                    (item.index.get_level_values('PERIODDATE') <= end_date)
                    ] 
        
        # get loss amount and loss rate for all PD_group
        nco = bw_output_sub.sum()['NCOAMOUNT'] if curve_switch else bw_output_sub.sum()['LGDAMOUNT']
        
        bw_output_as_of_date = last_day_of_month(utilities.addMonths2date(min(item.index.get_level_values('PERIODDATE')), -1))
        if as_of_date == bw_output_as_of_date:
            starting_balance = bw_output_sub.sum()['STARTINGBALANCE']
        else:
            start_date_sub = item[
                    (item.index.get_level_values('BW_MODE') == bw_mode)
                    &
                    (item.index.get_level_values('PERIODDATE') == as_of_date)
                    ] 
            starting_balance = start_date_sub.sum()['BALANCE']
        nco_rate = nco/starting_balance
        loss.append((nco_rate * 100, nco))
        
    # append last value to the loss list
    loss.append(loss[-1])
    return(loss)

# generate sensitivity plots for loss amount/loss rate from balance walk
def generateSensitivityPlot(loss_1, loss_2, variables_name, plot_title, save_path):
    BASE_A, A_SA = {'singleInput': loss_1}, {'singleInput': loss_2}

    values = [i[1] for i in BASE_A['singleInput']] + [i[1] for i in A_SA['singleInput'][1:]]
    pct_value = [i[0] for i in BASE_A['singleInput']] + [i[0] for i in A_SA['singleInput'][1:]]
    aa = triple_sensitivity_plot(names = variables_name,value=values,pct_value=pct_value,title = plot_title, dollar_ind = True )
    aa.savefig(save_path)   

# macro combination
macro_list = ['FZ_US', 'FGDPQ_US', 'FLBR_US', 'FHOFHOPIQ_US']
scenario_list = ['FRB_ADVERSE', 'FRB_SA']       
severity_list = ['ADVERSE', 'STRESS']
all_combos = combo_generator(macro_list,scenario_list, triangle = True) 
# remove forth combination to combine last two macro
del all_combos[3]

############################# MC Round 1 setting ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2017,6,30)            # not in run.py
STRESS_TESTING_CYCLE = "MidCycle2017"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           # not in run.py
FINANCIAL_IN_RFO_SWITCH = False

############################# MC Round 1 setting (CCAR scenario) ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2016,12,31)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2017,6,30)            # not in run.py
STRESS_TESTING_CYCLE = "CCAR2017"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           # not in run.py
FINANCIAL_IN_RFO_SWITCH = False

######################### CCAR 2018 Official Run 1 ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "BHC_STRESS"   # FRB_BASE/FRB_ADVERSE/FRB_SA/BHC_STRESS   # GLOBAL_STRESS
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018  # ICAAP2018_CCAR
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 48   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"


# get portfolio snapshot
anchor_query, anchor_data = bw.getBWFormatAnchorData(
                as_of_date=AS_OF_DATE,
                debug=True,
                pd_groups=["MIDDLE_MARKET", "BUSINESS_BANKING", "ABL"]
            )

cf_container = []
transformed_macro_series_list = []
macro_data_list = []

# comb = {'FLBR_US': 'FRB_BASE', 'FHOFHOPIQ_US': 'FRB_BASE', 'FZ_US': 'FRB_BASE', 'FGDPQ_US': 'FRB_BASE'}
# comb = all_combos[0]
for idx, comb in enumerate(all_combos):
    print('Running C&I model-......' + str(idx+1) + ' with:')
#    print(idx)
#    print(comb)
    if idx == 0:
        # Create CNIModel instance for Base severity
        cni_model_instance = cni.CNIModel(
            as_of_date=AS_OF_DATE,                    
            scenario=scenario_list,                              # scenario list
            scenario_context=STRESS_TESTING_CYCLE,                                 
            scenario_date=SCENARIO_DATE,                 # scenario as-of-date
            scenario_severity_level=severity_list[0],                              # scenario severity level
            forecast_periods=FORECAST_PERIODS,                                         
            forecast_periods_frequency='monthly',                        
            pass_srr=4.0,                                                
            model_id="743 - Commercial Rating Model - C&I PD - SBNA",    
            debug=False,                                                 
            include_originations_switch=True,                            
            auto_fetch_macros=True,                                      
            limit_contracts=None,   
            statement_days_threshold=STATEMENT_DAYS_THRESHOLD,                                     
            portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,       
            mature_non_pass_locs=True,                                   
            mra_asofdate = MRA_ASOFDATE,
            scenario_combinations = comb,                                 # scenario_combinations
            financial_in_rfo = FINANCIAL_IN_RFO_SWITCH
            )
        
    else:
        # create CNI model instance for SA severity case
        cni_model_instance = cni.CNIModel(
            as_of_date=AS_OF_DATE,                    
            scenario=scenario_list,                              # scenario list
            scenario_context=STRESS_TESTING_CYCLE,                                 
            scenario_date=SCENARIO_DATE,                 # scenario as-of-date
            scenario_severity_level=severity_list[1],                              # scenario severity level
            forecast_periods=FORECAST_PERIODS,                                         
            forecast_periods_frequency='monthly',                        
            pass_srr=4.0,                                                
            model_id="743 - Commercial Rating Model - C&I PD - SBNA",    
            debug=False,                                                 
            include_originations_switch=True,                            
            auto_fetch_macros=True,                                      
            limit_contracts=None,       
            statement_days_threshold=STATEMENT_DAYS_THRESHOLD,                                 
            portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,       
            mature_non_pass_locs=True,                                   
            mra_asofdate = MRA_ASOFDATE,
            scenario_combinations = comb,                                 # scenario_combinations
            financial_in_rfo = FINANCIAL_IN_RFO_SWITCH
            )
    
    # check macro and transformation
    transformed_macro_series_list.append(cni_model_instance.transformed_macro_series)
    macro_data_list.append(cni_model_instance.macro_data)
    
    ## Create a session instance and a model shopping cart to run the CNIModel
    ccar_session = CCARSession(
        session_id='C&I Risk Rating 2017 UAT',
        session_date=datetime.datetime(2016,12,31)
    )
    cart = ModelShoppingCart(ccar_session=ccar_session)
    ## Add model to the shopping cart and execute
    cart.addModel(cni_model_instance)
    cart.checkout() # execute() is called here
    
    ## Get contributor file and store in the cf container
    cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
    cf_container.append(cf.getCFData())

    ## reset CF generator and shopping cart
    ccar_session.contributor_file_generator.resetGenerator()
    cart.resetCart()

# generate balance walk outputs and combine them 
bw_output_list = []
pivot_bw_list = []
count = 1

EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_2Q17.xlsm'
segfield2_to_nco_timing_curve=getNCOCurve(        
        forecast_period=FORECAST_PERIODS,
        nco_data_path = EJM_MASTER_FILE_PATH,
        timing_curve_switch = True   
    )      

for cf_data in cf_container:
    print('Running balance walk.......' + str(count))
    t0=time.time()
    bw_output = balanceWalkMacroSensitivity(
                    cf_data = cf_data,
                    anchor_data = anchor_data,
                    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
                    process_ALLL_balances = True,
                    debug = True
                )
    bw_output_list.append(bw_output)
    pivot_bw=balanceWalkPivot(bw_output,FORECAST_PERIODS)  
    pivot_bw_list.append(pivot_bw)
    print('Blance walk completed in ' + str(time.time()-t0) + ' s.')
    count+=1
    
# save and loan balance walk output
_pickle.dump(bw_output_list, open("I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/bw_output_list_ADVERSE_STRESS_CCAR Scenario.p", 'wb')) 
_pickle.dump(transformed_macro_series_list, open("I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/transformed_macro_series_list_ADVERSE_STRESS_CCAR Scenario.p", 'wb')) 
_pickle.dump(macro_data_list, open("I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/macro_data_list_ADVERSE_STRESS_CCAR Scenario.p", 'wb')) 

bw_output_list_BASE_ADVRESE = _pickle.load(open("I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/bw_output_list_BASE_ADVERSE_CCAR Scenario.p", 'rb'))
bw_output_list_ADVRESE_STRESS = _pickle.load(open("I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/bw_output_list_ADVERSE_STRESS_CCAR Scenario.p", 'rb'))
#trans = _pickle.load(open("I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/transformed_macro_series_list_BASE_ADVERSE_4.p", 'rb'))
#macro = _pickle.load(open("I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/macro_data_list_BASE_ADVERSE_4.p", 'rb'))

item = bw_output_list[0]
FORECAST_MONTH = 27
    
loss_1 = getLossFromBW(bw_output_list = bw_output_list_BASE_ADVRESE,
              bw_mode = 1, 
              curve_switch = False,
              as_of_date = AS_OF_DATE,
              forecast_month = FORECAST_MONTH
              )
loss_2 = getLossFromBW(bw_output_list = bw_output_list_ADVRESE_STRESS,
              bw_mode = 1, 
              curve_switch = False,
              as_of_date = AS_OF_DATE,
              forecast_month = FORECAST_MONTH    
              )
              
### test last 5Q  ###   
loss_1 = getLossFromBW(bw_output_list = bw_output_list_BASE_ADVRESE,
              bw_mode = 1, 
              curve_switch = False,
              as_of_date = datetime.datetime(2018, 6, 30) ,
              forecast_month = 15
              )
loss_2 = getLossFromBW(bw_output_list = bw_output_list_ADVRESE_STRESS,
              bw_mode = 1, 
              curve_switch = False,
              as_of_date = datetime.datetime(2018, 6, 30) ,
              forecast_month = 15    
              )

generateSensitivityPlot(loss_1 = loss_1,
                        loss_2 = loss_2,
                        variables_name = ['FRB_BASE', 'HPI', 'Unemployment Rate','Others','FRB_ADVERSE', 'HPI', 'Unemployment Rate','Others','FRB_SA'],
                        plot_title = 'C&I Sensitivity', 
                        save_path = 'I:/CRMPO/DEPT/Steven/sensitivity/MidCycle2017/C&I_Sensitivity_CCAR Scenraio_9Q_NO_TC.png'
                    )








# generate sensitivity plots for loss amount/loss rate from balance walk
def generateSensitivityPlot(loss_1, loss_2, variables_name, plot_title, save_path):
    BASE_A, A_SA = {'singleInput': loss_1}, {'singleInput': loss_2}

    values = [i[1] for i in BASE_A['singleInput']] + [i[1] for i in A_SA['singleInput'][1:]]
    pct_value = [i[0] for i in BASE_A['singleInput']] + [i[0] for i in A_SA['singleInput'][1:]]
    aa = triple_sensitivity_plot(names = variables_name,value=values,pct_value=pct_value,title = plot_title, dollar_ind = True )
    aa.savefig(save_path)  

## bar plot for loss rate
#for item in bw_output_list:
#    # calculate loss amount and loss rate using balance walk output
#    BW_MODE = 1
#    # get subset of specific BW_MODE
#    bw_output_sub = item[item.index.get_level_values('BW_MODE') == BW_MODE]
#    
#    # get loss amount and loss rate for all PD_group
#    pd_group_nco = bw_output_sub.groupby(bw_output_sub.index.get_level_values('PD_GROUP')).sum()['NCOAMOUNT']
#    pd_group_balance = bw_output_sub.groupby(bw_output_sub.index.get_level_values('PD_GROUP')).sum()['STARTINGBALANCE']
#    pd_group_nco_rate = pd_group_nco/pd_group_balance
#    
#        
#    # bar plot for loss rate
#    label = ('ABL', 'BUSINESS_BANKING', 'MIDDLE_MARKET')
#    fig, ax = plt.subplots()
#    y_pos = np.arange(len(label))
#    plt.bar(y_pos, pd_group_nco_rate, align='center', width = 0.5, alpha=1)
#    ax.set_xticks(y_pos)
#    ax.set_xticklabels(label)
#    ax.set_xlabel('PD Group')
#    ax.set_ylabel('Loss Rate')
#    vals = ax.get_yticks()
#    ax.set_yticklabels(['{:3.1f}%'.format(x * 100) for x in vals])
#    ax.set_title('Loss Rate for C&I with Balance Walk Mode ' + str(BW_MODE))

def sensitivity_plot(
    names : list,
    value : list,
    tags : str = 'percent',
    title : str = '',
    dollar_ind : bool = False):
    # color dict (will be used if necessary)
    plot_config = {"FRB_BASE": ('lime', '-'),
                   "FRB_ADVERSE": ('royalblue', '-'),
                   "FRB_SA": ('gold', '-'),
                   "BHC_SA": ('red', '-'),
                   "Historical": ('grey', '-'), 
                   "DR_BASE": ('lime', '-'),
                   "DR_SA": ('red', '-'),
                   "MC_BASE": ('lime', '-'),
                   "MC_ADVERSE": ('darkorange', '-'),
                   "MC_SA": ('red', '-')}            
    # input
    
    #    names = ['Base','SA-Macro1','SA-Macro2','SA-Macro3','SA-Macro4','SA']
    #    value = [8,12,15,19,40,40]  
    
    names = [names[0]]+[ '+' + i for i in names[1:-1]] + [names[-1]]

    # make the data
    differ = np.diff(value).tolist()
    posi = np.arange(len(value))
    
    
    change = value[-1] - value[0]
    ch_per = [round(d/change,4) for d in differ][0:-1]
    ch_value = [value[0]] + differ[0:-1] + [value[-1]]
    # adjust for height and bottom
    height = [value[0]] + differ[0:-1]+[value[-1]] 
    bottom = [0] + np.cumsum(height).tolist()[0:-2] + [0]
    width = 0.05
    space = 0.1
    left = [space+i*(width+space) for i in posi]
    
    # adjust for the last bin
    lastheight = height[0:-1]
    lastheight.append(value[-1] - sum(lastheight))
    lastbottom = bottom[0:-1]
    lastbottom.append(sum(height[0:-1]))
    lastleft = [left[-1]]*len(lastheight)
    
    # personalized color
    norm = Normalize(vmin = - min(value), vmax = max(value))
    color = cm.PuBu(norm(height))
    lastcolor = color[0:-1]
    
    # make up adding lines data
    starter_x = np.asarray(left[0:-1]) + width 
    starter_y = value[0:-1]
    end_x = [left[-1]]*len(starter_x)
    end_y = starter_y
    
    # Create figure: fig ->figure object; axs->subplot object
    fig,axs = plt.subplots(1,1,figsize = (12,8))
    # set the margins of plots
    axs.set_xlim(space*0.8,(space + width)*len(value)+space*0.2)
    axs.set_ylim(0,max(value)*1.1)
    
    # add bars
    bar1 = axs.bar(left = left[0:-1],
                   height = height[0:-1],
                   bottom = bottom[0:-1], 
                   width=[width]*(len(value)-1),
                   color =color[0:-1], 
                   alpha = 0.75,
                   edgecolor = color[0:-1],
                   linewidth =0.01)
    bar2 = axs.bar(left = lastleft,
                   height = lastheight,
                   bottom = lastbottom, 
                   width=[width]*len(lastheight),
                   color =lastcolor, 
                   alpha = 0.75,
                   edgecolor = lastcolor,
                   linewidth =0.01)
    
    # add reference line
    axs.hlines(starter_y,starter_x,end_x,linestyle = 'dashdot',color='pink')
    
    # labels control system
    axs.tick_params(
        axis='both',          
        which='both',      
        bottom='off',      
        top='off',        
        left = 'off',
        right = 'off',
        labelbottom='on',
        labelleft = 'off')
    axs.set_xticks(np.asarray(left) + width/2)
    axs.set_xticklabels(names,fontsize = 18)
    
    # Titles control
    axs.set_title(title,fontsize = 20)
    
    #text function to draw tags on bins
    def set_text(bins,ax,value,tags):
        for b,j in zip(bins,value):
            height = b.get_height()
            if j == value[0]:
                if tags == 'percent':
                    ax.text(b.get_x()+b.get_width()/2,b.get_y()+b.get_height(),
                            '%.2f'%(100*j)+'%',ha='center',va='bottom',fontsize=12)
                else:
                    if dollar_ind:
                        ax.text(b.get_x()+b.get_width()/2,b.get_y()+b.get_height(),
                            '${:,.0f}'.format(j),ha='center',va='bottom',fontsize=12)
                    else:
                        ax.text(b.get_x()+b.get_width()/2,b.get_y()+b.get_height(),
                                '%.2f'%(100*j) + '%',ha='center',va='bottom',fontsize=12)
            else:
                if tags == 'percent':
                    ax.text(b.get_x()+b.get_width()/2,b.get_y()+b.get_height(),
                            '%.2f'%(100*j)+'%',ha='center',va='bottom',fontsize=12)
                else:
                    # add a '+' sign for change of values
                    if dollar_ind:
                        ax.text(b.get_x()+b.get_width()/2,b.get_y()+b.get_height(),
                                '+${:,.0f}'.format(j),ha='center',va='bottom',fontsize=12)
                    else:
                        ax.text(b.get_x()+b.get_width()/2,b.get_y()+b.get_height(),
                                '+%.2f'%(100*j) + '%',ha='center',va='bottom',fontsize=12)                                       
                    
    if tags == 'percent':
        set_text(bar1[1:],axs,ch_per,tags)
    elif tags == 'value':
        set_text(bar1,axs,ch_value[0:-1],tags)
        set_text([bar2[-1]],axs,[ch_value[-1]],tags)
    else:
        raise ValueError("Input type cannot find.")
    # adjustment part
    fig.subplots_adjust(left=0.1, right =0.9 ,bottom=0.1, top=0.9)
    axs.axis('on')
    axs.grid(False)
    return fig

'''
#################### old versions  ######################
## generate sensitivity plots for loss amount/loss rate from balance walk
#def generateSensitivityPlot(bw_output_list, pd_group, bw_mode, dollar_switch, contribution_switch, xlabel, save_path):
#    # check validility of inputs
#    if bw_mode not in [1,2,3,4]:
#        raise ValueError("Invalid balance walk mode! Valid values are 1,2,3,4")
#    utilities.checkDataType(dollar_switch, bool)
#    utilities.checkDataType(contribution_switch, bool)
#    
#    # plot 
#    pp = PdfPages(save_path)
#    for portfolio in pd_group:
#        loss_container = []
#        for item in bw_output_list:
#            # get subset of specific BW_MODE
#            bw_output_sub = item[item.index.get_level_values('BW_MODE') == bw_mode]
#            
#            # get loss amount and loss rate for all PD_group
#            pd_group_nco = bw_output_sub.groupby(bw_output_sub.index.get_level_values('PD_GROUP')).sum()['NCOAMOUNT']
#            pd_group_balance = bw_output_sub.groupby(bw_output_sub.index.get_level_values('PD_GROUP')).sum()['STARTINGBALANCE']
#            pd_group_nco_rate = pd_group_nco/pd_group_balance
#            if not dollar_switch:
#                loss_container.append(pd_group_nco_rate[portfolio])
#            elif dollar_switch:
#                loss_container.append(pd_group_nco[portfolio])
#            else:
#                raise ValueError("Invalid loss metric")
#        loss_container.append(loss_container[-1])
#        value = loss_container
#        title = (' Loss Amount ' if dollar_switch else ' Loss Rate ') + 'Sensitivity Plot for ' + portfolio 
#        if contribution_switch:
#            sensitivity_plot(xlabel, value, tags = 'percent', title = title, dollar_ind = dollar_switch)
#        else:
#            sensitivity_plot(xlabel, value, tags = 'value', title = title, dollar_ind = dollar_switch)
#        pp.savefig()
#    pp.close()


#  HPI first  
generateSensitivityPlot(
                    bw_output_list = bw_output_list_hpi, 
                    pd_group = ['ABL', 'BUSINESS_BANKING', 'MIDDLE_MARKET'],
                    bw_mode = 1, 
                    dollar_switch = True,
                    contribution_switch = True,
                    xlabel = ['BASE','HPI', 'Unemployment', 'GDP', 'Corp Profits', 'SA'],
                    save_path = 'I:/CRMPO/DEPT/Steven/sensitivity/sensitivity_plot_hpi_contribution.pdf'
                )      
# Unemployment first 
generateSensitivityPlot(
                    bw_output_list = bw_output_list_unemploy, 
                    pd_group = ['ABL', 'BUSINESS_BANKING', 'MIDDLE_MARKET'],
                    bw_mode = 1, 
                    dollar_switch = True,
                    contribution_switch = True,
                    xlabel = ['BASE', 'Unemployment', 'HPI', 'GDP', 'Corp Profits', 'SA'],
                    save_path = 'I:/CRMPO/DEPT/Steven/sensitivity/sensitivity_plot_unemploy_contribution.pdf'
                )          
'''




