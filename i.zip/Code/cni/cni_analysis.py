# -*- coding: utf-8 -*-
"""
Created on Sat May 20 07:44:21 2017

@author: n882049
"""
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.utilities.utilities as utilities
from CIFI.controllers.models.cniriskrating import CNIMasterDataset, CNIModel
from CIFI.controllers.utilities.logging import Logger, LogItem
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.models.macrovariables.macrovariables import ScenarioMacroSeries
from CIFI.models.modelproperties.modelproperties import ModelProperties
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.controllers.models.riskratingmodel import Mapping
from CIFI.config import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO
from CIFI.models.masterdataset.financialstatements import getRawMRA, getSourceSystemToMRAMap
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalk, balanceWalkMacroSensitivity, getNCOCurve, balanceWalkPivot
import datetime
import pandas as pd
from pandasql import sqldf
import numpy as np
import dateutil.relativedelta as relativedelta
import bisect
import math
import time
from tinydb import TinyDB, Query
import matplotlib.pyplot as plt
import copy
import _pickle

##########################################################################
################ -1. get LINE_TERM from MV_CCMIS_ALL_DATA ################
##########################################################################
asofdate = datetime.datetime(2017,9,30)
# Helpers
date2OracleSTR = lambda x: x.strftime("%d-%b-%Y").upper()

t_0 = time.time()   
query = """
            SELECT DISTINCT SOURCEID, ONE_OBLIGOR_NUMBER, CUSTOMERNUMBER, FACILITYNUMBER, LINE_TERM
            FROM {}
            WHERE AS_OF_DATE = '{}'
            AND UPPER(SOURCEID) NOT IN ('OFFLINE')
        """.format(
                CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["LINE_TERM_DATA"],
                date2OracleSTR(asofdate)
                )

line_term_data = queryRFO(query=query, moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"]) 

t_1 = time.time()
runtime = round((t_1 - t_0), 4)
print('Fetch completed in ' + str(runtime) + ' s.')

line_term_data.to_excel("I:/CRMPO/CCAR/3Q17/4 - Models/Wholesale/C&I/MV_CCMIS_ALL_DATA_LINE_TERM_sep17.xlsx", index = False)
        
##########################################################################
################ 0. run C&I model ########################################
##########################################################################

# before run the following, run the whole cniriskrating.py file

############################# CCAR 2017 RUN ##############################
AS_OF_DATE = datetime.datetime(2016,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2016,12,31)
SCENARIO_DATE = datetime.datetime(2016,12,31)           
MRA_ASOFDATE = datetime.datetime(2016,12,31)            
SCENARIO = "FRB_ADVERSE"
STRESS_TESTING_CYCLE = "CCAR2017"
SCENARIO_SEVERITY_LEVEL = "STRESS"
FORECAST_PERIODS = 27
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = False

############################# SP20 RUN Round 1 ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,2,28)
SCENARIO_DATE = datetime.datetime(2017,3,31)           
MRA_ASOFDATE = datetime.datetime(2016,12,31)            
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "P20"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 45
STATEMENT_DAYS_THRESHOLD = 426           

############################# SP20 RUN Round 2 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,5,31)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,5,31)            
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "MidCycle2017_May"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 396           
FINANCIAL_IN_RFO_SWITCH = False

############################# MC Round 1  ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)            
SCENARIO = "STRESS"   # BASE/ADVERSE/STRESS
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = False

############################# MC Round 1 setting (CCAR scenario) ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2016,12,31)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)            
SCENARIO = "FRB_SA"
STRESS_TESTING_CYCLE = "CCAR2017"
SCENARIO_SEVERITY_LEVEL = "STRESS"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = True

############################# MC Round 2 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)            
SCENARIO = "BASE"    # BASE/ADVERSE/STRESS
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           
FINANCIAL_IN_RFO_SWITCH = True

############################# ALLL RUN ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
MRA_ASOFDATE = datetime.datetime(2017,6,30)     
FINANCIAL_IN_RFO_SWITCH = True
       
SCENARIO = "BASE" 
STRESS_TESTING_CYCLE = "ALLL_MidCycle2017"  
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 30
STATEMENT_DAYS_THRESHOLD = 366           
PD_LAG1Q_SWITCH = False
USE_RFO_MACRO_SERIES = False
NEW_LEQ_SWITCH = False
DISCOUNTING_LGD_SWITCH = False
ADD_UAT_COLUMNS = True

############################# IFRS UAT Run ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)
MRA_ASOFDATE = datetime.datetime(2017,6,30)
FINANCIAL_IN_RFO_SWITCH = True
STATEMENT_DAYS_THRESHOLD = 366

###### NEW IFRS RUN ######    
FORECAST_PERIODS = 132   # number of forecast month
IFRS_SWITCH = True
USE_RFO_MACRO_SERIES = False   # Use macro in SQLite
SCENARIO = "S3" # BASE/S1/S3
STRESS_TESTING_CYCLE = "IFRS9"
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/BASE/ADVERSE
ADD_UAT_COLUMNS = True    # add detailed columns for UAT
CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_dec16org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
FORECAST_RESULT_FREQUENCY = 'monthly'   # the output dataset is monthly(official run) or quarterly(uat purpose)

###### NEW CCAR RUN ######    
FORECAST_PERIODS = 39   # number of forecast month
SCENARIO = "BASE" # BASE/S1/S3
STRESS_TESTING_CYCLE = "MidCycle2017"  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/BASE/ADVERSE


###### OLD IFRS RUN ######    
PD_LAG1Q_SWITCH = True    # lag 1Q for macro for PD computation
PD_SPECIAL_SET1 = True    # If SRR in (1.0, 1.1, 1.2) or (SRR<1 and LOCAL_NPL_FLAG=”Y”) then PD=1 
USE_RFO_MACRO_SERIES = False   # Use macro in SQLite
NEW_LEQ_SWITCH = True    # Use new LEQ factors(44Q)
DISCOUNTING_LGD_SWITCH = True   # discounting LGD using interest rate and nco curve
ADD_UAT_COLUMNS = True    # add detailed columns for UAT
CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_dec16org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
MATURITY_SWITCH = True   # mature loans (check monthly)
MAXIMUM_MATURITY_DATE_IMPUTATION = True  # if maxMaturityDate missing, add 11 year from origination date
FORECAST_RESULT_FREQUENCY = 'quarterly'   # the output dataset is monthly(official run) or quarterly(uat purpose)
STAGE_DIFF_SWITCH = False  # forecast horizon different for stage 1 (4Q) and stage 2/3 (44Q)
PROVIDE_TEST_FACILITY = False  # provide specific facilities to test
MRS_SRR_SWITCH = True # convert SRR from 0.1 interval to 0.5 interval (downward)
FIX_FORECAST_PERIOD = True # fixed or dynamic decide forecast period for each facility  
IFRS_SWITCH = True

###### CCAR Model RUN ######    
PD_LAG1Q_SWITCH = True    # lag 1Q for macro for PD computation
PD_SPECIAL_SET1 = False    # If SRR in (1.0, 1.1, 1.2) or (SRR<1 and LOCAL_NPL_FLAG=”Y”) then PD=1 
USE_RFO_MACRO_SERIES = False   # Use macro in SQLite
NEW_LEQ_SWITCH = True    # Use new LEQ factors(44Q)
DISCOUNTING_LGD_SWITCH = False   # discounting LGD using interest rate and nco curve
ADD_UAT_COLUMNS = True    # add detailed columns for UAT
CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_dec16org_new_interestrate.csv'  # path for staging data(stage/average interest rate)
MATURITY_SWITCH = False   # mature loans (check monthly)
MAXIMUM_MATURITY_DATE_IMPUTATION = False  # if maxMaturityDate missing, add 11 year from origination date
FORECAST_RESULT_FREQUENCY = 'monthly'   # the output dataset is monthly(official run) or quarterly(uat purpose)
STAGE_DIFF_SWITCH = False  # forecast horizon different for stage 1 (4Q) and stage 2/3 (44Q)
PROVIDE_TEST_FACILITY = False  # provide specific facilities to test
MRS_SRR_SWITCH = True # convert SRR from 0.1 interval to 0.5 interval (downward)
FIX_FORECAST_PERIOD = True # fixed or dynamic decide forecast period for each facility  
IFRS_SWITCH = False

############################# ICAAP 2018 ##############################
AS_OF_DATE = datetime.datetime(2017,9,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,9,30)
SCENARIO_DATE = datetime.datetime(2017,9,30)           
MRA_ASOFDATE = datetime.datetime(2017,9,30)     
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "GLOBAL_STRESS" 
STRESS_TESTING_CYCLE = "ICAAP2018"  
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 39   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 366

############################# IFRS Nov Run ##############################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,11,30)
SCENARIO_DATE = datetime.datetime(2017,12,31)          
MRA_ASOFDATE = datetime.datetime(2017,11,30)   
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "IFRS9_BASE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 366
IFRS_SWITCH = True

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'nov17'  # 'dec16'/'jun17'/'oct17'/'nov17'
CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/CCAR/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'quarterly'

######################### CCAR Risk Rating UAT Run ######################
AS_OF_DATE = datetime.datetime(2017,9,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,9,30)
SCENARIO_DATE = datetime.datetime(2017,9,30)            
SCENARIO = "STRESS"   # BASE/ADVERSE/STRESS
STRESS_TESTING_CYCLE = "MidCycle2017"   
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 27   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 366
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/3Q17/4 - Models/Wholesale/Risk Rating/rfo_cni_sep2017_orig_01172018.xlsx"
# For test purpose
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'quarterly'

######################### CCAR 2018 Dry Run ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,11,30)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "BHC_STRESS"   # BASE/ADVERSE/STRESS
STRESS_TESTING_CYCLE = "DryRun2018"   
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 27   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_nov_2017.xlsx"
# For test purpose
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'quarterly'

######################### CCAR 2018 Official Run 1 ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "FRB_SA"   # FRB_BASE/FRB_ADVERSE/FRB_SA/BHC_STRESS   # GLOBAL_STRESS
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018  # ICAAP2018_CCAR
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 48   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"

# For test purpose
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'quarterly'


######################### CCAR 2018 Using CCAR2017 Scenario Run ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2016,12,31)           
SCENARIO = "FRB_BASE"   # FRB_BASE/FRB_ADVERSE/FRB_SA/BHC_SA   
STRESS_TESTING_CYCLE = "CCAR2017"  # CCAR2017  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 27   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017_no_orig.xlsx"

############################# IFRS Jan Run ##############################
AS_OF_DATE = datetime.datetime(2018,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,1,31)
SCENARIO_DATE = datetime.datetime(2018,3,31)          
MRA_ASOFDATE = datetime.datetime(2018,1,31)   
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "IFRS9_NEGATIVE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 366
IFRS_SWITCH = True

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'jan18'  # 'dec16'/'jun17'/'oct17'/'nov17/jan18'
CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/CCAR/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = False  # True if test
FORECAST_RESULT_FREQUENCY = 'monthly' # 'quarterly' if test


######################### EBA run (CCAR model;Dec snapshot;11 years) ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "EBA_STRESS"   # EBA_BASE/EBA_STRESS
STRESS_TESTING_CYCLE = "EBA2018"  # CCAR2018  # ICAAP2018_CCAR
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/STRESS
FORECAST_PERIODS = 132   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"

# For test purpose
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'

######################### P21 run (CCAR model;Feb snapshot; 45 month) ######################
AS_OF_DATE = datetime.datetime(2018,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,2,28)
SCENARIO_DATE = datetime.datetime(2018,3,31)        
STRESS_TESTING_CYCLE = "P21"  # P21
SCENARIO = "BASE"   # BASE
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE
FORECAST_PERIODS = 45   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/1Q18/1 - Data/Risk Rating/rfo_cni_feb_2018.xlsx"

# For test purpose
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'quarterly' # 'quarterly' if test

######################### CCAR 2018 Official Run 1 (27 month for SAS UAT)######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "FRB_ADVERSE"   # FRB_BASE/FRB_ADVERSE/FRB_SA/BHC_STRESS   # GLOBAL_STRESS
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018  # ICAAP2018_CCAR
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 27   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"
# For test purpose
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'


############################# IFRS DEC Run (for SAS UAT) ##############################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)          
MRA_ASOFDATE = datetime.datetime(2017,12,31)
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "IFRS9_POSITIVE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M12"  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 546
IFRS_SWITCH = True

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'dec17'  # 'dec16'/'jun17'/'oct17'/'nov17'
CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/CCAR/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'

############################# IFRS MAR Run ##############################
AS_OF_DATE = datetime.datetime(2018,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,3,31)
SCENARIO_DATE = datetime.datetime(2017,9,30)       
MRA_ASOFDATE = AS_OF_DATE
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "IFRS9_BASE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 546 # 366/546
IFRS_SWITCH = True

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'mar18'  # 'dec16'/'jun17'/'oct17'/'nov17'
CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/CCAR/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = False
FORECAST_RESULT_FREQUENCY = 'monthly'

############################# IFRS April Run ##############################
AS_OF_DATE = datetime.datetime(2018,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,4,30)
SCENARIO_DATE = datetime.datetime(2017,9,30)       
MRA_ASOFDATE = AS_OF_DATE
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "IFRS9_BASE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 546 # 366/546
IFRS_SWITCH = True

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'apr18'  # 'dec16'/'jun17'/'oct17'/'nov17'
CI_STAGING_DATASET_INPUT_PATH = 'I:/MTHDO/Dept/LossImplementation/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'

############################# IFRS April Run: 0613 forecast 2 more months for Apr snapshot ##############################
AS_OF_DATE = datetime.datetime(2018,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,4,30)
SCENARIO_DATE = datetime.datetime(2017,9,30)       
MRA_ASOFDATE = AS_OF_DATE
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "IFRS9_BASE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 366 # 366/546
IFRS_SWITCH = True

# 2018_M2 run
SCENARIO_DATE = datetime.datetime(2018,3,31)
STRESS_TESTING_CYCLE = "IFRS9_2018_M2"  
  

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'apr18'  # 'dec16'/'jun17'/'oct17'/'nov17'
CI_STAGING_DATASET_INPUT_PATH = 'I:/MTHDO/Dept/LossImplementation/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'

############################# IFRS May Run: 0618 M9 ##############################
AS_OF_DATE = datetime.datetime(2018,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,5,31)
SCENARIO_DATE = datetime.datetime(2017,9,30)       
MRA_ASOFDATE = AS_OF_DATE
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "IFRS9_NEGATIVE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 366 # 366/546
IFRS_SWITCH = True

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'may18'  # 'dec16'/'jun17'/'oct17'/'nov17'
CI_STAGING_DATASET_INPUT_PATH = 'I:/MTHDO/Dept/LossImplementation/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'

############################# IFRS May Run: 0627 P21  ##############################
AS_OF_DATE = datetime.datetime(2018,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,5,31)
SCENARIO_DATE = datetime.datetime(2018,3,31)       
MRA_ASOFDATE = AS_OF_DATE
FINANCIAL_IN_RFO_SWITCH = True
SCENARIO = "BASE" # BASE
STRESS_TESTING_CYCLE = "P21"  #P21  
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE
FORECAST_PERIODS = 132   # number of forecast month: 132
STATEMENT_DAYS_THRESHOLD = 546 # 366/546
IFRS_SWITCH = True

staging_dataset_folder_name = '3Q17'  # 2Q17/3Q17/4Q17
staging_dataset_file_suffix = 'may18'  # 'dec16'/'jun17'/'oct17'/'nov17'
CI_STAGING_DATASET_INPUT_PATH = 'I:/MTHDO/Dept/LossImplementation/{}/2 - IFRS/Commercial/C&I/staging_cni_opt2b_{}org_new_interestrate.csv'.format(
                    staging_dataset_folder_name, staging_dataset_file_suffix)  # path for staging data(stage/average interest rate)
#CI_STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/staging_cni_opt2b_jun17org_new_interestrate.csv'  # path for staging data(stage/average interest rate)

# for test
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'


######################### EBA run round 2(CCAR model;Dec snapshot;60 months) ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "EBA_BASE"   # EBA_BASE/EBA_STRESS
STRESS_TESTING_CYCLE = "EBA2018_R2"  # CCAR2018  # ICAAP2018_CCAR
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/STRESS
FORECAST_PERIODS = 60   # number of forecast month
STATEMENT_DAYS_THRESHOLD = 546  # 366+180
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"

# For test purpose
ADD_UAT_COLUMNS = True
FORECAST_RESULT_FREQUENCY = 'monthly'



##########################################################################
######################## RUNS ####################################
##########################################################################
## NEW CCAR Risk Rating OFFICIAL RUN ##
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    scenario_combinations = None,
    financial_in_rfo = True,
    new_financial_logic = True,
    show_result_plot = True,
    risk_rating_dataset_input_path = RISK_RATING_DATASET_INPUT_PATH
)

## NEW CCAR Risk Rating UAT RUN (ADDING intermediate columns) ##
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    scenario_combinations = None,
    financial_in_rfo = True,
    new_financial_logic = True,
    show_result_plot = True,
    risk_rating_dataset_input_path = RISK_RATING_DATASET_INPUT_PATH,
    add_uat_columns = ADD_UAT_COLUMNS,  # for test
    forecast_result_frequency = FORECAST_RESULT_FREQUENCY   # for test
)


## CCAR RUN ##
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True,
    show_result_plot = True
)

## IFRS RUN ##
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    staging_dataset_input_path = CI_STAGING_DATASET_INPUT_PATH,
    ifrs_switch = IFRS_SWITCH,
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True,
    show_result_plot = True,
    add_uat_columns = ADD_UAT_COLUMNS,  # for test
    forecast_result_frequency = FORECAST_RESULT_FREQUENCY   # for test
)


CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    PD_lag1Q_switch = PD_LAG1Q_SWITCH,
    PD_special_set1 = PD_SPECIAL_SET1,
    use_RFO_macro_series = USE_RFO_MACRO_SERIES,
    new_LEQ_switch = NEW_LEQ_SWITCH,
    discounting_LGD_switch = DISCOUNTING_LGD_SWITCH,
    add_uat_columns = ADD_UAT_COLUMNS,
    staging_dataset_input_path = CI_STAGING_DATASET_INPUT_PATH,
    stage_diff_switch = STAGE_DIFF_SWITCH,
    fix_forecast_period = FIX_FORECAST_PERIOD,
    maturity_switch = MATURITY_SWITCH,
    maximum_maturity_date_imputation = MAXIMUM_MATURITY_DATE_IMPUTATION,
    mrs_srr_switch = MRS_SRR_SWITCH,
    forecast_result_frequency = FORECAST_RESULT_FREQUENCY,
    provide_test_facility = PROVIDE_TEST_FACILITY,
    ifrs_switch = IFRS_SWITCH,
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True,
    show_result_plot = True
)

## Create CNIModel instance
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True,
    show_result_plot = True
)

## Check portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = CI_ABL_risk_rating_model_instance.portfolio_snapshot
# portfolio_snapshot.to_excel('I:/CRMPO/DEPT/Steven/CNI_TO_SAS/dec_snapshot_risk_rating_python_0402_fixM2MAT.xlsx', index = False)
portfolio_snapshot.to_excel('c:/Users/n882049/Downloads/dec_snapshot.xlsx', index = False)

# Check intermediate dataset
risk_rating_dataset = CI_ABL_risk_rating_model_instance._CNIModel__cni_mds_instance.risk_rating_dataset
mds_mra_financial_ratios = CI_ABL_risk_rating_model_instance._CNIModel__cni_mds_instance.mds_mra_financial_ratios
mds_mra_additional_fields = CI_ABL_risk_rating_model_instance._CNIModel__cni_mds_instance.mds_mra_additional_fields
line_term_type_dataset = CI_ABL_risk_rating_model_instance._CNIModel__cni_mds_instance.line_term_type_dataset

## Check raw and transformed macro series
transformed_macro_series = CI_ABL_risk_rating_model_instance.transformed_macro_series

## Check raw and transformed macro series including t0
transformed_macro_series_include_t0 = CI_ABL_risk_rating_model_instance.transformed_macro_series_include_t0

## Check raw and transformed macro series including all
transformed_macro_series_include_all = CI_ABL_risk_rating_model_instance.transformed_macro_series_include_all

## Check change in sales, profit margin and pd mapping stress time series
macro_data = CI_ABL_risk_rating_model_instance.macro_data

## Check a list of all mapping objects as a dict
mapping_objects = CI_ABL_risk_rating_model_instance.mappings

## Get all rated contracts as a dict (quarterly forecast)
results_dictionary = CI_ABL_risk_rating_model_instance.results_set

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = CI_ABL_risk_rating_model_instance.results_df

## Get LEQ factors
leq_df = CI_ABL_risk_rating_model_instance.LEQ_df

## Get C&I portfolio average interest rate
portfolio_average_interestrate = CI_ABL_risk_rating_model_instance.portfolio_average_interestrate

###############  Add model to the shopping cart and execute  ###########
ccar_session = CCARSession(
    session_id='C&I Risk Rating CCAR 2018',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

cart.addModel(CI_ABL_risk_rating_model_instance)
cart.checkout()       # execute() is called here

###############  Add Overlay for C&I  #####################
adjustment_dictionary={'PD_GROUP':['ABL','BUSINESS_BANKING', 'MIDDLE_MARKET'], 'RATENAME':['PD','PD','PD'], 'MGMTADJUSTMENT':[-0.006752,-0.004128,-0.003977]}
ccar_session.contributor_file_generator.managementAdjustment(adjustment_dictionary = adjustment_dictionary, 
                                                             dataset_query_date = datetime.datetime(2017, 6, 30),
                                                             pd_group_switch = True)

#### Read contributor file pickle ####
cf = _pickle.load(open("C:/EXECUTION/MidCycle_overlay/CIFI/Execution/cf_files/cf_inventory_C&I_BASE_version_2.p", 'rb'))
cf = _pickle.load(open("I:/CRMPO/DEPT/Steven/CIFI/Execution/cf_files/cf_inventory_101_FRB_ADVERSE_version_1.p", 'rb'))
cf_data = cf[102].getCFData()
cf_data_new = cf_data[cf_data['PERIODDATE'] <= datetime.datetime(2020,3,31)]
cf_data_new=cf_data_new[cf_data_new['VINTAGE']==datetime.datetime(2017,12,31)]
                        
## get cf_data from csv
cf_data = pd.read_csv("I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/cf/C&I/Run 1/cf_id_102_FRB_BASE_Version_1.csv")
parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d')
cf_data["PERIODDATE"] = cf_data["PERIODDATE"].apply(parse_date)
cf_data["VINTAGE"] = cf_data["VINTAGE"].apply(parse_date)
#cf_data_new = cf_data[cf_data['PERIODDATE'] <= datetime.datetime(2020,3,31)]
cf_data_new=cf_data[cf_data['VINTAGE']==AS_OF_DATE]

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

# for IFRS cfs
cf_data = cf_data[~cf_data.RATENAME.isin(['ALLLCOVERAGE', 'CONTINGENTRESERVE'])]


## save result dataset
results_df.to_csv("I:/CRMPO/DEPT/Steven/run_result/1121ICAAP_prerun/cni_ICAAP_sep_GLOBAL_STRESS_result_df_1121.csv", index = False)

## save contributor file to CSV file
cf_data.to_csv("c:/Users/n882049/Desktop/cf_102_NEGATIVE.csv")
cf_data.to_csv("I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/EBA2018/cf/C&I/cf_id_102_EBA_STRESS_Version_1.csv", index = False)
cf_data.to_csv("I:/CRMPO/CCAR/4Q17/10 - Process & Analysis/Run Comparison/C&I_CCAR2017/cf_files/cf_id_102_FRB_BASE_Version_1.csv", index = False)
cf_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/1121ICAAP_prerun/cni_ICAAP_sep_GLOBAL_STRESS_CF_1121.csv", index = False)
cf_data.to_csv("I:/CRMPO/DEPT/Steven/CNI_TO_SAS/cni_cf_dec_frb_ad.csv", index = False)
cf_data.to_csv("I:/MTHDO/Dept/LossImplementation/1Q18/3 - Contributor Files/Wholesale/IFRS_Apr_Python/cni_cf_apr_m9_ifrs9_base.csv", index = False)




## analysis on the cf_data
cf_data_1 = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/IFRS_test/BASE_IFRS_june_cni_CF_0921_before.csv")
cf_data_2 = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/IFRS_test/BASE_IFRS_june_cni_CF_0922.csv")


## reset cf generator and shopping cart 
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()

### SP20 Run Balance Walk and sensitivity ####
# get anchor data from RFO
anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                pd_groups=["MIDDLE_MARKET", "BUSINESS_BANKING", "ABL"],
                overwrite_calculated_line = True,
                debug=True,
            )
# get anchor from risk rating dataset(From Joe; Using PD_GROUP_TOOL instead of PD_GROUP_2017)
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31) 
RISK_RATING_DATASET_INPUT_PATH = "I:/CRMPO/CCAR/4Q17/1 - Data/Risk Rating/rfo_cni_dec_2017.xlsx"

anchor_data = getBWFormatAnchorData(
                as_of_date = PORTFOLIO_SNAPSHOT_DATE,
                risk_rating_switch = True,
                only_risk_rating = True,
                cni_dataset_path = RISK_RATING_DATASET_INPUT_PATH, 
                overwrite_calculated_line = True,
                debug=True
    )

anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=["CRE_REITS", "CI_RR", "CI_OTHERS", "RUNOFF_CCRC"]
            )

## save anchor file to CSV file
anchor_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_may/ADVERSE_p20_may_cni_anchor_0710.csv")

# cf_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_CF.csv")
# anchor_data = pd.read_csv("I:/CRMPO/DEPT/Steven/run_result/P20_mar/p20_mar_cni_anchor.csv")

EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'
segfield2_to_nco_timing_curve=getNCOCurve(        
        forecast_period=FORECAST_PERIODS,
        nco_data_path = EJM_MASTER_FILE_PATH,
        timing_curve_switch = True   
    )      

segfield2_to_nco_timing_curve = None
REMOVE_LC_FROM_BALANCE = False
t0=time.time()
#SCENARIO = 'FRB_SA'
bw_output = balanceWalk(
    cf_data = cf_data,
    anchor_data=anchor_data,
    scenario_list=[SCENARIO],   
    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
    process_ALLL_balances = True,
    debug = True,
    remove_lc_from_balance=REMOVE_LC_FROM_BALANCE
)  
print('Blance walk completed in ' + str(time.time()-t0) + ' s.')


bw_output.to_csv('I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/Balance Walk/C&I/cf_id_102_BW_output_FRB_ADVERSE_version_1_.csv')
bw_output.to_csv('I:/CRMPO/CCAR/4Q17/10 - Process & Analysis/Run Comparison/C&I_CCAR2017/Balance Walk/CNI_CCAR2017_BW_output_FRB_BASE_version_1.csv')
bw_output.to_csv('C:/Users/n882049/Downloads/102_BW_output_FRB_ADVERSE_version_1.csv')

# Pivot balance walk output
pivot_bw=balanceWalkPivot(bw_output,27, AS_OF_DATE, bw_output_from_csv = False)        
pivot_bw.to_csv('I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/Balance Walk/C&I/cf_id_102_BW_Pivot_FRB_ADVERSE_version_1_.csv')
pivot_bw.to_csv('I:/CRMPO/CCAR/4Q17/10 - Process & Analysis/Run Comparison/C&I_CCAR2017/Balance Walk/CNI_CCAR2017_BW_Pivot_FRB_BASE_version_1.csv')
pivot_bw.to_csv('C:/Users/n882049/Downloads/102_BW_Pivot_EBA_STRESS_version_1.csv')

# Write to RFO
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
AS_OF_DATE = datetime.datetime(2017,12,31)
RUN_VERSION = 1
FILE_VERSION = 1
CONTRIBUTOR_FILE_ID = 102 # 101 for EJM; 102 for C&I
RUN_SIGNATURE='123117_122757'
PARTITION_KEY='S00000000422'

cf = _pickle.load(open("I:/CRMPO/DEPT/Steven/CIFI/Execution/cf_files/cf_inventory_102_FRB_ADVERSE_version_1.p", 'rb'))
cf[CONTRIBUTOR_FILE_ID].writeToMoodysRFO(
    p_reporting_date=PORTFOLIO_SNAPSHOT_DATE,
    as_of_date=AS_OF_DATE,
    p_run_id=RUN_VERSION,
    debug=True,
    moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
    table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
    contributor_file_id=CONTRIBUTOR_FILE_ID,
    file_version=FILE_VERSION,                                                 
    overwrite_vintage_asofdate=CONFIG['CONTRIBUTOR_FILE']["VINTAGE_ASOFDATE_VALUE"],
    run_signature=RUN_SIGNATURE,
    partition_key=PARTITION_KEY
)

##########################################################################
################ 1. get final result #####################################
##########################################################################

## Get all rated contracts at the quarterly level as a Pandas dataframe
results_df = CI_ABL_risk_rating_model_instance.results_df
# get final rating
test1 = results_df[['UNIQUE_FACILITY_ID','FORECAST_PERIOD', 'PD_GROUP', 'pd_1q', 'final_rating']]
test2 = pd.concat([test1]*3)
test3 = test2.sort(['UNIQUE_FACILITY_ID','FORECAST_PERIOD'])

# convert quarterly PD to monthly PD
test3['pd_1q'] = test3['pd_1q'].apply(lambda x: 1-(1-x)**(1/3))

# get date
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()

cf_data = cf.getCFData()
date = cf_data['PERIODDATE'][0:44*3]

## Get length of portfolio snapshot
portfolio_snapshot = CI_ABL_risk_rating_model_instance.portfolio_snapshot

date1 = list(date) * portfolio_snapshot.shape[0]
test3['PERIODDATE'] = date1

final = test3[['UNIQUE_FACILITY_ID', 'PERIODDATE', 'PD_GROUP', 'pd_1q']]
final.rename(
     index=str,
     columns={
              'UNIQUE_FACILITY_ID' : 'UNIQUE_FACILITY_ID',
              'PERIODDATE' : 'PERIODDATE',
              'PD_GROUP' : 'PD_GROUP',
              'pd_1q' : 'PD'
     },
     inplace = True
)
final.to_csv("I:/CRMPO/DEPT/CCAR/3Q17/IFRS/Commercial/C&I/UAT/BASE_ifrs_pd_ead_UAT.csv", index = False)

########### UAT on PD(quarterly)
results_df = CI_ABL_risk_rating_model_instance.results_df
RESULT_CLEAN_FIELDS = [
    'UNIQUE_FACILITY_ID',
    'FORECAST_PERIOD',
    'PeriodDate',
    'OPENDATE',
    'MAXIMUMMATURITYDATE',
    'MAXIMUMMATURITYDATE_NEW',
    'm2mat',
    'PD_GROUP',
#    'IS_Stage1',
#    'stage',
    'forecast_period_quarterly',
    'forecast_period_month',
    'SRR',
    'LOCAL_NPL_FLAG',
    'FACILITYTYPE',
    'StatementDate',
#    'StatementMonths',
#    'AuditMethod',
#    'StatementID',
#    'InterestExpense',
#    'CashAndEquivs',
#    'NetTradeAcctsRec',
#    'TotalCurLiabs',
#    'ProfitBeforeTax',
#    'NetSales',
#    'DebtToTNW',
    'r_DebtToTNW1',
    'r_EBITDAoIntrst',
    'r_quickRatio',  
    'r_proftmargin',
    'diff_proftmargin',
    'pct_chg_netsales',
    'V_Debt2TNW',
    'V_EBITDA2IntExp',
    'V_QuickR',
    'V_day_to_stmt2',
    'V_ProfitM',
    'V_ChgSales',
    'estimated_pd',
    'rating',
#    'finalrat_ind',
#    'FINALRAT',
#    'quantrat',
#    'rating_adjustment',
    'final_rating',
    'pd_mrs',
    'pd_mapping',
    'pd_1y',
    'pd_1q',
    'pd_1m',
    'COLLATERALCODE',
    'COLLATERAL_TYPE',
    'lgd_macro',
#    'avg_interestrate',
    'LGD',
    'New_LGD_ifrs',
    'EAD',
    'EAD_BOOK_BALANCE',
    'EAD_LETTER_OF_CREDIT',
    'EAD_AVAILABLE_LINE',
    'EAD_TOTAL_LINE',
    'ALLLCOVERAGE',
    'CONTINGENTRESERVE'
]			

test1 = results_df.sort_values(by = ['UNIQUE_FACILITY_ID','FORECAST_PERIOD'])
test1['SCENARIO'] = SCENARIO
final = test1[['SCENARIO'] + RESULT_CLEAN_FIELDS]
final.to_csv("I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/EBA2018/cf/C&I/CNI_EBA_STRESS_Intermediate.csv", index = False)
final.to_excel("c:/Users/n882049/Downloads/CNI_IFRS_Positive_Dec_Intermediate_monthly.xlsx")
final.to_excel("I:/MTHDO/Dept/LossImplementation/1Q18/3 - Contributor Files/Wholesale/IFRS_Apr_Python/cni_intermediate_apr_m9_ifrs9_base.xlsx", index = False)


# check rates sum
print(final['final_rating'].sum())
print(final['pd_1m'].sum())
print(final['New_LGD_ifrs'].sum())
print(final['EAD_AVAILABLE_LINE'].sum())




############ LGD for ALLL(quarterly)
RESULT_CLEAN_FIELDS = [
    'UNIQUE_FACILITY_ID',
    'FORECAST_PERIOD',
    'PD_GROUP',
    'COLLATERAL_TYPE',
    'LGD'
]

test1 = results_df.sort_values(by = ['UNIQUE_FACILITY_ID','FORECAST_PERIOD'])
test1 = test1.loc[(test1.PD_GROUP == 'MIDDLE_MARKET') | (test1.PD_GROUP == 'BUSINESS_BANKING')]
test1.to_csv("I:/CRMPO/CCAR/3Q17/ALLL/Commercial/C&I/alll_jun_cni_result_df.csv", index = False)
final = test1[RESULT_CLEAN_FIELDS]
final.to_csv("I:/CRMPO/CCAR/3Q17/ALLL/Commercial/C&I/alll_jun_cni_lgd.csv", index = False)



##########################################################################
################ 2. update ALLL for analysis #############################
##########################################################################

## only ALLL
alll_only = cf_data[cf_data['RATENAME'] == 'ALLLCOVERAGE']
alll_only.to_csv("I:/CRMPO/CCAR/1Q17/3 - Contributor Files/Wholesale/cf_files/archive/p20_feb_cni_CF_0517_ALLL_only.csv", index = False)

##########################################################################
################ 3. test MRA merging into RFO ##############################
##########################################################################

## Getting contract-level data for the CNI Risk Rating model
sample_mds_old = CNIMasterDataset(
    asofdate=datetime.datetime(2017,6,30),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2017,6,30),
    financial_in_rfo = False,
    new_financial_logic = True
)

financials = sample_mds_old.mds_mra_additional_fields
#financials = financials[financials['IS_ORIG'] == 'N']

from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/MRA_analysis/sample_test/MV_LOSS_COMMERCIAL_Mar_UAT.xlsx")
financials.to_excel(writer,'Sheet1', index = False)
writer.save()

# financials in RFO
sample_mds_new = CNIMasterDataset(
    asofdate=datetime.datetime(2017,6,30),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2017,6,30),
    financial_in_rfo = True,
    new_financial_logic = True
)



############################# CCAR 2017 RUN ##############################
AS_OF_DATE = datetime.datetime(2016,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2016,12,31)
SCENARIO_DATE = datetime.datetime(2016,12,31)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2016,12,31)            # not in run.py
SCENARIO = "FRB_SA"
STRESS_TESTING_CYCLE = "CCAR2017"
SCENARIO_SEVERITY_LEVEL = "STRESS"
FORECAST_PERIODS = 27
STATEMENT_DAYS_THRESHOLD = 366           # not in run.py

CI_instance_test = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = True,
    new_financial_logic = True
)



# mapping table
mapping_df = sample_mds_old.sourcesystem_to_mra
mapping_df.to_csv("I:/CRMPO/DEPT/Steven/MRA_analysis/sample_test/mapping_mar.csv", index = False)


# save data to spreadsheet
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/MRA_analysis/MV_LOSS_COMMERCIAL_Sample_Dec_new_logic.xlsx")
df = sample_mds_old.mds_mra_additional_fields
df.to_excel(writer,'Sheet1', index = False)
writer.save()

sample_mds_using_rfo = CNIMasterDataset(
    asofdate=datetime.datetime(2016,12,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2016,12,31),
    financial_in_rfo = True
)

## Accessing the most complete version of the data within the CNIMasterDataset instance
df_old = sample_mds_old.data
df_old = df_old.sort('UNIQUE_FACILITY_ID')
df_old.to_csv("I:/CRMPO/DEPT/Steven/MRA_analysis/to_test/dec_data_old.csv", index = False)

df_rfo = sample_mds_using_rfo.data
df_rfo = df_rfo.sort('UNIQUE_FACILITY_ID')
df_rfo.to_csv("I:/CRMPO/DEPT/Steven/MRA_analysis/to_test/dec_data_usingRFO.csv", index = False)


################# test RFO sample  #############
benckmark = pd.read_excel("I:/CRMPO/DEPT/Steven/MRA_analysis/sample_test/MV_LOSS_COMMERCIAL_Mar_UAT.xlsx")
commercial_raw = pd.read_csv("I:/CRMPO/DEPT/Steven/MRA_analysis/sample_test/TestFileFromTarek_0706/test_mv_loss_commercial.csv")
cni_raw = commercial_raw[commercial_raw['PD_GROUP_2017'].isin(['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'])]
CLEAN_FIELDS = [
    'ONEOBLIGORNUMBER',
    'CUSTOMERNUMBER',
    'FACILITYNUMBER',
    'MasterCustomerID',
    'StatementID',
    'StatementDate',
    'StatementMonths',
    'AuditMethod',
    'DebtToTNW',
    'EBITDA',
    'InterestExpense',
    'CashAndEquivs',
    'NetTradeAcctsRec',
    'TotalCurLiabs',
    'ProfitBeforeTax',
    'NetSales'
]

# (1)test merge
test_merge = commercial_raw[['ENTITY_CODE', 'EBITDA']]
merged = benckmark.merge(test_merge, left_on = 'MC_MasterCustomer_ID', right_on = 'ENTITY_CODE', how='left')
merged = merged[~merged.duplicated('UNIQUE_FACILITY_ID')]
merged_clean = merged[['UNIQUE_FACILITY_ID','ONEOBLIGORNUMBER', 'CUSTOMERNUMBER', 'MasterCustomerId', 'MasterOneObligorId', 'MC_MasterCustomer_ID', 'ENTITY_CODE', 'EBITDA_x', 'EBITDA_y']]

test_merge = cni_raw[['UNIQUE_FACILITY_ID', 'MASTER_CUSTOMER_ID', 'MASTER_ONE_OBLIGOR_ID']]
merged = benckmark.merge(test_merge, left_on = 'UNIQUE_FACILITY_ID', right_on = 'UNIQUE_FACILITY_ID', how='left')
merged = merged[~merged.duplicated('UNIQUE_FACILITY_ID')]

merged_clean = merged[['UNIQUE_FACILITY_ID','ONEOBLIGORNUMBER', 'CUSTOMERNUMBER', 'MasterCustomerId', 'MasterOneObligorId', 'MASTER_CUSTOMER_ID', 'MASTER_ONE_OBLIGOR_ID']]
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/MRA_analysis/sample_test/test_merge_id_0706_UAT_Obligor_Cust.xlsx")
merged_clean.to_excel(writer,'Sheet1', index = False)
writer.save()

len(merged_clean[merged_clean['MasterCustomerId'] == merged_clean['MASTER_CUSTOMER_ID']])
len(merged_clean[merged_clean['MasterCustomerId'] != merged_clean['MASTER_CUSTOMER_ID']])

len(merged_clean[merged_clean['MasterOneObligorId'] == merged_clean['MASTER_ONE_OBLIGOR_ID']])
len(merged_clean[merged_clean['MasterOneObligorId'] != merged_clean['MASTER_ONE_OBLIGOR_ID']])

# (2)test value
test_merge = cni_raw[['UNIQUE_FACILITY_ID', 'MASTER_CUSTOMER_ID', 'MASTER_ONE_OBLIGOR_ID',  'EBITDA']]
test_merge['EBITDA'] = test_merge['EBITDA'].str.replace(',', '')
test_merge['EBITDA'] = pd.to_numeric(test_merge['EBITDA'])

merged = benckmark.merge(test_merge, left_on = 'UNIQUE_FACILITY_ID', right_on = 'UNIQUE_FACILITY_ID', how='left')
merged = merged[~merged.duplicated('UNIQUE_FACILITY_ID')]

merged_clean = merged[['UNIQUE_FACILITY_ID', 'MasterCustomerId', 'MasterOneObligorId', 'MC_MasterCustomer_ID','EBITDA_x', 'EBITDA_y']]
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/MRA_analysis/sample_test/test_merge_value_UAT_EBITDA_0706.xlsx")
merged_clean.to_excel(writer,'Sheet1', index = False)
writer.save()

len(merged_clean[merged_clean['MasterCustomerId'] == merged_clean['MASTER_CUSTOMER_ID']])
len(merged_clean[merged_clean['MasterCustomerId'] != merged_clean['MASTER_CUSTOMER_ID']])

len(merged_clean[merged_clean['MasterOneObligorId'] == merged_clean['MASTER_ONE_OBLIGOR_ID']])
len(merged_clean[merged_clean['MasterOneObligorId'] != merged_clean['MASTER_ONE_OBLIGOR_ID']])

#### test logic change ####
old_snapshot = pd.read_excel("I:/CRMPO/DEPT/Steven/run_result/CCAR_dec/ccar_dec_cni_snapshot.xlsx")
new_snapshot = pd.read_excel("I:/CRMPO/DEPT/Steven/run_result/CCAR_dec/ccar_dec_cni_snapshot_new_logit_2.xlsx")

old_snapshot['MasterCustomerId_y'] = new_snapshot['MasterCustomerId']
old_snapshot['MasterOneObligorId_y'] = new_snapshot['MasterOneObligorId']
old_snapshot['MC_MasterCustomer_ID_y'] = new_snapshot['MC_MasterCustomer_ID']
old_snapshot['StatementDate_y'] = new_snapshot['StatementDate']
old_snapshot['EBITDA_y'] = new_snapshot['EBITDA']

from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/run_result/CCAR_dec/ccar_dec_cni_snapshot_compare_2.xlsx")
old_snapshot.to_excel(writer,'Sheet1', index = False)
writer.save()

##########################################################################
################ 4. C&I April data for Lizzy #############################
##########################################################################

## note: remove origination table data: set include_originations=False ##
## April mapping table is not ready, use March data instead   ##
sample_mds = CNIMasterDataset(
    asofdate=datetime.datetime(2017,3,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=False,
    statement_days_threshold=540,
    mra_asofdate=datetime.datetime(2017,3,31),
    financial_in_rfo = False
)

financials = sample_mds.processed_mra_data
merged = sample_mds.mds_mra_additional_fields
merged.to_csv("I:/CRMPO/DEPT/Steven/ad hoc/C&I_with financials_Lizzy/CNI_APR_NoOrig.txt", index = False)

test_Dec = CNIMasterDataset(
    asofdate=datetime.datetime(2016,12,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=False,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2016,12,31),
    financial_in_rfo = False
)

financials_dec = test_Dec.processed_mra_data
merged_dec = test_Dec.mds_mra_additional_fields
merged_dec.to_csv("I:/CRMPO/DEPT/Steven/ad hoc/C&I_with financials_Lizzy/CNI_DEC_TEST.txt", index = False)


##########################################################################
################ 5. Analysis on IFRS data staging   ######################
##########################################################################
import _pickle 
dec_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/dec_cni_additional_fields.p", 'rb'))
mar_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/mar_cni_additional_fields.p", 'rb'))

# ccmis C&I data
dec_ccmis_raw = pd.read_excel("I:/CRMPO/DEPT/Steven/cni/IFRS/dec_cni_ccmis.xlsx")


statistics = mar_data['SRR'].describe()


mar_stage_3 = mar_data[
                  (mar_data['SRR'].isin([1.0, 1.1, 1.2]))
                  | 
                  ((mar_data['SRR'] < 1.0) & (mar_data['LOCAL_NPL_FLAG'] == 'Y'))
                  |
                  (mar_data['TDR'] == 'Y')
          ]
          
mar_stage_2 = mar_data[
                  ((mar_data['SRR'] >= 1.5) & (mar_data['SRR'] <= 4.0))
                  
          ]
          
mar_stage_1 = mar_data[~mar_data.isin(mar_stage_3)].dropna()
mar_stage_1 = mar_stage_1[~mar_stage_1.isin(mar_stage_2)].dropna()



####### About distribution of remaining loan terms (months to maturity)  ###
dec_data[pd.isnull(dec_data['MAXIMUMMATURITYDATE'])]
def maturity_mapping(x):
    if pd.isnull(x):           
        return 'Missing'
    elif x < 0:
        return 'Matured Loans'
    elif x <= 12:
        return '0-12 Months'
    elif x <= 24:
        return '13-24 Months'
    elif x <= 36:
        return '25-36 Months'
    elif x <= 96:
        return '37-96 Months'
    else:
        return '>96 Months'
dec_data['Maturity_Group'] = dec_data['m2mat'].apply(maturity_mapping)    

# count weighted
len_dec = len(dec_data)
dec_data.groupby(['Maturity_Group']).size()
dec_data.groupby(['Maturity_Group']).size()/len_dec
                 
# balance weighted
total_dec = sum(dec_data['BOOKBALANCE'])
dec_data.groupby(by = ['Maturity_Group']).sum()['BOOKBALANCE']
dec_data.groupby(by = ['Maturity_Group']).sum()['BOOKBALANCE']/total_dec
                
####### About distribution of rating (SRR)  ###      
def rating_mapping(x):
    return (int(2 * x) * 0.5)         
dec_data['Rating'] = dec_data['SRR'].apply(rating_mapping)    
# count weighted
len_dec = len(dec_data)
dec_data.groupby(['Rating']).size()
dec_data.groupby(['Rating']).size()/len_dec
                 
# balance weighted
total_dec = sum(dec_data['BOOKBALANCE'])
dec_data.groupby(by = ['Rating']).sum()['BOOKBALANCE']
dec_data.groupby(by = ['Rating']).sum()['BOOKBALANCE']/total_dec

####### Using CCMIS data  ###    
def maturity_mapping_ccmis(x):
    x = pd.to_numeric(x, errors = 'coerce')
    year_to_maturity = x - 2016
    if pd.isnull(year_to_maturity):           
        return 'Missing'
    elif year_to_maturity <= 0:
        return 'Matured Loans'
    elif year_to_maturity <= 1:
        return '0-12 Months'
    elif year_to_maturity <= 2:
        return '13-24 Months'
    elif year_to_maturity <= 3:
        return '25-36 Months'
    elif year_to_maturity <= 8:
        return '37-96 Months'
    else:
        return '>96 Months'  
        
dec_ccmis_raw['Maturity_Group'] = dec_ccmis_raw['Maturity Year'].apply(maturity_mapping_ccmis)    


# count weighted
len_dec = len(dec_ccmis_raw)
dec_ccmis_raw.groupby(['Maturity_Group']).size()
dec_ccmis_raw.groupby(['Maturity_Group']).size()/len_dec
                 
# balance weighted
total_dec = sum(dec_ccmis_raw['BOOKBALANCE'])
dec_ccmis_raw.groupby(by = ['Maturity_Group']).sum()['BOOKBALANCE']
dec_ccmis_raw.groupby(by = ['Maturity_Group']).sum()['BOOKBALANCE']/total_dec
                 
                      
dec_ccmis_raw['Rating'] = dec_ccmis_raw['SRR'].apply(rating_mapping)    
# count weighted
len_dec = len(dec_ccmis_raw)
dec_ccmis_raw.groupby(['Rating']).size()
dec_ccmis_raw.groupby(['Rating']).size()/len_dec
                 
# balance weighted
dec_ccmis_raw = sum(dec_ccmis_raw['BOOKBALANCE'])
dec_ccmis_raw.groupby(by = ['Rating']).sum()['BOOKBALANCE']
dec_ccmis_raw.groupby(by = ['Rating']).sum()['BookBalanceAmount']/total_dec

##########################################################################
################ 6. financials for Andre  ################################
##########################################################################
loans = pd.read_excel("I:/CRMPO/DEPT/Steven/ad hoc/C&I financials_Andre/CCLMID - CCMIS Key.xlsx")
# get annual statements
processed_mra_data_annual, raw_mra_data = preProcessMRAData(
    mra_extract_asofdate=datetime.datetime(2017,5,31),
    portfolio_asofdate=datetime.datetime(2017,5,31)
)
# get intrime statements
processed_mra_data_interim, raw_mra_data = preProcessMRAData(
    mra_extract_asofdate=datetime.datetime(2017,5,31),
    portfolio_asofdate=datetime.datetime(2017,5,31)
)

processed_mra_data_annual['MasterCustomerID'] = processed_mra_data_annual['MasterCustomerID'].astype(int)
processed_mra_data_interim['MasterCustomerID'] = processed_mra_data_interim['MasterCustomerID'].astype(int)

loan_merged = loans.merge(processed_mra_data_annual, left_on = 'MasterCustomerId', right_on = 'MasterCustomerID', how='left')
loan_merged_interim = loans.merge(processed_mra_data_interim, left_on = 'MasterCustomerId', right_on = 'MasterCustomerID', how='left')
CLEAN_FIELDS = [
    'MasterCustomerId',
    'SourceId',
    'OneObligorNumber',
    'CustomerNumber',
    'FacilityNumber',
    'StatementDate',
    'StatementMonths',
    'DebtToTNW',
    'EBITDA',
    'InterestExpense',
    'CashAndEquivs',
    'NetTradeAcctsRec',
    'TotalCurLiabs',
    'ProfitBeforeTax',
    'NetSales'
]
loan_merged['FacilityNumber'] = loan_merged['FacilityNumber'].astype(str)
loan_clean = loan_merged[CLEAN_FIELDS]
calculateRatio(loan_clean)

loan_merged_interim['FacilityNumber'] = loan_merged_interim['FacilityNumber'].astype(str)
loan_clean_interim = loan_merged_interim[MRA_CLEAN_FIELDS]
calculateRatio(loan_clean_interim)

from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/ad hoc/C&I financials_Andre/CCLMID - CCMIS Key_add financials_annual.xlsx")
loan_clean.to_excel(writer,'Sheet1', index = False)
writer.save()

writer = ExcelWriter("I:/CRMPO/DEPT/Steven/ad hoc/C&I financials_Andre/CCLMID - CCMIS Key_add financials_interim.xlsx")
loan_clean_interim.to_excel(writer,'Sheet1', index = False)
writer.save()


### calculate ratios  ### 


def calculateRatio(df):
    # DebtToTNW
    df['r_DebtToTNW1'] = round(
        df['DebtToTNW'],
        32
    )
    
    # r_EBITDAoIntrst
    def r_EBITDAoIntrst(line):
        if pd.isnull(line['EBITDA']):
            return (np.NaN)
        elif (pd.isnull(line['InterestExpense'])) or (line['InterestExpense'] < 0):
            return (np.NaN)
        elif (line['InterestExpense'] == 0) and (pd.notnull(line['EBITDA'])):
            return (line['EBITDA'])
        else:
            return (line['EBITDA'] / line['InterestExpense'])
    df['r_EBITDAoIntrst'] = round(
        df.apply(
            func=r_EBITDAoIntrst,
            axis=1
        ),
        32
    )
    
    # r_quickRatio
    def r_quickRatio(line):
        if pd.isnull(line['CashAndEquivs'] + line['NetTradeAcctsRec']):
            return (np.NaN)
        elif (pd.isnull(line['TotalCurLiabs'])) or (line['TotalCurLiabs'] < 0):
            return (np.NaN)
        elif (line['TotalCurLiabs'] == 0) and (pd.notnull(line['CashAndEquivs'] + line['NetTradeAcctsRec'])):
            return (line['CashAndEquivs'] + line['NetTradeAcctsRec'])
        else:
            return ((line['CashAndEquivs'] + line['NetTradeAcctsRec']) / line['TotalCurLiabs'])
    df['r_quickRatio'] = round(
        df.apply(
            func=r_quickRatio,
            axis=1
        ),
        32
    )
    
    # r_proftmargin
    def r_proftmargin(line):
        if pd.isnull(line['ProfitBeforeTax']):
            return (np.NaN)
        elif (pd.isnull(line['NetSales'])) or (line['NetSales'] < 0):
            return (np.NaN)
        elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] >= 0):
            return (np.NaN)
        elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] < 0):
            return (line['ProfitBeforeTax'])
        else:
            return (line['ProfitBeforeTax'] / line['NetSales'])
    df['r_proftmargin'] = round(
        df.apply(
            func=r_proftmargin,
            axis=1
        ),
        32
    )

##########################################################################
################ 7. Test code change for C&I financials  #################
##########################################################################
asofdate=datetime.datetime(2016,12,31)
pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL']
pass_SRR=4.
debug=True
include_originations=True
statement_days_threshold=366
mra_asofdate=datetime.datetime(2016,12,31)
financial_in_rfo = True      

test_class = CCMISMasterDataset(
    asofdate=asofdate,
    pd_groups=pd_groups,
    include_originations=include_originations,
    debug=debug,
    limit_contracts=None,
    fetchCNI = financial_in_rfo
)                

parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S.%f')
test_class.data["StatementDate"] = test_class.data["StatementDate"].apply(parse_date)

mds_mra_tmp = test_class.data.copy(deep=True)

mds_mra_tmp = test_class.data.copy(deep=True)
if mds_mra_tmp is None:
    raise Exception('`self.mds_mra or self.data` is None.')

mds_mra_tmp['r_DebtToTNW1'] = round(
    mds_mra_tmp['DebtToTNW'],
    test_class.precision
)

# r_EBITDAoIntrst
def r_EBITDAoIntrst(line):
    if pd.isnull(line['EBITDA']):
        return (np.NaN)
    elif (pd.isnull(line['InterestExpense'])) or (line['InterestExpense'] < 0):
        return (np.NaN)
    elif (line['InterestExpense'] == 0) and (pd.notnull(line['EBITDA'])):
        return (line['EBITDA'])
    else:
        return (line['EBITDA'] / line['InterestExpense'])
mds_mra_tmp['r_EBITDAoIntrst'] = round(
    mds_mra_tmp.apply(
        func=r_EBITDAoIntrst,
        axis=1
    ),
    test_class.precision
)

# r_quickRatio
def r_quickRatio(line):
    if pd.isnull(line['CashAndEquivs'] + line['NetTradeAcctsRec']):
        return (np.NaN)
    elif (pd.isnull(line['TotalCurLiabs'])) or (line['TotalCurLiabs'] < 0):
        return (np.NaN)
    elif (line['TotalCurLiabs'] == 0) and (pd.notnull(line['CashAndEquivs'] + line['NetTradeAcctsRec'])):
        return (line['CashAndEquivs'] + line['NetTradeAcctsRec'])
    else:
        return ((line['CashAndEquivs'] + line['NetTradeAcctsRec']) / line['TotalCurLiabs'])
mds_mra_tmp['r_quickRatio'] = round(
    mds_mra_tmp.apply(
        func=r_quickRatio,
        axis=1
    ),
    test_class.precision
)

# r_proftmargin
def r_proftmargin(line):
    if pd.isnull(line['ProfitBeforeTax']):
        return (np.NaN)
    elif (pd.isnull(line['NetSales'])) or (line['NetSales'] < 0):
        return (np.NaN)
    elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] >= 0):
        return (np.NaN)
    elif (line['NetSales'] == 0) and (line['ProfitBeforeTax'] < 0):
        return (line['ProfitBeforeTax'])
    else:
        return (line['ProfitBeforeTax'] / line['NetSales'])
mds_mra_tmp['r_proftmargin'] = round(
    mds_mra_tmp.apply(
        func=r_proftmargin,
        axis=1
    ),
    test_class.precision
)

# Finalize
mds_mra_financial_ratios = mds_mra_tmp


# Prepare data
mds_additional_fields_tmp =mds_mra_financial_ratios.copy(deep=True)

# Process SRR pass/non-pass
def SRR_rating_pass(line):
    if line["SRR"] <= 4:
        return False
    else:
        return True
mds_additional_fields_tmp["SRR_rating_pass"] = mds_additional_fields_tmp.apply(
    func=SRR_rating_pass,
    axis=1
)

# Compute statement age in days
def statementAgeInDays(line):
    # old code
    # return(utilities.daysDifference(line["ASOFDATE"],line["StatementDate"]))
    diff = utilities.daysDifference(line["ASOFDATE"],line["StatementDate"]) 
    # for missing statement date, return -1
    if int(diff) < 0:
        return -1
    else:
        return int(diff)

mds_additional_fields_tmp["asofdate2stmtdate"] = mds_additional_fields_tmp.apply(
    func=statementAgeInDays,
    axis=1
)

# Compute months to maturity
def monthsToMaturity(line):
    mat_d = line["MAXIMUMMATURITYDATE"]
    as_of_d = line["ASOFDATE"]

    try:
        r_delta = relativedelta.relativedelta(mat_d, as_of_d)
    except (TypeError, AssertionError):
        m2mat = np.nan
    else:
        m2mat = r_delta.years * 12 + r_delta.months
    return(m2mat)
mds_additional_fields_tmp["m2mat"] = mds_additional_fields_tmp.apply(
    func=monthsToMaturity,
    axis=1
)

# Compute maturity indicator
def maturityIndicator(line):
    if pd.isnull(line["m2mat"]):
        return(False)
    elif line["m2mat"] <= 0:
        return(True)
    else:
        return(False)

mds_additional_fields_tmp["matureInd"] = mds_additional_fields_tmp.apply(
    func=maturityIndicator,
    axis=1
)

##########################################################################
################ 8. Improve code effiency  ###############################
##########################################################################

######### option 1: use cProfile  ########
import cProfile
# sample use
#import re
#cProfile.run('re.compile("foo|bar")')

cProfile.run('CI_ABL_risk_rating_model_instance = CNIModel(\
    as_of_date=AS_OF_DATE,\
    scenario=SCENARIO,\
    scenario_context=STRESS_TESTING_CYCLE,\
    scenario_date=SCENARIO_DATE,\
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,\
    forecast_periods=FORECAST_PERIODS,\
    forecast_periods_frequency="monthly",\
    pass_srr=4.0,\
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",\
    debug=False,\
    include_originations_switch=True, \
    auto_fetch_macros=True,\
    limit_contracts=None,\
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,\
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,\
    mature_non_pass_locs=True,\
    mra_asofdate = MRA_ASOFDATE,\
    scenario_combinations = None,\
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,\
    new_financial_logic = True)', 'CNIModel.profile')

import pstats
stats = pstats.Stats('CNIModel.profile')
# This sorts the profile by cumulative time in a function, and then only prints the ten most significant lines.
stats.strip_dirs().sort_stats('cumulative').print_stats(10)
stats.sort_stats('time').print_stats(10)
# the list is first culled down to 50% (re: .5) of its original size, then only lines containing init are maintained, and that sub-sub-list is printed.
stats.sort_stats('time', 'cumulative').print_stats(.5, 'init')
stats.print_callers(.5, 'init')


######### option 2: use pycallgraph  ########
from pycallgraph import PyCallGraph
from pycallgraph.output import GraphvizOutput
graphviz = GraphvizOutput()
graphviz.output_file = 'I:/CRMPO/DEPT/Steven/ad hoc/C&I improve efficiency/cni_class_graph.png'

with PyCallGraph(output=graphviz):
    CI_ABL_risk_rating_model_instance = CNIModel(
        as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
        scenario=SCENARIO,                                           # scenario name
        scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
        scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
        scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
        forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
        forecast_periods_frequency='monthly',                        # forecast periods frequency
        pass_srr=4.0,                                                # initial passing SRR
        model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
        debug=False,                                                 # debug mode, if True more messages will be displayed
        include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
        auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
        limit_contracts=None,                                        # for testing purposes number of random contracts to pick
        statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
        portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
        mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
        mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
        scenario_combinations = None,
        financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
        new_financial_logic = True
    )

##########################################################################
########### 9. Use adverse GDP/adverse corporate profits for Stress run ##
##########################################################################
import itertools
# get the combination of macro and scenario
def combo_generator(variables,scenarios,triangle = True):
    if isinstance(scenarios,str) or len(scenarios) == 1:
        return {i:j for i,j in zip(variables,[scenarios]*len(variables))}
    if triangle:
        all_combos = itertools.combinations_with_replacement(scenarios, len(variables))
        outputs = []
        start = next(all_combos)
        while start is not None:
            per = {v:s for v,s in zip(variables,start)}
            outputs.append(per)
            try:
                start = next(all_combos)
            except StopIteration:
                start = None
        return outputs
    else:
        outputs = []
        raw_all_combos = list(itertools.combinations_with_replacement(scenarios*len(variables), len(variables)))
        processed = set(raw_all_combos)
        for combo in processed:
            per = {v:s for v,s in zip(variables,combo)}
            outputs.append(per)
        return outputs
        
# macro combination
macro_list = ['FGDPQ_US', 'FZ_US', 'FLBR_US', 'FHOFHOPIQ_US']
scenario_list = ["ADVERSE","STRESS"]
all_combos = combo_generator(macro_list,scenario_list) 
all_combos[3] # only GDP adverse
all_combos[2] # GDP and corportae profit adverse

############################# SP20 RUN Round 2 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           # not in run.py
MRA_ASOFDATE = datetime.datetime(2017,6,30)            # not in run.py
#SCENARIO = "STRESS"
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO_SEVERITY_LEVEL = "STRESS"
FORECAST_PERIODS = 42
STATEMENT_DAYS_THRESHOLD = 366           # not in run.py
FINANCIAL_IN_RFO_SWITCH = False

ccar_session = CCARSession(
    session_id='C&I Risk Rating 2017 Mid Cycle',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

## Create CNIModel instance
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=scenario_list,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = all_combos[2],
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True
)

## Use normal code to generate cf file and anchor data, then do bw:
bw_output = balanceWalkMacroSensitivity(
    cf_data = cf_data,
    anchor_data=anchor_data,
    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
    process_ALLL_balances = True,
    debug = True
)  

##########################################################################
################ 10. EJM test run using C&I model  #######################
##########################################################################
sample_mds = CNIMasterDataset(
    asofdate=datetime.datetime(2017,6,30),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL', 'CRE_REITS', 'CI_OTHERS', 'CI_RR', 'RUNOFF_CCRC'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2017,6,30),
    financial_in_rfo = True
)
sample_mds_1 = CNIMasterDataset(
    asofdate=datetime.datetime(2017,6,30),
    pd_groups=['CI_OTHERS', 'CI_RR', 'RUNOFF_CCRC'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2017,6,30),
    financial_in_rfo = True
)


## Check portfolio snapshot, equivalent to CNIMasterDataset::mds_mra_additional_fields
portfolio_snapshot = sample_mds.data
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/ad hoc/20170807_EJM C&I test run_Huilong/snapshots_C&I_June.xlsx")
portfolio_snapshot.to_excel(writer,'Sheet1', index = False)
writer.save()

##########################################################################
################ 11. Balance Walk output aggregation (from Tracy)  ####### 
##########################################################################
file_path = "I:\\CRMPO\\DEPT\\Steven\\ad hoc\\20170809_CNI test run using pd_mrs_AM\\cni_BW_Output_STRESS_testMRS.csv"
def getForecastTrend(bw_mode, file_path):
    end_forecast_date = lambda as_of_date, forecast_period: utilities.monthEndDate(utilities.addMonths2date(as_of_date, forecast_period))

    data=pd.read_csv(file_path)
    parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d')
    data["PERIODDATE"] = data["PERIODDATE"].apply(parse_date)
    
    # filter bw_mode
    data=data[
                (data['BW_MODE']==bw_mode)
                    &
                (data['PERIODDATE'] <= end_forecast_date(datetime.datetime(2017, 6, 30), 27))
             ]

    data=data.groupby(['PD_GROUP', 'PERIODDATE'])['BALANCE','CALCULATEDLINE','STARTINGBALANCE','LGDAMOUNT'].sum()
    
    data['StartBookBalance']=data.groupby(level=['PD_GROUP']).transform('first')['STARTINGBALANCE']
    
    #data['%NCO']=data['NCOAMOUNT']/data['StartBookBalance']
    data['%LGD']=data['LGDAMOUNT']/data['StartBookBalance']
    
    return(data)
pivot = getForecastTrend(4, file_path)
from pandas import ExcelWriter
writer = ExcelWriter("I:\\CRMPO\\DEPT\\Steven\\ad hoc\\20170809_CNI test run using pd_mrs_AM\\cni_BW_FINAL_Output_STRESS_testMRS_Mode4.xlsx")
pivot.to_excel(writer,'Sheet1')
writer.save()

##########################################################################
################ 12. C&I missing financials analysis  ####################
##########################################################################

######### CCAR: DEC Data #######
dec_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/dec_cni_additional_fields.p", 'rb'))
dec_data = dec_data[dec_data['PD_GROUP'] == 'ABL']
######### MidCycle: June Data #######
june_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/jun_old_finanical_cni_additional_fields.p", 'rb'))
june_data = june_data[june_data['PD_GROUP'] == 'ABL']

## save snapshots and analysis in excel ##
portfolio_snapshot = june_data
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/cni_snapshot/cni_snapshot_june_midcycle.xlsx")
portfolio_snapshot.to_excel(writer,'Sheet1', index = False)
writer.save()

# Risk Driver Distribution comparison plots for CCAR 2017 and MidCycle 2017
riskDriverDistributionComparison('ABL', dec_data, june_data, 366, 366, 'CCAR 2017', 'MidCycle 2017', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/CCAR2017 - MidCycle Run1_PD_GROUP/test/BalanceWeighted/')

riskDriverDistributionComparison('ABL', dec_data, june_data, 366, 366, 'CCAR 2017', 'MidCycle 2017', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/CCAR2017 - MidCycle Run1_PD_GROUP/test/CountWeighted/')

##########################################################################
################ 13. C&I using pd_mrs without pd_mapping #################
##########################################################################

# set PD_mapping_switch to be False!

CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    PD_mapping_switch = False,
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True
)


##########################################################################
################ 14. C&I Risk Driver Run #####################################
##########################################################################
from CIFI.sensitivity.risk_driver import SnapShotCheck
AS_OF_DATE1 = datetime.datetime(2017,6,30)
AS_OF_DATE2 = datetime.datetime(2017,9,30)
NAME1 = 'June 2017'
NAME2 = 'Sept 2017'
PATH = 'I:\\CRMPO\\CCAR\\2Q17\\10 - Process & Analysis\\Risk Driver\\test\\C&I'

################################# C&I #####################################
######### Config for C&I ############
FINANCIAL_IN_RFO1 = True
FINANCIAL_IN_RFO2 = True
STATEMENT_DAYS_THRESHOLD1 = 366
STATEMENT_DAYS_THRESHOLD2 = 366

CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = True,
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        )
CNI_instance.executeGraph()

CNI_instance = SnapShotCheck(
        portfolio = 'C&I',
        asofdate1 = AS_OF_DATE1,
        asofdate2 = AS_OF_DATE2,
        name1 = NAME1,
        name2 = NAME2,
        path = PATH,
        entire_pd_groups_switch = False,
        pd_groups=['ABL'],
        graph_switch = True,
        orig = False,
        financial_in_rfo1 = FINANCIAL_IN_RFO1,
        financial_in_rfo2 = FINANCIAL_IN_RFO2,
        statement_days_threshold1 = STATEMENT_DAYS_THRESHOLD1,
        statement_days_threshold2 = STATEMENT_DAYS_THRESHOLD2,
        )

CNI_instance.average_result
################################# Get dataset #################################
## Getting raw dataset
raw_dataset1 = CNI_instance.raw_dataset1
raw_dataset2 = CNI_instance.raw_dataset2

## Getting processed dataset
processed_dataset1 = CNI_instance.processed_dataset1
processed_dataset2 = CNI_instance.processed_dataset2

## Getting final dataset
dataset_with_bin1 = CNI_instance.dataset_with_bin1
dataset_with_bin2 = CNI_instance.dataset_with_bin2

##########################################################################
################ 15. Devoloper's Sep Snapshot data request ###############
##########################################################################
global CNI_PD_GROUP_LIST
CNI_PD_GROUP_LIST = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL']

# CCAR model #
ccar_sep_snapshot = CCMISMasterDataset(
    asofdate=datetime.datetime(2017,9,30),
    include_originations=True,
    pd_groups=CNI_PD_GROUP_LIST,
    debug=True,
    limit_contracts=None,
    fetchCNI = True
)

# IFRS model #
ifrs_sep_snapshot = CCMISMasterDataset(
    asofdate=datetime.datetime(2017,9,30),
    include_originations=False,
    pd_groups=CNI_PD_GROUP_LIST,
    debug=True,
    limit_contracts=None,
    fetchCNI = True
)


##########################################################################
################ 16. IFRS Jan Snapshot data  #############################
##########################################################################
ifrs_cni_data = CNIMasterDataset(
    asofdate=datetime.datetime(2018,1,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.0,
    limit_contracts=None,
    include_originations=True,
    statement_days_threshold=366,
    financial_in_rfo = True,
    new_financial_logic = True,
    maximum_maturity_date_imputation = True,
    mrs_srr_switch = True
)

########################################################################################################################
################ 17. Analysis for C&I CCAR migrate from python to SAS process  #########################################
########################################################################################################################
test = pd.read_excel("I:/CRMPO/DEPT/Steven/CNI_TO_SAS/CNI_CCAR_RUN1_FRB_SA_IntermediateDataset.xlsx")
test = pd.read_excel("I:/CRMPO/DEPT/Steven/CNI_TO_SAS/CNI_CCAR_RUN1_FRB_SA_matureEAD_IntermediateDataset_monthly.xlsx")
test_q1 = test[test['FORECAST_PERIOD'] == 1]
#test_q1 = test


# check frequency
print(test_q1.groupby('V_day_to_stmt2').size())
print(test_q1.groupby('V_Debt2TNW').size())
print(test_q1.groupby('V_EBITDA2IntExp').size())
print(test_q1.groupby('V_QuickR').size())
print(test_q1.groupby('V_ProfitM').size())
print(test_q1.groupby('V_ChgSales').size())

# check pd
print(test_q1.groupby('rating').size())
print(test_q1.groupby('rating_adjustment').size())
print(test_q1.groupby('final_rating').size())
test[['estimated_pd','pd_mapping','pd_mrs', 'pd_1y', 'pd_1q', 'pd_1m']].describe()

# check lgd
print(test.groupby('COLLATERAL_TYPE').size())
test[['lgd_macro', 'LGD']].describe()

# check ead
test[['EAD', 'EAD_BOOK_BALANCE','EAD_LETTER_OF_CREDIT','EAD_AVAILABLE_LINE','EAD_TOTAL_LINE']].describe()

# check coverage rates
test[['ALLLCOVERAGE', 'CONTINGENTRESERVE']].describe()

# check final output rates
test[['pd_1m','LGD','EAD', 'EAD_BOOK_BALANCE','EAD_LETTER_OF_CREDIT','EAD_AVAILABLE_LINE','EAD_TOTAL_LINE','ALLLCOVERAGE', 'CONTINGENTRESERVE']].describe()

# check cf rates
cf_data[['RATENAME','MODELOUTPUTRATE']].groupby('RATENAME').describe()

test_cf_anchor = cf_data[~cf_data["MODELSEGMENT"].str.contains('_O')]
test_cf_anchor[['RATENAME','MODELOUTPUTRATE']].groupby('RATENAME').describe()           
                         
test_cf_orig = cf_data[cf_data["MODELSEGMENT"].str.contains('_O')]
test_cf_orig[['RATENAME','MODELOUTPUTRATE']].groupby('RATENAME').describe() 

# compare cf rates
sas=pd.read_csv("I:/CRMPO/DEPT/Steven/CNI_TO_SAS/CNI_SAS_FRB_SA_V1.csv")
parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%d%b%y:%H:%M:%S.%f').date()
sas["Vintage"] = sas["Vintage"].apply(parse_date)
sas["PeriodDate"] = pd.to_timedelta(sas["PeriodDate"], unit='s') + pd.datetime(1960, 1, 1)



check = cf_data[['MODELSEGMENT','PERIODDATE','VINTAGE', 'RATENAME','MODELOUTPUTRATE']].merge(
                    sas[['ModelSegment','PeriodDate','Vintage','RATENAME','MODELOUTPUTRATE']],
                    left_on=['MODELSEGMENT','PERIODDATE','VINTAGE', 'RATENAME'],
                    right_on=['ModelSegment','PeriodDate','Vintage','RATENAME'],
                    how='left',
)

check_pd=check[(round(check['PD_x'],5)!=round(check['PD_y'],5))]  
check_lgd=check[(round(check['LGD_x'],5)!=round(check['LGD_y'],5))]
                
# save intermediate dataset from CF (with vintage differentiation)
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

test = pd.pivot_table(cf_data,index=['MODELSEGMENT','VINTAGE','PERIODDATE'],columns=['RATENAME'],values='MODELOUTPUTRATE')
test1=test.reset_index()
test1[['PD','LGD','EAD', 'EADBALANCE','EADLETTEROFCREDIT','EADAVAILABLELINE','EADTOTALLINE','ALLLCOVERAGE', 'CONTINGENTRESERVE']].describe()
final = test1.sort_values(by=['MODELSEGMENT','VINTAGE','PERIODDATE'])
final.to_excel('I:/CRMPO/DEPT/Steven/CNI_TO_SAS/cni_python_frb_ad_intermediate.xlsx')

########################################################################################################################
################ 18. Analysis for C&I IFRS migrate from python to SAS process  #########################################
########################################################################################################################
# compare snapshot 
dec_ifrs_snapshot_python = pd.read_excel("I:/CRMPO/DEPT/Steven/CNI_TO_SAS/IFRS_SAS/dec_snapshot_ifrs_rfo_python.xlsx")
dec_ifrs_snapshot_sas = pd.read_excel("I:/CRMPO/DEPT/Steven/CNI_TO_SAS/IFRS_SAS/cni_ifrs_dec_snapshot_sas_rr.xlsx")
dec_ifrs_snapshot_sas_unrated = dec_ifrs_snapshot_sas[dec_ifrs_snapshot_sas['FINALRAT_IND'] == 0]
unrated_in_python = dec_ifrs_snapshot_sas_unrated[['UNIQUE_FACILITY_ID','FACILITY_INTEREST_RATE']].merge(
    dec_ifrs_snapshot_python[['UNIQUE_FACILITY_ID','ASOFDATE','avg_interestrate']],
    left_on='UNIQUE_FACILITY_ID',
    right_on='UNIQUE_FACILITY_ID',
    how='left'
)

# subset (get unrated loans)
dec_ifrs_snapshot_python = dec_ifrs_snapshot_python[dec_ifrs_snapshot_python['UNIQUE_FACILITY_ID'].isin(['AFS0050163489005016348900501634890000000091',
'AFS0050163489005016348900501634890000000158',
'AFS0050170203005197186400519718640000000018',
'AFS0050172126005017212600501721260000000034',
'AFS0050178438005017843800501784380000000109',
'AFS0050186670005018667000501866700000000117',
'AFS0050200133005020013300502001330000000034',
'AFS0050201800005020180000502018000000000075',
'AFS0050205835005020583500502058350000000075',
'AFS0050205835005020583500502058350000000083',
'AFS0050262828005026282800502628280000001131',
'AFS0050262828005255581500525558150000000018',
'AFS0050262828005255581500525558150000000067',
'AFS0051333883005133388300513338830000000018',
'AFS0051364367005136436700513643670000000190',
'AFS0051400468005140046800514004680000001552',
'AFS0051400468005140046800514004680000001610',
'AFS0051562606005156260600515626060000000018',
'AFS0051562606005156260600515626060000000281',
'AFS0051562606005156260600515626060000000331'])]

 # compare monthly result 
dec_ifrs_intermediate_monthly_python = pd.read_excel("I:/CRMPO/DEPT/Steven/CNI_TO_SAS/IFRS_SAS/CNI_IFRS_Negative_Dec_Intermediate_monthly.xlsx")              
dec_ifrs_intermediate_monthly_python_sample = dec_ifrs_intermediate_monthly_python[dec_ifrs_intermediate_monthly_python['UNIQUE_FACILITY_ID'].isin(['AFS0050163489005016348900501634890000000091',

])]
dec_ifrs_intermediate_monthly_python_sample.to_excel("c:/Users/n882049/Downloads/CNI_IFRS_Positive_Dec_Intermediate_monthly_sample.xlsx")
dec_ifrs_intermediate_monthly_python_sample[['pd_1m','LGD','New_LGD_ifrs','EAD', 'EAD_BOOK_BALANCE','EAD_LETTER_OF_CREDIT','EAD_AVAILABLE_LINE','EAD_TOTAL_LINE']].describe()
                              
########################################################################################################################
################ 18. Aggregate function for C&I IFRS Run  #########################################
########################################################################################################################
# step                     
CI_ABL_risk_rating_model_instance = CNIModel(
    as_of_date=AS_OF_DATE,                                       # scenario and 'forecast window' as-of-date
    scenario=SCENARIO,                                           # scenario name
    scenario_context=STRESS_TESTING_CYCLE,                       # stress testing cycle
    scenario_date=SCENARIO_DATE,                                    # scenario 'real' as-of-date
    scenario_severity_level=SCENARIO_SEVERITY_LEVEL,             # scenario severity level
    forecast_periods=FORECAST_PERIODS,                           # number of forecast periods (unit is defined in the frequency parameter)
    forecast_periods_frequency='monthly',                        # forecast periods frequency
    pass_srr=4.0,                                                # initial passing SRR
    model_id="743 - Commercial Rating Model - C&I PD - SBNA",    # Model ID (normally MRMG code), must match model properties inventory
    debug=False,                                                 # debug mode, if True more messages will be displayed
    include_originations_switch=True,                            # whether or not to include origination contracts in the contract-level dataset
    auto_fetch_macros=True,                                      # part of the parent class CCARModel, whether or not to fetch macros automatically
    limit_contracts=None,                                        # for testing purposes number of random contracts to pick
    statement_days_threshold=STATEMENT_DAYS_THRESHOLD,           # threshold for statement days penalty; normally 366; for SP20, add additional 2 month
    staging_dataset_input_path = CI_STAGING_DATASET_INPUT_PATH,
    ifrs_switch = IFRS_SWITCH,
    portfolio_snapshot_date=PORTFOLIO_SNAPSHOT_DATE,             # CNIMasterDataset as-of-date
    mature_non_pass_locs=True,                                   # force maturing non-pass loans to get a 0 EAD after maturity
    mra_asofdate = MRA_ASOFDATE,                                 # financial statement(mra) as of date
    scenario_combinations = None,
    financial_in_rfo = FINANCIAL_IN_RFO_SWITCH,
    new_financial_logic = True,
    show_result_plot = True,
    add_uat_columns = ADD_UAT_COLUMNS,  # for test
    forecast_result_frequency = FORECAST_RESULT_FREQUENCY   # for test
)
    
ccar_session = CCARSession(
    session_id='C&I Risk Rating CCAR 2018',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

cart.addModel(CI_ABL_risk_rating_model_instance)
cart.checkout()       # execute() is called here

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()
# for IFRS cfs
cf_data = cf_data[~cf_data.RATENAME.isin(['ALLLCOVERAGE', 'CONTINGENTRESERVE'])]
                  
results_df = CI_ABL_risk_rating_model_instance.results_df

## reset cf generator and shopping cart 
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()


RESULT_CLEAN_FIELDS = [
    'UNIQUE_FACILITY_ID',
    'FORECAST_PERIOD',
    'PeriodDate',
    'OPENDATE',
    'MAXIMUMMATURITYDATE',
    'MAXIMUMMATURITYDATE_NEW',
    'm2mat',
    'PD_GROUP',
#    'IS_Stage1',
#    'stage',
    'forecast_period_quarterly',
    'forecast_period_month',
    'SRR',
    'LOCAL_NPL_FLAG',
    'FACILITYTYPE',
    'StatementDate',
#    'StatementMonths',
#    'AuditMethod',
#    'StatementID',
#    'InterestExpense',
#    'CashAndEquivs',
#    'NetTradeAcctsRec',
#    'TotalCurLiabs',
#    'ProfitBeforeTax',
#    'NetSales',
#    'DebtToTNW',
    'r_DebtToTNW1',
    'r_EBITDAoIntrst',
    'r_quickRatio',  
    'r_proftmargin',
    'diff_proftmargin',
    'pct_chg_netsales',
    'V_Debt2TNW',
    'V_EBITDA2IntExp',
    'V_QuickR',
    'V_day_to_stmt2',
    'V_ProfitM',
    'V_ChgSales',
    'estimated_pd',
    'rating',
#    'finalrat_ind',
#    'FINALRAT',
#    'quantrat',
#    'rating_adjustment',
    'final_rating',
    'pd_mrs',
    'pd_mapping',
    'pd_1y',
    'pd_1q',
    'pd_1m',
    'COLLATERALCODE',
    'COLLATERAL_TYPE',
    'lgd_macro',
#    'avg_interestrate',
    'LGD',
    'New_LGD_ifrs',
    'EAD',
    'EAD_BOOK_BALANCE',
    'EAD_LETTER_OF_CREDIT',
    'EAD_AVAILABLE_LINE',
    'EAD_TOTAL_LINE',
    'ALLLCOVERAGE',
    'CONTINGENTRESERVE'
]			

test1 = results_df.sort_values(by = ['UNIQUE_FACILITY_ID','FORECAST_PERIOD'])
test1['SCENARIO'] = SCENARIO
final = test1[['SCENARIO'] + RESULT_CLEAN_FIELDS]

# save files
cf_data.to_csv("I:/MTHDO/Dept/LossImplementation/1Q18/3 - Contributor Files/Wholesale/IFRS_May_P21/cni_cf_may_p21_base_546.csv", index = False)
final.to_excel("I:/MTHDO/Dept/LossImplementation/1Q18/3 - Contributor Files/Wholesale/IFRS_May_P21/cni_intermediate_may_p21_base_546.xlsx", index = False)

