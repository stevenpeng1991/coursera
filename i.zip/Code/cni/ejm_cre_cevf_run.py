# -*- coding: utf-8 -*-
"""
Created on Wed Jul  5 10:44:10 2017

@author: n882049
"""
import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.sensitivity.balancewalk as bw
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalkMacroSensitivity
import CIFI.controllers.utilities.utilities as utilities
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import matplotlib.cm as cm
import datetime
import numpy as np
import pandas as pd
import itertools
import _pickle 
from matplotlib.backends.backend_pdf import PdfPages
from CIFI.controllers.models.cniriskrating import *
from CIFI.config import CONFIG

from CIFI.controllers.models.riskratingmodel import RiskRatingModel
from CIFI.controllers.ejm.ejmmaster import ejmDictionaryGenerator, EJMGenerator
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart

############################# SP20 RUN Round 1 ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,2,28)
SCENARIO_DATE = datetime.datetime(2017,3,31)          
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "P20"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 45
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\1Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_1Q17.xlsm'
EJM_SCENARIO_SEVERITY_LEVEL = "BASE"

############################# STAGF ##############################
AS_OF_DATE = datetime.datetime(2017,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,3,31)
SCENARIO_DATE = datetime.datetime(2017,3,31)          
SCENARIO = "STAGF"
STRESS_TESTING_CYCLE = "IFRS92017"
SCENARIO_SEVERITY_LEVEL = "ADVERSE"
FORECAST_PERIODS = 27
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\1Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_1Q17.xlsm'
EJM_SCENARIO_SEVERITY_LEVEL = "ADVERSE"

############################# P20 Run 2 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,5,31)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
SCENARIO = "STRESS"
STRESS_TESTING_CYCLE = "P20_MAY"
SCENARIO_SEVERITY_LEVEL = "STRESS"
FORECAST_PERIODS = 42
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_2Q17.xlsm'
EJM_SCENARIO_SEVERITY_LEVEL = "STRESS"

############################# MC Round 1 ##############################
AS_OF_DATE = datetime.datetime(2017,6,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           # not in run.py
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "MidCycle2017"
SCENARIO_SEVERITY_LEVEL = "BASE"
FORECAST_PERIODS = 42
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_2Q17.xlsm'
EJM_SCENARIO_SEVERITY_LEVEL = "BASE"

############################# ICAAP ##############################
AS_OF_DATE = datetime.datetime(2017,9,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,9,30)
SCENARIO_DATE = datetime.datetime(2017,9,30)           # not in run.py
SCENARIO = "GLOBAL_STRESS"
STRESS_TESTING_CYCLE = "ICAAP2018"
SCENARIO_SEVERITY_LEVEL = "ADVERSE"
FORECAST_PERIODS = 39
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\3Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_3Q17.xlsm'
EJM_SCENARIO_SEVERITY_LEVEL = "ADVERSE"

############################# IFRS SEP RUN ##############################
AS_OF_DATE = datetime.datetime(2017,9,30)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,9,30)
SCENARIO_DATE = datetime.datetime(2017,9,30)           # not in run.py
SCENARIO = "IFRS9_NEGATIVE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 45   # Attention: max length in ejm master is 45, if larger than 45, addCFChunk will give missing;
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\3Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_3Q17.xlsm'
EJM_SCENARIO_SEVERITY_LEVEL = "ADVERSE"
ONLY_RUN_CEVF_CRECONSTRUCTION = True

############################# CCAR NOV DRY RUN ##############################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,11,30)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "BHC_STRESS"   # BASE/ADVERSE/STRESS
STRESS_TESTING_CYCLE = "DryRun2018"   
EJM_SCENARIO_SEVERITY_LEVEL = "BHC_STRESS"
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 27   # Attention: max length in ejm master is 45, if larger than 45, addCFChunk will give missing;
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'
ENERGY_FINANCE_FACILITY_RATE = True
ONLY_RUN_CEVF_CRECONSTRUCTION = False

############################# CCAR OFFICIAL RUN 1 ##############################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "FRB_SA"   # FRB_BASE/FRB_ADVERSE/FRB_SA/BHC_STRESS   # GLOBAL_STRESS
STRESS_TESTING_CYCLE = "CCAR2018"  # CCAR2018/ICAAP2018_CCAR
EJM_SCENARIO_SEVERITY_LEVEL = "STRESS"  # BASE/ADVERSE/STRESS/BHC_STRESS/BHC_ADVERSE
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/ADVERSE/STRESS
FORECAST_PERIODS = 48   # Attention: max length in ejm master is 45, if larger than 45, addCFChunk will give missing;
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'
ENERGY_FINANCE_FACILITY_RATE = True
ONLY_RUN_CEVF_CRECONSTRUCTION = False

############################# IFRS Jan Run ##############################
AS_OF_DATE = datetime.datetime(2018,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,1,31)
SCENARIO_DATE = datetime.datetime(2018,3,31)          
SCENARIO = "IFRS9_NEGATIVE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"  
EJM_SCENARIO_SEVERITY_LEVEL = "ADVERSE"  
SCENARIO_SEVERITY_LEVEL = "ADVERSE"   # BASE/BASE/ADVERSE
FORECAST_PERIODS = 45   # number of forecast month: 132
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'
ONLY_RUN_CEVF_CRECONSTRUCTION = True

######################### EBA run (CCAR model;Dec snapshot;11 years) ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "EBA_BASE"   # EBA_BASE/EBA_STRESS
STRESS_TESTING_CYCLE = "EBA2018"  # CCAR2018  # ICAAP2018_CCAR
EJM_SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/STRESS
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE/STRESS
FORECAST_PERIODS = 132   # number of forecast month
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'
ENERGY_FINANCE_FACILITY_RATE = True
ONLY_RUN_CEVF_CRECONSTRUCTION = False

######################### P21 run (CCAR model;Feb snapshot; 45 month) ######################
AS_OF_DATE = datetime.datetime(2018,3,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2018,2,28)
SCENARIO_DATE = datetime.datetime(2018,3,31)  
STRESS_TESTING_CYCLE = "P21"  # P21
SCENARIO = "BASE"   # BASE
EJM_SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE
SCENARIO_SEVERITY_LEVEL = "BASE"   # BASE
FORECAST_PERIODS = 45   # number of forecast month
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\1Q18\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_1Q18.xlsm'
ENERGY_FINANCE_FACILITY_RATE = True
ONLY_RUN_CEVF_CRECONSTRUCTION = False

######################### EBA run round 2(CCAR model;Dec snapshot;60 months) ######################
AS_OF_DATE = datetime.datetime(2017,12,31)
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
SCENARIO_DATE = datetime.datetime(2017,12,31)           
SCENARIO = "EBA_STRESS"   # EBA_BASE/EBA_STRESS
STRESS_TESTING_CYCLE = "EBA2018_R2"  # CCAR2018  # ICAAP2018_CCAR
EJM_SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/STRESS
SCENARIO_SEVERITY_LEVEL = "STRESS"   # BASE/STRESS
FORECAST_PERIODS = 60   # number of forecast month
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'
ENERGY_FINANCE_FACILITY_RATE = True
ONLY_RUN_CEVF_CRECONSTRUCTION = False


#############################################################
######################### EJM RUN  ##########################
#############################################################

# check ejm dictionary
ejm_dictionary=ejmDictionaryGenerator(
    asofdate = PORTFOLIO_SNAPSHOT_DATE,
    version_date=AS_OF_DATE,
    scenario_pairs = {
        EJM_SCENARIO_SEVERITY_LEVEL:SCENARIO
    },
    pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
    rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
    rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
    ejm_master_file_path = EJM_MASTER_FILE_PATH,
    energy_finance_facility_rate = ENERGY_FINANCE_FACILITY_RATE,
    only_run_cevf_creconstruction = ONLY_RUN_CEVF_CRECONSTRUCTION,
    forecast_periods = FORECAST_PERIODS,
    debug=False
)


ccar_session = CCARSession(
    session_id='Commercial EJM 2017',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

######################### CCAR RUN  ##########################
commercial_ejm_generator = EJMGenerator(
    as_of_date = AS_OF_DATE,
    ejm_dictionary=ejmDictionaryGenerator(
        asofdate = PORTFOLIO_SNAPSHOT_DATE,
        version_date=AS_OF_DATE,
        scenario_pairs = {
            EJM_SCENARIO_SEVERITY_LEVEL:SCENARIO
        },
        pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
        rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
        rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
        ejm_master_file_path = EJM_MASTER_FILE_PATH,
        only_run_cevf_creconstruction = ONLY_RUN_CEVF_CRECONSTRUCTION,
        energy_finance_facility_rate = ENERGY_FINANCE_FACILITY_RATE,
        forecast_periods = FORECAST_PERIODS,
        debug=False,
        logger=ccar_session._logger
    ),
    forecast_periods=FORECAST_PERIODS,
    process_additional_ead=False,
    debug=False,
    logger=ccar_session._logger
)

######################### IFRS RUN  ##########################
commercial_ejm_generator = EJMGenerator(
    as_of_date = AS_OF_DATE,
    ejm_dictionary=ejmDictionaryGenerator(
        asofdate = PORTFOLIO_SNAPSHOT_DATE,
        version_date=AS_OF_DATE,
        scenario_pairs = {
            EJM_SCENARIO_SEVERITY_LEVEL:SCENARIO
        },
        pd_group_field = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT_PD_GROUP_FIELD_NAME"],
        rfo_commercial_anchor_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"],
        rfo_commercial_orig_tb = CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ORIG_DATA"],
        ejm_master_file_path = EJM_MASTER_FILE_PATH,
        only_run_cevf_creconstruction = ONLY_RUN_CEVF_CRECONSTRUCTION,
        debug=False,
        logger=ccar_session._logger
    ),
    forecast_periods=FORECAST_PERIODS,
    process_additional_ead=False,
    debug=False,
    logger=ccar_session._logger
)
    
# ejm disctionary
ejm_dict = commercial_ejm_generator.ejm_dictionary
    
###############  Add model to the shopping cart and execute  ###########
cart.addModel(commercial_ejm_generator)
cart.checkout()       # execute() is called here

###############  Add Overlay for EJM  #####################
adjustment_dictionary={'PD_GROUP':['ENERGY_FINANCE','MWH', 'DFP_CHRYSLER', 'DFP_FOOTPRINT'], 'RATENAME':['PD','PD','PD','PD'], 'MGMTADJUSTMENT':[-0.004509,0.360049,-0.002132,-0.000672]}
ccar_session.contributor_file_generator.managementAdjustment(adjustment_dictionary = adjustment_dictionary, 
                                                             dataset_query_date = datetime.datetime(2017, 6, 30),
                                                             pd_group_switch = True)

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

cf_data.to_csv("I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/EBA2018/cf/EJM_CEVF_CREConstruction/cf_id_101_EBA_BASE_Version_1.csv", index = False)
cf_data.to_csv("I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/cf/Energy_Finance_FRB_BASE_Version_1.csv", index = False)
cf.to_csv("I:/CRMPO/DEPT/Steven/P20_feb/p20_feb_ejm.csv")

#### Read contributor file pickle ####
cf = _pickle.load(open("I:/CRMPO/DEPT/Steven/CIFI/Execution/cf_files/cf_inventory_101_FRB_BASE_version_1.p", 'rb'))
cf_data = cf[101].getCFData()
cf_data_new = cf_data[cf_data['PERIODDATE'] <= datetime.datetime(2020,3,31)]
cf_data_new=cf_data_new[cf_data_new['VINTAGE']==AS_OF_DATE]

# analysis of count number
count = cf_data['RATENAME']
count.value_counts()

## get cf_data from csv
cf_data = pd.read_csv("I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/cf/EJM_CEVF_CREConstruction/cf_id_101_FRB_BASE_Version_1.csv")
parse_date = lambda x: pd.NaT if pd.isnull(x) else datetime.datetime.strptime(x, '%Y-%m-%d')
cf_data["PERIODDATE"] = cf_data["PERIODDATE"].apply(parse_date)
cf_data["VINTAGE"] = cf_data["VINTAGE"].apply(parse_date)
cf_data_new = cf_data[cf_data['PERIODDATE'] <= datetime.datetime(2020,3,31)]
cf_data_new=cf_data_new[cf_data_new['VINTAGE']==AS_OF_DATE]


            data=cf_inventory[contributor_file_id].getCFData()
            # Filter for current vintage
            data=data[data['VINTAGE']==AS_OF_DATE]
            # Filter for current book (no origination)
            if contributor_file_id != 101:
                data=data[~data['MODELSEGMENT'].str.contains('_O')]
                
            cf_entire_inventory=pd.concat([cf_entire_inventory,data])

### EJM Balance Walk ####
# get portfolio snapshot
### All file 101: include CEVF/CRE Construction ###
anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=['CEVF_RR','CI_OTHERS','CI_RR','CRE_REITS',
                           'CRE_UNSECURED','DFP_CHRYSLER','DFP_FOOTPRINT',
                           'ENERGY_FINANCE','EQUIPMENT_FINANCE_LEASING','GOVERNMENT_BANKING','MWH','RUNOFF_CCRC',
                           'CEVF_RETAIL', 'CRE_CONSTRUCTION'],
                overwrite_calculated_line = True
            )
### All pure EJM: excluding CEVF/CRE Construction ###
anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=['CEVF_RR','CI_OTHERS','CI_RR','CRE_REITS',
                           'CRE_UNSECURED','DFP_CHRYSLER','DFP_FOOTPRINT',
                           'ENERGY_FINANCE','EQUIPMENT_FINANCE_LEASING','GOVERNMENT_BANKING','MWH','RUNOFF_CCRC'],
                overwrite_calculated_line = True
            )
### Only Energy Finance ###
anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=['ENERGY_FINANCE'],
                overwrite_calculated_line = True
            )

EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_4Q17.xlsm'

segfield2_to_nco_timing_curve=getNCOCurve(        
        forecast_period=27,
        nco_data_path = EJM_MASTER_FILE_PATH,
        timing_curve_switch = True   
    )      

segfield2_to_nco_timing_curve = None
t0=time.time()
bw_output = balanceWalk(
    cf_data = cf_data,
    anchor_data=anchor_data,
    scenario_list=[SCENARIO],   
    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
    process_ALLL_balances = True,
    debug = True
)  
print('Blance walk completed in ' + str(time.time()-t0) + ' s.')

bw_output.to_csv('I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/Balance Walk/EJM_CEVF_CREConstruction/BW_output_GLOBAL_STRESS_version_1.csv')
bw_output.to_csv('I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/Balance Walk/Energy_Finance_BW_output_FRB_BASE_version_1.csv')

# Pivot balance walk output
pivot_bw=balanceWalkPivot(bw_output,27, AS_OF_DATE, bw_output_from_csv = False)    
pivot_bw.to_csv('I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/Balance Walk/EJM_CEVF_CREConstruction/BW_Pivot_GLOBAL_STRESS_version_1.csv') 
pivot_bw.to_csv('I:/CRMPO/CCAR/4Q17/3 - Contributor Files/Wholesale/CCAR2018/Balance Walk/Energy_Finance_BW_Pivot_FRB_BASE_version_1.csv')

# Write to RFO
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,12,31)
AS_OF_DATE = datetime.datetime(2017,12,31)
RUN_VERSION = 1
FILE_VERSION = 1
CONTRIBUTOR_FILE_ID = 102 # 101 for EJM; 102 for C&I
RUN_SIGNATURE='123117_122757'
PARTITION_KEY='S00000000422'

cf = _pickle.load(open("I:/CRMPO/DEPT/Steven/CIFI/Execution/cf_files/cf_inventory_102_FRB_ADVERSE_version_1.p", 'rb'))
cf[CONTRIBUTOR_FILE_ID].writeToMoodysRFO(
    p_reporting_date=PORTFOLIO_SNAPSHOT_DATE,
    as_of_date=AS_OF_DATE,
    p_run_id=RUN_VERSION,
    debug=True,
    moodys_rfo_env=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"],
    table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["CONTRIBUTOR_DATA"],
    contributor_file_id=CONTRIBUTOR_FILE_ID,
    file_version=FILE_VERSION,                                                 
    overwrite_vintage_asofdate=CONFIG['CONTRIBUTOR_FILE']["VINTAGE_ASOFDATE_VALUE"],
    run_signature=RUN_SIGNATURE,
    partition_key=PARTITION_KEY
)

#############################################################
######################### CRE RUN  ##########################
#############################################################
ccar_session = CCARSession(
    session_id='CRE Risk Rating 2017',
    session_date=AS_OF_DATE
)
cart = ModelShoppingCart(ccar_session=ccar_session)

CRE_risk_rating_instance = RiskRatingModel(
            uncertainty_rate=0.00,
            as_of_date=AS_OF_DATE,
            dataset_query_date=PORTFOLIO_SNAPSHOT_DATE,
            scenario_date=SCENARIO_DATE,
            model_id='2016-SBNA-Loss-Commercial-CRE',
            scenario=SCENARIO,
            scenario_severity_level=SCENARIO_SEVERITY_LEVEL,
            scenario_context=STRESS_TESTING_CYCLE,
            forecast_periods=FORECAST_PERIODS,
            ne_scalar=False,
            crepi_multifamily_scalar=None,
            debug=True,
            bau=None,
            origination=True,
            book_balance_filter=None,
            gl_filter=True,
            path_dependent=True,
            read_input=False
        )       




###############  Add model to the shopping cart and execute  ###########
cart.addModel(CRE_risk_rating_instance)
cart.checkout()       # execute() is called here

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

## save contributor file to CSV file
cf_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_may/ADVERSE_p20_may_cre_CF_0712_testCoverageRate.csv", index = False)

## reset cf generator and shopping cart 
ccar_session.contributor_file_generator.resetGenerator()
cart.resetCart()

#cf_data_test = pd.read_csv("I:/CRMPO/CCAR/1Q17/11 - Controls/SP20 Archive/CIFI/run_log/STAGF/MARCH DATA/cf_id_103.csv")


### SP20 Run Balance Walk and sensitivity ####
# get portfolio snapshot
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalk, balanceWalkMacroSensitivity, getNCOCurve, balanceWalkPivot
anchor_query, anchor_data = getBWFormatAnchorData(
                as_of_date=PORTFOLIO_SNAPSHOT_DATE,
                debug=True,
                pd_groups=["CRE_MULTIFAMILY", "CRE_OTHER"]
            )
## save anchor file to CSV file
anchor_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/P20_may/ADVERSE_p20_may_cre_anchor_0710.csv")

EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_2Q17.xlsm'
segfield2_to_nco_timing_curve=getNCOCurve(        
        forecast_period=FORECAST_PERIODS,
        nco_data_path = EJM_MASTER_FILE_PATH,
        timing_curve_switch = True   
    )      
t0=time.time()
bw_output = balanceWalk(
    cf_data = cf_data,
    anchor_data=anchor_data,
    scenario_list=[SCENARIO],
    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
    process_ALLL_balances = True,
    debug = True
)  
print('Blance walk completed in ' + str(time.time()-t0) + ' s.')

bw_output.to_csv('I:/CRMPO/DEPT/Steven/run_result/P20_may/ADVERSE_p20_may_cre_BW_Output_0710.csv')

# Pivot balance walk output
pivot_bw=balanceWalkPivot(bw_output,27, AS_OF_DATE, bw_output_from_csv = False)           
pivot_bw.to_csv('I:/CRMPO/DEPT/Steven/run_result/0209CCAR2018test/ejm_sa_27_pivot.csv')


############### test: CRE sensitivity run #############
anchor_query, anchor_data = getBWFormatAnchorData(
    as_of_date=datetime.datetime(2017, 6, 30),
    debug=True,
    pd_groups=["CRE_MULTIFAMILY", "CRE_OTHER"]
)

all_combos=[
{'FGDPQ_US': 'BASE',
  'FHOFHOPIQ_US': 'BASE',
  'FHSTQ_US': 'BASE',
  'FIRBAACI7Q_US': 'BASE',
  'FLBR_US': 'BASE',
  'FRBBBQ_US': 'BASE',
  'FRTB3M_US': 'BASE',
  'FZFL075035503Q_US': 'BASE'},
{'FGDPQ_US': 'BASE',
  'FHOFHOPIQ_US': 'BASE',
  'FHSTQ_US': 'BASE',
  'FIRBAACI7Q_US': 'BASE',
  'FLBR_US': 'ADVERSE',
  'FRBBBQ_US': 'BASE',
  'FRTB3M_US': 'BASE',
  'FZFL075035503Q_US': 'BASE'},
{'FGDPQ_US': 'BASE',
  'FHOFHOPIQ_US': 'ADVERSE',
  'FHSTQ_US': 'BASE',
  'FIRBAACI7Q_US': 'BASE',
  'FLBR_US': 'ADVERSE',
  'FRBBBQ_US': 'BASE',
  'FRTB3M_US': 'BASE',
  'FZFL075035503Q_US': 'BASE'},
{'FGDPQ_US': 'BASE',
  'FHOFHOPIQ_US': 'ADVERSE',
  'FHSTQ_US': 'BASE',
  'FIRBAACI7Q_US': 'BASE',
  'FLBR_US': 'ADVERSE',
  'FRBBBQ_US': 'BASE',
  'FRTB3M_US': 'BASE',
  'FZFL075035503Q_US': 'ADVERSE'},
{'FGDPQ_US': 'ADVERSE',
  'FHOFHOPIQ_US': 'ADVERSE',
  'FHSTQ_US': 'BASE',
  'FIRBAACI7Q_US': 'BASE',
  'FLBR_US': 'ADVERSE',
  'FRBBBQ_US': 'BASE',
  'FRTB3M_US': 'BASE',
  'FZFL075035503Q_US': 'ADVERSE'},
{'FGDPQ_US': 'ADVERSE',
  'FHOFHOPIQ_US': 'ADVERSE',
  'FHSTQ_US': 'ADVERSE',
  'FIRBAACI7Q_US': 'ADVERSE',
  'FLBR_US': 'ADVERSE',
  'FRBBBQ_US': 'ADVERSE',
  'FRTB3M_US': 'ADVERSE',
  'FZFL075035503Q_US': 'ADVERSE'}]



t0=time.time()
cf_container = []
transformed_macro_series_list = []
comb = all_combos[0]
for idx, comb in enumerate(all_combos):
    if idx == 0:
        # Create CNIModel instance for Base severity
        cre_instance = RiskRatingModel(
                            uncertainty_rate=0.00,
                            as_of_date=datetime.datetime(2017,6,30),
                            dataset_query_date=datetime.datetime(2017,6,30),
                            scenario_date=datetime.datetime(2017,6,30),
                            model_id='2016-SBNA-Loss-Commercial-CRE',
                            scenario=["BASE", "ADVERSE"],
                            scenario_severity_level='BASE',
                            scenario_context='MidCycle2017',
                            forecast_periods=42,
                            ne_scalar=False,
                            crepi_multifamily_scalar=None,
                            debug=True,
                            bau=None,
                            origination=True,
                            book_balance_filter=None,
                            gl_filter=True,
                            path_dependent=True,
                            read_input=False,
                            scenario_combinations=comb
                        )
    else:
        # create CNI model instance for SA severity case
        cre_instance = RiskRatingModel(
            uncertainty_rate=0.00,
            as_of_date=datetime.datetime(2017, 6, 30),
            dataset_query_date=datetime.datetime(2017, 6, 30),
            scenario_date=datetime.datetime(2017, 6, 30),
            model_id='2016-SBNA-Loss-Commercial-CRE',
            scenario=["BASE", "ADVERSE"],
            scenario_severity_level='ADVERSE',
            scenario_context='MidCycle2017',
            forecast_periods=42,
            ne_scalar=False,
            crepi_multifamily_scalar=None,
            debug=True,
            bau=None,
            origination=True,
            book_balance_filter=None,
            gl_filter=True,
            path_dependent=True,
            read_input=False,
            scenario_combinations=comb
        )

    # check macro and transformation
    transformed_macro_series_list.append(cre_instance.transformed_macro_series)

    ## Create a session instance and a model shopping cart to run the CNIModel
    ccar_session = CCARSession(
        session_id='CRE',
        session_date=datetime.datetime(2017, 6, 30)
    )
    cart = ModelShoppingCart(ccar_session=ccar_session)
    ## Add model to the shopping cart and execute
    cart.addModel(cre_instance)
    cart.checkout()  # execute() is called here

    ## Get contributor file and store in the cf container
    cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
    cf_container.append(cf.getCFData())

    ## reset CF generator and shopping cart
    ccar_session.contributor_file_generator.resetGenerator()
    cart.resetCart()

print(('get cf in {}').format(time.time()-t0))

# generate balance walk outputs and combine them 
bw_output_list = []
pivot_bw_list = []
count = 1
EJM_MASTER_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\5 - EJMs\\Commercial\\COMMERCIAL_EJM_MASTER_2Q17.xlsm'
segfield2_to_nco_timing_curve=getNCOCurve(        
        forecast_period=FORECAST_PERIODS,
        nco_data_path = EJM_MASTER_FILE_PATH,
        timing_curve_switch = True   
    )      

for cf_data in cf_container:
    print('Running balance walk.......' + str(count))
    t0=time.time()
    bw_output = balanceWalkMacroSensitivity(
                    cf_data = cf_data,
                    anchor_data = anchor_data,
                    segfield2_to_nco_timing_curve=segfield2_to_nco_timing_curve,
                    process_ALLL_balances = True,
                    debug = True
                )
    bw_output_list.append(bw_output)
    pivot_bw=balanceWalkPivot(bw_output,FORECAST_PERIODS)  
    pivot_bw_list.append(pivot_bw)
    print('Blance walk completed in ' + str(time.time()-t0) + ' s.')
    count+=1
  
bw_mode = 1
loss_amount = []
loss_rate = []
for item in bw_output_list:
    # get subset of specific BW_MODE
    bw_output_sub = item[item.index.get_level_values('BW_MODE') == bw_mode]
    
    # get loss amount and loss rate for all PD_group
    nco = bw_output_sub.sum()['NCOAMOUNT']
    starting_balance = bw_output_sub.sum()['STARTINGBALANCE']
    nco_rate = nco/starting_balance
    loss_amount.append(nco)
    loss_rate.append(nco_rate * 100)

# Or: use pivot table of bw output
#for item in pivot_bw_list:
#    # get subset of specific BW_MODE
#    pivot_bw_sub = item[item.index.get_level_values('BW_MODE') == bw_mode]
#    
#    # get loss amount and loss rate for all PD_group
#    nco = pivot_bw_sub.sum()['NCOAMOUNT']
#    starting_balance = pivot_bw_sub.sum()['STARTINGBALANCE']
#    nco_rate = nco/starting_balance
#    loss_amount.append(nco)
#    loss_rate.append(nco_rate * 100)
    
# append last value to the loss list
loss_amount.append(loss_amount[-1])
loss_rate.append(loss_rate[-1])


#############################################################
######################### CEVF RUN  #########################
#############################################################
from CIFI.controllers.models.logitmodel import TwoFLogitModel
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart

### IFRS TESTING ###
AS_OF_DATE = datetime.datetime(2017,6,30)
SCENARIO_DATE = datetime.datetime(2017,6,30)           
PORTFOLIO_SNAPSHOT_DATE = datetime.datetime(2017,6,30)     
FORECAST_PERIODS = 12   # number of forecast month
STAGING_DATASET_INPUT_PATH = 'I:/CRMPO/DEPT/Steven/IFRS/cevf_june17_max_days_past_due.csv'  # path for staging data(stage/max_days_past_due)

# IFRS Test Run # 
SCENARIO = "IFRS9_NEGATIVE" # IFRS9_BASE/IFRS9_POSITIVE/IFRS9_NEGATIVE
STRESS_TESTING_CYCLE = "IFRS9_2017_M9"
FORECAST_PERIODS_FREQUENCY = 'monthly'
# MidCycle Test Run #  
SCENARIO = "ADVERSE" # BASE/S1/S3
STRESS_TESTING_CYCLE = "MidCycle2017"  


ccar_session = CCARSession(
    session_id='2-Factor Logit Model Test',
    session_date=AS_OF_DATE
)

cart = ModelShoppingCart(ccar_session=ccar_session)


## MODEL ID
# CEVF : 53 - Scenario Analysis Model - CEVF PD - SBNA


TwoLogit = TwoFLogitModel(
                uncertainty_rate = 0.00,
                as_of_date = AS_OF_DATE,
                model_id = '53 - Scenario Analysis Model - CEVF PD - SBNA',
                scenario = SCENARIO,
                scenario_context = STRESS_TESTING_CYCLE,
                forecast_periods = FORECAST_PERIODS,
                scenario_date = SCENARIO_DATE,
                forecast_periods_frequency = FORECAST_PERIODS_FREQUENCY,
                staging_dataset_input_path = STAGING_DATASET_INPUT_PATH,
                portfolio_snapshot_date = PORTFOLIO_SNAPSHOT_DATE
                )

###############  Add model to the shopping cart and execute  ###########
cart.addModel(TwoLogit)
cart.checkout()       # execute() is called here

## Get portfolio snapshot
portfolio_snapshot = TwoLogit.portfolio_snapshot
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/run_result/IFRS_test/cevf_ifrs_june_snapshot_1130.xlsx")
# writer = ExcelWriter("I:/CRMPO/CCAR/3Q17/ALLL/Commercial/C&I/alll_jun_cni_snapshot.xlsx")
portfolio_snapshot.to_excel(writer,'Sheet1', index = False)
writer.save()

## Check raw and transformed macro series
#transformed_macro_series = TwoLogit.transformed_macro_series_include_t0
transformed_macro_data = TwoLogit.macro_data
transformed_macro_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/IFRS_test/cevf_ifrs_june_IFRS9_NEGATIVE_macro_1130_new.csv", index = True)


## Get portfolio calculated PD
print(TwoLogit.getPDSeries())

## Get the ContributorFile() instance from the ContributorFileGenerator() instance inside the session
cf = ccar_session.contributor_file_generator.generateContributorFileInstance()
if cf is not None:
    cf.checkCFIntegrity().getResponse()
cf_data = cf.getCFData()

## save contributor file to CSV file
cf_data.to_csv("I:/CRMPO/DEPT/Steven/run_result/IFRS_test/cevf_ifrs_june_IFRS9_BASE_CF_1130.csv", index = False)

########### Creat UAT dataset on PD(monthly) ###########
cf_data = cf.getCFData()
RESULT_CLEAN_FIELDS = [
    'SCENARIO',
    'PERIODDATE',
    'MODELSEGMENT',
    'IDIOSYNCRATICRATE3',
    'IDIOSYNCRATICRATE2',
    'IDIOSYNCRATICRATE1',
    'IDIOSYNCRATICRATE5',
    'IDIOSYNCRATICRATE4',
    'MODELOUTPUTRATE'
]			

test1 = cf_data[RESULT_CLEAN_FIELDS]
test1.rename(
     index=str,
     columns={
              'SCENARIO': 'Scenario',
              'PERIODDATE': 'PeriodDate',
              'MODELSEGMENT': 'Unique_Facility_ID',
              'IDIOSYNCRATICRATE3': 'MaximumMaturityDate',
              'IDIOSYNCRATICRATE2': 'MonthToMaturity',
              'IDIOSYNCRATICRATE1': 'ForecastLength',
              'IDIOSYNCRATICRATE5': 'Stage',
              'IDIOSYNCRATICRATE4': 'Old_PD',
              'MODELOUTPUTRATE': 'Prod_PD'
     },
     inplace = True
)

CEVF_BASE_LGD = 0.27
CEVF_STRESS_LGD = 0.390263823468832
CEVF_ADVERSE_LGD = (CEVF_BASE_LGD + CEVF_STRESS_LGD) / 2
test1['Prod_LGD'] = CEVF_BASE_LGD if SCENARIO in ['IFRS9_BASE', 'IFRS9_POSITIVE'] else CEVF_ADVERSE_LGD
test1['Unique_Facility_ID'] = test1['Unique_Facility_ID'].apply(lambda x: x[2:])

final = test1.sort_values(by = ['Unique_Facility_ID','PeriodDate'])
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/CCAR/3Q17/2 - IFRS/Commercial/CEVF/UAT/test/cevf_ifrs_negative_1205_monthly_1.xlsx")
final.to_excel(writer,'Sheet1', index = False)
writer.save()

##########################################################################
################ 1. EJM move to SAS #####################################
##########################################################################
#Result from python
cf_data_python_final = cf_data[cf_data['MODELSEGMENT'] != 'SBAFS0052513798005251379800525137980000000018_O']
cf_data_python_final = cf_data_python_final[['MODELSEGMENT','RATENAME','PERIODDATE','MODELOUTPUTRATE']]

#Result from sas
cf_data_sas = pd.read_excel('c:/Users/n882049/Downloads/CF_DATA_SAS.xlsx')

#compare rates
merge = cf_data_python_final.merge(cf_data_sas, left_on = ['MODELSEGMENT','RATENAME','PERIODDATE'],right_on = ['MODELSEGMENT','RATENAME','PERIODDATE'], how = 'left')
merge['compare'] = (round(merge['MODELOUTPUTRATE_x'],5) == round(merge['MODELOUTPUTRATE_y'],5))
merge.to_excel('c:/Users/n882049/Downloads/test_ejmsas.xlsx')