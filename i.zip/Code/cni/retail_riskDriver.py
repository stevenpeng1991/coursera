'''
Sample Code
# Risk Driver Distribution comparison plots for CCAR 2017 and SP20
riskDriverPlot_retail('HELOC', HELOC_CCAR2017_dict, HELOC_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/heloc_riskDriver/HELOC_RiskDriverDistribution_BalanceWeighted_test.pdf')
riskDriverPlot_retail('HELOC', HELOC_CCAR2017_dict, HELOC_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/heloc_riskDriver/HELOC_RiskDriverDistribution_CountWeighted.pdf')
riskDriverPlot_retail('MORTGAGE', MORTGAGE_CCAR2017_dict, MORTGAGE_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/mortgage_riskDriver/MORTGAGE_RiskDriverDistribution_BalanceWeighted.pdf')
riskDriverPlot_retail('MORTGAGE', MORTGAGE_CCAR2017_dict, MORTGAGE_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/mortgage_riskDriver/MORTGAGE_RiskDriverDistribution_CountWeighted.pdf')

'''

import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
from CIFI.controllers.models.riskratingmodel import Mapping
import datetime
import matplotlib.pyplot as plt
import plotly.plotly as py
import plotly.graph_objs as go
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib as mpl
mpl.rcParams.update(mpl.rcParamsDefault)

global LABEL_DICT
LABEL_DICT = {
        'r_DebtToTNW1': ('Missing', '<=-1.01', '-1.01 - 0.75', '0.75 - 2.11', '2.11 - 3.36', '>3.36'),
        'r_EBITDAoIntrst': ('Missing', '<=1.13', '1.13 - 3.46', '3.46 - 8.01', '8.01 - 20.83', '>20.83'),
        'r_quickRatio': ('Missing', '<=0.46', '0.46 - 1.06', '1.06 - 1.61', '>1.61'),
        'asofdate2stmtdate': ('Missing', '<=1 year', '>1 year'),
        'r_proftmargin': ('Missing', '<=-0.012', '-0.012 - 0.004', '0.004 -0.020', '0.020 - 0.292', '>0.292'),
        'SRR': ('pass: SRR > 4', 'non-pass: SRR <= 4'),
        'COLLATERAL_TYPE': ('COMM PROP', 'UNSECURED', 'EQUIP/VEH', 'HOSP/RESI/FIN/OTHER'),
        'FACILITYTYPE': ('Revolving Line of Credit', 'Not Revolving Line of Credit'),
        'cltv_heloc': ('0%--<50%', '50%--<80%', '>=80%, Missing'),
        'cltv_mortgage': ('0%--<50%', '50%--<70%', '70%--<80%', '>=80%, Missing'),
        'fico_heloc': ('<=699,Missing', '700-739', '740-799', '>=800'),
        'fico_mortgage': ('<=659,Missing', '660-699', '700-739', '>=740'),
        'lien': ('Missing', 'First Lien', 'Second Lien'),
        'loan_age_heloc': ('<=18 MOB', '19-48 MOB', '49-72 MOB', '>=73 MOB'),
        'loan_age_mortgage': ('<=12 MOB', '13-48 MOB', '49-96 MOB', '>=97 MOB'),
        'location': ('MA,NH', 'RI, CT, NY, NJ', 'PA', 'Others'),
        'product_type': ('Fixed Rate', 'Adjusted Rate')
        }




# specify the risk driver for retail
global RISK_DRIVER_DICT_retail
RISK_DRIVER_DICT_retail = {
                'cltv_heloc': 'CLTV',
                'cltv_mortgage': 'CLTV',
                'fico_heloc': 'FICO Score', 
                'fico_mortgage': 'FICO Score', 
                'lien': 'Lien Position',
                'loan_age_heloc': 'Loan Age', 
                'loan_age_mortgage': 'Loan Age', 
                'location': 'Property Location',
                'product_type': 'Product Type'
                }  

HELOC_CCAR2017_dict = {
          'cltv_heloc': {
                'balance': (1178924450, 3103640732, 1127197858),
                'account_number': (27631, 51090, 18475)
                },
          'fico_heloc': {
                'balance': (811863510, 950884002, 1557218455, 2089797073),
                'account_number': (12617, 13533, 26919, 44127)
                },
          'lien': {
                'balance': (19854270, 2609412315, 2780496455),
                'account_number': (633, 39780, 56783)
                },
          'loan_age_heloc': {
                'balance': (1077618828, 1229482515, 606418161, 2496243536),
                'account_number': (17160, 20770, 13921, 45345)
                },
          'location': {
                'balance': (1693225334, 2507290249, 1095151854, 114095603),
                'account_number': (29851, 39074, 25996, 2275)
                }
    }
    
HELOC_SP20_dict = {
          'cltv_heloc': {
                'balance': (1180416370, 3104889995, 1108625550),
                'account_number': (27574, 51325, 18084)
                },
          'fico_heloc': {
                'balance': (821568005, 954736278, 1554747857, 2062879775),
                'account_number': (12778, 13506, 26877, 43822)
                },
          'lien': {
                'balance': (19568937, 2607657050, 2766705928),
                'account_number': (628, 39726, 56629)
                },
          'loan_age_heloc': {
                'balance': (1010455001, 1314881022, 584405756, 2484190136),
                'account_number': (15948, 21983, 13498, 45554)
                },
          'location': {
                'balance': (1681528358, 2517969257, 1081157812, 113276488),
                'account_number': (29811, 39100, 25827, 2245)
                }
    }

MORTGAGE_CCAR2017_dict = {
          'cltv_mortgage': {
                'balance': (711170802, 1730953341, 2516299462, 1648125160),
                'account_number': (4010, 6818, 9536, 10123)
                },
          'fico_mortgage': {
                'balance': (934372304, 609876003, 1384660843, 3677639615),
                'account_number': (8492, 3752, 5683, 12560)
                },
          'product_type': {
                'balance': (4821035533, 1785513232),
                'account_number': (23852, 6635)
                },
          'loan_age_mortgage': {
                'balance': (1581456856, 2032393888, 1166334677, 1826363344),
                'account_number': (3669, 5798, 5931, 15089)
                },
          'location': {
                'balance': (2361753794, 2573817426, 838246576, 832730969),
                'account_number': (10196, 10716, 5265, 4310)
                }
    }
      
MORTGAGE_SP20_dict = {
          'cltv_mortgage': {
                'balance': (744875325, 1776358117, 2614723095, 1625614265),
                'account_number': (4126, 6900, 9683, 9854)
                },
          'fico_mortgage': {
                'balance': (860894940, 621686867, 1445280790, 3833708205),
                'account_number': (8046, 3775, 5820, 12922)
                },
          'product_type': {
                'balance': (4968835408, 1792735394),
                'account_number': (24016, 6547)
                },
          'loan_age_mortgage': {
                'balance': (1798272393, 1989939935, 1195220270, 1778138204),
                'account_number': (4416, 5448, 5954, 14745)
                },
          'location': {
                'balance': (2422560071, 2735693105, 865922208, 737395418),
                'account_number': (10285, 11131, 5323, 3824)
                }
    }


# retail portfolio risk driver plots  
# retail portfolio risk driver plots  
def riskDriverPlot_retail(portfolio, dict_1, dict_2, name1, name2, weight_mode, outputPath):
    # check validility of inputs
    if weight_mode not in ['count', 'balance']:
        raise ValueError("Invalid weight mode! Valid values are 'count' and 'balance'")
    pp = PdfPages(outputPath)
    for risk_driver in dict_1:
        # set x label
        def autolabel(data,rects):
            # Now make some labels
            labels = ['{:3.1f}%'.format(i * 100)  for i in data]
        
            for rect, label in zip(rects, labels):
                height = rect.get_height()
                ax.text(rect.get_x() + rect.get_width()/2, 1 * height, label, ha = 'center', va = 'bottom', fontsize=8)
                
        ##### Count weighted #####
        if weight_mode is 'count':
            total_account1, total_account2 = sum(dict_1[risk_driver]['account_number']), sum(dict_2[risk_driver]['account_number'])
            bucket_count1, bucket_count2 = pd.Series(dict_1[risk_driver]['account_number']), pd.Series(dict_2[risk_driver]['account_number'])
            bucket_percentage1, bucket_percentage2 = bucket_count1 / total_account1, bucket_count2/ total_account2  
            
            # setup for bar chart
            print('>>> Creating risk driver distribution plots for ' + risk_driver + ' (Count Weighted) ' )
            fig, ax = plt.subplots()
            label = LABEL_DICT[risk_driver]        
            
            ax.axis('on')
            plt.gca().yaxis.grid(color = 'gray', linestyle = 'dashed', zorder = 0)
            ax.patch.set_facecolor('white')
            index = np.arange(len(label)) + 0.15
            bar_width = 0.38
            opacity = 0.95
            rects1 = plt.bar(index, bucket_percentage1, bar_width,
                             alpha = opacity,
                             color = '#000080',
                             label = name1, zorder = 5)
            
            rects2 = plt.bar(index + bar_width, bucket_percentage2, bar_width,
                             alpha = opacity,
                             color = '#87CEFA',
                             label = name2, zorder = 5)
            
            plt.ylabel('Facility weighted % of Portfolio')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            plt.ylim(0, max(max(bucket_percentage1), max(bucket_percentage2)) * 1.1)
            plt.title('Distribution of ' + portfolio + ' portfolio across '+ RISK_DRIVER_DICT_retail[risk_driver] + ' bins', fontsize = 12)
            plt.xticks(index + 1 * bar_width, label, fontsize=9, rotation=10)
            legend = plt.legend()
            
            autolabel(bucket_percentage1, rects1)
            autolabel(bucket_percentage2, rects2) 
            # Shrink current axis's height by 10% on the bottom
            box = ax.get_position()
            ax.set_position([box.x0, box.y0 + box.height * 0.1,
                             box.width, box.height * 0.9])
            # Put a legend below current axis
            ax.legend(loc = 'upper center', bbox_to_anchor = (0.5, -0.09),
              fancybox = True, shadow = False, frameon = True, ncol = 5)
            legend.get_frame().set_edgecolor('grey')
            legend.get_frame().set_linewidth(0.5)
            pp.savefig()
            
        ##### balance weighted #####
        elif weight_mode is 'balance':
            total_balance1, total_balance2 = sum(dict_1[risk_driver]['balance']), sum(dict_2[risk_driver]['balance'])
            bucket_sum1, bucket_sum2 = pd.Series(dict_1[risk_driver]['balance']), pd.Series(dict_2[risk_driver]['balance'])
            bucket_sum_percentage1, bucket_sum_percentage2 = bucket_sum1 / total_balance1, bucket_sum2 / total_balance2
            # setup for bar chart    
            print('>>> Creating risk driver distribution plots for ' + risk_driver + ' (Balance Weighted) ' )
            fig, ax = plt.subplots()
            label = LABEL_DICT[risk_driver]       
            
            ax.axis('on')
            plt.gca().yaxis.grid(color = 'gray', linestyle = 'dashed', zorder = 0)
            ax.patch.set_facecolor('white')
            index = np.arange(len(label)) + 0.15
            bar_width = 0.38
            opacity = 0.95
            rects1 = plt.bar(index, bucket_sum_percentage1, bar_width,
                             alpha = opacity,
                             color = '#000080',
                             label = name1, zorder = 5)
            
            rects2 = plt.bar(index + bar_width, bucket_sum_percentage2, bar_width,
                             alpha = opacity,
                             color = '#87CEFA',
                             label = name2, zorder = 5)
            
            plt.ylabel('Balanced weighted % of Portfolio')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            plt.ylim(0, max(max(bucket_sum_percentage1), max(bucket_sum_percentage2)) * 1.1)
            plt.title('Distribution of ' + portfolio + ' portfolio across '+ RISK_DRIVER_DICT_retail[risk_driver] + ' bins', fontsize = 12)
            plt.xticks(index + 1 * bar_width, label, fontsize=9, rotation=10)
            legend = plt.legend()
            
            autolabel(bucket_sum_percentage1, rects1)
            autolabel(bucket_sum_percentage2, rects2) 
            # Shrink current axis's height by 10% on the bottom
            box = ax.get_position()
            ax.set_position([box.x0, box.y0 + box.height * 0.1,
                             box.width, box.height * 0.9])
            # Put a legend below current axis
            ax.legend(loc = 'upper center', bbox_to_anchor = (0.5, -0.09),
              fancybox = True, shadow = False, frameon = True, ncol = 5)
            legend.get_frame().set_edgecolor('grey')
            legend.get_frame().set_linewidth(0.5)
            pp.savefig()
    
    pp.close()
        
