import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.sensitivity.balancewalk as bw
import CIFI.controllers.models.cniriskrating as cni
from CIFI.controllers.utilities.session import CCARSession, Session
from CIFI.controllers.models.ccarmodel import CCARModel, ModelShoppingCart
from CIFI.sensitivity.balancewalk import getBWFormatAnchorData, processBWFacility, balanceWalkMacroSensitivity
import CIFI.controllers.utilities.utilities as utilities
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import matplotlib.cm as cm
import datetime
import numpy as np
import pandas as pd
import itertools
import _pickle 
from matplotlib.backends.backend_pdf import PdfPages

# get portfolio snapshot
Dec_CNI_Data = cni.CNIMasterDataset(
    asofdate=datetime.datetime(2016,12,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    mra_asofdate=datetime.datetime(2016,12,31)
)

Feb_CNI_Data = cni.CNIMasterDataset(
    asofdate=datetime.datetime(2017,2,28),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    mra_asofdate=datetime.datetime(2016,12,31)
)

balance_sum_Dec = Dec_CNI_Data.mds_mra_additional_fields.groupby('PD_GROUP').agg({'BOOKBALANCE': ['sum','count']})
balance_sum_Feb = Feb_CNI_Data.mds_mra_additional_fields.groupby('PD_GROUP').agg({'BOOKBALANCE': ['sum','count']})


# match PD group to which NCO curve to use
anchor_query, anchor_data_all = getBWFormatAnchorData(
                as_of_date=datetime.datetime(2017, 2, 28),
                debug=True,
                pd_groups=["MIDDLE_MARKET", "BUSINESS_BANKING", "ABL"]
            )

test = anchor_data_all.groupby(['PD_GROUP', 'SEGMENTATIONFIELD2']).count()



