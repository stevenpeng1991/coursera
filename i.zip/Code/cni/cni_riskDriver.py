'''
## sample code

######### DEC Data #######
Dec_CNI_Data = cni.CNIMasterDataset(
    asofdate=datetime.datetime(2016,12,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,
    mra_asofdate=datetime.datetime(2016,12,31)
)

dec_data = Dec_CNI_Data.mds_mra_additional_fields
_pickle.dump(dec_data, open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/dec_cni_additional_fields.p", 'wb')) 
dec_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/dec_cni_additional_fields.p", 'rb'))
dec_data = dec_data[dec_data['PD_GROUP'] == 'ABL']

######### FEB Data #######
Feb_CNI_Data = cni.CNIMasterDataset(
    asofdate=datetime.datetime(2017,2,28),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=540,                  # add additinal months, previous 366
    mra_asofdate=datetime.datetime(2016,12,31)
)

feb_data = Feb_CNI_Data.mds_mra_additional_fields
_pickle.dump(feb_data, open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/feb_cni_additional_fields.p", 'wb')) 
feb_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/feb_cni_additional_fields.p", 'rb'))

######### MAR Data #######
Mar_CNI_Data = cni.CNIMasterDataset(
    asofdate=datetime.datetime(2017,3,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=540,                  # add additinal months, previous 366
    mra_asofdate=datetime.datetime(2017,3,31),
    financial_in_rfo=False
)

mar_data = Mar_CNI_Data.mds_mra_additional_fields
_pickle.dump(mar_data, open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/mar_cni_additional_fields.p", 'wb')) 
mar_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/mar_cni_additional_fields.p", 'rb'))

######### MAY Data #######
MAY_CNI_Data = cni.CNIMasterDataset(
    asofdate=datetime.datetime(2017,5,31),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=396,                  # add additinal months, previous 366
    mra_asofdate=datetime.datetime(2017,5,31),
    financial_in_rfo = False,
    new_financial_logic = True
)

may_data = MAY_CNI_Data.mds_mra_additional_fields
_pickle.dump(may_data, open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/may_newest_396day_cni_additional_fields.p", 'wb')) 
may_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/may_newest_396day_cni_additional_fields.p", 'rb'))
may_data_old = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/may_old_cni_additional_fields.p", 'rb'))

######### June Data #######
JUN_CNI_Data = cni.CNIMasterDataset(
    asofdate=datetime.datetime(2017,6,30),
    pd_groups=['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL'],
    pass_SRR=4.,
    debug=True,
    include_originations=True,
    statement_days_threshold=366,                  # add additinal months, previous 366
    mra_asofdate=datetime.datetime(2017,6,30),
    financial_in_rfo = False,
    new_financial_logic = True
)

june_data = JUN_CNI_Data.mds_mra_additional_fields
_pickle.dump(june_data, open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/jun_new_finanical_cni_additional_fields.p", 'wb')) 
### In MidCycle Run1, still use old source file (jun_old_finanical_cni_additional_fields) ###
june_data_newRFO = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/jun_new_finanical_cni_additional_fields.p", 'rb'))
june_data = _pickle.load(open("I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/jun_old_finanical_cni_additional_fields.p", 'rb'))
june_data = june_data[june_data['PD_GROUP'] == 'ABL']

## save and loan balance walk output
_pickle.dump(bw_output_list, open("I:/CRMPO/DEPT/Steven/sensitivity/bw_output_list_BASE_ADVERSE_4.p", 'wb')) 
_pickle.dump(transformed_macro_series_list, open("I:/CRMPO/DEPT/Steven/sensitivity/transformed_macro_series_list_BASE_ADVERSE_4.p", 'wb')) 
_pickle.dump(macro_data_list, open("I:/CRMPO/DEPT/Steven/sensitivity/macro_data_list_BASE_ADVERSE_4.p", 'wb')) 

bw_output_list_test = _pickle.load(open("I:/CRMPO/DEPT/Steven/sensitivity/bw_output_list_BASE_ADVERSE_4.p", 'rb'))

## save snapshots ##
portfolio_snapshot = june_data
from pandas import ExcelWriter
writer = ExcelWriter("I:/CRMPO/DEPT/Steven/cni_snapshot/cni_snapshot_june_midcycle.xlsx")
portfolio_snapshot.to_excel(writer,'Sheet1', index = False)
writer.save()

# Risk Driver Distribution comparison plots for CCAR 2017 and MidCycle 2017
riskDriverDistributionComparison('BUSINESS_BANKING', dec_data, june_data, 366, 366, 'CCAR 2017', 'MidCycle 2017', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/CCAR2017 - MidCycle Run1_PD_GROUP/test/BalanceWeighted/')

riskDriverDistributionComparison('BUSINESS_BANKING', dec_data, june_data, 366, 366, 'CCAR 2017', 'MidCycle 2017', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/CCAR2017 - MidCycle Run1_PD_GROUP/test/CountWeighted/')

# Risk Driver Distribution comparison plots for P20 run 2 and mid cycle run 1
riskDriverDistributionComparison('C&I', may_data, june_data, 396, 366, 'P20 Run2', 'MC Run1', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/P20 R2-MC R1/BalanceWeighted/')

riskDriverDistributionComparison('C&I', may_data, june_data, 396, 366, 'P20 Run2', 'MC Run1', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/P20 R2-MC R1/CountWeighted/')

# Risk Driver Distribution comparison plots for new and old mapping logic for Mid-Cycle
riskDriverDistributionComparison('C&I', may_data_old, may_data, 396, 396, 'old logic', 'new logic', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/old-new/BalanceWeighted/')

riskDriverDistributionComparison('C&I', may_data_old, may_data, 396, 396, 'old logic', 'new logic', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/old-new/CountWeighted/')

# Risk Driver Distribution comparison plots for CCAR 2017 and Mid-Cycle
riskDriverDistributionComparison('C&I', dec_data, may_data, 366, 366, 'CCAR 2017', 'Mid-Cycle', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/CCAR-MidCycle/BalanceWeighted/')

riskDriverDistributionComparison('C&I', dec_data, may_data, 366, 366, 'CCAR 2017', 'Mid-Cycle', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/CCAR-MidCycle/CountWeighted/')

# Risk Driver Distribution comparison plots for Mid-Cycle and SP20
riskDriverDistributionComparison('C&I', feb_data, may_data, 540, 366, 'SP 20', 'Mid-Cycle', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/MidCycle-SP20/BalanceWeighted/')

riskDriverDistributionComparison('C&I', feb_data, may_data, 540, 366, 'SP 20', 'Mid-Cycle', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/MidCycle-SP20/CountWeighted/')


# Risk Driver Distribution comparison plots for CCAR 2017 and SP20
riskDriverDistributionComparison('C&I', dec_data, feb_data, 366, 540, 'CCAR 2017', 'SP 20', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/test/')

riskDriverDistributionComparison('C&I', dec_data, feb_data, 366, 540, 'CCAR 2017', 'SP 20', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/test/')

# Distribution plots for risk drivers
riskDriverDistribution(
                   cniMasterDataInstance = Dec_CNI_Data, 
                   weight_mode = 'count',
                   outputPath = 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/C&I_RiskDriverDistribution_Dec_CountWeighted_test.pdf'
                   )
riskDriverDistribution(
                   cniMasterDataInstance = Dec_CNI_Data, 
                   weight_mode = 'balance',
                   outputPath = 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/C&I_RiskDriverDistribution_Dec_BalanceWeighted_test.pdf'
                   )
riskDriverDistribution(
                   cniMasterDataInstance = Mar_CNI_Data, 
                   weight_mode = 'balance',
                   outputPath = 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/C&I_RiskDriverDistribution_Mar_BalanceWeighted_test.pdf'
                   )

# RETAIL PLOTS: Risk Driver Distribution comparison plots for CCAR 2017 and SP20
riskDriverPlot_retail('HELOC', HELOC_CCAR2017_dict, HELOC_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/heloc_riskDriver/HELOC_RiskDriverDistribution_BalanceWeighted.pdf')
riskDriverPlot_retail('HELOC', HELOC_CCAR2017_dict, HELOC_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/heloc_riskDriver/HELOC_RiskDriverDistribution_CountWeighted.pdf')
riskDriverPlot_retail('MORTGAGE', MORTGAGE_CCAR2017_dict, MORTGAGE_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'balance',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/mortgage_riskDriver/MORTGAGE_RiskDriverDistribution_BalanceWeighted.pdf')
riskDriverPlot_retail('MORTGAGE', MORTGAGE_CCAR2017_dict, MORTGAGE_SP20_dict, 'CCAR 2017', 'SP 20', 
                                 'count',
                                 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/mortgage_riskDriver/MORTGAGE_RiskDriverDistribution_CountWeighted.pdf')
'''

import os
import sys
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)
import CIFI.controllers.models.cniriskrating as cni
from CIFI.controllers.models.riskratingmodel import Mapping
import datetime
import matplotlib.pyplot as plt
import plotly.plotly as py
import plotly.graph_objs as go
import numpy as np
import pandas as pd
import _pickle 
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib as mpl
mpl.rcParams.update(mpl.rcParamsDefault)

global MAPPING_DICT
MAPPING_DICT = {
            'r_DebtToTNW1':
            {
                'IN_VAR': 'r_DebtToTNW1',
                'OUT_VAR': 'r_DebtToTNW1_Group',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -1.009854, 0.752294, 2.113506, 3.357537
                ),
                'MAPPED_VALUES': (
                    1, 2, 3, 4, 5
                ),

                'MISSING': 0,
            },
#            'r_DebtToTNW1':
#            {
#                'IN_VAR': 'r_DebtToTNW1',
#                'OUT_VAR': 'r_DebtToTNW1_Group',
#                'TYPE': 'interval_left',
#                'IN_VALUES': (
#                    -1.009854, 0.752294, 2.113506, 3.357537
#                ),
#                'MAPPED_VALUES': (
#                    '<-1.01', '-1.01 to 0.75', '0.75 to 2.11', '2.11 to 3.36', '>3.36'
#                ),
#
#                'MISSING': 'missing', 
#            },
            'r_EBITDAoIntrst':
            {
                'IN_VAR': 'r_EBITDAoIntrst',
                'OUT_VAR': 'r_EBITDAoIntrst_Group',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    1.13793103448275, 3.46031746031746, 8.00684931506849, 20.8333333333333
                ),
                'MAPPED_VALUES': (
                    1, 2, 3, 4, 5
                ),

                'MISSING': 0

            },
            'r_quickRatio':
            {
                'IN_VAR': 'r_quickRatio',
                'OUT_VAR': 'r_quickRatio_Group',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    0.46828143021914, 1.06599578750292, 1.61751152073732
                ),
                'MAPPED_VALUES': (
                    1, 2, 3, 4
                ),

                'MISSING': 0
            },            
#            'ChgSales':
#            {
#                'IN_VAR': 'ChgSales',
#                'OUT_VAR': 'ChgSales_Group',
#                'TYPE': 'interval_left',
#                'IN_VALUES': (
#                    -0.12697919900651, -0.04720423778693, 0, 0.0835806132542,
#                    0.15284210526315, 0.30612244897959
#                ),
#                'MAPPED_VALUES': (
#                    1, 2, 3, 4, 5, 6
#                ),
#
#                'MISSING': 0
#            },
            'r_proftmargin':
            {
                'IN_VAR': 'r_proftmargin',
                'OUT_VAR': 'r_proftmargin_Group',
                'TYPE': 'interval_left',
                'IN_VALUES': (
                    -0.01217656, 0.0040471885, 0.02028458976687, 0.29189044038668,
                ),
                'MAPPED_VALUES': (
                    1, 2, 3, 4, 5
                ),

                'MISSING': 0
            },
            'COLLATERAL_TYPE':
            {
                'IN_VAR': 'COLLATERAL_TYPE',
                'OUT_VAR': 'COLLATERAL_TYPE_Group',
                'TYPE': 'categorical',
                'IN_VALUES': (
                    'COMMERCIAL PROPERTIES', 'UNSECURED', 'EQUIPMENT/VEHICLE',
                    ('HOSPITAL/ MEDICAL CARE PROPERTIES','RESIDENTIAL PROPERTIES',
                    'FINANCIAL ASSETS','ALL ASSETS/OTHER')
                ),
                'MAPPED_VALUES': (
                    1,2,3,4
                ),
                'MISSING': 0
            }
        }

global LABEL_DICT
LABEL_DICT = {
        'r_DebtToTNW1': ('Missing', '<=-1.01', '-1.01 - 0.75', '0.75 - 2.11', '2.11 - 3.36', '>3.36'),
        'r_EBITDAoIntrst': ('Missing', '<=1.13', '1.13 - 3.46', '3.46 - 8.01', '8.01 - 20.83', '>20.83'),
        'r_quickRatio': ('Missing', '<=0.46', '0.46 - 1.06', '1.06 - 1.61', '>1.61'),
        'asofdate2stmtdate': ('Missing', 'Current Statement', 'Non-Current Statement'),
        'r_proftmargin': ('Missing', '<=-0.012', '-0.012 - 0.004', '0.004 -0.020', '0.020 - 0.292', '>0.292'),
        'SRR': ('Missing', 'pass: SRR > 4', 'non-pass: SRR <= 4'),
        'COLLATERAL_TYPE': ('Missing', 'COMM PROP', 'UNSECURED', 'EQUIP/VEH', 'HOSP/RESI/FIN/OTHER'),
        'FACILITYTYPE': ('Missing', 'Revolving Line of Credit', 'Non-Revolving Line of Credit'),
        'cltv_heloc': ('0%--<50%', '50%--<80%', '>=80%, Missing'),
        'cltv_mortgage': ('0%--<50%', '50%--<70%', '70%--<80%', '>=80%, Missing'),
        'fico_heloc': ('<=699,Missing', '700-739', '740-799', '>=800'),
        'fico_mortgage': ('<=659,Missing', '660-699', '700-739', '>=740'),
        'lien': ('Missing', 'First Lien', 'Second Lien'),
        'loan_age_heloc': ('<=18 MOB', '19-48 MOB', '49-72 MOB', '>=73 MOB'),
        'loan_age_mortgage': ('<=12 MOB', '13-48 MOB', '49-96 MOB', '>=97 MOB'),
        'location': ('MA,NH', 'RI, CT, NY, NJ', 'PA', 'Others'),
        'product_type': ('Fixed Rate', 'Adjusted Rate')
        }


# specify the risk driver
global RISK_DRIVER_DICT
RISK_DRIVER_DICT = {
                'r_DebtToTNW1': 'Debt to Tangible Net Worth Ratio',
                'r_EBITDAoIntrst': 'EBITDA to Interest Coverage Ratio', 
                'r_quickRatio': 'Quick Ratio',
                'asofdate2stmtdate': 'Days to Financial Statement', 
                'r_proftmargin': 'Profit Margin',
                'SRR': 'SRR',
                'COLLATERAL_TYPE': 'Collateral Type',
                'FACILITYTYPE': 'Facility Type'
                }  

# pre-process data and map risk driver into different groups
def preProcessRiskDriver(raw_data_merged, statement_days_threshold, risk_driver):
    risk_driver_data = pd.concat([raw_data_merged[risk_driver], raw_data_merged['BOOKBALANCE']], axis = 1)
    
    if risk_driver is 'asofdate2stmtdate':
        def asofdate2stmtdate_mapping(x):
            if pd.isnull(x) or (x == -1):            
                return 0
            elif x <= statement_days_threshold:
                return 1
            else:
                return 2
        risk_driver_data['Group'] = risk_driver_data[risk_driver].apply(asofdate2stmtdate_mapping)    
    elif risk_driver is 'SRR':
        risk_driver_data['Group'] = risk_driver_data[risk_driver].apply(lambda x: 0 if pd.isnull(x) else (1 if x > 4 else 2))      
    elif risk_driver is 'FACILITYTYPE':
        risk_driver_data['Group'] = risk_driver_data[risk_driver].apply(lambda x: 0 if pd.isnull(x) else (1 if x == 'Revolving Line of Credit' else 2))
    else:
        # assign group values by mapping
        risk_driver_map = Mapping(in_map = MAPPING_DICT[risk_driver], debug = False)
        risk_driver_data['Group'] = [
                    risk_driver_map.apply(item) for item in risk_driver_data[risk_driver]
                ]  
    return risk_driver_data

riskDriverDistributionComparison(portfolio = 'C&I', data1 = dec_data, data2 = june_data, statement_days_threshold1 = 366, statement_days_threshold2 = 366, name1 = 'CCAR 2017', name2 = 'MidCycle 2017', 
                                 name1 = 'balance',
                                 outputPath = 'I:/CRMPO/DEPT/Steven/RiskDriverDistribution/cni_riskDriver/CCAR2017 - MidCycle Run1_PD_GROUP/test/BalanceWeighted/')
risk_driver = 'SRR'
    
# Risk Driver Distribution comparison plots for CCAR 2017 and SP20
def riskDriverDistributionComparison(portfolio, data1, data2, statement_days_threshold1, statement_days_threshold2, name1, name2, weight_mode, outputPath):
    # check validility of inputs
    if weight_mode not in ['count', 'balance']:
        raise ValueError("Invalid weight mode! Valid values are 'count' and 'balance'")
        
    if portfolio in ['ABL', 'MIDDLE_MARKET','BUSINESS_BANKING']:
        data1, data2 = data1[data1['PD_GROUP'] == portfolio], data2[data2['PD_GROUP'] == portfolio]
    elif portfolio != 'C&I':
        raise ValueError("Invalid portfolio name! Valid values are 'C&I', 'ABL', 'MIDDLE_MARKET','BUSINESS_BANKING'")
        
    def zeroPercentHandle(try_expression, except_expression, i):
    # function to handel zero percent for some buckets
        try:
            temp = try_expression[i]
        except:
            temp = except_expression
        return(temp)
        
    #pp = PdfPages(outputPath)
    for risk_driver in RISK_DRIVER_DICT:
        risk_driver_data1 = preProcessRiskDriver(raw_data_merged = data1, statement_days_threshold = statement_days_threshold1, risk_driver = risk_driver)
        risk_driver_data2 = preProcessRiskDriver(raw_data_merged = data2, statement_days_threshold = statement_days_threshold2, risk_driver = risk_driver)                
        
        # set x label
        def autolabel(data,rects):
            # Now make some labels
            labels = ['{:3.1f}%'.format(i * 100)  for i in data]
        
            for rect, label in zip(rects, labels):
                height = rect.get_height()
                ax.text(rect.get_x() + rect.get_width()/2, 1 * height, label, ha = 'center', va = 'bottom', fontsize=8)
        
        label = LABEL_DICT[risk_driver]  
        ##### Count weighted #####
        if weight_mode is 'count':
            total_account1, total_account2 = len(risk_driver_data1), len(risk_driver_data2)
            bucket_count1, bucket_count2 = risk_driver_data1.groupby(['Group']).size(), risk_driver_data2.groupby(['Group']).size()
            temp1, temp2 = pd.Series(np.zeros(len(label))), pd.Series(np.zeros(len(label)))
            bucket_percentage1, bucket_percentage2 = bucket_count1 / total_account1, bucket_count2/ total_account2  
            for i in range(len(label)):
                temp1[i]= zeroPercentHandle(bucket_percentage1, 0, i)
                temp2[i]= zeroPercentHandle(bucket_percentage2, 0, i)
            bucket_percentage1, bucket_percentage2 = temp1, temp2
            # setup for bar chart
            print('>>> Creating risk driver distribution plots for ' + RISK_DRIVER_DICT[risk_driver] + ' (Count Weighted) ' )
            fig, ax = plt.subplots()      
            ax.axis('on')
            plt.gca().yaxis.grid(color = 'gray', linestyle = 'dashed', zorder = 0)
            ax.patch.set_facecolor('white')
            index = np.arange(len(label)) + 0.15
            bar_width = 0.38
            opacity = 0.95
            rects1 = plt.bar(index, bucket_percentage1, bar_width,
                             alpha = opacity,
                             color = '#000080',
                             label = name1, zorder = 5)
            
            rects2 = plt.bar(index + bar_width, bucket_percentage2, bar_width,
                             alpha = opacity,
                             color = '#6495ed',
                             label = name2, zorder = 5)
            
            plt.ylabel('Facility weighted % of Portfolio')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            plt.ylim(0, max(max(bucket_percentage1), max(bucket_percentage2)) * 1.1)
            plt.title('Distribution of ' + portfolio + ' portfolio across '+ RISK_DRIVER_DICT[risk_driver] + ' bins', fontsize = 14)
            plt.xticks(index + 1 * bar_width, label, fontsize=9, rotation=10)
            legend = plt.legend()
            
            autolabel(bucket_percentage1, rects1)
            autolabel(bucket_percentage2, rects2) 
            # Shrink current axis's height by 10% on the bottom
            box = ax.get_position()
            ax.set_position([box.x0, box.y0 + box.height * 0.1,
                             box.width, box.height * 0.9])
            # Put a legend below current axis
            ax.legend(loc = 'upper center', bbox_to_anchor = (0.5, -0.09),
              fancybox = True, shadow = False, frameon = True, ncol = 5)
            legend.get_frame().set_edgecolor('grey')
            legend.get_frame().set_linewidth(0.5)
            plt.savefig(outputPath + portfolio + '_' + RISK_DRIVER_DICT[risk_driver] + '.png', dpi=300)
    
            plt.show()
        
        
        ##### balance weighted #####
        elif weight_mode is 'balance':
            total_balance1, total_balance2 = sum(risk_driver_data1['BOOKBALANCE']), sum(risk_driver_data2['BOOKBALANCE'])
            bucket_sum1, bucket_sum2 = risk_driver_data1.groupby(by = ['Group']).sum()['BOOKBALANCE'], risk_driver_data2.groupby(by = ['Group']).sum()['BOOKBALANCE']
            temp1, temp2 = pd.Series(np.zeros(len(label))), pd.Series(np.zeros(len(label)))
            bucket_sum_percentage1, bucket_sum_percentage2 = bucket_sum1 / total_balance1, bucket_sum2 / total_balance2
            for i in range(len(label)):
                temp1[i]= zeroPercentHandle(bucket_sum_percentage1, 0, i)
                temp2[i]= zeroPercentHandle(bucket_sum_percentage2, 0, i)
            bucket_sum_percentage1, bucket_sum_percentage2 = temp1, temp2
            
            # setup for bar chart    
            print('>>> Creating risk driver distribution plots for ' + RISK_DRIVER_DICT[risk_driver] + ' (Balance Weighted) ' )
            fig, ax = plt.subplots()     
            
            ax.axis('on')
            plt.gca().yaxis.grid(color = 'gray', linestyle = 'dashed', zorder = 0)
            ax.patch.set_facecolor('white')
            index = np.arange(len(label)) + 0.15
            bar_width = 0.38
            opacity = 0.95
            rects1 = plt.bar(index, bucket_sum_percentage1, bar_width,
                             alpha = opacity,
                             color = '#000080',
                             label = name1, zorder = 5)
            
            rects2 = plt.bar(index + bar_width, bucket_sum_percentage2, bar_width,
                             alpha = opacity,
                             color = '#6495ed',
                             label = name2, zorder = 5)
            
            plt.ylabel('Balanced weighted % of Portfolio')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            plt.ylim(0, max(max(bucket_sum_percentage1), max(bucket_sum_percentage2)) * 1.1)
            plt.title('Distribution of ' + portfolio + ' portfolio across '+ RISK_DRIVER_DICT[risk_driver] + ' bins', fontsize = 14)
            plt.xticks(index + 1 * bar_width, label, fontsize=9, rotation=10)
            legend = plt.legend()
            
            autolabel(bucket_sum_percentage1, rects1)
            autolabel(bucket_sum_percentage2, rects2) 
            # Shrink current axis's height by 10% on the bottom
            box = ax.get_position()
            ax.set_position([box.x0, box.y0 + box.height * 0.1,
                             box.width, box.height * 0.9])
            # Put a legend below current axis
            ax.legend(loc = 'upper center', bbox_to_anchor = (0.5, -0.09),
              fancybox = True, shadow = False, frameon = True, ncol = 5)
            legend.get_frame().set_edgecolor('grey')
            legend.get_frame().set_linewidth(0.5)
            plt.savefig(outputPath + portfolio + '_' + RISK_DRIVER_DICT[risk_driver] + '.png', dpi=300)
            
            plt.show()

# specify the risk driver for retail
global RISK_DRIVER_DICT_retail
RISK_DRIVER_DICT_retail = {
                'cltv_heloc': 'CLTV',
                'cltv_mortgage': 'CLTV',
                'fico_heloc': 'FICO Score', 
                'fico_mortgage': 'FICO Score', 
                'lien': 'Lien Position',
                'loan_age_heloc': 'Loan Age', 
                'loan_age_mortgage': 'Loan Age', 
                'location': 'Property Location',
                'product_type': 'Product Type'
                }  

HELOC_CCAR2017_dict = {
          'cltv_heloc': {
                'balance': (1178924450, 3103640732, 1127197858),
                'account_number': (27631, 51090, 18475)
                },
          'fico_heloc': {
                'balance': (811863510, 950884002, 1557218455, 2089797073),
                'account_number': (12617, 13533, 26919, 44127)
                },
          'lien': {
                'balance': (19854270, 2609412315, 2780496455),
                'account_number': (633, 39780, 56783)
                },
          'loan_age_heloc': {
                'balance': (1077618828, 1229482515, 606418161, 2496243536),
                'account_number': (17160, 20770, 13921, 45345)
                },
          'location': {
                'balance': (1693225334, 2507290249, 1095151854, 114095603),
                'account_number': (29851, 39074, 25996, 2275)
                }
    }
    
HELOC_SP20_dict = {
          'cltv_heloc': {
                'balance': (1180416370, 3104889995, 1108625550),
                'account_number': (27574, 51325, 18084)
                },
          'fico_heloc': {
                'balance': (821568005, 954736278, 1554747857, 2062879775),
                'account_number': (12778, 13506, 26877, 43822)
                },
          'lien': {
                'balance': (19568937, 2607657050, 2766705928),
                'account_number': (628, 39726, 56629)
                },
          'loan_age_heloc': {
                'balance': (1010455001, 1314881022, 584405756, 2484190136),
                'account_number': (15948, 21983, 13498, 45554)
                },
          'location': {
                'balance': (1681528358, 2517969257, 1081157812, 113276488),
                'account_number': (29811, 39100, 25827, 2245)
                }
    }

MORTGAGE_CCAR2017_dict = {
          'cltv_mortgage': {
                'balance': (711170802, 1730953341, 2516299462, 1648125160),
                'account_number': (4010, 6818, 9536, 10123)
                },
          'fico_mortgage': {
                'balance': (934372304, 609876003, 1384660843, 3677639615),
                'account_number': (8492, 3752, 5683, 12560)
                },
          'product_type': {
                'balance': (4821035533, 1785513232),
                'account_number': (23852, 6635)
                },
          'loan_age_mortgage': {
                'balance': (1581456856, 2032393888, 1166334677, 1826363344),
                'account_number': (3669, 5798, 5931, 15089)
                },
          'location': {
                'balance': (2361753794, 2573817426, 838246576, 832730969),
                'account_number': (10196, 10716, 5265, 4310)
                }
    }
      
MORTGAGE_SP20_dict = {
          'cltv_mortgage': {
                'balance': (744875325, 1776358117, 2614723095, 1625614265),
                'account_number': (4126, 6900, 9683, 9854)
                },
          'fico_mortgage': {
                'balance': (860894940, 621686867, 1445280790, 3833708205),
                'account_number': (8046, 3775, 5820, 12922)
                },
          'product_type': {
                'balance': (4968835408, 1792735394),
                'account_number': (24016, 6547)
                },
          'loan_age_mortgage': {
                'balance': (1798272393, 1989939935, 1195220270, 1778138204),
                'account_number': (4416, 5448, 5954, 14745)
                },
          'location': {
                'balance': (2422560071, 2735693105, 865922208, 737395418),
                'account_number': (10285, 11131, 5323, 3824)
                }
    }



# retail portfolio risk driver plots  
def riskDriverPlot_retail(portfolio, dict_1, dict_2, name1, name2, weight_mode, outputPath):
    # check validility of inputs
    if weight_mode not in ['count', 'balance']:
        raise ValueError("Invalid weight mode! Valid values are 'count' and 'balance'")
    pp = PdfPages(outputPath)
    for risk_driver in dict_1:
        # set x label
        def autolabel(data,rects):
            # Now make some labels
            labels = ['{:3.1f}%'.format(i * 100)  for i in data]
        
            for rect, label in zip(rects, labels):
                height = rect.get_height()
                ax.text(rect.get_x() + rect.get_width()/2, 1 * height, label, ha = 'center', va = 'bottom', fontsize=8)
                
        ##### Count weighted #####
        if weight_mode is 'count':
            total_account1, total_account2 = sum(dict_1[risk_driver]['account_number']), sum(dict_2[risk_driver]['account_number'])
            bucket_count1, bucket_count2 = pd.Series(dict_1[risk_driver]['account_number']), pd.Series(dict_2[risk_driver]['account_number'])
            bucket_percentage1, bucket_percentage2 = bucket_count1 / total_account1, bucket_count2/ total_account2  
            
            # setup for bar chart
            print('>>> Creating risk driver distribution plots for ' + risk_driver + ' (Count Weighted) ' )
            fig, ax = plt.subplots()
            label = LABEL_DICT[risk_driver]        
            
            ax.axis('on')
            plt.gca().yaxis.grid(color = 'gray', linestyle = 'dashed', zorder = 0)
            ax.patch.set_facecolor('white')
            index = np.arange(len(label)) + 0.15
            bar_width = 0.38
            opacity = 0.95
            rects1 = plt.bar(index, bucket_percentage1, bar_width,
                             alpha = opacity,
                             color = '#000080',
                             label = name1, zorder = 5)
            
            rects2 = plt.bar(index + bar_width, bucket_percentage2, bar_width,
                             alpha = opacity,
                             color = '#87CEFA',
                             label = name2, zorder = 5)
            
            plt.ylabel('Facility weighted % of Portfolio')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            plt.ylim(0, max(max(bucket_percentage1), max(bucket_percentage2)) * 1.1)
            plt.title('Distribution of ' + portfolio + ' portfolio across '+ RISK_DRIVER_DICT_retail[risk_driver] + ' bins', fontsize = 12)
            plt.xticks(index + 1 * bar_width, label, fontsize=9, rotation=10)
            legend = plt.legend()
            
            autolabel(bucket_percentage1, rects1)
            autolabel(bucket_percentage2, rects2) 
            # Shrink current axis's height by 10% on the bottom
            box = ax.get_position()
            ax.set_position([box.x0, box.y0 + box.height * 0.1,
                             box.width, box.height * 0.9])
            # Put a legend below current axis
            ax.legend(loc = 'upper center', bbox_to_anchor = (0.5, -0.09),
              fancybox = True, shadow = False, frameon = True, ncol = 5)
            legend.get_frame().set_edgecolor('grey')
            legend.get_frame().set_linewidth(0.5)
            pp.savefig()
            
        ##### balance weighted #####
        elif weight_mode is 'balance':
            total_balance1, total_balance2 = sum(dict_1[risk_driver]['balance']), sum(dict_2[risk_driver]['balance'])
            bucket_sum1, bucket_sum2 = pd.Series(dict_1[risk_driver]['balance']), pd.Series(dict_2[risk_driver]['balance'])
            bucket_sum_percentage1, bucket_sum_percentage2 = bucket_sum1 / total_balance1, bucket_sum2 / total_balance2
            # setup for bar chart    
            print('>>> Creating risk driver distribution plots for ' + risk_driver + ' (Balance Weighted) ' )
            fig, ax = plt.subplots()
            label = LABEL_DICT[risk_driver]       
            
            ax.axis('on')
            plt.gca().yaxis.grid(color = 'gray', linestyle = 'dashed', zorder = 0)
            ax.patch.set_facecolor('white')
            index = np.arange(len(label)) + 0.15
            bar_width = 0.38
            opacity = 0.95
            rects1 = plt.bar(index, bucket_sum_percentage1, bar_width,
                             alpha = opacity,
                             color = '#000080',
                             label = name1, zorder = 5)
            
            rects2 = plt.bar(index + bar_width, bucket_sum_percentage2, bar_width,
                             alpha = opacity,
                             color = '#6495ed',
                             label = name2, zorder = 5)
            
            plt.ylabel('Balanced weighted % of Portfolio')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            plt.ylim(0, max(max(bucket_sum_percentage1), max(bucket_sum_percentage2)) * 1.1)
            plt.title('Distribution of ' + portfolio + ' portfolio across '+ RISK_DRIVER_DICT_retail[risk_driver] + ' bins', fontsize = 12)
            plt.xticks(index + 1 * bar_width, label, fontsize=9, rotation=10)
            legend = plt.legend()
            
            autolabel(bucket_sum_percentage1, rects1)
            autolabel(bucket_sum_percentage2, rects2) 
            # Shrink current axis's height by 10% on the bottom
            box = ax.get_position()
            ax.set_position([box.x0, box.y0 + box.height * 0.1,
                             box.width, box.height * 0.9])
            # Put a legend below current axis
            ax.legend(loc = 'upper center', bbox_to_anchor = (0.5, -0.09),
              fancybox = True, shadow = False, frameon = True, ncol = 5)
            legend.get_frame().set_edgecolor('grey')
            legend.get_frame().set_linewidth(0.5)
            pp.savefig()
    
    pp.close()
        
  

        
   
# Distribution plots for risk drivers                 
def riskDriverDistribution(cniMasterDataInstance, weight_mode, outputPath):
    if weight_mode not in ['count', 'balance']:
        raise ValueError("Invalid weight mode! Valid values are 'count' and 'balance'")
    raw_data_merged = cniMasterDataInstance.mds_mra_additional_fields
    pp = PdfPages(outputPath)
    #plt.figure(figsize=(3, 2))
    for risk_driver in RISK_DRIVER_DICT:
        risk_driver_data = pd.concat([raw_data_merged[risk_driver], raw_data_merged['BOOKBALANCE']], axis = 1)
        
        if risk_driver is 'asofdate2stmtdate':
            def asofdate2stmtdate_mapping(x):
                if pd.isnull(x) or (x == -1):            
                    return 0
                elif x <= cniMasterDataInstance.statement_days_threshold:
                    return 1
                else:
                    return 2
            risk_driver_data['Group'] = risk_driver_data[risk_driver].apply(asofdate2stmtdate_mapping)    
        elif risk_driver is 'SRR':
            risk_driver_data['Group'] = risk_driver_data[risk_driver].apply(lambda x: 1 if x > 4 else 2)   
        elif risk_driver is 'FACILITYTYPE':
            risk_driver_data['Group'] = risk_driver_data[risk_driver].apply(lambda x: 1 if x == 'Revolving Line of Credit' else 2)  
        else:
            # assign group values by mapping
            risk_driver_map = Mapping(in_map = MAPPING_DICT[risk_driver], debug = False)
            risk_driver_data['Group'] = [
                        risk_driver_map.apply(item) for item in risk_driver_data[risk_driver]
                    ]  
                
        ##### count weighted #####
        if weight_mode is 'count':
            total_account = len(risk_driver_data)
            bucket_count = risk_driver_data.groupby(['Group']).size()
            bucket_percentage = bucket_count / total_account     
            # setup for bar chart
            print('>>> Creating risk driver distribution plots for ' + RISK_DRIVER_DICT[risk_driver] + ' (Count Weighted)')
            label = LABEL_DICT[risk_driver]
            y_pos = np.arange(len(label))
            fig, ax = plt.subplots()
            plt.bar(y_pos, bucket_percentage, align='center', width = 0.5, alpha=1)
            ax.set_xticks(y_pos)
            ax.set_xticklabels(label)
            ax.set_xlabel(RISK_DRIVER_DICT[risk_driver])
            ax.set_ylabel('Percentage')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            ax.set_title(RISK_DRIVER_DICT[risk_driver])
            pp.savefig()
        
        ##### balance weighted #####
        elif weight_mode is 'balance':
            total_balance = sum(risk_driver_data['BOOKBALANCE'])
            bucket_sum = risk_driver_data.groupby(by = ['Group']).sum()['BOOKBALANCE']
            bucket_sum_percentage = bucket_sum / total_balance
            # setup for bar chart    
            print('>>> Creating risk driver distribution plots for ' + RISK_DRIVER_DICT[risk_driver]  + ' (Balance Weighted)')
            label = LABEL_DICT[risk_driver]
            y_pos = np.arange(len(label))
            fig, ax = plt.subplots()
            plt.bar(y_pos, bucket_sum_percentage, align='center', width = 0.5, alpha=1)
            ax.set_xticks(y_pos)
            ax.set_xticklabels(label)
            ax.set_xlabel(RISK_DRIVER_DICT[risk_driver])
            ax.set_ylabel('Percentage')
            vals = ax.get_yticks()
            ax.set_yticklabels(['{:3.0f}%'.format(x * 100) for x in vals])
            ax.set_title(RISK_DRIVER_DICT[risk_driver])
            pp.savefig()

    pp.close()

    
# test with: getGraph('CRE',cre_2017,cre_2017_feb,name1='CCAR 2017',name2='SP 20',variable='OCCUPANCY')  
def getGraph(portfolio,variablename,dataset1,dataset2,name1,name2,variable,weight_switch):
#    plt.style.use('ggplot')
#    data1=dataset1.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})
#    data2=dataset2.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})      

    # Set Weight measure
    if weight_switch == 'Exposure': 
        data1=dataset1.groupby(variable)['Exposure_Weight'].sum()
        data2=dataset2.groupby(variable)['Exposure_Weight'].sum()  
    elif weight_switch == 'Balance': 
        data1=dataset1.groupby(variable)['Balance_Weight'].sum()
        data2=dataset2.groupby(variable)['Balance_Weight'].sum()
    elif weight_switch == 'Facility': 
        data1=dataset1.groupby(variable)['Facility_Weight'].sum()
        data2=dataset2.groupby(variable)['Facility_Weight'].sum()
    else:
        raise ValueError("Input weight switch should be <Exposure>,<Balance> or <facility>.")        
        
    # check whether two datasets have equal length               
    if len(data1)<len(data2):
        for item in [i for i in data2.index if i not in data1.index]:
            data1[item]=0
    elif len(data1)>len(data2):
        for item in [i for i in data1.index if i not in data2.index]:
            data2[item]=0  
                 
    if (portfolio=='GCB') & (variable=='RatingGroup'): 
        for item in [i for i in range(1,9) if i not in data1.index]:
            data1[item]=0   
        for item in [i for i in range(1,9) if i not in data2.index]:
            data2[item]=0        
    if True in (data1.index!=data2.index):
        raise ValueError('Index is different')             
    position={
               'LTV_Bins':
                    {
                      '> 100%':0, 
                      '80%-100%':1,
                      '65%-80%':2,
                      '50%-65%':3,
                      'Missing':4,
                      '<= 50%':5           
                     } ,    
               'OCCUPANCY_Bins':
                    {
                      '<= 65%':0,
                      '65%-85%':1,
                      '85%-95%':2,
                      'Missing':3,
                      '> 95%':4             
                     }, 
               'Months to Maturity_Bins':
                    {
                      '<= 0':0,
                      'Missing':1,
                      '0-12':2,
                      '12-24':3,
                      '24-36':4,
                      '>36':5 
                     },
               'industry':
                    {
                      'ConsumerAndIndustrial_USCAN':0,
                      'ConsumerAndIndustrial_RoW':1,
                      'OilAndGas_Global':2,
                      'Finance_RoW':3,
                      'Finance_USCAN':4
                     },
               'RatingGroup':
                    {
                      1:0,
                      2:1,
                      3:2,
                      4:3,
                      5:4,
                      6:5,
                      7:6,
                      8:7
                 
                     }                               
              }

    fig, ax = plt.subplots()
    plt.gca().yaxis.grid(color='gray', linestyle='dashed',zorder=0)
    ax.patch.set_facecolor('white')
    index = np.array([position[variable][item] for item in data1.index])
    bar_width = 0.38
    opacity = 0.95
    rects1 = plt.bar(index, data1.values, bar_width,
                     alpha=opacity,
                     color='#000080',
                     label=name1,zorder=5)
    
    rects2 = plt.bar(index+bar_width, data2.values, bar_width,
                     alpha=opacity,
                     color='#6495ed',
                     label=name2,zorder=5)
    
#    plt.xlabel(variable[0]+(variable[1:].lower()))
    plt.ylabel('{} weighted % of Portfolio'.format(weight_switch),fontsize=8)
    plt.ylim(0,max(data1.values)*1.2)
    plt.title('Distribution of %s portfolio across %s bins' % (portfolio,variablename),fontsize=10)
    if (portfolio=='GCB')&(variable=='industry'):
        data1.index=[
                  'Consumer&Industrial:USCAN',
                  'Consumer&Industrial:Rest of World',
                  'Oil&Gas:Global',
                  'Finance:RoW',
                  'Finance:USCAN']        
    plt.xticks(index + 0.5*bar_width, data1.index,fontsize=5,rotation=10)
    plt.legend()
         
    def autolabel(data,rects):
        # Now make some labels
        labels = ['{:3.1f}%'.format(i*100)  for i in data.values]
    
        for rect, label in zip(rects, labels):
            height = rect.get_height()
            ax.text(rect.get_x() + rect.get_width()/2, 1*height, label, ha='center', va='bottom',fontsize=rect.get_width()*12)
    autolabel(data1,rects1)
    autolabel(data2,rects2) 
    ax.set_yticklabels(['{:3.0f}%'.format(x*100) for x in ax.get_yticks()])
    # Shrink current axis's height by 10% on the bottom
    box = ax.get_position()
    ax.set_position([box.x0, box.y0 + box.height * 0.1,
                     box.width, box.height * 0.9])
    # Put a legend below current axis
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.09),
      fancybox=True, shadow=False, ncol=5,fontsize=8)

#    plt.tight_layout()
    plt.savefig("%s.png" % '%s_%s_%s' % (portfolio,variablename,name1),dpi=300)    
    plt.show()        
