# connection to RFO database
import cx_Oracle
import pandas as pd
import time
from CIFI.config import CONFIG
from CIFI.models.masterdataset.rfoplayground import queryRFO

# Method 1: use query RFO
query = '''
 SELECT *
 FROM MV_LOSS_COMMERCIAL
 WHERE 
 ASOFDATE = '31-MAY-2018' 
 AND UNIQUE_FACILITY_ID = 'CRE000721514000072151400007215140' 
        '''
dd = queryRFO(query=query,moodys_rfo_env="PROD_ENV")   
test_df = queryRFO(query=query,moodys_rfo_env="PROD_ENV")   
dd = queryRFO(query=query,moodys_rfo_env="UAT_ENV")       
dd.to_excel('c:/Users/n882049/Downloads/orig_oct.xlsx')

query = '''
SELECT ASOFDATE, CCLMID, To_Char(RATDATE,'MM/DD/YYYY HH12:MI:SS PM') AS RATDATE
          , RATINGID, CHNGNUM, CLITYPE, MODCALC, RISKSTAT, FINALRAT,QUANTRAT, DEBTTONW, EBITDAINT, QUICKRAT, PROFMARG,
          PERCCHANNETSAL, DAYSTOSTAT,  DEBTYIEL, LOANTOVA, OCPCYRT, STATECOD, MONTHTOM  FROM  MV_LOSS_COMMERCIAL WHERE PARTITION_KEY='S00000000540' ORDER BY CCLMID

        '''

query = '''
        SELECT DISTINCT ASOFDATE, COUNT(ASOFDATE)
        FROM MV_LOSS_COMMERCIAL
        GROUP BY ASOFDATE
        ORDER BY ASOFDATE DESC
        '''
query = '''
        SELECT DISTINCT ASOFDATE, PARTITION_KEY, RUN_SIGNATURE, COUNT(ASOFDATE)
        FROM MV_LOSS_COMMERCIAL
        GROUP BY ASOFDATE, PARTITION_KEY, RUN_SIGNATURE
        ORDER BY ASOFDATE DESC
        '''   
query = '''
        SELECT DISTINCT ASOFDATE, PARTITION_KEY, RUN_SIGNATURE, COUNT(ASOFDATE)
        FROM MV_LOSS_COMMERCIAL_ORIG
        GROUP BY ASOFDATE, PARTITION_KEY, RUN_SIGNATURE
        ORDER BY ASOFDATE DESC
        '''      
query = '''
        SELECT DISTINCT AS_OF_DATE, PARTITION_KEY, RUN_SIGNATURE, COUNT(ASOFDATE)
        FROM MV_CCMIS_ALL_DATA
        GROUP BY AS_OF_DATE, PARTITION_KEY, RUN_SIGNATURE
        ORDER BY AS_OF_DATE DESC
        '''      
query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '28-FEB-2018' 
        and PD_GROUP_2017 = 'GCB'
        and rownum <= 5
        '''
query = '''
        select distinct PD_GROUP_2017, NPLATTRITION, NETCHARGEOFFCURVE
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '30-SEP-2018' 
        '''
query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '31-DEC-2017' 
        and PARTITION_KEY = 'S00000000540'
        and PD_GROUP_2017 in ('MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL', 'CRE_MULTIFAMILY', 'CRE_OTHER')
        '''
query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '31-OCT-2018' 
        and PD_GROUP_2017 in ('SBB', 'BUSINESS_BANKING')
        '''
query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '30-NOV-2018' 
        and Channel = 'Streamlined'
        '''

query = '''
        select unique_facility_id, pd_group_2017, channel, utilizationbookbalance, calculated_line
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '31-AUG-2018' 
        and PARTITION_KEY = 'S00000000540'
        and Channel in ('Streamlined')
        '''
        
query = '''
        select channel, count(unique_facility_id)
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '31-AUG-2018' 
        group by channel
        '''

query = '''
        select distinct unique_facility_id, costcenter, pd_group_2017, utilizationbookbalance, calculated_line
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '30-SEP-2018' 
        and costcenter = '8398'
        '''
query = '''
        select *
        from MV_LOSS_COMMERCIAL_ORIG
        where ASOFDATE = '30-JUN-2018' 
        and costcenter = '8398'
        '''
query = '''
        select distinct pd_group_2018, count(uniqueid)
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '31-DEC-2018' 
        group by pd_group_2018
        '''
query = '''
        select  *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '30-JUN-2018' 
        and unique_facility_id = 'INFO LEASE111618111618002-0005097-013'
        '''
        
group = dd.groupby('PD_GROUP_2017')[['UTILIZATIONBOOKBALANCE','CALCULATED_LINE']].sum()

query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '31-MAY-2018' 
        and rownum <= 5
        '''
query = '''
        select distinct PD_GROUP_2017, PD, LGD, EAD
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '31-DEC-2017' 
        and PD_GROUP_2017 in ('CEVF_RETAIL','CRE_CONSTRUCTION') 
        '''    
query = '''
        SELECT *
        FROM MV_LOSS_COMMERCIAL_ORIG
        WHERE PARTITION_KEY = 'S00000000560'             
        '''
query = '''
        select unique_facility_id, pd_group_2017, channel, utilizationbookbalance, calculated_line
        from MV_LOSS_COMMERCIAL_ORIG
        where ASOFDATE = '31-AUG-2018' 
        and PARTITION_KEY = 'S00000000540'
        '''
query = '''
        SELECT DISTINCT ASOFDATE, EBITDA, COUNT(EBITDA)
        FROM MV_LOSS_COMMERCIAL
        GROUP BY ASOFDATE, EBITDA
        ORDER BY ASOFDATE DESC
        '''
# Contributor file count check group by file id 
query = '''
        SELECT PARTITION_KEY, RUN_SIGNATURE, CONTRIBUTOR_FILE_ID, SCENARIO, FILE_VERSION, COUNT(CONTRIBUTOR_FILE_ID) as COUNT
        FROM STG_CONTRIBUTOR_DATA
        WHERE CONTRIBUTOR_FILE_ID in (101,102,103,104) 
        AND RUN_SIGNATURE='022818_1228101'
        AND PARTITION_KEY='S00000000504'
        GROUP BY
                      PARTITION_KEY,
                      RUN_SIGNATURE,
                      FILE_VERSION,
                      CONTRIBUTOR_FILE_ID,
                      SCENARIO
        '''

        
# check segment balance
query = '''
        select PD_GROUP_2018,
        SUM(UTILIZATIONBOOKBALANCE),
        COUNT(UTILIZATIONBOOKBALANCE)
        from maccar.MV_LOSS_COMMERCIAL
        WHERE ASOFDATE = '31-DEC-2018' 
        and sourceid != 'OFFLINE'
        GROUP BY PD_GROUP_2018
        ORDER BY PD_GROUP_2018
        '''
        
# Macro variable table: updated to CCAR2018 
query = '''
select distinct Cycle, SCENARIO, ASOFBOOKDATE
from MV_MEV_NORMALIZED
order by ASOFBOOKDATE DESC
        '''
query = '''
select distinct Cycle, SCENARIO, ASOFBOOKDATE
from MV_MEV_NORMALIZED
        '''
query = '''
        SELECT distinct PARTITION_KEY, RUN_SIGNATURE
        FROM MV_FE_CCMIS_REVOLVE
        order by PARTITION_KEY
        '''
query = '''
select *
from MV_MEV_NORMALIZED
where rownum <= 5
        '''
query = '''
select *
from MV_MEV_NORMALIZED
where cycle = 'IFRS9_2018_M12'
and scenario in ('IFRS9_NEGATIVE')
and FREQUENCY ='QUARTERLY'
and indicator = 'FLBR_MA'
        '''
dd2 = queryRFO(query=query,moodys_rfo_env="PROD_ENV")     
        
        
# check specific facility
query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '30-JUN-2018' 
        and UNIQUE_FACILITY_ID = 'AFS0052400053005240005300000003800000000703'
        '''

query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '30-JUN-2018' 
        and UNIQUE_FACILITY_ID = 'AFS0052400053005240005300000003800000000703'
        '''        

query = '''
        select *
        from MV_LOSS_COMMERCIAL_ORIG
        where RUN_SIGNATURE = '093018_1228550'
        '''
        
query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where ASOFDATE = '30-JUN-2018' 
        and UNIQUE_FACILITY_ID in (
            'AFS0052400053005240005300000003800000000703',
            'AFS0052400053005240005300000003800000000737',
            'AFS0052400053005240005300000004300000000448',
            'AFS0052400053005240005300000006530000000695',
            'AFS0052400053005240005300000003490000000513',
            'AFS0052400053005240005300000003070000000505',
            'AFS0052749970005274997000000000180000000026',
            'AFS0052400053005240005300000003800000000422',
            'AFS0052745408005274540800000000180000000042',
            'AFS0052400053005240005300000005960000000638',
            'AFS0052400053005240005300000003800000000570',
            'AFS0052400053005240005300000003490000000364',
            'AFS0052745408005274540800000000180000000067',
            'AFS0052749970005274997000000000420000000067',
            'AFS0052756843005275684300000000180000000026',
            'AFS0052400053005240005300000003800000000729',
            'AFS0052400053005240005300000003490000000547',
            'AFS0052400053005240005300000003800000000745',
            'AFS0052400053005240005300000003490000000372',
            'AFS0052400053005240005300000003800000000778',
            'AFS0052400053005240005300000006530000000679',
            'AFS0052760068005276006800000000180000000026',
            'AFS0052400053005240005300000005960000000646',
            'AFS0052400053005240005300000004300000000455',
            'AFS0052400053005240005300000003800000000588',
            'AFS0052400053005240005300000003070000000331',
            'AFS0052745408005274540800000000180000000075',
            'AFS0052400053005240005300000003070000000554',
            'AFS0052400053005240005300000003800000000414',
            'AFS0052400053005240005300000003070000000323',
            'AFS0052749970005274997000000000420000000059',
            'AFS0052400053005240005300000003800000000497',
            'AFS0052400053005240005300000005960000000620'
            )
        '''

                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
        
# test orig table
query = '''
        select *
        from MV_LOSS_COMMERCIAL_ORIG
        where ASOFDATE = '31-DEC-2017' 
        '''
        
query = '''
        select ASOFDATE, REPORTING_DATE, PARTITION_KEY, RUN_SIGNATURE, count(*) as count
        from MV_LOSS_COMMERCIAL_ORIG
        group by PARTITION_KEY, RUN_SIGNATURE, REPORTING_DATE, ASOFDATE
        order by ASOFDATE desc, REPORTING_DATE desc
        '''
        
query = '''
       SELECT DISTINCT
            MAX(PD_GROUP_2017) AS PD_GROUP_2017,
            PD,
            LGD,
            EAD,
            ALLLCOVERAGE,
            CONTINGENTRESERVE,
            EADBALANCE,
            EADLETTEROFCREDIT,
            EADAVAILABLELINE,
            EADTOTALLINE
        FROM CCAR_A_PRESENTATION.MV_LOSS_COMMERCIAL_ORIG
        WHERE
            UPPER(SOURCEID) NOT IN ('OFFLINE')
            AND
            (
                FAS114_STATUS = 'A - NOT REQUIRED'
                AND
                LOCAL_NPL_FLAG = 'N'
            )
            AND
            ASOFDATE = '31-DEC-2017' 
        GROUP BY
            PD,
            LGD,
            EAD,
            ALLLCOVERAGE,
            CONTINGENTRESERVE,
            EADBALANCE,
            EADLETTEROFCREDIT,
            EADAVAILABLELINE,
            EADTOTALLINE
        HAVING
            (
            SUM(CALCULATED_LINE) > 0
            OR 
            SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
            )
        '''

query = '''
       SELECT DISTINCT
            PD_GROUP_2017,
            PD,
            LGD,
            EAD,
            ALLLCOVERAGE,
            CONTINGENTRESERVE,
            EADBALANCE,
            EADLETTEROFCREDIT,
            EADAVAILABLELINE,
            EADTOTALLINE
        FROM MV_LOSS_COMMERCIAL
        WHERE PD_GROUP_2017 in ('CEVF_RETAIL', 'CRE_CONSTRUCTION')
        AND ASOFDATE = '30-JUN-2018' 
        '''

# get MWH balance   
query = '''
        SELECT ASOFDATE, unique_facility_id, sum(UTILIZATIONBOOKBALANCE) as bookbalance, 
        max(MAXIMUMMATURITYDATE) as MAXIMUMMATURITYDATE,facilitytype,MONTHS_BETWEEN (TO_DATE(max(MAXIMUMMATURITYDATE)), TO_DATE(ASOFDATE)) as MonthToMaturity
        FROM MV_LOSS_COMMERCIAL
        where PD_GROUP_2017 like 'MWH'
        and ASOFDATE = '28-FEB-2018' 
        and (FAS114_STATUS = 'A - NOT REQUIRED' AND LOCAL_NPL_FLAG = 'N')
        and SourceId != 'OFFLINE'
        having sum(UTILIZATIONBOOKBALANCE) > 0
        group by unique_facility_id, ASOFDATE, facilitytype
        order by bookbalance desc
        ''' 
# check MV_FE_CCMIS_TERM_LOAN
query = '''
        (select UNIQUEIDENTIFIER, TOTALLINE
        from MV_FE_CCMIS_REVOLVE
        where REPORTING_DATE = '31-DEC-2017')
        UNION ALL
        (select UNIQUEIDENTIFIER, UTILIZATIONBOOKBALANCE as TOTALLINE
        from MV_FE_CCMIS_TERM_LOAN 
        where REPORTING_DATE = '31-DEC-2017')
        '''
        
query = '''
        select UNIQUEIDENTIFIER, BALANCE, TOTALLINE, LINE_TERM
        from MV_FE_CCMIS_REVOLVE
        where REPORTING_DATE = '31-DEC-2017'
        '''
        
query = '''
        select UNIQUEIDENTIFIER, BALANCE, BALANCE as TOTALLINE, LINE_TERM
        from MV_FE_CCMIS_TERM_LOAN 
        where REPORTING_DATE = '31-DEC-2017'
        '''
query = '''
        select distinct LINE_TERM
        from MV_LOSS_COMMERCIAL 
        where REPORTING_DATE = '31-DEC-2017'
        '''
query = '''
        select *
        from MV_MEV_NORMALIZED
        where Cycle in ('CCAR2018')
        and Indicator = 'FRTB3M_US'
        and Frequency = 'QUARTERLY'
        '''
query = '''
        select *
        from MV_MEV_NORMALIZED
        where Cycle = 'CCAR2019'
        and Indicator = 'FCPWTI_US'
        and Frequency = 'MONTHLY'
        '''
        
# check origination table
query =  '''
                SELECT
                    SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                    SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                    SUM(CALCULATED_LINE) AS EXPOSURE,
                    MAX(SEGMENTNAME) AS SEGMENTNAME,
                    MAX(PD_GROUP_2017) AS PD_GROUP,
                    MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                    FACILITYTYPE,
                    SEGMENTATIONFIELD2,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EADAVAILABLELINE,
                    EADBALANCE,
                    EADLETTEROFCREDIT,
                    EADTOTALLINE,
                    EAD,
                    LGD,
                    PD,
                    LINE_TERM
                FROM
                ( SELECT master.*, fe.*
                  FROM
                 (SELECT
                    UPPER(SOURCEID) AS SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    UNIQUEID,
                    UTILIZATIONBOOKBALANCE,
                    UTILIZATIONLCAMOUNT,
                    CALCULATED_LINE,
                    SEGMENTNAME,
                    PD_GROUP_2017,
                    MAXIMUMMATURITYDATE,
                    FACILITYTYPE,
                    SEGMENTATIONFIELD2,
                    TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                    TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                    TO_CHAR(EADAVAILABLELINE) AS EADAVAILABLELINE,
                    TO_CHAR(EADBALANCE) AS EADBALANCE,
                    TO_CHAR(EADLETTEROFCREDIT) AS EADLETTEROFCREDIT,
                    TO_CHAR(EADTOTALLINE) AS EADTOTALLINE,
                    TO_CHAR(EAD) AS EAD,
                    TO_CHAR(LGD) AS LGD,
                    TO_CHAR(PD) AS PD
                 FROM MV_LOSS_COMMERCIAL
                 WHERE
                     ASOFDATE = '31-DEC-2017'
                     AND
                     UPPER(PD_GROUP_2017) NOT IN ('SMALL BUSINESS BANKING', 'SBB')
                     AND PD_GROUP_2017 = 'GCB'
                     AND
                     (
                         (
                             FAS114_STATUS = 'A - NOT REQUIRED'
                             AND
                             LOCAL_NPL_FLAG = 'N'
                         )
                     )
                     AND
                     UPPER(SOURCEID) NOT IN ('OFFLINE')
                ) master
                LEFT JOIN
                (
                 SELECT *
                 FROM
                 (
                  (SELECT UNIQUEIDENTIFIER, LINE_TERM
                  FROM MV_FE_CCMIS_REVOLVE
                  WHERE REPORTING_DATE = '31-DEC-2017')
                  UNION ALL
                  (SELECT 
                  UNIQUEIDENTIFIER, LINE_TERM
                  FROM MV_FE_CCMIS_TERM_LOAN
                  WHERE REPORTING_DATE = '31-DEC-2017')
                 ) 
                ) fe
                 ON master.UNIQUEID = fe.UNIQUEIDENTIFIER
                 )
                GROUP BY
                    SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    FACILITYTYPE,
                    SEGMENTATIONFIELD2,
                    ALLLCOVERAGE,
                    CONTINGENTRESERVE,
                    EADAVAILABLELINE,
                    EADBALANCE,
                    EADLETTEROFCREDIT,
                    EADTOTALLINE,
                    EAD,
                    LGD,
                    PD,
                    LINE_TERM
                HAVING
                    (
                    SUM(CALCULATED_LINE) > 0
                    OR 
                    SUM(UTILIZATIONLCAMOUNT + UTILIZATIONBOOKBALANCE) > 0
                    )

        '''
query = '''
            SELECT
                    SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                    SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                    SUM(CALCULATED_LINE) AS EXPOSURE,
                    MAX(SEGMENTNAME) AS SEGMENTNAME,
                    MAX(PD_GROUP_2017) AS PD_GROUP,
                    MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                    ALLLCOVERAGE,
                    LINE_TERM
            FROM
            (
            SELECT master.*, fe.*
                  FROM
                 (SELECT
                    UPPER(SOURCEID) AS SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    UNIQUEID,
                    UTILIZATIONBOOKBALANCE,
                    UTILIZATIONLCAMOUNT,
                    CALCULATED_LINE,
                    SEGMENTNAME,
                    PD_GROUP_2017,
                    MAXIMUMMATURITYDATE,
                    FACILITYTYPE,
                    SEGMENTATIONFIELD2,
                    TO_CHAR(ALLLCOVERAGE) AS ALLLCOVERAGE,
                    TO_CHAR(CONTINGENTRESERVE) AS CONTINGENTRESERVE,
                    TO_CHAR(EADAVAILABLELINE) AS EADAVAILABLELINE,
                    TO_CHAR(EADBALANCE) AS EADBALANCE,
                    TO_CHAR(EADLETTEROFCREDIT) AS EADLETTEROFCREDIT,
                    TO_CHAR(EADTOTALLINE) AS EADTOTALLINE,
                    TO_CHAR(EAD) AS EAD,
                    TO_CHAR(LGD) AS LGD,
                    TO_CHAR(PD) AS PD
                 FROM MV_LOSS_COMMERCIAL
                 WHERE
                     ASOFDATE = '31-DEC-2017'
                     AND
                     UPPER(PD_GROUP_2017) NOT IN ('SMALL BUSINESS BANKING', 'SBB')
                     AND PD_GROUP_2017 = 'GCB'
                     AND
                     (
                         (
                             FAS114_STATUS = 'A - NOT REQUIRED'
                             AND
                             LOCAL_NPL_FLAG = 'N'
                         )
                     )
                     AND
                     UPPER(SOURCEID) NOT IN ('OFFLINE')
                ) master
                LEFT JOIN
                (
                 SELECT *
                 FROM
                 (
                  (SELECT UNIQUEIDENTIFIER, LINE_TERM
                  FROM MV_FE_CCMIS_REVOLVE
                  WHERE REPORTING_DATE = '31-DEC-2017')
                  UNION ALL
                  (SELECT UNIQUEIDENTIFIER, LINE_TERM
                  FROM MV_FE_CCMIS_TERM_LOAN
                  WHERE REPORTING_DATE = '31-DEC-2017')
                 ) 
                ) fe
                 ON master.UNIQUEID = fe.UNIQUEIDENTIFIER
                 )
                 GROUP BY
                    SOURCEID,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    UNIQUE_FACILITY_ID,
                    ALLLCOVERAGE,
                    LINE_TERM
                 '''

query = '''
        select *
        from MV_LOSS_COMMERCIAL
        where
        ASOFDATE = '31-DEC-2017' 
        AND
        UNIQUE_FACILITY_ID in (
'AFS0050278923005027892300502789230000000026',
'AFS0050543516005175784200517578420000000042',
'AFS0050857627005178307900517830790000000042',
'AFS0051121619005112161900511216190000000026',
'AFS0051167315005116731500511673150000000034',
'AFS0051167315005116731500511673150000000067',
'AFS0051333115005209804800520980480000000034',
'AFS0051346349005134634900513463490000000018',
'AFS0051631237005202098400520209840000000034',
'AFS0051647332005214865200521486520000000034',
'AFS0051787401005229396100522939610000000026',
'AFS0051836794005183679400518367940000000042',
'AFS0051843675005184367500518436750000000042',
'AFS0051984388005198438800519843880000000133',
'AFS0052192726005219276700521927670000000026',
'AFS0052196412005219641200521964120000000042',
'AFS0052225856005222585600522258560000000059',
'AFS0052272700005227270000522727000000000026',
'AFS0052374795005237479500523747950000000026',
'AFS0052402778005239833100523983310000000026',
'AFS0052413320005241332000524133200000000059',
'AFS0052468076005246807600524680760000000026',
'AFS0052508939005250893900525089390000000018',
'AFS0052583809005258380900525838090000000026',
'AFS0052592487005259248700525924870000000018',
'AFS0052596793005259679300525967930000000042',
'CRE010700318901070031890107003189'
)
        '''



# Method 2: config manually

# connection config
environment=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["CURRENT"]
#environment='UAT_ENV'
connection_strings = CONFIG['MOODYS_RFO_ORACLE_CONNECTION'][environment]

# oracle connection setup
cx_Oracle_DSN = cx_Oracle.makedsn(
	host=connection_strings["HOST_IP"],
	port=connection_strings["ORACLE_PORT"],
	sid=connection_strings["SID"]
)
connection = cx_Oracle.connect(
	user=connection_strings["USER_NAME"],
	password=connection_strings["PASSWORD"],
	dsn=cx_Oracle_DSN
)

# cursor
cursor = connection.cursor()

# write query here
query = """
        SELECT *
        FROM MACCAR.STG_RFO_Commercial_Table
        WHERE RUN_SIGNATURE = 'Apr30_1310'
        and UNIQUE_FACILITY_ID = 'AFS0050163166005016316600501631660000000018'
        """

query = """
        SELECT *
        FROM MACCAR.MV_LOSS_COMMERCIAL
        WHERE ROWNUM <= 10
        """

query = """
        SELECT *
        FROM MACCAR.STG_RFO_Commercial_Table
        WHERE PD_GROUP_2017 IN ('MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL', 'CRE_MULTIFAMILY', 'CRE_OTHER')
        AND ROWNUM <= 10
        """
        
query = """
        SELECT distinct IFRS9_STAGING
        FROM MACCAR.STG_RFO_Commercial_Table
        """
        
query = """
        SELECT UNIQUE_FACILITY_ID, LINE_TERM
        FROM MACCAR.MV_CCMIS_ALL_DATA
        WHERE AS_OF_DATE = '31-DEC-2017'
        AND ROWNUM <=10
        GROUP BY UNIQUE_FACILITY_ID, LINE_TERM
        """
        
query = """
        SELECT *
        FROM MACCAR.MV_CCMIS_ALL_DATA
        WHERE AS_OF_DATE = '31-OCT-2018'
        AND ROWNUM <=10
        """

anchor_table_name=CONFIG['MOODYS_RFO_ORACLE_CONNECTION']["TABLE_NAMES"]["SB_COMM_ANCHOR_DATA"]
date2OracleSTR = lambda x: x.strftime("%d-%b-%Y").upper()
import datetime
asofdate = datetime.datetime(2017, 9, 30)
def to_sql_array(a, wrapper=('(', ')'), quote=False):
    s = wrapper[0]
    for h in a:
        if quote:
            s += "'"+str(h) + "',"
        else:
            s += str(h) + ','
    s = s.strip(',')
    s += wrapper[1]
    return s
pd_groups = ['MIDDLE_MARKET', 'BUSINESS_BANKING', 'ABL']
pd_groups = ['CRE_MULTIFAMILY', 'CRE_OTHER']

query = """
                SELECT
                ASOFDATE,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                MAX(MASTER_CUSTOMER_ID) AS MASTER_CUSTOMER_ID,  
                SUM(UTILIZATIONLCAMOUNT) AS LCAMOUNT,
                LOCAL_NPL_FLAG,
                MAX(PRI_COLLATVALUE) AS PRI_COLLATVALUE,
                ROUND(MAX(SRR), 1) AS SRR,
                UPPER(SOURCEID) AS SOURCEID,
                FAS114_STATUS,
                SUM(UTILIZATIONBOOKBALANCE) AS BOOKBALANCE,
                SUM(CALCULATED_LINE) AS EXPOSURE,
                MIN(UTILIZATIONOPENDATE) AS OPENDATE,
                MAX(MAXIMUMMATURITYDATE) AS MAXIMUMMATURITYDATE,
                MAX(CURRENTOCCUPANCY) AS CURRENTOCCUPANCY,
                MAX(PRI_COLLATNOI) AS PRI_COLLATNOI,
                UNIQUE_FACILITY_ID,
                TDR,
                MAX(PD_GROUP) AS PD_GROUP,
                MAX(COSTCENTER) AS COSTCENTER,             
                FACILITYTYPE,
                RETYPE,
                COLLATERALCODE,
                COLLATERAL_DESCRIPTION,
                CONSOLIDATED_COLLATERAL_CODE,
                PRI_COLLATSTATE,
                UNSECURED_INDICATOR,
                IS_ORIG,
                StatementMonths,
                AuditMethod,
                StatementID,
                EBITDA,
                InterestExpense,
                CashAndEquivs,
                NetTradeAcctsRec,
                TotalCurLiabs,
                ProfitBeforeTax,
                NetSales,
                DebtToTNW
            FROM (
                SELECT
                    ASOFDATE,
                    ONEOBLIGORNUMBER,
                    CUSTOMERNUMBER,
                    FACILITYNUMBER,
                    MASTER_CUSTOMER_ID,
                    UTILIZATIONLCAMOUNT,
                    LOCAL_NPL_FLAG,
                    PRI_COLLATVALUE,
                    SRR,
                    SOURCEID,
                    FAS114_STATUS,
                    UTILIZATIONBOOKBALANCE,
                    CALCULATED_LINE,
                    UTILIZATIONOPENDATE,
                    MAXIMUMMATURITYDATE,
                    CURRENTOCCUPANCY,
                    CASE WHEN PRI_COLLATNOI = 0 THEN NULL ELSE PRI_COLLATNOI END AS PRI_COLLATNOI,
                    UNIQUE_FACILITY_ID,
                    TDR,
                    TO_CHAR(PD_GROUP_2017) AS PD_GROUP,
                    FACILITYTYPE,
                    RETYPE,
                    COLLATERALCODE,
                    COLLATERAL_DESCRIPTION,
                    CONSOLIDATED_COLLATERAL_CODE,
                    PRI_COLLATSTATE,
                    UNSECURED_INDICATOR,
                    COSTCENTER,
                    'N' AS IS_ORIG,
                    TO_NUMBER(STATEMENTMONTHS) AS StatementMonths,
                    AUDITMETHOD AS AuditMethod,
                    TO_NUMBER(STATEMENTID) AS StatementID,
                    TO_NUMBER(REPLACE(EBITDA, ',','')) AS EBITDA,
                    TO_NUMBER(REPLACE(INTERESTEXPENSE, ',','')) AS InterestExpense,
                    TO_NUMBER(REPLACE(CASHANDEQUIVS, ',','')) AS CashAndEquivs,
                    TO_NUMBER(REPLACE(NETTRADEACCTSREC, ',','')) AS NetTradeAcctsRec,
                    TO_NUMBER(REPLACE(TOTALCURLIABS, ',','')) AS TotalCurLiabs,
                    TO_NUMBER(REPLACE(PROFITBEFORETAX, ',','')) AS ProfitBeforeTax,
                    TO_NUMBER(REPLACE(NETSALES, ',','')) AS NetSales,
                    TO_NUMBER(REPLACE(DEBTTOTNW, ',','')) AS DebtToTNW
                FROM {}
                WHERE
                    ASOFDATE = '{}'                
            )
            WHERE
                UPPER(SOURCEID) NOT IN ('OFFLINE')
                {}
            GROUP BY
                ASOFDATE,
                ONEOBLIGORNUMBER,
                CUSTOMERNUMBER,
                FACILITYNUMBER,
                LOCAL_NPL_FLAG,
                SOURCEID,
                FAS114_STATUS,
                UNIQUE_FACILITY_ID,
                TDR,
                FACILITYTYPE,
                RETYPE,
                COLLATERALCODE,
                COLLATERAL_DESCRIPTION,
                CONSOLIDATED_COLLATERAL_CODE,
                PRI_COLLATSTATE,
                UNSECURED_INDICATOR,
                IS_ORIG,
                EBITDA,
                InterestExpense,
                CashAndEquivs,
                NetTradeAcctsRec,
                TotalCurLiabs,
                ProfitBeforeTax,
                NetSales,
                DebtToTNW,
                StatementMonths,
                AuditMethod,
                StatementID
            HAVING
                SUM(CALCULATED_LINE) > 0
        """.format(
            anchor_table_name,
            date2OracleSTR(asofdate),
            " AND PD_GROUP IN "+to_sql_array(a=pd_groups, quote=True) if len(pd_groups)>0 else ""
        )
    
t_0 = time.time()
# execute the query
cursor.execute(query)

# query data
query_data = pd.DataFrame(
	cursor.fetchall(),
	columns=[item[0] for item in cursor.description]
)
t_1 = time.time()
runtime = round((t_1 - t_0), 4)
print('Query completed in ' + str(runtime) + ' s.')

# to see the datatype of all columns
cursor.description

joe_apr = pd.read_excel("c:/Users/n882049/Downloads/joe_apr.xlsx")
rfo_may = dd

test_joe_apr = joe_apr[['UNIQUEID','pd_group_tool','ratdate','MONTHTOM','CHNGNUM','CCLMID','RATINGID','OCPCYRT','LOANTOVA','DEBTYIEL',
                        'FINALRAT','quantrat','DEBTTONW','EBITDAINT','QUICKRAT','PROFMARG','PERCCHANNETSAL','DAYSTOSTAT',
                        'STATECOD','RISKSTAT','MODCALC','CLITYPE']]
test_rfo_may = rfo_may[['UNIQUEID','PD_GROUP_TOOL','RATDATE','MONTHTOM','CHNGNUM','CCLMID','RATINGID','OCPCYRT','LOANTOVA','DEBTYIEL',
                        'FINALRAT','QUANTRAT','DEBTTONW','EBITDAINT','QUICKRAT','PROFMARG','PERCCHANNETSAL','DAYSTOSTAT',
                        'STATECOD','RISKSTAT','MODCALC','CLITYPE']]



merge = test_rfo_may.merge(
    test_joe_apr,
    left_on='UNIQUEID',
    right_on='UNIQUEID',
    how='left'
)

