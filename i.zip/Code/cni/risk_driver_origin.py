# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 10:06:00 2017

@author: n838126
"""

'''
SAMPLE USE

AS_OF_DATE1=datetime.datetime(2017,3,31)
AS_OF_DATE2=datetime.datetime(2017,6,30)
NAME1='CCAR 2017'
NAME2='MidCycle 2017'
PATH = 'I:\\CRMPO\\CCAR\\2Q17\\10 - Process & Analysis\\Risk Driver\\test\\'

GCB_instance=SnapShotCheck(
        portfolio='GCB',
        asofdate1=AS_OF_DATE1,
        asofdate2=AS_OF_DATE2,
        name1=NAME1,
        name2=NAME2,
        path=PATH,
        industrytag_file1='I:\\CRMPO\\CCAR\\1Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Mar.xlsx',
        industrytag_file2='I:\\CRMPO\\CCAR\\2Q17\\4 - Models\\Wholesale\\GCB\\GCB_MV_LOSS_COMMERCIAL_Jun.xlsx',
        orig=False
                )

GCB_instance.executeGraph()

CRE_instance=SnapShotCheck(
        portfolio='CRE',
        asofdate1=AS_OF_DATE1,
        asofdate2=AS_OF_DATE2,
        name1=NAME1,
        name2=NAME2,
        path=path
        orig=False
                )
CRE_instance.executeGraph()

'''






import os
import sys
#wd = 'I:\\CRMPO\\DEPT\\Hachuel\\CCAR\\CIFI'
wd = '/'.join(os.getcwd().split('\\')[:os.getcwd().split('\\').index('CIFI')])
if wd not in sys.path:
    sys.path.append(wd)   
from CIFI.models.masterdataset.masterdataset import CCMISMasterDataset
from CIFI.controllers.models.cniriskrating import CNIModel
from CIFI.controllers.models.riskratingmodel import Mapping
import matplotlib.pyplot as plt
from CIFI.config import CONFIG
import datetime
import dateutil.relativedelta as relativedelta
import pandas as pd
import numpy as np


class SnapShotCheck():
    # Member properties


    # Member methods
    def __init__(
        self,
        portfolio,
        asofdate1,
        asofdate2,
        name1,
        name2,
        path,
        orig=False,
        **kwargs
    ):
        self.portfolio=portfolio
        self.asofdate1=asofdate1
        self.asofdate2=asofdate2
        self.name1=name1
        self.name2=name2
        self.path=path
        self.orig=orig
        
        self.industrytag_file1=kwargs.get('industrytag_file1')
        self.industrytag_file2=kwargs.get('industrytag_file2')
        
    def getRawData(self,portfolio,as_of_date):
        print('>>> Fetch {} portfolio : {}'.format(portfolio,as_of_date))
        # pull raw data from RFO
        # define data columns
        columns = {'CRE':[     
                         'ASOFDATE',                         
                         'SOURCEID',
                         'ONEOBLIGORNUMBER',
                         'CUSTOMERNUMBER',
                         'FACILITYNUMBER',
                         'FAS114_STATUS',
                         'LOCAL_NPL_FLAG',
                         'TDR',
                         'COLLATERALCODE',
                         'UNIQUE_FACILITY_ID',
                         'CURRENTOCCUPANCY',
                         'MAXIMUMMATURITYDATE',
                         'PD_GROUP',
                         'PRI_COLLATNOI',
                         'PRI_COLLATVALUE',
                         'PRI_COLLATSTATE',
                         'PROPERTY_TYPE_MAP',
                         'SRR',
                         'BOOKBALANCE',
                         'OPENDATE',
                         'IS_ORIG'],
                             
                'GCB':[    
                         'ASOFDATE',                         
                         'COLLATERALCODE',                        
                         'SOURCEID',
                         'ONEOBLIGORNUMBER',
                         'CUSTOMERNUMBER',
                         'FACILITYNUMBER',
                         'LCAMOUNT',
                         'EXPOSURE',
                         'UNSECURED_INDICATOR',
                         'UNIQUE_FACILITY_ID',
                         'PD_GROUP',
                         'SRR',
                         'BOOKBALANCE',
                         'IS_ORIG'
                        ]} 
                
        if portfolio == 'CRE':
            pd_groups=['CRE_MULTIFAMILY', 'CRE_OTHER']
        elif portfolio == 'GCB':
            pd_groups=['GCB']
            
        # Fetch data    
        dataset= CCMISMasterDataset(
                            	asofdate=as_of_date,
                            	pd_groups=pd_groups,
                            	debug=False
                          ).data[columns[portfolio]]    
        
        # Filter for existing book loans
        if self.orig==False:
            dataset=dataset[~dataset['IS_ORIG'].str.contains('Y')]            
        return(dataset)
    
    def processData(self,industrytag_file,portfolio,as_of_date): 
        
        dataset=self.getRawData(portfolio,as_of_date)       
        # format data
        def processCREData(dataset):    
            # replace special character
            dataset=dataset.replace({'uav': np.nan,None:np.nan,'NA':np.nan,'na':np.nan,'Unknown':np.nan,' ':np.nan}, regex=True)   
            # check numeric data type
            
            for field in ['COLLATERALCODE','CURRENTOCCUPANCY','PRI_COLLATNOI','PRI_COLLATVALUE','PROPERTY_TYPE_MAP','SRR','BOOKBALANCE']:
                dataset[field]=dataset[field].apply(pd.to_numeric)
            # NOI 0 is missing
            dataset['PRI_COLLATNOI']=dataset['PRI_COLLATNOI'].replace({0: np.nan}, regex=True)  
            return(dataset) 
        # tag data with rating and industry
        def processGCBData(dataset,industrytag_file):          
            # get rating and segment for each facility        
            # read in excel file to get industry segments         
            if os.path.exists(industrytag_file) & os.path.isfile(industrytag_file):
                industrytag = pd.ExcelFile(industrytag_file)
                industrytag_data = industrytag.parse('GCB_List')
            else:
                raise Exception('Input master datset file does not exist or is not reachable.')    
                  
            srr_rating=pd.DataFrame({'GCB_SRR':[
                                                     1,1.1,1.2,1.5,
                                                     2,2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,
                                                     3,3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,
                                                     4,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,
                                                     5,5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9,
                                                     6,6.1,6.2,6.3,6.4,6.5,6.6,6.7,6.8,6.9,
                                                     7,7.1,7.2,7.3,7.4,7.5,7.6,7.7,7.8,7.9,
                                                     8,8.1,8.2,8.3,8.4,8.5,8.6,8.7,8.8,8.9,
                                                     9,9.1,9.2,9.3
                                                    ],
                                             'NonFin_Rating':[
                                                 9,9,9,
                                                 8,8,8,8,8,8,8,8,8,8,8,
                                                 7,7,7,7,
                                                 6,6,6,6,6,
                                                 5,5,5,5,5,5,5,5,5,5,5,5,5,
                                                 4,4,4,4,4,4,4,	4,4,
                                                 3,3,3,3,3,3,3,3,3,
                                                 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                                                 1,1,1,1,1,1
                                                   ],
                                             'Fin_Rating':[
                                                 9,9,9,
                                                 8,
                                                 7,7,7,7,7,
                                                 6,6,6,6,6,
                                                 5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
                                                 4,4,4,4,4,4,4,4,4,4,
                                                 3,3,3,3,3,3,3,3,3,3,
                                                 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                                                 1,1,1,1,1,1,1,1,1
                                             ]})
                              
            # get industry segment for each facility                                                
            # Creat New column for origination in order to merge with the file provided                        
                    
            data_segment=pd.merge(
                        left=dataset,right=industrytag_data,
                        how='left',left_on='UNIQUE_FACILITY_ID',right_on='Unique_Facility_ID')
    
            # Check origination get the same industry and srr                           
            untaged_industry_positive_exposure=(
                        data_segment[pd.isnull(data_segment['industry'])&(data_segment['EXPOSURE']>0)])
            if len(untaged_industry_positive_exposure)!=0:
              raise ValueError('There is untaged industry besides 0 exposure loans')
              
            # get RatingGroup from SRR  
            data_segment['SRR']=data_segment['SRR'].round(1)

            data_rating=pd.merge(left=data_segment,right=srr_rating,how='left',on='GCB_SRR')
    
            untaged_f_rating_positive_exposure=(
                        data_rating[pd.isnull(data_rating['Fin_Rating'])&(data_rating['EXPOSURE']>0)])
            if len(untaged_f_rating_positive_exposure)!=0:
              raise ValueError('There is untaged financial rating besides 0 exposure loans')                       
            untaged_nf_rating_positive_exposure=(
                        data_rating[pd.isnull(data_rating['NonFin_Rating'])&(data_rating['EXPOSURE']>0)])                    
            if len(untaged_nf_rating_positive_exposure)!=0:
              raise ValueError('There is untaged non-financial rating besides 0 exposure loans')               
            
            # get rating for each facility        
            data_rating['RatingGroup']=data_rating['Fin_Rating'].where(
                                          (
                                        (
                               data_rating['industry']== ['Finance_USCAN','Finance_RoW'][0]
                                        )|(
                               data_rating['industry']==['Finance_USCAN','Finance_RoW'][1])
                                          ),
                          other=data_rating['NonFin_Rating']
                                                    )  
            return(data_rating) 
        
        
        if portfolio == 'CRE':
            data=processCREData(dataset)
            print('>>> Format {} portfolio : {}'.format(portfolio,as_of_date))    
        elif portfolio == 'GCB':    
            data=processGCBData(dataset,industrytag_file)
            print('>>> Tag {} portfolio : {}'.format(portfolio,as_of_date))    
        else:
            raise ValueError('Can handle portfolio other than GCB or CRE')  
        return(data)
                                            
        # get 'Multifamily_Status', 'Property', 'Property_Type', 'division', 'm2mat'
    def getVariable(self,portfolio,dataset,as_of_date): 
        # Map dataset with different variable bins
        print('>>> Map {} portfolio : {}'.format(portfolio,as_of_date))    
        # mapping function
        list_of_mappings=[   
                            {
                                'IN_VAR':'Ltv_Non_Multifamily',
                                'OUT_VAR':'WOE_LTV_Non_Multifamily',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0.388257496,
                                              0.43967162769487,
                                              0.7884597706,
                                              0.8376397627,
                                              0.8937550834,
                                              0.9571615309,
                                              1.0354949941,
                                              1.1625173411
                                             ),
                                'MAPPED_VALUES': ('(~,0.39]',
                                                  '(0.39,0.45]',
                                                  '(0.45,0.79]',
                                                  '(0.79,0.84]',
                                                  '(0.84,0.89]',
                                                  '(0.89,0.96]',
                                                  '(0.96,1.04]',
                                                  '(1.04,1.16]',
                                                  '(1.16,~)'
                                                 ),
                                'MISSING': 'Missing'
                            },
                            {
                                'IN_VAR':'OCCUPANCY',
                                'OUT_VAR':'OCCUPANCY_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0.65,
                                              0.85,
                                              0.95
                                             ),
                                'MAPPED_VALUES': ('<= 65%',
                                                  '65%-85%',
                                                  '85%-95%',
                                                  '> 95%'
                                                 ),
                                'MISSING': 'Missing'
                            },        
                            {
                                'IN_VAR':'LTV',
                                'OUT_VAR':'LTV_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0.5,
                                              0.65,
                                              0.806,
                                              1
                                             ),
                                'MAPPED_VALUES': ('<= 50%',
                                                  '50%-65%',
                                                  '65%-80%',
                                                  '80%-100%',
                                                  '> 100%'
                                                 ),
                                'MISSING': 'Missing'
                            },                               
                            {
                                    
                                'IN_VAR':'Months to Maturity',
                                'OUT_VAR':'Months to Maturity_Bins',
                                'TYPE': 'interval_left',
                                'IN_VALUES': (0,
                                              12,
                                              24,
                                              36
                                             ),
                                'MAPPED_VALUES': ('<= 0',
                                                  '0-12',
                                                  '12-24',
                                                  '24-36',
                                                  '>36'
                                                 ),
                                'MISSING': 'Missing'
                            }                      
                    ] 
        
        def getMaturity(maturitydate,as_of_date):
            maxmaturity=maturitydate
            # get month end date for maximum maturity date
            if pd.isnull(maxmaturity) or maxmaturity=='.':
                monthend_maxmaturity=maturitydate
            else:            
                if maxmaturity.month == 12:
                    monthend_maxmaturity=maxmaturity.replace(year=maxmaturity.year+1,month=1, day=1)-datetime.timedelta(days=1)
                else:
                    monthend_maxmaturity=maxmaturity.replace(month=maxmaturity.month+1, day=1)-datetime.timedelta(days=1)
        
            if (
                 pd.isnull(maturitydate)
               ) or (
                       maturitydate == '.' 
                     ) or (
                             maturitydate == '01/01/9999'):
                return(np.nan)
            else:
                m2mat=relativedelta.relativedelta(monthend_maxmaturity,as_of_date)                
                    
                return(m2mat.years*12+m2mat.months)   
               
        def processMappings(list_of_mappings):
            """ This function associates some mappings 
        
            Args:
                list_of_mapping: a mapping list, which will be the keys of the mapping dictionaries
            Return:
                mapping_dict: a mapping dictionary, key-> 'IN_VAR' of the mapping, value->mapping object corresponding
                                 to the key
            """
            mapping_dict = {}
            for mapping in list_of_mappings:
                mapping_dict[mapping['IN_VAR']] = Mapping(
                    in_map=mapping
                )
            return mapping_dict
        
        if portfolio == 'CRE':
            mappings=processMappings(list_of_mappings=list_of_mappings)
            # Get month to maturity    
            dataset['M2MAT']=dataset['MAXIMUMMATURITYDATE'].apply(lambda x: getMaturity(x,as_of_date))    
            # get ltv,debtyield     
            dataset['LTV']=dataset['BOOKBALANCE']/dataset['PRI_COLLATVALUE']
            dataset['debtyield']=dataset['PRI_COLLATNOI']/dataset['BOOKBALANCE']     
            dataset['LTV_Bins']=dataset['LTV'].apply(lambda x: mappings['LTV'].apply(to_map=x))
            dataset['OCCUPANCY_Bins']=dataset['CURRENTOCCUPANCY'].apply(lambda x: mappings['OCCUPANCY'].apply(to_map=x))  
            dataset['Months to Maturity_Bins']=dataset['M2MAT'].apply(lambda x: mappings['Months to Maturity'].apply(to_map=x)) 
        if portfolio == 'GCB':        
            dataset['Exposure_Weight']=dataset['EXPOSURE']/dataset['EXPOSURE'].sum() 
        # get weight
        dataset['Balance_Weight']=dataset['BOOKBALANCE']/dataset['BOOKBALANCE'].sum()
        dataset['Facility_Weight']=1/len(dataset['UNIQUE_FACILITY_ID'])       
        return(dataset)        
    
    def getGraph(self,portfolio,variablename,dataset1,dataset2,asofdate1,asofdate2,name1,name2,variable,weight_switch):
        print('>>> Plot {} : {} '.format(portfolio,variablename))                                
    #    plt.style.use('ggplot')
    #    data1=dataset1.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})
    #    data2=dataset2.groupby(variable+'_Bins').agg({'Balance_Weight':np.sum})      
    
        # Set Weight measure
        if weight_switch == 'Exposure': 
            data1=dataset1.groupby(variable)['Exposure_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Exposure_Weight'].sum().to_frame()  
        elif weight_switch == 'Balance': 
            data1=dataset1.groupby(variable)['Balance_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Balance_Weight'].sum().to_frame()
        elif weight_switch == 'Facility': 
            data1=dataset1.groupby(variable)['Facility_Weight'].sum().to_frame()
            data2=dataset2.groupby(variable)['Facility_Weight'].sum().to_frame()
        else:
            raise ValueError("Input weight switch should be <Exposure>,<Balance> or <facility>.")        
        
        # rename
        data1.columns=[name1]
        data2.columns=[name2]
        
        # merge
        data=pd.merge(data1,data2,how='outer',left_index=True,right_index=True)
        
        # check whether two datasets have equal length               
                  
        if (portfolio=='GCB') & (variable=='RatingGroup'): 
            for item in [i for i in range(1,9) if i not in data.index]:
                data.loc[item]=0  
            #drop default rating
            data.drop([9],inplace=True)  
            
        position={
                   'LTV_Bins':
                        {
                          '> 100%':0, 
                          '80%-100%':1,
                          '65%-80%':2,
                          '50%-65%':3,
                          'Missing':4,
                          '<= 50%':5           
                         } ,    
                   'OCCUPANCY_Bins':
                        {
                          '<= 65%':0,
                          '65%-85%':1,
                          '85%-95%':2,
                          'Missing':3,
                          '> 95%':4             
      
                         }, 
                   'Months to Maturity_Bins':
                        {
                          '<= 0':0,
                          'Missing':1,
                          '0-12':2,
                          '12-24':3,
                          '24-36':4,
                          '>36':5 
    
                         },
                   'industry':
                        {
                          'ConsumerAndIndustrial_USCAN':0,
                          'ConsumerAndIndustrial_RoW':1,
                          'OilAndGas_Global':2,
                          'Finance_RoW':3,
                          'Finance_USCAN':4
                         },
                   'RatingGroup':
                        {
                          1:0,
                          2:1,
                          3:2,
                          4:3,
                          5:4,
                          6:5,
                          7:6,
                          8:7,
                          9:8
                     
                         }                               
                  }
        # get graph position
        data_position=pd.DataFrame.from_dict(position[variable],orient='index')  
        data_position.columns=['position']     
        data=pd.merge(data_position,data,left_index=True,right_index=True,how='left')
        data.fillna(0,inplace=True)
        data.sort_values('position',inplace=True)
        
        fig, ax = plt.subplots()
        plt.gca().yaxis.grid(color='gray', linestyle='dashed',zorder=0)
        ax.patch.set_facecolor('white')
        index = np.array(data.position)
        bar_width = 0.38
        opacity = 0.95
        rects1 = plt.bar(index, data[name1], bar_width,
                         alpha=opacity,
                         color='#000080',
                         label=name1,zorder=5)
        
        rects2 = plt.bar(index+bar_width, data[name2], bar_width,
                         alpha=opacity,
                         color='#6495ed',
                         label=name2,zorder=5)
        
    #    plt.xlabel(variable[0]+(variable[1:].lower()))
        plt.ylabel('{} Weighted % of Portfolio'.format(weight_switch),fontsize=8)
        plt.ylim(0,max(max(data[name1]),max(data[name2]))*1.2)
        
        if (portfolio=='GCB') & (variable=='RatingGroup'): 
            plt.title('Distribution of %s portfolio across %s bins*' % (portfolio,variablename),fontsize=10)
        else:
            plt.title('Distribution of %s portfolio across %s bins' % (portfolio,variablename),fontsize=10)
            
        if (portfolio=='GCB')&(variable=='industry'):
            data.index=[
                      'Consumer&Industrial:USCAN',
                      'Consumer&Industrial:Rest of World',
                      'Oil&Gas:Global',
                      'Finance:RoW',
                      'Finance:USCAN'                  
                      ]        
    
        plt.xticks(index + 0.5*bar_width, data.index,fontsize=5,rotation=10)
        plt.legend()
             
        def autolabel(data,rects):
            # Now make some labels
            labels = ['{:3.1f}%'.format(i*100)  for i in data.values]
        
            for rect, label in zip(rects, labels):
                height = rect.get_height()
                ax.text(rect.get_x() + rect.get_width()/2, 1*height, label, ha='center', va='bottom',fontsize=rect.get_width()*12)
                
        autolabel(data[name1],rects1)
        autolabel(data[name2],rects2) 
        ax.set_yticklabels(['{:3.0f}%'.format(x*100) for x in ax.get_yticks()])
        # Shrink current axis's height by 10% on the bottom
        box = ax.get_position()
        ax.set_position([box.x0, box.y0 + box.height * 0.1,
                         box.width, box.height * 0.9])
        # Put a legend below current axis
        ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15),
          fancybox=True, shadow=False, ncol=5,fontsize=8)
        
    #    plt.tight_layout()
        plt.savefig("{}/{}_{}_{}_{}.png" .format(self.path,portfolio,variablename,name1,name2),dpi=300)    
        plt.show()  

    def executeGraph(self):   
        # Execution function
        
        # Fetch and format data
        dataset1=self.processData(self.industrytag_file1,self.portfolio,self.asofdate1)
        dataset2=self.processData(self.industrytag_file2,self.portfolio,self.asofdate2)   


        # Get variable bins
        dataset1 = self.getVariable(self.portfolio,dataset1,self.asofdate1)
        dataset2 = self.getVariable(self.portfolio,dataset2,self.asofdate2)
        # define risk drivers in each portfolio
        variable_dictionary={'GCB':{
                                    0: {
                                        'variablename':'Industry',
                                        'variable':'industry',
                                        'weight_switch':'Exposure'
                                        },
                                    1: {
                                        'variablename':'Rating Group',
                                        'variable':'RatingGroup',
                                        'weight_switch':'Exposure'
                                        }
                                    },
                                    
                              'CRE':{   
                                    0: {
                                        'variablename':'LTV',
                                        'variable':'LTV_Bins',
                                        'weight_switch':'Balance'
                                        },
                                    1: {
                                        'variablename':'Occupancy',
                                        'variable':'OCCUPANCY_Bins',
                                        'weight_switch':'Balance'
                                        },      
                                    2: {
                                        'variablename':'Months to Maturity',
                                        'variable':'Months to Maturity_Bins',
                                        'weight_switch':'Balance'
                                        }   
                                    }
                             } 
                                
        # start plotting
        for item in variable_dictionary[self.portfolio]:                        
            self.getGraph(
                     portfolio=self.portfolio,
                     variablename=variable_dictionary[self.portfolio][item]['variablename'],
                     dataset1=dataset1,
                     dataset2=dataset2,
                     asofdate1=self.asofdate1,
                     asofdate2=self.asofdate2,
                     name1=self.name1,
                     name2=self.name2,
                     variable=variable_dictionary[self.portfolio][item]['variable'],
                     weight_switch=variable_dictionary[self.portfolio][item]['weight_switch']
                     )
