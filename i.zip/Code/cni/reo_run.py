from CIFI.controllers.models.postbw_reo import ReoModel
import datetime

############ CCAR 2017 RUN ############
AS_OF_DATE = datetime.datetime(2016,12,31)
FORECAST_PERIODS = 9  #quarterly
CURRENT_REO = 7334625.00
SCENARIO = "FRB_SA"
STRESS_TESTING_CYCLE = "CCAR2017"
ROLL_FILE_PATH = 'I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Data\\SBNA_CCAR_FRB_SA_ROLL_20170308.xlsx'
RESULT_PATH = 'I:\\CRMPO\\CCAR\\4Q16\\4 - Models\\Wholesale\\REO\\Result\\test'

############ Mid Cycle 2017 RUN 1 ############
AS_OF_DATE = datetime.datetime(2017,6,30)
FORECAST_PERIODS = 14  #quarterly
CURRENT_REO = 4969125.00
SCENARIO = "ADVERSE"
STRESS_TESTING_CYCLE = "MidCycle2017"
ROLL_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\4 - Models\\Wholesale\\REO\\Data\\Run 1B\\SBNA_MidCycle2017_ADVERSE_ROLL_20170808.xlsx'
RESULT_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\4 - Models\\Wholesale\\REO\\Result\\MidCycle_run1'

############ Mid Cycle 2017 RUN 2 ############
AS_OF_DATE = datetime.datetime(2017,6,30)
FORECAST_PERIODS = 14  #quarterly
CURRENT_REO = 4969125.00
SCENARIO = "BASE"
STRESS_TESTING_CYCLE = "MidCycle2017"
ROLL_FILE_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\4 - Models\\Wholesale\\REO\\Data\\Run2\\SBNA_MidCycle2017_BASE_ROLL_20170831.xlsx'
RESULT_PATH = 'I:\\CRMPO\\CCAR\\2Q17\\4 - Models\\Wholesale\\REO\\Result'

############ ICAAP2018 RUN (Sep 2017) ############
AS_OF_DATE = datetime.datetime(2017,9,30)
FORECAST_PERIODS = 13  #quarterly
CURRENT_REO = 7725375.00
SCENARIO = "GLOBAL_STRESS"
STRESS_TESTING_CYCLE = "ICAAP2018"
ROLL_FILE_PATH = 'I:\\CRMPO\\CCAR\\3Q17\\4 - Models\\Wholesale\\REO\\Data\\SBNA_ICAAP2018_GLOBALSTRESS_ROLL_20171127.xlsx'
RESULT_PATH = 'I:\\CRMPO\\CCAR\\3Q17\\4 - Models\\Wholesale\\REO\\Result'

reo = ReoModel(
            current_reo = CURRENT_REO,
            percent_npl_to_reo = 0.0891472868217054,
            time_in_reo = 5,
            ltv = 1.43,
            reo_expenses = 0.30,
            lag_into_reo = 7,
            as_of_date = AS_OF_DATE,
            forecast_periods = FORECAST_PERIODS, 
            context=STRESS_TESTING_CYCLE,                                                                                                                                
            scenario=SCENARIO,
            file_path=ROLL_FILE_PATH,
            result_path=RESULT_PATH,
            use_rfo=True,
            forecast_periods_frequency='monthly'
        )
        
reo_result = reo.reoResult()                                                                                                                                                                                                                                                                                                                                                           

monthly_balance=reo.reoMonthlyBalance()
monthly_expense=getREO.reoMonthlyExpense()
monthly_collateral_loss=reo.reoMonthlyCollateralLoss()

