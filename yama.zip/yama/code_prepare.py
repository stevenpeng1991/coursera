import pandas as pd
import numpy as np

# Count the occurrences of each word in a given sentence
def word_count(str):
    counts = dict()
    words = str.split()

    for word in words:
        if word in counts:
            counts[word] += 1
        else:
            counts[word] = 1

    return counts

print( word_count('the quick brown fox jumps over the lazy dog.'))


test_string = 'there is some water in the bottle near a big rosk a bird is very thirsty'
def count_word(string):
    word_list = string.split() 
    count = dict()
    for word in word_list:
        if word in count:
            count[word] += 1
        else:
            count[word] = 1
    return(count)
    
count_word(test_string)

count.keys()
sorted(count.values())


Using List:
# initialize list of lists
data = [['p', 1], ['q', 2], ['r', 3]]

# Create the pandas DataFrame

df = pd.DataFrame(data, columns = ['Letter', 'Number'])

# print dataframe.

df

Using dict of narray/lists:
To create DataFrame from dict of narray/list, all the narray must be of same length. If index is passed then the length index should be equal to the length of arrays. If no index is passed, then by default, index will be range(n) where n is the array length.

Using arrays:
# DataFrame using arrays.

import pandas as pd

# initialise data of lists.

data = {‘Name’:[‘Tom’, ‘Jack’, ‘nick’, ‘juli’], ‘marks’:[99, 98, 95, 90]}

# Creates pandas DataFrame.

df = pd.DataFrame(data, index =[‘rank1’, ‘rank2’, ‘rank3’, ‘rank4’])

# print the data

df